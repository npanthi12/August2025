

linprd <- function(dat=fintrain, model=c("COX", "RSF", "CRSF"), rsf_best=rsf_best,
                   crsf_best=crsf_best, seedini){
  modl <- match.arg(model)
if(modl=="COX"){
cox_model <- coxph(Surv(time, status) ~ ., data = dat)
dat$linp <- predict(cox_model, type = "lp")
dat1 <- dat%>%mutate(quart = paste("Q", ntile(linp, 4), sep=""),
                        quart=factor(quart))
rsc <- dat1$linp
coxkm <- survfit(Surv(time, status)~quart, data=dat1, conf.type="plain")
plt <- ggsurvplot(coxkm, risk.table=TRUE, title="KM-plot by quartile of linear predictor (Cox)", caption="")
}

if(modl=="RSF"){
argsrsf <- list(form=Surv(time, status)~., 
                dat=dat, 
                ntree=rsf_best$ntree, mtry=rsf_best$mtry, 
                nodesize=rsf_best$nodesize, seedini=seedini, importance=FALSE)
rsf_model <- do.call(predmodrsf, argsrsf)

# Extract the cumulative hazard function
chf <- rsf_model$chf
dat$cumhrd <- chf[,length(rsf_model$time.interest)]
dat1 <- dat%>%mutate(quart = ntile(cumhrd, 4))
rsc <- dat1$cumhrd
rsfkm <- survfit(Surv(time, status)~quart, data=dat1, conf.type="plain")
plt <- ggsurvplot(rsfkm, risk.table=TRUE, title="KM-plot by quartile of cumulative hazard function (RSF)", caption="")
}
if(modl=="CRSF"){
argscrsf <- list(form=Surv(time, status)~., 
                 dat=dat, 
                 ntree=crsf_best$ntree, mtry=crsf_best$mtry, 
                 mincriterion=crsf_best$mincriterion, minbucket = crsf_best$minbucket, seedini=seedini)
cf_model <- do.call(predmodcrsfd, argscrsf)
surv_preds <- predict(cf_model, type="prob")
event_times <- unique(dat$time[dat$status==1])
max_event_time <- max(event_times)
cumhd <- c()
for(i in 1:nrow(dat)){
  surv_curv1 <- surv_preds[[i]]
  times <- surv_curv1$time
  cumhd <- c(cumhd, surv_curv1$cumhaz[max(which(times<=max_event_time))])
}

dat$cumhrd <- cumhd
dat1 <- dat%>%mutate(quart = ntile(cumhrd, 4))
rsc <- dat1$cumhrd
crsfkm <- survfit(Surv(time, status)~quart, data=dat1, conf.type="plain")
plt <- ggsurvplot(crsfkm, risk.table=TRUE, title="KM-plot by quartile of cumulative hazard function (CRSF)", caption="")
}
return(list(plt, rsc))
}