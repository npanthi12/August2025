source("Z:/Private/npanthi/April analysis/pred_plt_km.R")
#Import data
#Train data
indat <- read_sas("Z:/Private/npanthi/February analysis/analysis_refresh_02142025/adefpr_6236_02032025.sas7bdat")
fin1 <- setDT(indat)
indat<- lazy_dt(indat)
#Data processing
dat <-fin1[CHDXCLAS =="LUNG" & SAFFL == "Y" & NXEGFR=="",][, BLNLR:=as.numeric(round(BLNLR,2)),
][C1D1DS%in%c(120, 160, 200, 220, 300),
][FOLLOWUP_W>=20,][,`:=`(LNPTMCAT=factor(LNPTMCAT, levels=c("0/1", "2", ">=3"), ordered=T),
                         LNPTCAT = factor(LNPTCAT, levels=c("0/1", "2", ">=3"), ordered=T))
][, RAS_PERCENTAGE_PRE:=as.numeric(RAS_PERCENTAGE_PRE),
][, RAS_PERCENTAGE_CHANGE:=as.numeric(RAS_PERCENTAGE_CHANGE),][RAS_COMPLETE_CLEARANCE!="NA",
][!is.na(RAS_PERCENTAGE_PRE),]


dat <- as.data.frame(dat)

datuse <- dat
#Test data
indattes <- read_sas("Z:/Private/npanthi/April analysis/adefpr_6291_001_04072025.sas7bdat")
fin1 <- setDT(indattes)
indattes<- lazy_dt(indattes)
#Data processing
dat <-fin1[CHHISTO== "Non-Small Cell Lung Cancer (NSCLC)" & SAF14WFL == "Y" & C1D1DOSE=="200mg BID" & PRG12CFL!="Y",
           ][, LNPTCAT:=LNPTMCAT][,`:=`(LNPTCAT = factor(LNPTCAT, levels=c("0/1", "2", ">=3"), ordered=T))]
dat <- as.data.frame(dat)
datusetes <- dat
# Baseline+Activity markers+ctDNA
# Covariates considered
#Set 1
#Test data: set 1
covs <- c("CBR", "ORR")
fintrain <- dat_process(dat=datuse, covs=covs, resp=c("PFSAVAL", "PFSCNSR"), step=2)
#######################################################
#Data Processing
fintest <- dat_process(dat=datusetes, covs=covs, resp=c("PFSAVAL", "PFSCNSR"), step=2)
############################################################
#Plot
args <- list(train_dat=fintrain, test_dat=fintest,covs=covs, best_lamb =1e-04,
             seedini=1234)
do.call(pred_plt, args)


###Set 2
covs <- c("CBR", "ORR", "DCRU", "BESTTLLPCHG", "BESTNLRPCHG", "LNPTCAT", "TLLUNGFL")
fintrain <- dat_process(dat=datuse, covs=covs, resp=c("PFSAVAL", "PFSCNSR"), step=2)
#######################################################
#Data Processing
fintest <- dat_process(dat=datusetes, covs=covs, resp=c("PFSAVAL", "PFSCNSR"), step=2)
############################################################
#Plot
args <- list(train_dat=fintrain, test_dat=fintest,covs=covs, best_lamb =0.0032745,
             seedini=1234)
do.call(pred_plt, args)

##Boot
rd_res <- function(dat, respn, pred, covs, predlevtrt, predlevref){
  
  form <- f.build(respn, c(pred, covs))
  fit1 <- glm(form, data = dat, family=binomial)
  #Predicted values
  
  pred_y_trt <- stats::predict.glm(fit1, newdata=data.frame(dat%>%mutate(COMPOUND=predlevtrt)), type="response")
  esttrt<- mean(pred_y_trt, na.rm=T)
  esttrt
  pred_y_ref <- predict(fit1, newdata=data.frame(dat%>%mutate(COMPOUND=predlevref)), type="response")
  estref<- mean(pred_y_ref, na.rm=T)
  estref
  estdiff <- esttrt - estref
  estdiff
  #95% CI using bootstrapping
  #' Run the boot function. Set a seed to obtain reproducibility
  bootfunc <- function(data,index){
    boot_dat <- data[index,]
    tryCatch({
      fit1 <- glm(form, data = boot_dat, family="binomial")
    },
    error = function(e) {
      message("An Error Occurred")
      
      #print(e)
    },
    warning = function(w) {
      message("A Warning Occurred")
      #print(w)
      
    })
    pred_y_trt <- stats::predict.glm(fit1, newdata=data.frame(boot_dat%>%mutate(COMPOUND=predlevtrt)), type="response")
    pred_y_ref <- predict(fit1, newdata=data.frame(boot_dat%>%mutate(COMPOUND=predlevref)), type="response")
    est_trt <-  mean(pred_y_trt, na.rm=T)
    est_ref <-  mean(pred_y_ref, na.rm=T)
    diff <- est_trt - est_ref
    res <- c(est_trt, est_ref, diff)
    return(res)
  }
  set.seed(1234)
  boot_res <- boot::boot(dat,bootfunc,R=2000)
  boot_RD_trt <- boot.ci(boot_res,index=1)
  boot_RD_ref <- boot.ci(boot_res,index=2)
  boot_RD_diff <- boot.ci(boot_res,index=3)
  ci_trt <- paste(round(as.matrix(boot_RD_trt$bca[4]), 4), ",", 
                  round(as.matrix(boot_RD_trt$bca[5]), 4))
  ci_ref <- paste(round(as.matrix(boot_RD_ref$bca[4]), 4), ",", 
                  round(as.matrix(boot_RD_ref$bca[5]), 4))
  ci_diff <- paste(round(as.matrix(boot_RD_diff$bca[4]), 4), ",", 
                   round(as.matrix(boot_RD_diff$bca[5]), 4))
  res_trt <- paste(round(esttrt, 4), "(", ci_trt, ")")
  res_ref <- paste(round(estref, 4), "(", ci_ref, ")")
  res_diff <- paste(round(estdiff, 4), "(", ci_diff, ")")
  out <- list(res_trt, res_ref, res_diff)
  return(out)
}