library(partykit)
library(survival)
library(dplyr)
data("veteran")
dat <- survival::veteran
dat$status <- as.numeric(dat$status==1)
tree_model <- pecCtree(Surv(time, status)~., data=dat)
class(tree_model)
plot(tree_model)
dat$node <- predict(tree_model, type="node")
head(dat)
calc_cumhazard <- function(df){
  df <- df%>%arrange(time)%>%
    mutate(n_risk=rev(cumsum(rev(rep(1, nrow(df))))),
           d=status,
           hazard=d/n_risk,
           cumhazard=cumsum(hazard))
  return(df[, c("time", "status", "n_risk", "hazard", "cumhazard")])
}
node_list <- split(dat, dat$node)
cumhaz_by_node <- lapply(node_list, calc_cumhazard)
cumhaz_by_node[[1]]
library(ggplot2)
cumhaz_all <- bind_rows(
  lapply(names(cumhaz_by_node), function(n){
    df <- cumhaz_by_node[[n]]
    df$node <- as.factor(n)
    df
  })
)
ggplot(cumhaz_all, aes(x=time, y=cumhazard, color=node))+
  geom_step()+theme_minimal()

predictSurvProb(object=tree_model, newdata=dat, times=6)
set.seed(2)
train_idx <- sample(1:nrow(dat), 0.7*nrow(dat))
train_data <- dat[train_idx,]
test_data <- dat[-train_idx,]
times <- quantile(train_data$time, probs = seq(0.1, 0.9, by=0.1))

pec_result <- pec(object=list(Tree=tree_model),
                  formula=Surv(time, status)~1,
                  data=test_data,
                  times=times,
                  exact=FALSE,
                  cens.model="marginal",
                  splitMethod="none")
ibs <- crps(pec_result)[2]
plot(pec_result, ylab="Prediction error (Brier-Score)")
pred_tree <- -1*predictSurvProb(tree_model, newdata=train_data, times=c(1,200))[, 2]
pred_tree1 <- -1*predictSurvProb(tree_model, newdata=test_data, times=c(1,200))[, 2]
library(survAUC)
AUC_tree <- AUC.cd(Surv.rsp=Surv(train_data$time, train_data$status),
                   Surv.rsp.new = Surv(test_data$time, test_data$status),
                   lp=pred_tree,
                   lpnew=pred_tree1,
                   times=200)
cox_model <- coxph(Surv(time, status)~., data=train_data, x=TRUE, y=TRUE)
#10-fold cross-validation
cv_pec <- pec(object=list(Tree=tree_model, Cox=cox_model),
              formula = Surv(time, status)~1,
              data=dat,
              times=times,
              cens.model="marginal",
              splitMethod = "cv10",
              B=100)
plot(cv_pec, ylab="Prediction Error (Brier score)")
crps(cv_pec)
boot_pec <- pec(object=list(Tree=tree_model, Cox=cox_model),
                formula=Surv(time, status)~1,
                data=dat,
                times=times,
                cens.model="marginal",
                splitMethod = "boot632",
                B=100)
plot(boot_pec)
crps(boot_pec)
tree_model <- party::ctree(Surv(time, status)~., data=dat%>%dplyr::select(everything(), -node),
                              controls = party::ctree_control(mincriterion = 0, minbucket=30, minsplit=25,
                                                      maxdepth=3))
plot(tree_model)
tree_model <- pecCtree(Surv(time, status)~., data=dat%>%dplyr::select(everything(), -node),
                           controls = party::ctree_control(mincriterion = 0, minbucket=30, minsplit=25,
                                                           maxdepth=3))
plot(tree_model)

fit_ <- partykit::cforest(Surv(time, status)~., data=dat%>%dplyr::select(everything(), -node), 
                          ntree=2, mtry=7, 
                          perturb = list(replace = FALSE, 
                                        fraction = 1),
                          control = ctree_control())
# Extract the first tree from the forest
single_tree <- gettree(fit_, 1)

plot(single_tree)
##party
tree_model <- party::ctree(Surv(time, status)~., data=dat%>%dplyr::select(everything(), -node),
                              controls = party::ctree_control())
class(tree_model)
party::varimp(tree_model)
plot(tree_model)
fit_ <- party::cforest(Surv(time, status)~., data=dat%>%dplyr::select(everything(), -node), 
                          controls = party::cforest_control(teststat = "quad", testtype = "Univ", mincriterion = 0, 
                                                            replace = FALSE, fraction = 0.99, 
                                                            ntree=1, mtry=6))
party::varimp(fit_)
library("party")
cf <- fit_
pt <- party:::prettytree(cf@ensemble[[1]], names(cf@data@get("input")))
pt
nt <- new("BinaryTree")
nt@tree <- pt
nt@data <- cf@data
nt@responses <- cf@responses
nt
plot(nt)
##
fit_ <- partykit::cforest(Surv(time, status)~., data=dat)
partykit::varimp(fit_)
party::varimp(tree_model, conditional=TRUE)
split_vars <- unique(sapply(nodeids(tree_model, terminal=F), function(id){
  splitinfo <- partykit::split_node(partynode(tree_model)[[1]])
  if(!is.null(splitinfo))names(splitinfo$varid) else NA
}))
