
grd <- function(model="RSF", params){
  if(model=="RSF"){
    prm <- expand.grid(
      ntree = params$ntree,  # Number of trees
      mtry = params$mtry,          # Number of features to split at each node
      nodesize = params$nodesize      # Minimum size of terminal nodes
    )
  
  }else if(model=="CRSF"){
    prm <- expand.grid(
      ntree = params$ntree,  # Number of trees
      mtry = params$mtry,          # Number of features to split at each node
      mincriterion = params$mincriterion,
      minbucket = params$minbucket
    )
 
  }else if(model=="LASSO"){
    prm <- expand.grid(
      lambda =  params$lambda,
      alpha = params$alpha
    )
  }else if(model=="CRSFUNB"){
    prm=expand.grid(
      seedini = params$seedini  # Number of trees
      # mtry = params$mtry,          # Number of features to split at each node
      # mincriterion = params$mincriterion,
      # minbucket = params$minbucket
    )
  }else{
    prm=NULL
  }
  return(prm)
}

fld_indx <- function(dat, num_fld=num_outer_fld, seed=seedini+rep, create=TRUE){
  if(create){
  indx <- {set.seed(seed); createFolds(dat$status, k = num_fld)}
  }else{
    indx=NULL
  }
  return(indx)
}
#is.null(fld_indx(dat=fin, num_fld=num_outer_fld, seed=seedini+rep, create=FALSE))
source("Z:/Private/npanthi/April analysis/rsf_func.R")
resfin_map.rsf <- function(dat=dat, num_rept=num_repeats, num_outer_fld = num_outer_folds,
                   num_inner_fld=num_inner_folds, params = NULL, seedini=seedini, model=model, ...){
  prm <- grd(model, params=params)
  res <- map(1:num_rept, function(.z){
    #Outer loop: Split dataset into k folds
    cat("Running repeat", .z, "of", num_repeats, "\n")
    outer_folds_indx <- fld_indx(dat=dat, num_fld=num_outer_fld, seed=seedini+rep, create=TRUE)
    return(resbd_map.rsf(dat=dat, fold_indx=outer_folds_indx, num_outer_fld=num_outer_fld, 
                                                num_inner_fld=num_inner_fld, param=prm, 
                 seedini=seedini, rep=.z, model=model))
    
  })
  return(do.call("rbind", res))
}
# resfin_map.rsf(dat=fin, num_rept=num_repeats, num_outer_fld = num_outer_folds,
#                num_inner_fld=5, params=lasso_params, seedini=1234, model="LASSO")


# Get best c-index across all outer folds
resbd_map.rsf <- function(dat=dat, fold_indx=outer_folds, num_outer_fld=num_outer_folds, 
                  num_inner_fld=num_inner_folds, param = params, seedini=seedini, rep=rep, model=model){
  res <- map(1:num_outer_fld, function(.y){
    cat("Running outer fold", .y, "of", num_outer_fld, "in repeat", rep, "of", num_repeats, "\n")
    outer_train <- dat[-fold_indx[[.y]],]
    outer_test <- dat[fold_indx[[.y]], ]
  #Create Inner fold index from outer train
    if(length(unique(outer_train$status))==1){
      inner_folds <- {set.seed(seedini); createFolds(outer_train$time, k=num_inner_fld)}
    }else{
      inner_folds <- {set.seed(seedini); createFolds(outer_train$status, k=num_inner_fld)}
    }
    if(model=="RSF"|model=="CRSF"|model=="LASSO"){
    # Select best hyperparameters from Inner loop
    best_params <-resb_map.rsf(dat=outer_train, parm=param, num_folds=num_inner_folds, fold=inner_folds, 
                       seedini=seedini, iter_=.y, rep=rep, num_outer_fld=num_outer_fld, model=model)[[2]]
    }else{
      best_params <- ""
    }
   
    #Trai#Trai#Train the best model on outer train set
    best_model <- bes_mod(parm=best_params, da=outer_train, itr=1, seedini=seedini, importance=FALSE, model=model)
    #Evaluate the best model on the outer test set
    final_cindex <-  bes_met(modl=best_model, testdat=outer_test, traindat=outer_train, ibsc=FALSE)[[1]]
    final_ibs <- bes_met(modl=best_model, testdat=outer_test, traindat=outer_train, ibsc=TRUE)[[2]]
    #final_ibs <- SurvMetrics::IBS(best_model, outer_test)[[1]]
    #Store results
   
    return(cbind(data.frame(Repeat=rep, Fold=.y, C_index = final_cindex, ibs = final_ibs, seedini=seedini),
                  best_params))
  })
  return(do.call("rbind", res))
}

#Mean c-index values for all tuning parameters across inner fold and best tuning param
resb_map.rsf <- function(dat=outer_train, parm=param, num_folds=num_inner_folds, fold=inner_folds, 
                 seedini=seedini,iter_=.y, rep=rep, num_outer_fld=num_outer_fld, model=model){
  
  best_cindex <- 0
  best_params <- data.frame()
  res <- map(1:nrow(parm), function(.x){
    cat("Running param_grid", .x, "of", nrow(parm), "in outer fold", iter_, "of", num_outer_fld, "in repeat", rep, "of", num_repeats, "\n")
    #Get k-fold cross-validation c-index for this tuning parameter
  
    param_res <- resd_map.rsf(dat=dat, fold=fold, num_folds=num_folds,
                      parm=parm, seedini=seedini, iter=.x, out_fld=iter_, rep=rep, num_outer_fld=num_outer_fld, model=model)
    #Return mean C-index for this hyperparameter set
    return(param_res[[2]])
  })
  res1 <- do.call("rbind", res)[,1]
  best_cindex <- max(res1, na.rm=T)
  best_params <- parm[which.max(res1),]
  return(list(best_cindex, best_params))
}

#Mean c-index for one tuning parameter across all inner folds
resd_map.rsf <- function( dat=dat, fold=fold, num_folds=num_folds, 
                  parm=parm, seedini=seedini, iter=j, out_fld=iter_, rep=rep, num_outer_fld=num_outer_fld, model=model){

  res <- map(1:num_folds, function(.t){
    modtot <-  num_repeats*num_outer_fld*num_folds*nrow(parm)
    modnum <- .t+num_folds*(iter-1) + nrow(parm)*num_folds*(out_fld-1) + nrow(parm)*num_folds*num_outer_fld*(rep-1)
    cat("Running param_grid", iter, "of", nrow(parm),"in inner fold", .t, "of", num_folds,  "in outer fold", out_fld, "of", num_outer_fld, "in repeat", rep, "of", num_repeats, "Model", modnum, "of", modtot, "\n")
    #Split into inner training and validation sets
    inner_train <- dat[-fold[[.t]],]
    inner_valid <- dat[fold[[.t]],]
 
    #Train RSF model with current hyperparameters
    rsf_model <- bes_mod(parm=parm, da=inner_train, itr=iter, seedini=seedini, importance=FALSE, 
                         model=model)
    #Test model with inner test data
    cindex <- bes_met(modl=rsf_model, testdat=inner_valid, traindat=inner_train, ibsc=FALSE)[[1]]
    return(cindex)
  })
  cindex_values <- do.call("rbind", res)[,1]
  return(list(cindex_values, mean(cindex_values, na.rm=T)))
}

grd_ <- function(model="RSF", params=rfs_params, itr=1){
  if(model=="RSF"){
prm <- expand.grid(
  ntree = params$ntree,  # Number of trees
  mtry = params$mtry,          # Number of features to split at each node
  nodesize = params$nodesize      # Minimum size of terminal nodes
)
args <- list(form=Surv(time, status)~., dat=da,
             ntree = parm$ntree[itr],
             mtry = parm$mtry[itr],
             nodesize = parm$nodesize[itr], seedini=seedini, importance=importance)
class(prm) <- "RSF"
  }else if(model=="CRSF"){
    prm <- expand.grid(
      ntree = params$ntree,  # Number of trees
      mtry = params$mtry,          # Number of features to split at each node
      mincriterion = params$mincriterion,
      minbucket = params$minbucket
    )
    class(prm) <- "CRSF"
  }else if(model=="LASSO"){
    prm <- expand.grid(
      lambda =  params$lambda,
      alpha = params$alpha
    )
    class(prm) <- "LASSO"
  }
  return(prm)
}


bes_mod <- function(parm=best_params,da,itr=iter, seedini=seedini, importance=FALSE, model){
  if(model=="RSF"){
  args <- list(form=Surv(time, status)~., dat=da,
               ntree = parm$ntree[itr],
               mtry = parm$mtry[itr],
               nodesize = parm$nodesize[itr], seedini=seedini, importance=importance)
  best_model <- do.call("predmodrsf", args)
  }else if(model=="CRSF"){
    args <- list(form=Surv(time, status)~., dat=da,
                 ntree = parm$ntree[itr],
                 mtry = parm$mtry[itr],
                 mincriterion = parm$mincriterion[itr],
                 minbucket=parm$minbucket[itr], seedini=seedini)
    best_model <- do.call("predmodcrsf", args)
  }else if(model=="LASSO"){
    args <- list(form=Surv(time, status)~., dat=da,
                 alpha = parm$alpha[itr],
                 lambda = parm$lambda[itr], seedini=seedini)
    best_model <- do.call("predmodlasso", args)
  }else if(model=="CRSFUNB"){
    args <- list(form=Surv(time, status)~., dat=da, seedini=seedini)
    best_model <- do.call("predmodcrsfunb", args)
  }else{
    args <- list(form=Surv(time, status)~., dat=da)
    best_model <- do.call("predmodcox", args)
  }
  return(best_model)
}

bes_met <- function(modl, testdat, traindat, ibsc=FALSE){
  if(class(modl)[1]=="rfsrc"){
  cindex <- SurvMetrics::Cindex(modl, testdat)[[1]]
  if(ibsc=="TRUE"){
  perror <- suppressMessages(pec(object= modl,
                                 formula = Surv(time, status)~., cens.model="marginal",
                                 data=testdat, verbose=F, maxtime=200))
  ibsm <- ibs(perror, times=max(modl$time.interest))[[2]]
  }else{
    ibsm<- NULL
  }
  
  }else if(class(modl)[1]=="pecCforest"){
    modl_ <- rfsrc(Surv(time, status)~., data = traindat)
    distime <- modl_$time.interest  #get the survival time of events
    med_index <- median(1:length(distime)) 
    # Extract C-index (last error rate)
    mat_cforest <- suppressMessages(predictSurvProb(modl, newdata = testdat, times = distime))
    vec_rsf <- mat_cforest[ ,med_index]  #median survival probability of all samples
    cindex <- SurvMetrics::Cindex(Surv(testdat$time, testdat$status), vec_rsf)[[1]]
    if(ibsc=="TRUE"){
      perror <- suppressMessages(pec(object=modl,
                                     formula = Surv(time, status)~., cens.model="marginal",
                                     data=testdat, verbose=F, maxtime=200))
      ibsm <- ibs(perror, times=max(distime))[[2]]
    }else{
      ibsm<- NULL
    }
  }else if(class(modl)[1]=="coxnet"){
    modl_ <- rfsrc(Surv(time, status)~., data = traindat)
    distime <- modl_$time.interest  #get the survival time of events
    med_index <- median(1:length(distime)) 
    cov <- colnames(modl_$xvar)
    x_val <- data.matrix(testdat[, cov])
    y_val <- Surv(testdat$time, testdat$status)
    # Extract C-index (last error rate)
    mat_glmnet<-predictProb.glmnet(object= modl,response=y_val, x=x_val, 
                                   times= distime, complexity=modl$lambda)
    vec_glmnet <- mat_glmnet[ ,med_index]
    cindex <- SurvMetrics::Cindex(Surv(testdat$time, testdat$status), vec_glmnet)[[1]]
    if(ibsc=="TRUE"){
      frm <- as.formula(paste("Surv(time, status)~",
                              paste(cov, collapse="+")))
      perror <- suppressMessages(pec(object=modl,
                                     formula = frm, cens.model="marginal",
                                     data=testdat, verbose=F, maxtime=200))
      
      ibsm <- ibs(perror, times=max(distime))[[2]]
    }else{
      ibsm<- NULL
    }
  }else{
    args <- list(form=Surv(time, status)~., dat=traindat)
    args_tes <- list(form=Surv(time, status)~., dat=testdat)
    modl <- rfsrc(Surv(time, status)~., data = traindat)
    distime <- modl$time.interest  #get the survival time of events
    med_index <- median(1:length(distime)) 
    #
    c_index <- NULL
    model_cox_trnew <- do.call("predmodcox", args)
    model_cox_tenew <- do.call("predmodcox", args_tes)
    datrain <- cbind(model_cox_trnew$y, model_cox_trnew$x)
    datest <- cbind(model_cox_tenew$y, model_cox_tenew$x)
    
    coeff_fixed <- model_cox_trnew$coefficients
    a <- row.names(as.data.frame(coeff_fixed[!is.na(coeff_fixed)]))
    if(sum(colnames(datrain)[-c(1, 2)]!=a)==0){
      cindex= SurvMetrics::Cindex( model_cox_trnew, testdat)[[1]]
      perror <- suppressMessages(pec(object=model_cox_trnew,
                                     formula = Surv(time, status)~., cens.model="marginal",
                                     data=testdat, verbose=F, maxtime=200))
      ibsm <- ibs(perror, times=max(distime))[[2]]
      
    }else{
      form_new <- f.build("Surv(time, status)",a)
      model_coxnew<- coxph(form_new, data=as.data.frame(datrain), ties="breslow", x=TRUE)
      cindex= SurvMetrics::Cindex(model_coxnew, as.data.frame(datest))[[1]]
      perror <- suppressMessages(pec(object=model_coxnew,
                                     formula = Surv(time, status)~., cens.model="marginal",
                                     data= as.data.frame(datest), verbose=F, maxtime=200))
      ibsm <- ibs(perror, times=max(distime))[[2]]
    }
  }
  return(c(cindex, ibsm))
}
