
runpred <- function(dat, covs, n_resamples, train_fraction, n, seedini,
                    rfs_params = list("mtry" = c(2, 3, 5, 7, 9), "ntree"=c(200, 300, 500, 1000, 1500), 
                                      "nodesize" =c(7, 9, 11, 13, 15)),
                    crfs_params = list("mtry" = c(2, 3, 5, 7, 9), "ntree"=c(200, 300, 500, 1000, 1500), 
                                       "mincriterion" =c(0, 0.2, 0.4, 0.6, 0.8), "minbucket" = c(7, 9, 11, 13, 15, 20)),
                    lasso_params = list("lambda" = 10^seq(-4, 1, length=100), "alpha"=0.5), ...) {
  UseMethod("runpred", dat)
}

runpred.step2 <- function(dat, covs=NULL, n_resamples=4, train_fraction, n, seedini=1234,
                          rfs_params = list("mtry" = c(2, 3, 5, 7, 9), "ntree"=c(200, 300, 500, 1000, 1500), 
                                            "nodesize" =c(7, 9, 11, 13, 15)),
                          crfs_params = list("mtry" = c(2, 3, 5, 7, 9), "ntree"=c(200, 300, 500, 1000, 1500), 
                                             "mincriterion" =c(0, 0.2, 0.4, 0.6, 0.8), "minbucket" = c(7, 9, 11, 13, 15, 20)),
                          lasso_params = list("lambda" = 10^seq(-4, 1, length=100), "alpha"=0.5)){
  
  form <- cobalt::f.build("Surv(time, status)", covs)
  set.seed(seedini)
  
  res <- map(1:n_resamples, function(.y){
    cat("\nRunning resample", .y, "...\n")
    train_idx <-  {set.seed(seedini+.y); sample(seq_len(n), size = round(train_fraction*n), replace=FALSE)}
    test_idx <- setdiff(seq_len(n), train_idx)
    train_data <- dat[train_idx,]
    test_data <- dat[test_idx, ]
    best_params_cox_ <- NULL
    best_params_ <- NULL
    best_params_crsf_ <- NULL
    best_params_lasso_ <- NULL
    best_params_crsfunbias_ <- NULL
  tryCatch(
      {
        # Try to execute this block of code
        best_params_cox_ <-  fitmod(train_dat = train_data, test_dat = test_data, n_resamples=n_resamples, params=prm("cox"), form=form, covs=covs,
                                    iter=.y)
        
        best_params_ <- fitmod(train_dat = train_data, test_dat = test_data, params = prm("rsf"), form=form, covs=covs,
                               seedini=seedini, n_resamples=n_resamples,
                               iter=.y)
        
        best_params_crsf_ <- fitmod(train_dat = train_data, test_dat = test_data, params = prm("crsf"), form=form, covs=covs,
                                    seedini=seedini, n_resamples=n_resamples,
                                    iter=.y)
        
        best_params_lasso_ <- fitmod(train_dat = train_data, test_dat = test_data, params = prm("lasso"), form=form, covs=covs,
                                     seedini=seedini, n_resamples=n_resamples,
                                     iter=.y)
        
        best_params_crsfunbias_ <-  fitmod(train_dat = train_data, test_dat = test_data, params = prm("crsfunbias"), form=form, covs=covs,
                                           seedini=seedini, n_resamples=n_resamples,
                                           iter=.y)
        
      },
      error = function(e) {
        # Handle the error here
        message("An error occurred: ", e$message)
        return(NA)  # Return NA or any other default value
      }
    )
    
    return(list(best_params = best_params_, best_params_crsf = best_params_crsf_, 
                best_params_lasso = best_params_lasso_, best_params_cox = best_params_cox_, best_params_crsfunbias = best_params_crsfunbias_))
  })
  res1 <- do.call("rbind", res)
  out <- create_plt(best_params = res1[,1], best_params_crsf = res1[, 2], 
                    best_params_lasso = res1[,3], best_params_cox = res1[,4], best_params_crsfunbias = res1[, 5])
  
  return(out)
  
}

runpred.step2_ <- function(dat, covs=NULL, n_resamples=4, train_fraction, n, seedini=1234,
                          rfs_params = list("mtry" = c(2, 3, 5, 7, 9), "ntree"=c(200, 300, 500, 1000, 1500), 
                                            "nodesize" =c(7, 9, 11, 13, 15)),
                          crfs_params = list("mtry" = c(2, 3, 5, 7, 9), "ntree"=c(200, 300, 500, 1000, 1500), 
                                             "mincriterion" =c(0, 0.2, 0.4, 0.6, 0.8), "minbucket" = c(7, 9, 11, 13, 15, 20)),
                          lasso_params = list("lambda" = 10^seq(-4, 1, length=100), "alpha"=0.5)){
  
  form <- cobalt::f.build("Surv(time, status)", covs)
  set.seed(seedini)

  res <- map(1:n_resamples, function(.y){
    cat("\nRunning resample", .y, "...\n")
    train_idx <-  {set.seed(seedini+.y); sample(seq_len(n), size = round(train_fraction*n), replace=FALSE)}
    test_idx <- setdiff(seq_len(n), train_idx)
    train_data <- dat[train_idx,]
    test_data <- dat[test_idx, ]
    
    best_params_cox_ <-  fitmod(train_dat = train_data, test_dat = test_data, n_resamples=n_resamples, params=prm("cox"), form=form, covs=covs,
                                iter=.y)
    
    best_params_ <- fitmod(train_dat = train_data, test_dat = test_data, params = prm("rsf"), form=form, covs=covs,
                               seedini=seedini, n_resamples=n_resamples,
                               iter=.y)
    
    best_params_crsf_ <- fitmod(train_dat = train_data, test_dat = test_data, params = prm("crsf"), form=form, covs=covs,
                                    seedini=seedini, n_resamples=n_resamples,
                                    iter=.y)
    
    best_params_lasso_ <- fitmod(train_dat = train_data, test_dat = test_data, params = prm("lasso"), form=form, covs=covs,
                                     seedini=seedini, n_resamples=n_resamples,
                                     iter=.y)
    
    best_params_crsfunbias_ <-  fitmod(train_dat = train_data, test_dat = test_data, params = prm("crsfunbias"), form=form, covs=covs,
                                       seedini=seedini, n_resamples=n_resamples,
                                       iter=.y)
    
    return(list(best_params = best_params_, best_params_crsf = best_params_crsf_, 
           best_params_lasso = best_params_lasso_, best_params_cox = best_params_cox_, best_params_crsfunbias = best_params_crsfunbias_))
  })
  res1 <- do.call("rbind", res)
  out <- create_plt(best_params = res1[,1], best_params_crsf = res1[, 2], 
                    best_params_lasso = res1[,3], best_params_cox = res1[,4], best_params_crsfunbias = res1[, 5])
  
  return(out)
  
}


prm <- function(param){
  if(param=="rsf"){
    use_param = rfs_params
    class(use_param) <- "rsf"
  }else if(param=="crsf"){
    use_param = crfs_params
    class(use_param) <- "crsf"
  }else if(param=="lasso"){
    use_param=lasso_params
    class(use_param) <- "lasso"
  }else if(param=="cox"){
    use_param <- ""
    class(use_param) <- "cox"
  }else{
    use_param <- crsfunbias_params
    class(use_param) <- "crsfunbias"
  }
  return(use_param)
}

fitmod <- function(train_dat, test_dat, params, form, covs, seedini, n_resamples, iter, ...) {
  UseMethod("fitmod", params)
}

fitmod.rsf <- function(train_dat, test_dat, params, form, covs, seedini, n_resamples, iter){
  # Define parameter grid
  param_grid_rsf <- expand.grid(
    ntree = params$ntree,  # Number of trees
    mtry = params$mtry,          # Number of features to split at each node
    nodesize = params$nodesize      # Minimum size of terminal nodes
  )
  # Store results
  results <- data.frame(ntree = integer(), mtry = integer(), nodesize = integer(), c_index = numeric(), seed=numeric())

  res <- map(1:nrow(param_grid_rsf), function(.x){
    cat("Running RSF model", .x, "of", nrow(param_grid_rsf), "in resample", iter, "of", n_resamples, "\n")
    sed <- seedini+.x

    model <- rfsrc(form, data = train_dat, 
                   ntree = param_grid_rsf$ntree[.x], 
                   mtry = param_grid_rsf$mtry[.x], 
                   nodesize = param_grid_rsf$nodesize[.x],
                   importance = TRUE, seed=sed)
    # Extract C-index (last error rate)
    c_index <- SurvMetrics::Cindex(model, test_dat)
    
    # Store results
    return(c(param_grid_rsf$ntree[.x], param_grid_rsf$mtry[.x], param_grid_rsf$nodesize[.x], c_index, sed))
  })

  results <- as.data.frame(do.call("rbind", res))
  # Rename columns
  colnames(results) <- c( "ntree", "mtry", "nodesize", "c_index", "seed")
  
  # Print best parameters
  return(results[which.max(results$c_index), ])
}

fitmod.crsf <- function(train_dat = train_data, test_dat = test_data, params = crfs_params, form=form, covs=covs,
                        seedini=seedini, n_resamples=n_resamples,
                        iter=j){
  ##########
  param_grid_crsf <- expand.grid(
    ntree = params$ntree,  # Number of trees
    mtry = params$mtry,          # Number of features to split at each node
    mincriterion = params$mincriterion,
    minbucket = params$minbucket
  )
  model <- rfsrc(form, data = train_dat)
  distime <- model$time.interest  #get the survival time of events
  med_index <- median(1:length(distime)) 
  # Store crsf results
  results_crsf <- data.frame(ntree = integer(), mtry = integer(), mincriterion = integer(), minbucket = integer(), c_index = numeric(), seed=numeric())
  
  res <- map(1:nrow(param_grid_crsf), function(.x){
    cat("Running cRSF model", .x, "of", nrow(param_grid_crsf), "in resample", iter, "of", n_resamples, "\n")
    sed <- seedini+.x
    model_crsf <- {set.seed(sed); pecCforest(form, data = train_dat,  
                   controls = cforest_control(ntree = param_grid_crsf$ntree[.x], 
                    mtry=param_grid_crsf$mtry[.x], mincriterion=param_grid_crsf$mincriterion[.x],
                    minbucket = param_grid_crsf$minbucket[.x]))}
    
    # Extract C-index (last error rate)
    mat_cforest <- suppressMessages(predictSurvProb(model_crsf, newdata = test_dat, times = distime))
    vec_rsf <- mat_cforest[ ,med_index]  #median survival probability of all samples
    times <- test_dat$time
    status <- test_dat$status
    cindex_crsf <- SurvMetrics::Cindex(Surv(times, status), vec_rsf)
    #cindex_crsf
    
    # Store results
    return(c(param_grid_crsf$ntree[.x], param_grid_crsf$mtry[.x], param_grid_crsf$mincriterion[.x], param_grid_crsf$minbucket[.x], cindex_crsf, sed))
  })
  
  results_crsf <- as.data.frame(do.call("rbind", res))
  
  # Rename columns
  colnames(results_crsf) <- c( "ntree", "mtry", "mincriterion", "minbucket", "c_index", "seed")
  
  # Print best parameters
  return(results_crsf[which.max(results_crsf$c_index), ])
}

fitmod.crsfunbias <- function(train_dat = train_data, test_dat = test_data, params = crfs_params, form=form, covs=covs,
                        seedini=seedini, n_resamples=n_resamples,
                        iter=j){
  cat("Running cRSF(unbiased) model ", "1 ", "in resample", iter, "of", n_resamples, "\n")
  ##########
  # param_grid_crsf <- expand.grid(
  #   ntree = params$ntree,  # Number of trees
  #   mtry = params$mtry,          # Number of features to split at each node
  #   mincriterion = params$mincriterion,
  #   minbucket = params$minbucket
  # )
  model <- rfsrc(form, data = train_dat)
  distime <- model$time.interest  #get the survival time of events
  med_index <- median(1:length(distime)) 
  
  model_crsf <- {set.seed(seedini); pecCforest(form, data = train_dat,  controls = cforest_unbiased())}
  mat_cforest <- suppressMessages(predictSurvProb(model_crsf, newdata = test_dat, times = distime))
  vec_rsf <- mat_cforest[ ,med_index]  #median survival probability of all samples
  times <- test_dat$time
  status <- test_dat$status
  cindex_crsf <- SurvMetrics::Cindex(Surv(times, status), vec_rsf)
  return(data.frame(c_index=cindex_crsf))
  # Store crsf results
  #results_crsf <- data.frame(ntree = integer(), mtry = integer(), mincriterion = integer(), minbucket = integer(), c_index = numeric(), seed=numeric())
  
  # res <- map(1:nrow(param_grid_crsf), function(.x){
  #   cat("Running cRSF model", .x, "of", nrow(param_grid_crsf), "in resample", iter, "of", n_resamples, "\n")
  #   sed <- seedini+.x
  #   model_crsf <- {set.seed(sed); pecCforest(form, data = train_dat,  controls = cforest_control(ntree = param_grid_crsf$ntree[.x], mtry=param_grid_crsf$mtry[.x], mincriterion=param_grid_crsf$mincriterion[.x],
  #                                                                                                minbucket = param_grid_crsf$minbucket[.x]))}
  #   
  #   # Extract C-index (last error rate)
  #   mat_cforest <- suppressMessages(predictSurvProb(model_crsf, newdata = test_dat, times = distime))
  #   vec_rsf <- mat_cforest[ ,med_index]  #median survival probability of all samples
  #   times <- test_dat$time
  #   status <- test_dat$status
  #   cindex_crsf <- SurvMetrics::Cindex(Surv(times, status), vec_rsf)
  #   #cindex_crsf
  #   
  #   # Store results
  #   return(c(param_grid_crsf$ntree[.x], param_grid_crsf$mtry[.x], param_grid_crsf$mincriterion[.x], param_grid_crsf$minbucket[.x], cindex_crsf, sed))
  # })
  # 
  # results_crsf <- as.data.frame(do.call("rbind", res))
  # 
  # # Rename columns
  # colnames(results_crsf) <- c( "ntree", "mtry", "mincriterion", "minbucket", "c_index", "seed")
  # 
  # # Print best parameters
  # return(results_crsf[which.max(results_crsf$c_index), ])
}

fitmod.lasso <- function(train_dat = train_data, test_dat = test_data, params = lasso_params,form=form, covs=covs,
                         seedini=seedini, n_resamples=n_resamples,
                         iter=j){
  param_grid_lasso <- expand.grid(
    lambda =  params$lambda,
    alpha = params$alpha
  )
  model <- rfsrc(form, data = train_dat)
  distime <- model$time.interest  #get the survival time of events
  med_index <- median(1:length(distime))
  #covin <- colnames(train_data)[!colnames(train_data)%in%c("time", "status", "evnt", "PFSISDEAVAL", "PFSISDECNSR")]
  covin <- covs
  x_train <- data.matrix(train_dat[, covin])
  y_train <- Surv(train_dat$time, train_dat$status)
  
  x_val <- data.matrix(test_dat[, covin])
  y_val <- Surv(test_dat$time, test_dat$status)
  # Store lasso results
  results_lasso <- data.frame(lambda = integer(), alpha = integer(), c_index = numeric(), seed=numeric())
  
  res <- map(1:nrow(param_grid_lasso), function(.x){
    cat("Running LASSO model", .x, "of", nrow(param_grid_lasso), "in resample",iter, "of", n_resamples, "\n")
    sed <- seedini+.x
    lasso_model <- {set.seed(sed); glmnet(x_train, y_train, family="cox", alpha = param_grid_lasso$alpha[.x], lambda = param_grid_lasso$lambda[.x])}
    
    times <- test_dat$time
    status <- test_dat$status
    mat_glmnet<-predictProb.glmnet(object= lasso_model,response=y_val, x=x_val, times= distime, complexity=param_grid_lasso$lambda[.x])
    vec_glmnet <- mat_glmnet[ ,med_index]
    c_index_lasso <- SurvMetrics::Cindex(Surv(times, status), vec_glmnet)
    # risk_scores <- predict(lasso_model, newx=x_val, s = lambda, type="link")
    # c_index <- concordance.index(x=risk_scores, surv.time=val_data$time,
    #                              surv.event=val_data$status, method="noether")$c.index
    return(c(param_grid_lasso$lambda[.x], param_grid_lasso$alpha[.x], c_index_lasso, sed))
    
  })

  results_lasso <- as.data.frame(do.call("rbind", res))
  
  # Rename columns
  colnames(results_lasso) <- c( "lambda",  "alpha", "c_index", "seed")
  
  # Print best parameters
  return(results_lasso[which.max(results_lasso$c_index), ])
  
}

fitmod.cox <- function(train_dat = train_data, test_dat = test_data, n_resamples=n_resamples, params,form=form, covs=covs,
                       iter=j){
  ######
  cat("Running Cox model ", "1 ", "in resample", iter, "of", n_resamples, "\n")
  model_cox_train <- coxph(form, data=train_dat, ties="breslow", x=TRUE)
  
    c_index= SurvMetrics::Cindex( model_cox_train, test_dat)

  return(data.frame(c_index= c_index))
}

fitmod.cox_ <- function(train_dat = train_data, test_dat = test_data, n_resamples=n_resamples, params,form=form, covs=covs,
                       iter=j){
  ######
  cat("Running Cox model ", "1 ", "in resample", iter, "of", n_resamples, "\n")
  model_cox_train <- coxph(form, data=train_dat, ties="breslow", x=TRUE)

  model_cox_test <- coxph(form, data=test_dat, ties="breslow", x=TRUE)
  datrain <- cbind(model_cox_train$y, model_cox_train$x)
  datest <- cbind(model_cox_test$y, model_cox_test$x)
  # formnew <- f.build("Surv(time, status)",colnames(da0)[-c(1, 2)])
  # coxph(formnew, data=as.data.frame(da0), ties="breslow", x=TRUE)
  # 
  # coxph(form, data=train_dat, ties="breslow", x=TRUE)
  # c_index= SurvMetrics::Cindex(model_coxnew, test_dat)
  
  coeff_fixed <- model_cox_train$coefficients
  a <- row.names(as.data.frame(coeff_fixed[!is.na(coeff_fixed)]))
  if(sum(colnames(datrain)[-c(1, 2)]!=a)==0){
    c_index= SurvMetrics::Cindex( model_cox_train, test_dat)
  }else{
  formnew <- f.build("Surv(time, status)",a)
  model_coxnew<- coxph(formnew, data=as.data.frame(da0), ties="breslow", x=TRUE)
  c_index= SurvMetrics::Cindex(model_coxnew, as.data.frame(datest))
  }
  # coeff_fixed <- model_cox$coefficients
  # coeff_fixed[is.na(coeff_fixed)]<- 0
  # cox_model_fixed <- model_cox
  # cox_model_fixed$coefficients <- coeff_fixed
  # updat <- model.matrix(f.build(,covs), train_dat)[, -1]
  
  # coeff_fixed <- model_cox$coefficients
  # coeff_fixed[is.na(coeff_fixed)]<- 0
  # cox_model_fixed <- model_cox
  # cox_model_fixed$coefficients <- coeff_fixed
  
  # Extract C-index
  #return(data.frame(c_index= SurvMetrics::Cindex(cox_model_fixed, test_dat)))
  return(data.frame(c_index= c_index))
}

create_plt <- function(best_params, best_params_crsf, best_params_lasso, best_params_cox, best_params_crsfunbias){
  finres <- do.call("rbind", best_params)
  finres_crsf <- do.call("rbind", best_params_crsf)
  finres_lasso <- do.call("rbind", best_params_lasso)
  finres_cox <- do.call("rbind", best_params_cox)
  finres_crsfunbias <- do.call("rbind", best_params_crsfunbias)
  
  finres1crsf <-  cbind(model=rep("cRSF", nrow(finres_crsf)), finres_crsf%>%arrange(desc(c_index)))
  finres1rsf <- cbind(model=rep("RSF", nrow(finres)), finres%>%arrange(desc(c_index)))
  finres1lasso <- cbind(model=rep("LASSO", nrow(finres_lasso)), finres_lasso%>%arrange(desc(c_index)))
  finres1cox <- cbind(model=rep("Cox", nrow(finres_cox)), as.data.frame(finres_cox)%>%arrange(desc(c_index)))
  finres1crsfunbias <-  cbind(model=rep("cRSF(unbiased)", nrow(finres_crsfunbias)), finres_crsfunbias%>%arrange(desc(c_index)))
  
  data_cindex = data.frame('Cindex' = c(finres1crsf$c_index, finres1rsf$c_index, finres1crsfunbias$c_index, finres1lasso$c_index, finres1cox$c_index),
                           'model' = c(rep('cRSF', nrow(finres1crsf)), rep('RSF', nrow(finres1rsf)), rep('cRSF(unbias)', nrow(finres1crsfunbias)),
                                       rep('Lasso', nrow(finres1lasso)), rep('Cox', nrow(finres1cox))))
  data_exp <- data.frame(rsf_cindex=finres1rsf$c_index, crsf_cindex=finres1crsf$c_index, lasso_cindex = finres1lasso$c_index,
                         cox_cindex = finres1cox$c_index, crsfunbias_cindex=finres1crsfunbias$c_index)
  
  plt <- ggplot(data_cindex, aes(x = model, y = Cindex, fill = model)) +
    geom_boxplot() +
    #stat_summary(fun=mean, geom="point", shape=20, size=3, color="red")+
    stat_summary(fun=mean, geom="crossbar", width=0.5, color="red")+
    scale_fill_manual(values = c("#FFBBCC", "#88CCFF", "green", "orange","blue"))
  return(list(data_exp, plt))
}


if(TRUE){
  library(glmnet)
  basesurv <- function (response, lp, times.eval = NULL, centered = FALSE)
  {
    if (is.null(times.eval)) times.eval <- sort(unique(response[,1]))
    
    t.unique <- sort(unique(response[,1][response[,2] == 1]))
    alpha    <- length(t.unique)
    
    for (i in 1:length(t.unique)) {
      alpha[i] <- sum(response[,1][response[,2] == 1] == t.unique[i])/sum(exp(lp[response[,1] >=  t.unique[i]]))
    }
    
    obj   <- approx(t.unique, cumsum(alpha), yleft=0, xout = times.eval, rule=2)
    
    if (centered) obj$y <- obj$y * exp(mean(lp))
    obj$z <- exp(-obj$y)
    
    names(obj) <- c("times","cumBaseHaz","BaseSurv")
    return(obj)
  }
  fit.glmnet <- function (response, x, cplx, ...) 
  {
    #require(glmnet)
    res <- NULL
    tryerr <- try(res <- glmnet(y = response, x = data.matrix(x), lambda = cplx,  ...), silent=TRUE)
    
    if(!is(tryerr, 'try-error') && is(res,"coxnet")) {
      res$linear.predictor  <- as.numeric(predict(res, newx=data.matrix(x), type="link"))
      res$response          <- response
    }
    class(res) <- class(res)[1]
    res
  }
  complexity.glmnet <- function (response, x, full.data, ...) 
  {
    #require(glmnet)
    lambda <- NULL
    tryerr <- try(cv <- cv.glmnet(y = response, x = data.matrix(x),  ...), silent=TRUE)
    
    if(!is(tryerr, 'try-error')){
      lambda <-cv$lambda.min
    }    
    lambda
  }
  predictProb.coxnet <- predictProb.glmnet <- function (object, response, x, times, complexity) 
  {
    #require(glmnet)    
    lp       <- as.numeric(predict(object, newx=data.matrix(x),s=complexity, type="link"))
    basesurv1 <- basesurv(response,lp, sort(unique(times)))
    p        <- exp(exp(lp) %*% -t(basesurv1$cumBaseHaz))
    
    if (NROW(p) != NROW(x) || NCOL(p) != length(times)) 
      stop("Prediction failed")
    p
  }
  Cindexn <- function (object, predicted, t_star = -1) 
  {
    if (inherits(object, "coxph")) {
      obj <- object
      test_data <- predicted
      t_star0 <- t_star
      distime <- sort(unique(as.vector(obj$y[obj$y[, 2] == 
                                               1])))
      if (t_star0 <= 0) {
        t_star0 <- median(distime)
      }
      vec_coxph <- predictSurvProb(obj, test_data, t_star0)
      object_coxph <- Surv(test_data$time, test_data$status)
      object <- object_coxph
      predicted <- vec_coxph
    }
    if (inherits(object, c("rfsrc"))) {
      obj <- object
      test_data <- predicted
      t_star0 <- t_star
      distime <- obj$time.interest
      if (t_star0 <= 0) {
        t_star0 <- median(distime)
      }
      med_index <- order(abs(distime - t_star0))[1]
      mat_rsf <- predict(obj, test_data)$survival
      vec_rsf <- mat_rsf[, med_index]
      object_rsf <- Surv(test_data$time, test_data$status)
      object <- object_rsf
      predicted <- vec_rsf
    }
    if (inherits(object, c("survreg"))) {
      obj <- object
      test_data <- predicted
      t_star0 <- t_star
      distime <- sort(unique(as.vector(obj$y[obj$y[, 2] == 
                                               1])))
      if (t_star0 <= 0) {
        t_star0 <- median(distime)
      }
      predicted <- predictSurvProb2survreg(obj, test_data, 
                                           t_star0)
      object <- Surv(test_data$time, test_data$status)
    }
    time <- object[, 1]
    status <- object[, 2]
    if (length(time) != length(status)) {
      stop("The lengths of time and status are not equal")
    }
    if (length(time) != length(predicted)) {
      stop("The lengths of time and predicted are not equal")
    }
    if (any(is.na(time) | is.na(status) | is.na(predicted))) {
      stop("The input vector cannot have NA")
    }
    permissible <- 0
    concord <- 0
    par_concord <- 0
    n <- length(time)
    for (i in 1:(n - 1)) {
      for (j in (i + 1):n) {
        if ((time[i] < time[j] & status[i] == 0) | (time[j] < 
                                                    time[i] & status[j] == 0)) {
          next
        }
        if (time[i] == time[j] & status[i] == 0 & status[j] == 
            0) {
          next
        }
        permissible <- permissible + 1
        if (time[i] != time[j]) {
          if ((time[i] < time[j] & predicted[i] < predicted[j]) | 
              (time[j] < time[i] & predicted[j] < predicted[i])) {
            concord <- concord + 1
          }
          else if (predicted[i] == predicted[j]) {
            par_concord <- par_concord + 0.5
          }
        }
        if (time[i] == time[j] & status[i] == 1 & status[j] == 
            1) {
          if (predicted[i] == predicted[j]) {
            concord <- concord + 1
          }
          else {
            par_concord <- par_concord + 0.5
          }
        }
        if (time[i] == time[j] & ((status[i] == 1 & status[j] == 
                                   0) | (status[i] == 0 & status[j] == 1))) {
          if ((status[i] == 1 & predicted[i] < predicted[j]) | 
              (status[j] == 1 & predicted[j] < predicted[i])) {
            concord <- concord + 1
          }
          else {
            par_concord <- par_concord + 0.5
          }
        }
      }
    }
    C_index <- (concord + par_concord)/permissible
    names(C_index) <- "C index"
    return(round(C_index, 6))
  }
}