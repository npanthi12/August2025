
list(train_dat=fintrain, test_dat=fintest,covs=covs, best_lamb =1e-04,
     seedini=1234, usecvlamb=FALSE, appr=2)

pred_plt <- function(train_dat=fintrain, test_dat=fintest,covs=covs, best_lamb =1e-04,
                     seedini=seedini){
  
  #Model fit
  fitrsf = rfsrc(Surv(time, status)~., data = train_dat)
  #mat_rsf = predict(fitrsf, test_data)$survival
  dis_time = fitrsf$time.interest
  
  #cforest
  args <- list(form=Surv(time, status)~., dat=train_dat, seedini=seedini)
  fitcforest <- do.call("predmodcrsfunb", args)
  mat_cforest <- suppressMessages(predictSurvProb(fitcforest, newdata = test_dat, times = dis_time))
  km_data <- data.frame(time = fitrsf$time.interest, survival = t(mat_cforest))
  plt_data <- km_data%>%mutate(surv= rowMeans(km_data[,-1]))
  #apply(km_data[,-1], 1, mean, na.rm=T)
  da2 <- data.frame(surv=plt_data$surv, time=km_data$time, group="Predicted(cforest-unbiased)")
  #glmnet
  x1 <- model.matrix( ~ ., train_dat[,-c(3, 4)])[,-1]
  x1_mean <- apply(x1, 2, mean)
  x1_sd <- apply(x1, 2, sd)
  x1_scaled <- scale(x1, center=x1_mean, scale=x1_sd)
  y1 <- Surv(train_dat$time, train_dat$status)
  # cvfit <- {set.seed(seedini); cv.glmnet(x1_scaled, y1, family = "cox", type.measure = "C", nfolds=5)}
  # lamb <- cvfit$lambda.min
  fit <- glmnet(x1_scaled, y1, family = "cox", lambda=best_lamb)
  x2 <-  model.matrix( ~ ., test_dat[,-c(3, 4)])[,-1]
  x2_mean <- apply(x2, 2, mean)
  x2_sd <- apply(x2, 2, sd)
  x2_scaled <- scale(x2, center=x2_mean, scale=x2_sd)
  y2 <- Surv(test_dat$time, test_dat$status)
  
  
  mat_glmnet<-predictProb.glmnet(object=fit,response=y2, x=x2, times=dis_time, complexity=best_lamb)
  km_dataglm <- data.frame(time = fitrsf$time.interest, 
                           survival = t(mat_glmnet))
  plt_dataglm <- km_dataglm%>%mutate(surv= rowMeans(km_dataglm[,-1]))
  #km_data$surv <- rowMeans(km_data[,-1])
  da3 <- data.frame(surv=plt_dataglm$surv, time=plt_dataglm$time, group="Predicted(glmnet)")
  ##Exact
  fit <- survfit(Surv(test_dat$time, test_dat$status)~1, conf.type="plain")

  survest <- stepfun(fit$time, c(1, fit$surv))
  #da <- data.frame(surv=survest(test_dat$time), time=test_dat$time, group="Exact")

  da <- data.frame(surv=survest(dis_time), time=fitrsf$time.interest, group="Exact")
  daf <- rbind(da, da2, da3)
  
  
  p <-   ggplot(daf, aes(x = time, y = surv, color=group)) +
    geom_step(lwd=1.5) +
    labs(title = "Predicted KM Curves",
         x = "Time",
         y = "Survival Probability")+ scale_color_manual(values=c("red", "black", "green", "orange", "blue", "purple"))+
    theme_classic2()
  daf1 <- daf%>%arrange(surv)%>%filter(surv <= 0.5)%>%arrange(desc(surv))
  # dplyr::summarize(med_surv=max(surv))%>%
  # left_join(daf%>%arrange(surv)%>%filter(surv>0.48 & surv <= 0.5))%>%arrange(time)
  daf2 <- daf1[!duplicated(daf1$group),]
  med <- daf2%>%dplyr::select(group, median_time=time)
  return(list(p, med))
}

#' Run the boot function. Set a seed to obtain reproducibility
#' #' Run the boot function. Set a seed to obtain reproducibility
bootfunc <- function(data,index){
  boot_dat <- data[index,]
  # tryCatch({
  pred <- suppressMessages(pred_plt_boot(train_dat=boot_dat, test_dat=fintest,covs=covs, 
                                         seedini=seedini))
  
  # },
  # error = function(e) {
  #   message("An Error Occurred")
  #   
  #   #print(e)
  # },
  # warning = function(w) {
  #   message("A Warning Occurred")
  #   #print(w)
  #   
  # })
  res1<- NA
  res2<-NA
  res3<-NA
  res1<-pred$median_time[1]
  res2 <-pred$median_time[2]
  res3<-pred$median_time[3]
  res <- c(res1, res2, res3)
  return(res)
}
library(boot)
boot_res <- {set.seed(1234); boot::boot(data=fintrain,bootfunc,R=10)}
boot_cforest <- boot.ci(boot_res,index=1)
boot_observ <- boot.ci(boot_res,index=2)
boot_laso <- boot.ci(boot_res,index=3)
ci_cforest <- paste(round(as.matrix(boot_cforest$bca[4]), 4), ",", 
                    round(as.matrix(boot_cforest$bca[5]), 4))
ci_observ <- paste(round(as.matrix(boot_observ$bca[4]), 4), ",", 
                   round(as.matrix(boot_observ$bca[5]), 4))
ci_laso <- paste(round(as.matrix(boot_laso$bca[4]), 4), ",", 
                 round(as.matrix(boot_laso$bca[5]), 4))
res_cforest <- paste(round(esttrt, 4), "(", ci_trt, ")")
res_observ <- paste(round(estref, 4), "(", ci_ref, ")")
res_lasso <- paste(round(estdiff, 4), "(", ci_diff, ")")
out <- list(res_cforest, res_observ, res_lasso)


