

final_mod <- function(dat, covs=covs, 
                      params = params, seedini=NULL, ...) {
  UseMethod("final_mod", params)
}

final_mod.rsf <- function(dat, covs=covs, 
                          params = params, seedini=NULL){
  # Define parameter grid
  param_grid <- expand.grid(
    ntree = params$ntree,  # Number of trees
    mtry = params$mtry,          # Number of features to split at each node
    nodesize = params$nodesize      # Minimum size of terminal nodes
  )
  
  # Run tuning loop
  
  form <- f.build("Surv(time,status)", covs)
  # Store results
  results <- data.frame( ntree = integer(), mtry = integer(), 
                         nodesize = integer(), c_index = numeric(), seed=numeric())
  
  res <- map(1:nrow(param_grid), function(.x){
    cat("Running rsf model", .x, "of", nrow(param_grid), "\n")
    sed <-  seedini+.x
    model <- rfsrc(form, data = dat, 
                   ntree = param_grid$ntree[.x], 
                   mtry = param_grid$mtry[.x], 
                   nodesize = param_grid$nodesize[.x],
                   importance = TRUE, seed=sed)
    # Extract C-index (last error rate)
    c_index <- 1 - model$err.rate[length(model$err.rate)]
    
    # Store results
    return (c(param_grid$ntree[.x], param_grid$mtry[.x], param_grid$nodesize[.x], c_index, sed))
  })
  
  results <- as.data.frame(do.call("rbind", res))
  
  # Rename columns
  colnames(results) <- c( "ntree", "mtry", "nodesize", "c_index", "seed")
  
  # Print best parameters
  best_params <- results[which.max(results$c_index), ]
  
  #Variable ranking
  results_rnk <- data.frame(covariate = character(), delta_cindex = integer())
  res1 <- map(1:length(covs), function(.x){
    cat("Variable Ranking: Running rsf model", .x, "of", length(covs), "\n")
    covsnew <- setdiff(covs, covs[.x])
    formnew <- f.build("Surv(time,status)", covsnew)
    modelnew <- rfsrc(formnew, data = fin, 
                      ntree =  best_params$ntree, 
                      mtry =  best_params$mtry, 
                      nodesize =  best_params$nodesize,
                      importance = TRUE, seed= best_params$seed)
    
    c_indexnew <- 1 - modelnew$err.rate[length(modelnew$err.rate)]
    deltacindex=best_params$c_index - c_indexnew
     return(c(covs[.x], deltacindex))
  })
  results_rnk <- as.data.frame(do.call("rbind", res1))
  # Rename columns
  colnames(results_rnk) <- c( "covariate", "delta_cindex")
  finres <- results_rnk%>%arrange(desc(delta_cindex))
  return(list(best_params, finres))
}

final_mod.crsf <- function(dat, covs=covs, 
                           params = params, seedini=NULL){
  
  # Define parameter grid
  param_grid_crsf <- expand.grid(
    ntree = params$ntree,  # Number of trees
    mtry = params$mtry,          # Number of features to split at each node
    mincriterion = params$mincriterion      # Minimum size of terminal nodes
  )
  
  # Run tuning loop
  form <- f.build("Surv(time,status)", covs)
  # Store results
  results <- data.frame( ntree = integer(), mtry = integer(), 
                         mincriterion = integer(), c_index = numeric(), seed=numeric())
  res <- map(1:nrow(param_grid_crsf), function(.x){
    
    cat("Running crsf model", .x, "of", nrow(param_grid_crsf), "\n")
    sed <-  seedini+.x
    model_crsf <- {set.seed(sed); party::cforest(form, data = dat,  controls = cforest_control(ntree = param_grid_crsf$ntree[.x], 
                            mtry=param_grid_crsf$mtry[.x], mincriterion=param_grid_crsf$mincriterion[.x]))}
    
    # Extract C-index (last error rate)
    oob_predictions <- suppressMessages(predict(model_crsf, OOB=TRUE, type="response"))
    c_index <- tryCatch(
      {
        # Try to execute this block of code
        concordance.index(x=oob_predictions, surv.time=dat$time, surv.event = dat$status)[[1]]
        
      },
      error = function(e) {
        # Handle the error here
        message("An error occurred: ", e$message)
        return(NA)  # Return NA or any other default value
      }
    )
    
    # Store results
    return(c(param_grid_crsf$ntree[i], param_grid_crsf$mtry[i], param_grid_crsf$mincriterion[i], c_index, sed))
  })
  results <- as.data.frame(do.call("rbind", res))
  # Rename columns
  colnames(results) <- c( "ntree", "mtry", "mincriterion", "c_index", "seed")
  
  # Print best parameters
  best_params <- results[which.max(results$c_index), ]
  
  #Variable ranking
  results <- data.frame(covariate = character(), delta_cindex = integer())
  
  res1 <- map(1:length(covs), function(.x){
    cat("Variable Ranking: Running crsf model", .x, "of", length(covs), "\n")
    covsnew <- setdiff(covs, covs[.x])
    formnew <- f.build("Surv(time,status)", covsnew)
    
    modelnew <- {set.seed(best_params$seed); party::cforest(formnew, data = fin,  
                                                            controls = cforest_control(ntree = best_params$ntree, 
                                                                                       mtry=best_params$mtry, mincriterion=best_params$mincriterion))}
    
    oob_pred <- suppressMessages(predict(modelnew, OOB=TRUE, type="response"))
    c_indexnew <- concordance.index(x=oob_pred, surv.time=fin$time, surv.event = fin$status)[[1]]
    deltacindex=best_params$c_index - c_indexnew
    return(c(covs[.x], deltacindex))
    
  })
  results_rnk <- as.data.frame(do.call("rbind", res1))
  # Rename columns
  colnames(results_rnk) <- c( "covariate", "delta_cindex")
  finres <- results_rnk%>%arrange(desc(delta_cindex))
  return(list(best_params, finres))
}

#Lasso
lassofit <- function(train_dat=train_data, test_dat=test_data, covslas=covsnew, lambda=res1$lambda, formlas=formnew){
  covin <- covslas
  x_train <- data.matrix(train_dat[, covin])
  y_train <- Surv(train_dat$time, train_dat$status)
  
  x_val <- data.matrix(test_dat[, covin])
  y_val <- Surv(test_dat$time, test_dat$status)
  # Store lasso results
  
  lasso_model <- glmnet(x_train, y_train, family="cox", alpha = 1, lambda = lambda)
  model <- rfsrc(formlas, data = train_dat)
  distime <- model$time.interest  #get the survival time of events
  med_index <- median(1:length(distime))
  times <- test_dat$time
  status <- test_dat$status
  mat_glmnet<-predictProb.glmnet(object= lasso_model,response=y_val, x=x_val, times= distime, complexity=lambda)
  vec_glmnet <- mat_glmnet[ ,med_index]
  c_index_lasso <- SurvMetrics::Cindex(Surv(times, status), vec_glmnet)
  return(c_index_lasso[[1]])
}

final_mod.lasso <- function(dat, covs=covs, 
                            params = params, seedini=NULL, n_resamples=1, train_fraction=0.7, n=nrow(dat)){
  
  form <- cobalt::f.build("Surv(time, status)", covs)
  set.seed(seedini)
  
  train_idx <-  sample(seq_len(n), size = round(train_fraction*n), replace=FALSE)
  test_idx <- setdiff(seq_len(n), train_idx)
  train_data <- dat[train_idx,]
  test_data <- dat[test_idx, ]
  
  
  best_params_lasso_ <- fitmod(train_dat = train_data, test_dat = test_data, params = prm("lasso"), form=form, covs=covs,
                               seedini=seedini, n_resamples=n_resamples,
                               iter=1)
  
  res1 <- best_params_lasso_
  
  #Variable ranking
  results <- data.frame(covariate = character(), delta_cindex = integer())
  res1 <- map(1:length(covs), function(.x){
    cat("Variable Ranking: Running lasso model", .x, "of", length(covs), "\n")
    covsnew <- setdiff(covs, covs[.x])
    formnew <- f.build("Surv(time,status)", covsnew)
    
    c_indexnew<-lassofit(train_dat=train_data, test_dat=test_data, covslas=covsnew, lambda=res1$lambda, formlas=formnew)
    c_indexnew
    deltacindex=res1$c_index - c_indexnew
    return(c(covs[.x], deltacindex))
    
  })
  results_rnk <- as.data.frame(do.call("rbind", res1))
  # Rename columns
  colnames(results_rnk) <- c( "covariate", "delta_cindex")
  finres <- results_rnk%>%arrange(desc(delta_cindex))
  
  return(list(res1, finres))
  
}

runpred.step3 <- function(dat, covs=covs, 
                          rfs_params = rfs_params, crfs_params = crfs_params, lasso_params = lasso_params, seedini=NULL){
  
  
  best_paramsrsf <- final_mod(dat=dat, covs=covs, 
                              params = prm("rsf"), seedini=seedini)
  best_paramscrsf <- final_mod(dat=dat, covs=covs, 
                               params = prm("crsf"), seedini=seedini)
  
  best_paramslasso <- final_mod(dat=dat, covs=covs, 
                                params = prm("lasso"), seedini=seedini)
  best_paramscox <- final_mod(dat=dat, covs=covs, 
                              params = prm(""))
  
  return(list(best_paramsrsf, best_paramscrsf, best_paramslasso, best_paramscox))
}


final_mod.cox <- function(dat = dat, covs=covs, params=params, ...){
  
  #Variable ranking
  results <- data.frame(covariate = character(), delta_cindex = integer())
  form <- f.build("Surv(time,status)", covs)
  c_index<-summary(coxph(form, data=dat, ties="breslow", x=TRUE))$concordance[[1]]
  res1 <- map(1:length(covs), function(.x){
    cat("Variable Ranking: Running cox model", .x, "of", length(covs), "\n")
    covsnew <- setdiff(covs, covs[.x])
    formnew <- f.build("Surv(time,status)", covsnew)
    
   
    c_indexnew <- summary(coxph(formnew, data=dat, ties="breslow", x=TRUE))$concordance[[1]]
    deltacindex=c_index - c_indexnew
    return(c(covs[.x], deltacindex))
    
  })
  results_rnk <- as.data.frame(do.call("rbind", res1))
  # Rename columns
  colnames(results_rnk) <- c( "covariate", "delta_cindex")
  finres <- results_rnk%>%arrange(desc(delta_cindex))
  return(finres)
}


