#rfsrc


predmod <- function(dat=dat, covs=covs, param=param, ...) {
  UseMethod("predmod", param)
}

predmod.rsf <- function(dat=dat, covs=covs, param=param){
form=f.build("Surv(time, status)", covs)
model <- rfsrc(form, data = dat, 
               ntree = param$ntree, 
               mtry = param$mtry, 
               nodesize = param$nodesize,
               importance = TRUE, seed=param$seed)
c_index <- SurvMetrics::Cindex(model, dat)
return(list(model, c_index))
}

#cforest
predmod.crsf <- function(dat=dat, covs=covs, param=param){
  form=f.build("Surv(time, status)", covs)
  modl <- rfsrc(form, dat)
  distime <- modl$time.interest  #get the survival time of events
  med_index <- median(1:length(distime)) 
  model_crsf <- {set.seed(param$seed); pecCforest(form, data = dat,  
              controls = cforest_control(ntree = param$ntree, 
              mtry=param$mtry, mincriterion=param$mincriterion, 
              minbucket=param$minbucket))}
  mat_cforest <- suppressMessages(predictSurvProb(model_crsf, newdata = dat, times = distime))
  vec_rsf <- mat_cforest[ ,med_index]  #median survival probability of all samples
  times <- dat$time
  status <- dat$status
  c_index <- SurvMetrics::Cindex(Surv(times, status), vec_rsf)
  return(list(model_crsf, c_index))
}

#cforest unbiased
predmod.crsfunbias <- function(dat=dat, covs=covs, param=param){
  form=f.build("Surv(time, status)", covs)
  modl <- rfsrc(form, dat)
  distime <- modl$time.interest  #get the survival time of events
  med_index <- median(1:length(distime)) 
  model_crsf <- {set.seed(param$seed); pecCforest(form, data = dat,  
                                            controls = cforest_unbiased())}
  mat_cforest <- suppressMessages(predictSurvProb(model_crsf, newdata = dat, times = distime))
  vec_rsf <- mat_cforest[ ,med_index]  #median survival probability of all samples
  times <- dat$time
  status <- dat$status
  c_index <- SurvMetrics::Cindex(Surv(times, status), vec_rsf)
  return(list(model_crsf, c_index))
}

#Lasso
predmod.lasso <- function(dat=dat, covs=covs, param=param){
  form=f.build("Surv(time, status)", covs)
  cov <- attr(terms(form), "term.labels")
  modl <- rfsrc(form, dat)
  distime <- modl$time.interest  #get the survival time of events
  med_index <- median(1:length(distime)) 

  x_train <- data.matrix(dat[, cov])
  y_train <- Surv(dat$time, dat$status)
  
  x_val <- data.matrix(dat[, cov])
  y_val <- Surv(dat$time, dat$status)
  
  model_lasso <- glmnet(x_train, y_train, family="cox", alpha = param$alpha, lambda = param$lambda)
  times <- dat$time
  status <- dat$status
  mat_glmnet<-predictProb.glmnet(object= model_lasso,response=y_val, x=x_val, times= distime, complexity=param$lambda)
  vec_glmnet <- mat_glmnet[ ,med_index]
  c_index_lasso <- SurvMetrics::Cindex(Surv(times, status), vec_glmnet)
  
  return(list(model_lasso, c_index_lasso))
}


#Cox
predmod.cox <- function(dat=dat, covs=covs, param=param){
  form=f.build("Surv(time, status)", covs)
  model_cox_train <- coxph(form, data=dat, ties="breslow", x=TRUE)
  
  model_cox_test <- coxph(form, data=dat, ties="breslow", x=TRUE)
  datrain <- cbind(model_cox_train$y, model_cox_train$x)
  datest <- cbind(model_cox_test$y, model_cox_test$x)
  
  coeff_fixed <- model_cox_train$coefficients
  a <- row.names(as.data.frame(coeff_fixed[!is.na(coeff_fixed)]))
  if(sum(colnames(datrain)[-c(1, 2)]!=a)==0){
    c_index= SurvMetrics::Cindex( model_cox_train, dat)
  }else{
    formnew <- f.build("Surv(time, status)",a)
    model_cox_train<- coxph(formnew, data=as.data.frame(datrain), ties="breslow", x=TRUE)
    c_index= SurvMetrics::Cindex(model_cox_train, as.data.frame(datest))
  }
  return(list(model_cox_train, c_index))
}



