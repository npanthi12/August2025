fitmod.lasso <- function(train_dat = train_data, test_dat = test_data, params = lasso_params,form=form, covs=covs,
                         seedini=seedini, n_resamples=n_resamples,
                         iter=j){
  param_grid_lasso <- expand.grid(
    lambda =  params$lambda,
    alpha = params$alpha
  )
  model <- rfsrc(form, data = train_dat)
  distime <- model$time.interest  #get the survival time of events
  med_index <- median(1:length(distime))
  #covin <- colnames(train_data)[!colnames(train_data)%in%c("time", "status", "evnt", "PFSISDEAVAL", "PFSISDECNSR")]
  covin <- covs
  x_train <- data.matrix(train_dat[, covin])
  y_train <- Surv(train_dat$time, train_dat$status)
  
  x_val <- data.matrix(test_dat[, covin])
  y_val <- Surv(test_dat$time, test_dat$status)
  # Store lasso results
  results_lasso <- data.frame(lambda = integer(), alpha = integer(), c_index = numeric(), seed=numeric())
  
  res <- map(1:nrow(param_grid_lasso), function(.x){
    cat("Running LASSO model", .x, "of", nrow(param_grid_lasso), "in resample",iter, "of", n_resamples, "\n")
    sed <- seedini+.x
    lasso_model <- {set.seed(sed); glmnet(x_train, y_train, family="cox", alpha = param_grid_lasso$alpha[.x], lambda = param_grid_lasso$lambda[.x])}
    
    times <- test_dat$time
    status <- test_dat$status
    mat_glmnet<-predictProb.glmnet(object= lasso_model,response=y_val, x=x_val, times= distime, complexity=param_grid_lasso$lambda[.x])
    vec_glmnet <- mat_glmnet[ ,med_index]
    c_index_lasso <- SurvMetrics::Cindex(Surv(times, status), vec_glmnet)
    # risk_scores <- predict(lasso_model, newx=x_val, s = lambda, type="link")
    # c_index <- concordance.index(x=risk_scores, surv.time=val_data$time,
    #                              surv.event=val_data$status, method="noether")$c.index
    return(c(param_grid_lasso$lambda[.x], param_grid_lasso$alpha[.x], c_index_lasso, sed))
    
  })
  
  results_lasso <- as.data.frame(do.call("rbind", res))
  
  # Rename columns
  colnames(results_lasso) <- c( "lambda",  "alpha", "c_index", "seed")
  
  # Print best parameters
  return(results_lasso[which.max(results_lasso$c_index), ])
  
}
