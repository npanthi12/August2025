fitmod <- function(train_dat, test_dat, params, form, covs, seedini, n_resamples, iter, ...) {
  UseMethod("fitmod", params)
}