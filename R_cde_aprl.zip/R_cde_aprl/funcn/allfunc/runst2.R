
runpred.step2 <- function(dat, covs=NULL, n_resamples=4, train_fraction, n, seedini=1234,
                          rfs_params = list("mtry" = c(2, 3, 5, 7, 9), "ntree"=c(200, 300, 500, 1000, 1500), 
                                            "nodesize" =c(7, 9, 11, 13, 15)),
                          crfs_params = list("mtry" = c(2, 3, 5, 7, 9), "ntree"=c(200, 300, 500, 1000, 1500), 
                                             "mincriterion" =c(0, 0.2, 0.4, 0.6, 0.8), "minbucket" = c(7, 9, 11, 13, 15, 20)),
                          lasso_params = list("lambda" = 10^seq(-4, 1, length=100), "alpha"=0.5)){
  
  form <- cobalt::f.build("Surv(time, status)", covs)
  set.seed(seedini)
  
  res <- map(1:n_resamples, function(.y){
    cat("\nRunning resample", .y, "...\n")
    train_idx <-  {set.seed(seedini+.y); sample(seq_len(n), size = round(train_fraction*n), replace=FALSE)}
    test_idx <- setdiff(seq_len(n), train_idx)
    train_data <- dat[train_idx,]
    test_data <- dat[test_idx, ]
    best_params_cox_ <- NULL
    best_params_ <- NULL
    best_params_crsf_ <- NULL
    best_params_lasso_ <- NULL
    best_params_crsfunbias_ <- NULL
    tryCatch(
      {
        # Try to execute this block of code
        best_params_cox_ <-  fitmod(train_dat = train_data, test_dat = test_data, n_resamples=n_resamples, params=prm("cox"), form=form, covs=covs,
                                    iter=.y)
        
        best_params_ <- fitmod(train_dat = train_data, test_dat = test_data, params = prm("rsf"), form=form, covs=covs,
                               seedini=seedini, n_resamples=n_resamples,
                               iter=.y)
        
        best_params_crsf_ <- fitmod(train_dat = train_data, test_dat = test_data, params = prm("crsf"), form=form, covs=covs,
                                    seedini=seedini, n_resamples=n_resamples,
                                    iter=.y)
        
        best_params_lasso_ <- fitmod(train_dat = train_data, test_dat = test_data, params = prm("lasso"), form=form, covs=covs,
                                     seedini=seedini, n_resamples=n_resamples,
                                     iter=.y)
        
        best_params_crsfunbias_ <-  fitmod(train_dat = train_data, test_dat = test_data, params = prm("crsfunbias"), form=form, covs=covs,
                                           seedini=seedini, n_resamples=n_resamples,
                                           iter=.y)
        
      },
      error = function(e) {
        # Handle the error here
        message("An error occurred: ", e$message)
        return(NA)  # Return NA or any other default value
      }
    )
    
    return(list(best_params = best_params_, best_params_crsf = best_params_crsf_, 
                best_params_lasso = best_params_lasso_, best_params_cox = best_params_cox_, best_params_crsfunbias = best_params_crsfunbias_))
  })
  res1 <- do.call("rbind", res)
  out <- create_plt(best_params = res1[,1], best_params_crsf = res1[, 2], 
                    best_params_lasso = res1[,3], best_params_cox = res1[,4], best_params_crsfunbias = res1[, 5])
  
  return(out)
  
}
