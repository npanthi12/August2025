create_plt <- function(best_params, best_params_crsf, best_params_lasso, best_params_cox, best_params_crsfunbias){
  finres <- do.call("rbind", best_params)
  finres_crsf <- do.call("rbind", best_params_crsf)
  finres_lasso <- do.call("rbind", best_params_lasso)
  finres_cox <- do.call("rbind", best_params_cox)
  finres_crsfunbias <- do.call("rbind", best_params_crsfunbias)
  
  finres1crsf <-  cbind(model=rep("cRSF", nrow(finres_crsf)), finres_crsf%>%arrange(desc(c_index)))
  finres1rsf <- cbind(model=rep("RSF", nrow(finres)), finres%>%arrange(desc(c_index)))
  finres1lasso <- cbind(model=rep("LASSO", nrow(finres_lasso)), finres_lasso%>%arrange(desc(c_index)))
  finres1cox <- cbind(model=rep("Cox", nrow(finres_cox)), as.data.frame(finres_cox)%>%arrange(desc(c_index)))
  finres1crsfunbias <-  cbind(model=rep("cRSF(unbiased)", nrow(finres_crsfunbias)), finres_crsfunbias%>%arrange(desc(c_index)))
  
  data_cindex = data.frame('Cindex' = c(finres1crsf$c_index, finres1rsf$c_index, finres1crsfunbias$c_index, finres1lasso$c_index, finres1cox$c_index),
                           'model' = c(rep('cRSF', nrow(finres1crsf)), rep('RSF', nrow(finres1rsf)), rep('cRSF(unbias)', nrow(finres1crsfunbias)),
                                       rep('Lasso', nrow(finres1lasso)), rep('Cox', nrow(finres1cox))))
  data_exp <- data.frame(rsf_cindex=finres1rsf$c_index, crsf_cindex=finres1crsf$c_index, lasso_cindex = finres1lasso$c_index,
                         cox_cindex = finres1cox$c_index, crsfunbias_cindex=finres1crsfunbias$c_index)
  
  plt <- ggplot(data_cindex, aes(x = model, y = Cindex, fill = model)) +
    geom_boxplot() +
    #stat_summary(fun=mean, geom="point", shape=20, size=3, color="red")+
    stat_summary(fun=mean, geom="crossbar", width=0.5, color="red")+
    scale_fill_manual(values = c("#FFBBCC", "#88CCFF", "green", "orange","blue"))
  return(list(data_exp, plt))
}
