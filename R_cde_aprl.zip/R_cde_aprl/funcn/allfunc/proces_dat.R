dat_process <- function(dat, covs, resp, step){
  findat21 <- dat%>%dplyr::select(all_of(covs), all_of(resp))
  covs11 <- c(covs[!covs%in%c("")], resp)
  da <- findat21%>%dplyr::select(all_of(covs11))
  data <- replace(da, da == "", NA)
  da1 <- sapply(data, function(x) sum(is.na(x)))
  names(da1[da1>0])
  covs_miss <- names(da1[da1>0])
  findat22 <- data%>%dplyr::select(all_of(covs11))%>%
    tidyr::drop_na()%>%
    dplyr::mutate_if(is.character, as.factor)
  covs_miss <- colnames(data)[apply(is.na(data), 2, any)]
  findat2 <- findat22
  findat2 <- as.data.frame(findat2)
  covs <- colnames(findat2)[!colnames(findat2)%in%c(resp[1], resp[2])]
  # findat2a <- findat2%>%
  #   dplyr::mutate(evnt=1-PFSCNSR, time=PFSAVAL)
  findat2a <- findat2
  findat2a$time <- findat2[[resp[1]]]
  findat2a$evnt <- 1-findat2[[resp[2]]]
  findat2a$status <- findat2a$evnt
  if(step==1){
    class(findat2a) <- c("step1", "data.frame")
  }else if(step==2){
    class(findat2a) <- c("step2", "data.frame")
  }else if(step==3){
    class(findat2a) <- c( "step3", "data.frame")
  }else{
    class(findat2a) <- c( "data.frame")
  }
  return(findat2a)
}