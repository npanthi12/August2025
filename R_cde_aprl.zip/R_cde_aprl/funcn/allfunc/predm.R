predmod <- function(dat=dat, covs=covs, param=param, ...) {
  UseMethod("predmod", param)
}