
lassofit <- function(train_dat=train_data, test_dat=test_data, covslas=covsnew, lambda=res1$lambda, alpha=res1$alpha, formlas=formnew, seedini=seedini){
  covin <- covslas
  x_train <- data.matrix(train_dat[, covin])
  y_train <- Surv(train_dat$time, train_dat$status)
  
  x_val <- data.matrix(test_dat[, covin])
  y_val <- Surv(test_dat$time, test_dat$status)
  # Store lasso results
  
  lasso_model <-  {set.seed(seedini); glmnet(x_train, y_train, family="cox", alpha = alpha, lambda = lambda)}
  model <- rfsrc(formlas, data = train_dat)
  distime <- model$time.interest  #get the survival time of events
  med_index <- median(1:length(distime))
  times <- test_dat$time
  status <- test_dat$status
  mat_glmnet<-predictProb.glmnet(object= lasso_model,response=y_val, x=x_val, times= distime, complexity=lambda)
  vec_glmnet <- mat_glmnet[ ,med_index]
  c_index_lasso <- SurvMetrics::Cindex(Surv(times, status), vec_glmnet)
  return(c_index_lasso[[1]])
}




# lassofit <- function(train_dat=train_data, test_dat=test_data, covslas=covsnew, lambda=res1$lambda, formlas=formnew){
#   covin <- covslas
#   x_train <- data.matrix(train_dat[, covin])
#   y_train <- Surv(train_dat$time, train_dat$status)
#   
#   x_val <- data.matrix(test_dat[, covin])
#   y_val <- Surv(test_dat$time, test_dat$status)
#   # Store lasso results
#   
#   lasso_model <- glmnet(x_train, y_train, family="cox", alpha = 1, lambda = lambda)
#   model <- rfsrc(formlas, data = train_dat)
#   distime <- model$time.interest  #get the survival time of events
#   med_index <- median(1:length(distime))
#   times <- test_dat$time
#   status <- test_dat$status
#   mat_glmnet<-predictProb.glmnet(object= lasso_model,response=y_val, x=x_val, times= distime, complexity=lambda)
#   vec_glmnet <- mat_glmnet[ ,med_index]
#   c_index_lasso <- SurvMetrics::Cindex(Surv(times, status), vec_glmnet)
#   return(c_index_lasso[[1]])
# }
