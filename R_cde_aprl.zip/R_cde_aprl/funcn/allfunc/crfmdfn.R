
final_mod.crsf <- function(dat, covs=covs, 
                           params = params, seedini=NULL){
  form <- cobalt::f.build("Surv(time, status)", covs)
  # Define parameter grid
  param_grid_crsf <- expand.grid(
    ntree = params$ntree,  # Number of trees
    mtry = params$mtry,          # Number of features to split at each node
    mincriterion = params$mincriterion,     # Minimum size of terminal nodes
    minbucket = params$minbucket
  )
  modl <- rfsrc(form, dat)
  distime <- modl$time.interest  #get the survival time of events
  med_index <- median(1:length(distime)) 
  
  # Run tuning loop
  form <- f.build("Surv(time,status)", covs)
  # Store results
  results <- data.frame( ntree = integer(), mtry = integer(), 
                         mincriterion = integer(), minbucket = integer(), c_index = numeric(), seed=numeric())
  res <- map(1:nrow(param_grid_crsf), function(.x){
    
    cat("Running crsf model", .x, "of", nrow(param_grid_crsf), "\n")
    sed <-  seedini+.x
    model_crsf <- {set.seed(sed); pecCforest(form, data = dat,  controls = cforest_control(ntree = param_grid_crsf$ntree[.x], 
                                                                                           mtry=param_grid_crsf$mtry[.x], mincriterion=param_grid_crsf$mincriterion[.x], minbucket=param_grid_crsf$minbucket[.x]))}
    
    #c_index <- SurvMetrics::Cindex(model_crsf, dat)
    # Extract C-index (last error rate)
    mat_cforest <- suppressMessages(predictSurvProb(model_crsf, newdata = dat, times = distime))
    vec_rsf <- mat_cforest[ ,med_index]  #median survival probability of all samples
    times <- dat$time
    status <- dat$status
    c_index <- SurvMetrics::Cindex(Surv(times, status), vec_rsf)
    # Extract C-index (last error rate)
    # oob_predictions <- suppressMessages(predict(model_crsf, OOB=TRUE, type="response"))
    # c_index <- tryCatch(
    #   {
    #     # Try to execute this block of code
    #     survcomp::concordance.index(x=oob_predictions, surv.time=dat$time, surv.event = dat$status)[[1]]
    #     
    #   },
    #   error = function(e) {
    #     # Handle the error here
    #     message("An error occurred: ", e$message)
    #     return(NA)  # Return NA or any other default value
    #   }
    # )
    
    # Store results
    return(c(param_grid_crsf$ntree[.x], param_grid_crsf$mtry[.x], param_grid_crsf$mincriterion[.x], param_grid_crsf$minbucket[.x], c_index[[1]], sed))
  })
  results <- as.data.frame(do.call("rbind", res))
  # Rename columns
  colnames(results) <- c( "ntree", "mtry", "mincriterion", "minbucket", "c_index", "seed")
  
  # Print best parameters
  best_params <- results[which.max(results$c_index), ]
  
  #Variable ranking
  results_rnk <- data.frame(covariate = character(), delta_cindex = numeric())
  
  res1 <- map(1:length(covs), function(.x){
    cat("Variable Ranking: Running crsf model", .x, "of", length(covs), "\n")
    covsnew <- setdiff(covs, covs[.x])
    formnew <- f.build("Surv(time,status)", covsnew)
    
    modelnew <- {set.seed(best_params$seed); pecCforest(formnew, data = dat,  
                                                        controls = cforest_control(ntree = best_params$ntree, 
                                                                                   mtry=best_params$mtry, mincriterion=best_params$mincriterion,
                                                                                   minbucket=best_params$minbucket))}
    
    #c_indexnew <- SurvMetrics::Cindex(modelnew, dat)
    # Extract C-index (last error rate)
    mat_cforest <- suppressMessages(predictSurvProb(modelnew, newdata = dat, times = distime))
    vec_rsf <- mat_cforest[ ,med_index]  #median survival probability of all samples
    times <- dat$time
    status <- dat$status
    c_indexnew <- SurvMetrics::Cindex(Surv(times, status), vec_rsf)
    # oob_pred <- suppressMessages(predict(modelnew, OOB=TRUE, type="response"))
    # c_indexnew <- NA
    # c_indexnew <- tryCatch(
    #   {
    #     survcomp::concordance.index(x=oob_pred, surv.time=dat$time, surv.event = dat$status)[[1]]
    #   },
    #   error = function(e) {
    #     # Handle the error here
    #     message("An error occurred: ", e$message)
    #     return(NA)  # Return NA or any other default value
    #   }
    # )  
    deltacindex=best_params$c_index - c_indexnew[[1]]
    return(data.frame(covart=covs[.x], delind=deltacindex))
    
  })
  results_rnk <- as.data.frame(do.call("rbind", res1))
  # Rename columns
  colnames(results_rnk) <- c( "covariate", "delta_cindex")
  finres <- results_rnk%>%arrange(desc(delta_cindex))
  return(list(best_params, finres))
  #return(list(best_params, res1, results))
}


# final_mod.crsf <- function(dat, covs=covs, 
#                            params = params, seedini=NULL){
#   
#   # Define parameter grid
#   param_grid_crsf <- expand.grid(
#     ntree = params$ntree,  # Number of trees
#     mtry = params$mtry,          # Number of features to split at each node
#     mincriterion = params$mincriterion      # Minimum size of terminal nodes
#   )
#   
#   # Run tuning loop
#   form <- f.build("Surv(time,status)", covs)
#   # Store results
#   results <- data.frame( ntree = integer(), mtry = integer(), 
#                          mincriterion = integer(), c_index = numeric(), seed=numeric())
#   res <- map(1:nrow(param_grid_crsf), function(.x){
#     
#     cat("Running crsf model", .x, "of", nrow(param_grid_crsf), "\n")
#     sed <-  seedini+.x
#     model_crsf <- {set.seed(sed); party::cforest(form, data = dat,  controls = cforest_control(ntree = param_grid_crsf$ntree[.x], 
#                                                                                                mtry=param_grid_crsf$mtry[.x], mincriterion=param_grid_crsf$mincriterion[.x]))}
#     
#     # Extract C-index (last error rate)
#     oob_predictions <- suppressMessages(predict(model_crsf, OOB=TRUE, type="response"))
#     c_index <- tryCatch(
#       {
#         # Try to execute this block of code
#         concordance.index(x=oob_predictions, surv.time=dat$time, surv.event = dat$status)[[1]]
#         
#       },
#       error = function(e) {
#         # Handle the error here
#         message("An error occurred: ", e$message)
#         return(NA)  # Return NA or any other default value
#       }
#     )
#     
#     # Store results
#     return(c(param_grid_crsf$ntree[i], param_grid_crsf$mtry[i], param_grid_crsf$mincriterion[i], c_index, sed))
#   })
#   results <- as.data.frame(do.call("rbind", res))
#   # Rename columns
#   colnames(results) <- c( "ntree", "mtry", "mincriterion", "c_index", "seed")
#   
#   # Print best parameters
#   best_params <- results[which.max(results$c_index), ]
#   
#   #Variable ranking
#   results <- data.frame(covariate = character(), delta_cindex = integer())
#   
#   res1 <- map(1:length(covs), function(.x){
#     cat("Variable Ranking: Running crsf model", .x, "of", length(covs), "\n")
#     covsnew <- setdiff(covs, covs[.x])
#     formnew <- f.build("Surv(time,status)", covsnew)
#     
#     modelnew <- {set.seed(best_params$seed); party::cforest(formnew, data = fin,  
#                                                             controls = cforest_control(ntree = best_params$ntree, 
#                                                                                        mtry=best_params$mtry, mincriterion=best_params$mincriterion))}
#     
#     oob_pred <- suppressMessages(predict(modelnew, OOB=TRUE, type="response"))
#     c_indexnew <- concordance.index(x=oob_pred, surv.time=fin$time, surv.event = fin$status)[[1]]
#     deltacindex=best_params$c_index - c_indexnew
#     return(c(covs[.x], deltacindex))
#     
#   })
#   results_rnk <- as.data.frame(do.call("rbind", res1))
#   # Rename columns
#   colnames(results_rnk) <- c( "covariate", "delta_cindex")
#   finres <- results_rnk%>%arrange(desc(delta_cindex))
#   return(list(best_params, finres))
# }
