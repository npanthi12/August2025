
runpred.step1 <- function(dat, covs=covs, 
                          rfs_params = list("mtry" = c(1), "ntree"=c(200, 300, 500, 1000, 1500), 
                                            "nodesize" =c(7, 9, 11, 13, 15)), seedini=1234, ...){
  
  
  # Define parameter grid
  param_grid <- expand.grid(
    ntree = rfs_params$ntree,  # Number of trees
    mtry = rfs_params$mtry,          # Number of features to split at each node
    nodesize = rfs_params$nodesize      # Minimum size of terminal nodes
  )
  
  best_params <- list()
  # Run tuning loop
  res1 <- map(1:length(covs), function(.y){
    covsin <- covs[.y]
    form <- f.build("Surv(time,status)", covsin)
    # Store results
    results <- data.frame(covariate = character(), ntree = integer(), mtry = integer(), nodesize = integer(), c_index = numeric(), seed=numeric())
    
    res <- map(1:nrow(param_grid), function(.x){
      cat("Running model", .x, "of", nrow(param_grid),"for covariate", .y, "of", length(covs), "\n")
      sed <- 1234+.x
      model <- rfsrc(form, data = findat2a, 
                     ntree = param_grid$ntree[.x], 
                     mtry = param_grid$mtry[.x], 
                     nodesize = param_grid$nodesize[.x],
                     importance = TRUE, seed=sed)
      # Extract C-index (last error rate)
      c_index <- 1 - model$err.rate[length(model$err.rate)]
      
      # Store results
      
      return(c(covsin, param_grid$ntree[.x], param_grid$mtry[.x], param_grid$nodesize[.x], c_index, sed))
    })
    results <- as.data.frame(do.call("rbind", res))
    
    # Rename columns
    colnames(results) <- c( "covariate", "ntree", "mtry", "nodesize", "c_index", "seed")
    
    # Print best parameters
    return(list(results, results[which.max(results$c_index), ]))
  })
  reslt <- do.call("rbind", res1)[,2]
  finres <-  as.data.frame(do.call("rbind", reslt))
  finres1 <- as.data.frame(finres)%>%arrange(desc(c_index))
  return(finres1)
}