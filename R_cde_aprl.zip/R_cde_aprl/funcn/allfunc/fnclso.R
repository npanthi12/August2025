if(TRUE){
  library(glmnet)
  basesurv <- function (response, lp, times.eval = NULL, centered = FALSE)
  {
    if (is.null(times.eval)) times.eval <- sort(unique(response[,1]))
    
    t.unique <- sort(unique(response[,1][response[,2] == 1]))
    alpha    <- length(t.unique)
    
    for (i in 1:length(t.unique)) {
      alpha[i] <- sum(response[,1][response[,2] == 1] == t.unique[i])/sum(exp(lp[response[,1] >=  t.unique[i]]))
    }
    
    obj   <- approx(t.unique, cumsum(alpha), yleft=0, xout = times.eval, rule=2)
    
    if (centered) obj$y <- obj$y * exp(mean(lp))
    obj$z <- exp(-obj$y)
    
    names(obj) <- c("times","cumBaseHaz","BaseSurv")
    return(obj)
  }
  fit.glmnet <- function (response, x, cplx, ...) 
  {
    #require(glmnet)
    res <- NULL
    tryerr <- try(res <- glmnet(y = response, x = data.matrix(x), lambda = cplx,  ...), silent=TRUE)
    
    if(!is(tryerr, 'try-error') && is(res,"coxnet")) {
      res$linear.predictor  <- as.numeric(predict(res, newx=data.matrix(x), type="link"))
      res$response          <- response
    }
    class(res) <- class(res)[1]
    res
  }
  complexity.glmnet <- function (response, x, full.data, ...) 
  {
    #require(glmnet)
    lambda <- NULL
    tryerr <- try(cv <- cv.glmnet(y = response, x = data.matrix(x),  ...), silent=TRUE)
    
    if(!is(tryerr, 'try-error')){
      lambda <-cv$lambda.min
    }    
    lambda
  }
  predictProb.coxnet <- predictProb.glmnet <- function (object, response, x, times, complexity) 
  {
    #require(glmnet)    
    lp       <- as.numeric(predict(object, newx=data.matrix(x),s=complexity, type="link"))
    basesurv1 <- basesurv(response,lp, sort(unique(times)))
    p        <- exp(exp(lp) %*% -t(basesurv1$cumBaseHaz))
    
    if (NROW(p) != NROW(x) || NCOL(p) != length(times)) 
      stop("Prediction failed")
    p
  }
}