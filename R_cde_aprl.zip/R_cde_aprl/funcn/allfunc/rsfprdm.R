predmod.rsf <- function(dat=dat, covs=covs, param=param){
  form=f.build("Surv(time, status)", covs)
  model <- rfsrc(form, data = dat, 
                 ntree = param$ntree, 
                 mtry = param$mtry, 
                 nodesize = param$nodesize,
                 importance = TRUE, seed=param$seed)
  c_index <- SurvMetrics::Cindex(model, dat)
  return(list(model, c_index))
}
