predmod.cox <- function(dat=dat, covs=covs, param=param){
  form=f.build("Surv(time, status)", covs)
  model_cox_train <- coxph(form, data=dat, ties="breslow", x=TRUE)
  
  model_cox_test <- coxph(form, data=dat, ties="breslow", x=TRUE)
  datrain <- cbind(model_cox_train$y, model_cox_train$x)
  datest <- cbind(model_cox_test$y, model_cox_test$x)
  
  coeff_fixed <- model_cox_train$coefficients
  a <- row.names(as.data.frame(coeff_fixed[!is.na(coeff_fixed)]))
  if(sum(colnames(datrain)[-c(1, 2)]!=a)==0){
    c_index= SurvMetrics::Cindex( model_cox_train, dat)
  }else{
    formnew <- f.build("Surv(time, status)",a)
    model_cox_train<- coxph(formnew, data=as.data.frame(datrain), ties="breslow", x=TRUE)
    c_index= SurvMetrics::Cindex(model_cox_train, as.data.frame(datest))
  }
  return(list(model_cox_train, c_index))
}