runpred <- function(dat, covs, n_resamples, train_fraction, n, seedini,
                    rfs_params = list("mtry" = c(2, 3, 5, 7, 9), "ntree"=c(200, 300, 500, 1000, 1500), 
                                      "nodesize" =c(7, 9, 11, 13, 15)),
                    crfs_params = list("mtry" = c(2, 3, 5, 7, 9), "ntree"=c(200, 300, 500, 1000, 1500), 
                                       "mincriterion" =c(0, 0.2, 0.4, 0.6, 0.8), "minbucket" = c(7, 9, 11, 13, 15, 20)),
                    lasso_params = list("lambda" = 10^seq(-4, 1, length=100), "alpha"=0.5), ...) {
  UseMethod("runpred", dat)
}
