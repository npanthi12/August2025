
predmod.crsfunbias <- function(dat=dat, covs=covs, param=param){
  form=f.build("Surv(time, status)", covs)
  modl <- rfsrc(form, dat)
  distime <- modl$time.interest  #get the survival time of events
  med_index <- median(1:length(distime)) 
  model_crsf <- {set.seed(param$seed); pecCforest(form, data = dat,  
                                                  controls = cforest_unbiased())}
  mat_cforest <- suppressMessages(predictSurvProb(model_crsf, newdata = dat, times = distime))
  vec_rsf <- mat_cforest[ ,med_index]  #median survival probability of all samples
  times <- dat$time
  status <- dat$status
  c_index <- SurvMetrics::Cindex(Surv(times, status), vec_rsf)
  return(list(model_crsf, c_index))
}
