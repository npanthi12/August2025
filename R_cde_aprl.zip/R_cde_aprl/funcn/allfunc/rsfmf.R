final_mod.rsf <- function(dat=NULL, covs=NULL, 
                          params = params, seedini=NULL){
  # Define parameter grid
  param_grid <- expand.grid(
    ntree = params$ntree,  # Number of trees
    mtry = params$mtry,          # Number of features to split at each node
    nodesize = params$nodesize      # Minimum size of terminal nodes
  )
  
  # Run tuning loop
  
  form <- f.build("Surv(time,status)", covs)
  # Store results
  results <- data.frame( ntree = integer(), mtry = integer(), 
                         nodesize = integer(), c_index = numeric(), seed=numeric())
  for (i in 1:nrow(param_grid)) {
    cat("Running rsf model", i, "of", nrow(param_grid), "\n")
    sed <-  seedini+i
    model <- rfsrc(form, data = dat, 
                   ntree = param_grid$ntree[i], 
                   mtry = param_grid$mtry[i], 
                   nodesize = param_grid$nodesize[i],
                   importance = TRUE, seed=sed)
    # Extract C-index (last error rate)
    #c_index <- 1 - model$err.rate[length(model$err.rate)]
    c_index <- SurvMetrics::Cindex(model, dat)
    # Store results
    results <- rbind(results, c(param_grid$ntree[i], param_grid$mtry[i], param_grid$nodesize[i], c_index[[1]], sed))
  }
  
  # Rename columns
  colnames(results) <- c( "ntree", "mtry", "nodesize", "c_index", "seed")
  
  # Print best parameters
  best_params <- results[which.max(results$c_index), ]
  
  #Variable ranking
  results <- data.frame(covariate = character(), delta_cindex = integer())
  for(i in 1:length(covs)){
    cat("Variable Ranking: Running rsf model", i, "of", length(covs), "\n")
    covsnew <- setdiff(covs, covs[i])
    formnew <- f.build("Surv(time,status)", covsnew)
    modelnew <- rfsrc(formnew, data = dat, 
                      ntree =  best_params$ntree, 
                      mtry =  best_params$mtry, 
                      nodesize =  best_params$nodesize,
                      importance = TRUE, seed= best_params$seed)
    
    #c_indexnew <- 1 - modelnew$err.rate[length(modelnew$err.rate)]
    c_indexnew <- SurvMetrics::Cindex(modelnew, dat)
    deltacindex=best_params$c_index - c_indexnew[[1]]
    results <- rbind(results, c(covs[i], deltacindex))
  }
  # Rename columns
  colnames(results) <- c( "covariate", "delta_cindex")
  finres <- results%>%arrange(desc(delta_cindex))
  return(list(best_params, finres))
}

# final_mod.rsf <- function(dat, covs=covs, 
#                           params = params, seedini=NULL){
#   # Define parameter grid
#   param_grid <- expand.grid(
#     ntree = params$ntree,  # Number of trees
#     mtry = params$mtry,          # Number of features to split at each node
#     nodesize = params$nodesize      # Minimum size of terminal nodes
#   )
#   
#   # Run tuning loop
#   
#   form <- f.build("Surv(time,status)", covs)
#   # Store results
#   results <- data.frame( ntree = integer(), mtry = integer(), 
#                          nodesize = integer(), c_index = numeric(), seed=numeric())
#   
#   res <- map(1:nrow(param_grid), function(.x){
#     cat("Running rsf model", .x, "of", nrow(param_grid), "\n")
#     sed <-  seedini+.x
#     model <- rfsrc(form, data = dat, 
#                    ntree = param_grid$ntree[.x], 
#                    mtry = param_grid$mtry[.x], 
#                    nodesize = param_grid$nodesize[.x],
#                    importance = TRUE, seed=sed)
#     # Extract C-index (last error rate)
#     c_index <- 1 - model$err.rate[length(model$err.rate)]
#     
#     # Store results
#     return (c(param_grid$ntree[.x], param_grid$mtry[.x], param_grid$nodesize[.x], c_index, sed))
#   })
#   
#   results <- as.data.frame(do.call("rbind", res))
#   
#   # Rename columns
#   colnames(results) <- c( "ntree", "mtry", "nodesize", "c_index", "seed")
#   
#   # Print best parameters
#   best_params <- results[which.max(results$c_index), ]
#   
#   #Variable ranking
#   results_rnk <- data.frame(covariate = character(), delta_cindex = integer())
#   res1 <- map(1:length(covs), function(.x){
#     cat("Variable Ranking: Running rsf model", .x, "of", length(covs), "\n")
#     covsnew <- setdiff(covs, covs[.x])
#     formnew <- f.build("Surv(time,status)", covsnew)
#     modelnew <- rfsrc(formnew, data = fin, 
#                       ntree =  best_params$ntree, 
#                       mtry =  best_params$mtry, 
#                       nodesize =  best_params$nodesize,
#                       importance = TRUE, seed= best_params$seed)
#     
#     c_indexnew <- 1 - modelnew$err.rate[length(modelnew$err.rate)]
#     deltacindex=best_params$c_index - c_indexnew
#     return(c(covs[.x], deltacindex))
#   })
#   results_rnk <- as.data.frame(do.call("rbind", res1))
#   # Rename columns
#   colnames(results_rnk) <- c( "covariate", "delta_cindex")
#   finres <- results_rnk%>%arrange(desc(delta_cindex))
#   return(list(best_params, finres))
# }
