
fitmod.rsf <- function(train_dat, test_dat, params, form, covs, seedini, n_resamples, iter){
  # Define parameter grid
  param_grid_rsf <- expand.grid(
    ntree = params$ntree,  # Number of trees
    mtry = params$mtry,          # Number of features to split at each node
    nodesize = params$nodesize      # Minimum size of terminal nodes
  )
  # Store results
  results <- data.frame(ntree = integer(), mtry = integer(), nodesize = integer(), c_index = numeric(), seed=numeric())
  
  res <- map(1:nrow(param_grid_rsf), function(.x){
    cat("Running RSF model", .x, "of", nrow(param_grid_rsf), "in resample", iter, "of", n_resamples, "\n")
    sed <- seedini+.x
    
    model <- rfsrc(form, data = train_dat, 
                   ntree = param_grid_rsf$ntree[.x], 
                   mtry = param_grid_rsf$mtry[.x], 
                   nodesize = param_grid_rsf$nodesize[.x],
                   importance = TRUE, seed=sed)
    # Extract C-index (last error rate)
    c_index <- SurvMetrics::Cindex(model, test_dat)
    
    # Store results
    return(c(param_grid_rsf$ntree[.x], param_grid_rsf$mtry[.x], param_grid_rsf$nodesize[.x], c_index, sed))
  })
  
  results <- as.data.frame(do.call("rbind", res))
  # Rename columns
  colnames(results) <- c( "ntree", "mtry", "nodesize", "c_index", "seed")
  
  # Print best parameters
  return(results[which.max(results$c_index), ])
}
