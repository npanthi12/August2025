final_mod <- function(dat, covs=NULL, 
                      params = params, seedini=NULL, ...) {
  UseMethod("final_mod", params)
}