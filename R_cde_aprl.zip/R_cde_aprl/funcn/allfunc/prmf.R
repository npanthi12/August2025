prm <- function(param){
  if(param=="rsf"){
    use_param = rfs_params
    class(use_param) <- "rsf"
  }else if(param=="crsf"){
    use_param = crfs_params
    class(use_param) <- "crsf"
  }else if(param=="lasso"){
    use_param=lasso_params
    class(use_param) <- "lasso"
  }else if(param=="cox"){
    use_param <- ""
    class(use_param) <- "cox"
  }else{
    use_param <- crsfunbias_params
    class(use_param) <- "crsfunbias"
  }
  return(use_param)
}