final_mod.crsfunbias <- function(dat, covs=covs, 
                                 params = params, seedini=NULL){
  form <- cobalt::f.build("Surv(time, status)", covs)
  cat("Running crsfunbias model", 1, "of", 1, "\n")
  modl <- rfsrc(form, dat)
  distime <- modl$time.interest  #get the survival time of events
  med_index <- median(1:length(distime)) 
  
  model_crsf <- {set.seed(seedini); pecCforest(form, data = dat,  controls = cforest_unbiased())}
  
  mat_cforest <- suppressMessages(predictSurvProb(model_crsf, newdata = dat, times = distime))
  vec_rsf <- mat_cforest[ ,med_index]  #median survival probability of all samples
  times <- dat$time
  status <- dat$status
  c_index <- SurvMetrics::Cindex(Surv(times, status), vec_rsf)
  best_params <- data.frame(c_index_=c_index[[1]], seed=seedini)
  #Variable ranking
  results_rnk <- data.frame(covariate = character(), delta_cindex = numeric())
  
  res1 <- map(1:length(covs), function(.x){
    cat("Variable Ranking: Running crsfunbias model", .x, "of", length(covs), "\n")
    covsnew <- setdiff(covs, covs[.x])
    formnew <- f.build("Surv(time,status)", covsnew)
    
    modelnew <- {set.seed(seedini); pecCforest(formnew, data = dat,  
                                               controls = cforest_unbiased())}
    
    #c_indexnew <- SurvMetrics::Cindex(modelnew, dat)
    # Extract C-index (last error rate)
    mat_cforest <- suppressMessages(predictSurvProb(modelnew, newdata = dat, times = distime))
    vec_rsf <- mat_cforest[ ,med_index]  #median survival probability of all samples
    times <- dat$time
    status <- dat$status
    c_indexnew <- SurvMetrics::Cindex(Surv(times, status), vec_rsf)
    # oob_pred <- suppressMessages(predict(modelnew, OOB=TRUE, type="response"))
    # c_indexnew <- NA
    # c_indexnew <- tryCatch(
    #   {
    #     survcomp::concordance.index(x=oob_pred, surv.time=dat$time, surv.event = dat$status)[[1]]
    #   },
    #   error = function(e) {
    #     # Handle the error here
    #     message("An error occurred: ", e$message)
    #     return(NA)  # Return NA or any other default value
    #   }
    # )  
    deltacindex=c_index[[1]] - c_indexnew[[1]]
    return(data.frame(covart=covs[.x], delind=deltacindex))
    
  })
  results_rnk <- as.data.frame(do.call("rbind", res1))
  # Rename columns
  colnames(results_rnk) <- c( "covariate", "delta_cindex")
  finres <- results_rnk%>%arrange(desc(delta_cindex))
  return(list(best_params, finres))
  #return(list(best_params, res1, results))
}