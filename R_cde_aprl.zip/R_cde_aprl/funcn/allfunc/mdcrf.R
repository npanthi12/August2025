fitmod.crsf <- function(train_dat = train_data, test_dat = test_data, params = crfs_params, form=form, covs=covs,
                        seedini=seedini, n_resamples=n_resamples,
                        iter=j){
  ##########
  param_grid_crsf <- expand.grid(
    ntree = params$ntree,  # Number of trees
    mtry = params$mtry,          # Number of features to split at each node
    mincriterion = params$mincriterion,
    minbucket = params$minbucket
  )
  model <- rfsrc(form, data = train_dat)
  distime <- model$time.interest  #get the survival time of events
  med_index <- median(1:length(distime)) 
  # Store crsf results
  results_crsf <- data.frame(ntree = integer(), mtry = integer(), mincriterion = integer(), minbucket = integer(), c_index = numeric(), seed=numeric())
  
  res <- map(1:nrow(param_grid_crsf), function(.x){
    cat("Running cRSF model", .x, "of", nrow(param_grid_crsf), "in resample", iter, "of", n_resamples, "\n")
    sed <- seedini+.x
    model_crsf <- {set.seed(sed); pecCforest(form, data = train_dat,  controls = cforest_control(ntree = param_grid_crsf$ntree[.x], mtry=param_grid_crsf$mtry[.x], mincriterion=param_grid_crsf$mincriterion[.x],
                                                                                                 minbucket = param_grid_crsf$minbucket[.x]))}
    
    # Extract C-index (last error rate)
    mat_cforest <- suppressMessages(predictSurvProb(model_crsf, newdata = test_dat, times = distime))
    vec_rsf <- mat_cforest[ ,med_index]  #median survival probability of all samples
    times <- test_dat$time
    status <- test_dat$status
    cindex_crsf <- SurvMetrics::Cindex(Surv(times, status), vec_rsf)
    #cindex_crsf
    
    # Store results
    return(c(param_grid_crsf$ntree[.x], param_grid_crsf$mtry[.x], param_grid_crsf$mincriterion[.x], param_grid_crsf$minbucket[.x], cindex_crsf, sed))
  })
  
  results_crsf <- as.data.frame(do.call("rbind", res))
  
  # Rename columns
  colnames(results_crsf) <- c( "ntree", "mtry", "mincriterion", "minbucket", "c_index", "seed")
  
  # Print best parameters
  return(results_crsf[which.max(results_crsf$c_index), ])
}
