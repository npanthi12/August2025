predmod.lasso <- function(dat=dat, covs=covs, param=param){
  form=f.build("Surv(time, status)", covs)
  cov <- attr(terms(form), "term.labels")
  modl <- rfsrc(form, dat)
  distime <- modl$time.interest  #get the survival time of events
  med_index <- median(1:length(distime)) 
  
  x_train <- data.matrix(dat[, cov])
  y_train <- Surv(dat$time, dat$status)
  
  x_val <- data.matrix(dat[, cov])
  y_val <- Surv(dat$time, dat$status)
  
  model_lasso <- glmnet(x_train, y_train, family="cox", alpha = param$alpha, lambda = param$lambda)
  times <- dat$time
  status <- dat$status
  mat_glmnet<-predictProb.glmnet(object= model_lasso,response=y_val, x=x_val, times= distime, complexity=param$lambda)
  vec_glmnet <- mat_glmnet[ ,med_index]
  c_index_lasso <- SurvMetrics::Cindex(Surv(times, status), vec_glmnet)
  
  return(list(model_lasso, c_index_lasso))
}