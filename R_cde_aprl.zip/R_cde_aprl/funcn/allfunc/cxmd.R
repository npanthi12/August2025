fitmod.cox <- function(train_dat = train_data, test_dat = test_data, n_resamples=n_resamples, params,form=form, covs=covs,
                       iter=j){
  ######
  cat("Running Cox model ", "1 ", "in resample", iter, "of", n_resamples, "\n")
  model_cox_train <- coxph(form, data=train_dat, ties="breslow", x=TRUE)
  
  c_index= SurvMetrics::Cindex( model_cox_train, test_dat)
  
  return(data.frame(c_index= c_index))
}