
final_mod.cox <- function(dat = NULL, covs=NULL, params=NULL, ...){
  form <- f.build("Surv(time,status)", covs)
  #Variable ranking
  #c_index <- SurvMetrics::Cindex(coxph(form, data=dat, ties="breslow", x=TRUE), dat)
  model_cox_train <- coxph(form, data=dat, ties="breslow", x=TRUE)
  
  model_cox_test <- coxph(form, data=dat, ties="breslow", x=TRUE)
  datrain <- cbind(model_cox_train$y, model_cox_train$x)
  datest <- cbind(model_cox_test$y, model_cox_test$x)
  
  coeff_fixed <- model_cox_train$coefficients
  a <- row.names(as.data.frame(coeff_fixed[!is.na(coeff_fixed)]))
  if(sum(colnames(datrain)[-c(1, 2)]!=a)==0){
    c_index= SurvMetrics::Cindex( model_cox_train, dat)
  }else{
    formnew <- f.build("Surv(time, status)",a)
    model_coxnew<- coxph(formnew, data=as.data.frame(datrain), ties="breslow", x=TRUE)
    c_index= SurvMetrics::Cindex(model_coxnew, as.data.frame(datest))
  }
  ###
  results <- data.frame(covariate = character(), delta_cindex = integer())
  for(i in 1:length(covs)){
    cat("Variable Ranking: Running cox model", i, "of", length(covs), "\n")
    covsnew <- setdiff(covs, covs[i])
    formn <- f.build("Surv(time,status)", covsnew)
    model_cox_tr <- coxph(formn, data=dat, ties="breslow", x=TRUE)
    
    model_cox_te <- coxph(formn, data=dat, ties="breslow", x=TRUE)
    datr <- cbind(model_cox_tr$y, model_cox_tr$x)
    date <- cbind(model_cox_te$y, model_cox_te$x)
    
    coeff_fixed <- model_cox_tr$coefficients
    a <- NULL
    a <- row.names(as.data.frame(coeff_fixed[!is.na(coeff_fixed)]))
    if(sum(colnames(datrain)[-c(1, 2)]!=a)==0){
      c_indexnew= SurvMetrics::Cindex( model_cox_tr, dat)
    }else{
      formnew <- f.build("Surv(time, status)",a)
      model_coxnew<- coxph(formnew, data=as.data.frame(datr), ties="breslow", x=TRUE)
      c_indexnew= SurvMetrics::Cindex(model_coxnew, as.data.frame(date))
    }
    
    #c_indexnew <- SurvMetrics::Cindex(coxph(formn, data=dat, ties="breslow", x=TRUE), dat)
    deltacindex=c_index[[1]] - c_indexnew[[1]]
    results <- rbind(results, c(covs[i], deltacindex))
    
  }
  # Rename columns
  colnames(results) <- c( "covariate", "delta_cindex")
  finres <- results%>%arrange(desc(delta_cindex))
  return(list(c_index_=c_index, finres))
}

# final_mod.cox <- function(dat = dat, covs=covs, params=params, ...){
#   
#   #Variable ranking
#   results <- data.frame(covariate = character(), delta_cindex = integer())
#   form <- f.build("Surv(time,status)", covs)
#   c_index<-summary(coxph(form, data=dat, ties="breslow", x=TRUE))$concordance[[1]]
#   res1 <- map(1:length(covs), function(.x){
#     cat("Variable Ranking: Running cox model", .x, "of", length(covs), "\n")
#     covsnew <- setdiff(covs, covs[.x])
#     formnew <- f.build("Surv(time,status)", covsnew)
#     
#     
#     c_indexnew <- summary(coxph(formnew, data=dat, ties="breslow", x=TRUE))$concordance[[1]]
#     deltacindex=c_index - c_indexnew
#     return(c(covs[.x], deltacindex))
#     
#   })
#   results_rnk <- as.data.frame(do.call("rbind", res1))
#   # Rename columns
#   colnames(results_rnk) <- c( "covariate", "delta_cindex")
#   finres <- results_rnk%>%arrange(desc(delta_cindex))
#   return(finres)
# }
# 
# 
