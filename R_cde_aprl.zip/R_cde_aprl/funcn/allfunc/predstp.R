
runpred.step3 <- function(dat, covs=covs, 
                          rfs_params = rfs_params, crfs_params = crfs_params, lasso_params = lasso_params, seedini=NULL){
  
  best_paramscox <- final_mod(dat=dat, covs=covs,
                              params = prm("cox"))
  
  best_paramscrsfunbias <- final_mod(dat=dat, covs=covs,
                                     params = prm(""), seedini=seedini)
  best_paramscrsf <- final_mod(dat=dat, covs=covs,
                               params = prm("crsf"), seedini=seedini)
  
  best_paramsrsf <- final_mod(dat=dat, covs=covs,
                              params = prm("rsf"), seedini=seedini)
  
  best_paramslasso <- final_mod(dat=dat, covs=covs,
                                params = prm("lasso"), seedini=seedini)
  
  
  
  return(list(best_paramsrsf, best_paramscrsf, best_paramslasso, best_paramscox, best_paramscrsfunbias))
  #return(list(best_paramscrsf))
}