
final_mod.lasso <- function(dat=NULL, covs=NULL, 
                            params = NULL, seedini=NULL, n_resamples=1, train_fraction=0.7, n=nrow(dat)){
  
  form <- cobalt::f.build("Surv(time, status)", covs)
  set.seed(seedini)
  # 
  # train_idx <-   {set.seed(seedini);sample(seq_len(n), size = round(train_fraction*n), replace=FALSE)}
  # test_idx <- setdiff(seq_len(n), train_idx)
  # train_data <- dat[train_idx,]
  # test_data <- dat[test_idx, ]
  
  best_params_lasso_ <- fitmod(train_dat = dat, test_dat = dat, params = prm("lasso"), form=form, covs=covs,
                               seedini=seedini, n_resamples=n_resamples,
                               iter=1)
  
  res1 <- best_params_lasso_
  
  #Variable ranking
  results <- data.frame(covariate = character(), delta_cindex = integer())
  for(i in 1:length(covs)){
    cat("Variable Ranking: Running lasso model", i, "of", length(covs), "\n")
    covsnew <- setdiff(covs, covs[i])
    formnew <- f.build("Surv(time,status)", covsnew)
    
    c_indexnew<-lassofit(train_dat=dat, test_dat=dat, covslas=covsnew, lambda=res1$lambda, alpha=res1$alpha, formlas=formnew, seedini=seedini)
    deltacindex=res1$c_index - c_indexnew
    results <- rbind(results, c(covs[i], deltacindex))
    
  }
  # Rename columns
  colnames(results) <- c( "covariate", "delta_cindex")
  finres <- results%>%arrange(desc(delta_cindex))
  
  return(list(res1, finres))
  
}



# final_mod.lasso <- function(dat, covs=covs, 
#                             params = params, seedini=NULL, n_resamples=1, train_fraction=0.7, n=nrow(dat)){
#   
#   form <- cobalt::f.build("Surv(time, status)", covs)
#   set.seed(seedini)
#   
#   train_idx <-  sample(seq_len(n), size = round(train_fraction*n), replace=FALSE)
#   test_idx <- setdiff(seq_len(n), train_idx)
#   train_data <- dat[train_idx,]
#   test_data <- dat[test_idx, ]
#   
#   
#   best_params_lasso_ <- fitmod(train_dat = train_data, test_dat = test_data, params = prm("lasso"), form=form, covs=covs,
#                                seedini=seedini, n_resamples=n_resamples,
#                                iter=1)
#   
#   res1 <- best_params_lasso_
#   
#   #Variable ranking
#   results <- data.frame(covariate = character(), delta_cindex = integer())
#   res1 <- map(1:length(covs), function(.x){
#     cat("Variable Ranking: Running lasso model", .x, "of", length(covs), "\n")
#     covsnew <- setdiff(covs, covs[.x])
#     formnew <- f.build("Surv(time,status)", covsnew)
#     
#     c_indexnew<-lassofit(train_dat=train_data, test_dat=test_data, covslas=covsnew, lambda=res1$lambda, formlas=formnew)
#     c_indexnew
#     deltacindex=res1$c_index - c_indexnew
#     return(c(covs[.x], deltacindex))
#     
#   })
#   results_rnk <- as.data.frame(do.call("rbind", res1))
#   # Rename columns
#   colnames(results_rnk) <- c( "covariate", "delta_cindex")
#   finres <- results_rnk%>%arrange(desc(delta_cindex))
#   
#   return(list(res1, finres))
#   
# }