library(haven)
library(data.table)
library(dtplyr)
library(survminer)
library(dplyr)
library(Hmisc)
library(AICcmodavg)
library(car)
library(broom)
library(cobalt)
library(ipw)
library(survey)
library(WeightIt)
library(glmtoolbox)
library(MatchIt)
library(MuMIn)
library(purrr)
library("survival")
library("survminer")
library(emmeans)
library(randomForestSRC)
library(ranger)
library(openxlsx)
library(randomForest)
library(dplyr)
library(ggraph)
library(igraph)
library(caret)
library(rpart.plot)
library(rpart)
library(party)
library(ggsurvfit)
library(visdat)
library(plotly)
library(GGally)
library(permimp)
library(DT)
library(ggsurvfit)
library(ggcorrplot)
library(tidyverse)
library(rcompanion)
library(knitr)
library(polycor)
library(StepReg)
library(pec)
library(SurvMetrics)
library(caret)
library(glmnet)

runpred <- function(dat, covs, n_resamples, train_fraction, n, seedini,
                    rfs_params = list("mtry" = c(2, 3, 5, 7, 9), "ntree"=c(200, 300, 500, 1000, 1500), 
                                      "nodesize" =c(7, 9, 11, 13, 15)),
                    crfs_params = list("mtry" = c(2, 3, 5, 7, 9), "ntree"=c(200, 300, 500, 1000, 1500), 
                                       "mincriterion" =c(0, 0.2, 0.4, 0.6, 0.8)),
                    lasso_params = list("lambda" = 10^seq(-4, 1, length=100))) {
  UseMethod("runpred", dat)
}

runpred.step1 <- function(dat, covs=covs, 
                          rfs_params = list("mtry" = c(1), "ntree"=c(200, 300, 500, 1000, 1500), 
                                            "nodesize" =c(7, 9, 11, 13, 15)), seedini=1234, ...){
  
  
  # Define parameter grid
  param_grid <- expand.grid(
    ntree = rfs_params$ntree,  # Number of trees
    mtry = rfs_params$mtry,          # Number of features to split at each node
    nodesize = rfs_params$nodesize      # Minimum size of terminal nodes
  )
  
  best_params <- list()
  # Run tuning loop
  res1 <- map(1:length(covs), function(.y){
    covsin <- covs[.y]
    form <- f.build("Surv(time,status)", covsin)
    # Store results
    results <- data.frame(covariate = character(), ntree = integer(), mtry = integer(), nodesize = integer(), c_index = numeric(), seed=numeric())
    
    res <- map(1:nrow(param_grid), function(.x){
      cat("Running model", .x, "of", nrow(param_grid),"for covariate", .y, "of", length(covs), "\n")
      sed <- 1234+.x
      model <- rfsrc(form, data = findat2a, 
                     ntree = param_grid$ntree[.x], 
                     mtry = param_grid$mtry[.x], 
                     nodesize = param_grid$nodesize[.x],
                     importance = TRUE, seed=sed)
      # Extract C-index (last error rate)
      c_index <- 1 - model$err.rate[length(model$err.rate)]
      
      # Store results
      
      return(c(covsin, param_grid$ntree[.x], param_grid$mtry[.x], param_grid$nodesize[.x], c_index, sed))
    })
    results <- as.data.frame(do.call("rbind", res))
    
    # Rename columns
    colnames(results) <- c( "covariate", "ntree", "mtry", "nodesize", "c_index", "seed")
  
    # Print best parameters
    return(list(results, results[which.max(results$c_index), ]))
  })
  reslt <- do.call("rbind", res1)[,2]
  finres <-  as.data.frame(do.call("rbind", reslt))
  finres1 <- as.data.frame(finres)%>%arrange(desc(c_index))
  return(finres1)
}

runpred.step1_ <- function(dat, covs=covs, 
                    rfs_params = list("mtry" = c(1), "ntree"=c(200, 300, 500, 1000, 1500), 
                                      "nodesize" =c(7, 9, 11, 13, 15)), seedini=1234, ...){
  
  
  # Define parameter grid
  param_grid <- expand.grid(
    ntree = rfs_params$ntree,  # Number of trees
    mtry = rfs_params$mtry,          # Number of features to split at each node
    nodesize = rfs_params$nodesize      # Minimum size of terminal nodes
  )
  
  best_params <- list()
  # Run tuning loop
  res1 <- map(1:length(covs), function(.y){
    covsin <- covs[.y]
    form <- f.build("Surv(time,status)", covsin)
    # Store results
    results <- data.frame(covariate = character(), ntree = integer(), mtry = integer(), nodesize = integer(), c_index = numeric(), seed=numeric())
    
    res <- map(1:nrow(param_grid), function(.x){
      cat("Running model", .x, "of", nrow(param_grid),"for covariate", .y, "of", length(covs), "\n")
      sed <- 1234+.x
      model <- rfsrc(form, data = findat2a, 
                     ntree = param_grid$ntree[.x], 
                     mtry = param_grid$mtry[.x], 
                     nodesize = param_grid$nodesize[.x],
                     importance = TRUE, seed=sed)
      # Extract C-index (last error rate)
      c_index <- 1 - model$err.rate[length(model$err.rate)]
      
      # Store results
      
      return(c(covsin, param_grid$ntree[.x], param_grid$mtry[.x], param_grid$nodesize[.x], c_index, sed))
    })
    results <- as.data.frame(do.call("rbind", res))
    
    # Rename columns
    colnames(results) <- c( "covariate", "ntree", "mtry", "nodesize", "c_index", "seed")
    
    # Print best parameters
    return(results[which.max(results$c_index), ])
  })
  
  finres <-  as.data.frame(do.call("rbind", res1))
  finres1 <- as.data.frame(finres)%>%arrange(desc(c_index))
  return(finres1)
}


dat_process <- function(dat, covs, resp, step){
  findat21 <- dat%>%dplyr::select(all_of(covs), all_of(resp))
  covs11 <- c(covs[!covs%in%c("")], resp)
  da <- findat21%>%dplyr::select(all_of(covs11))
  data <- replace(da, da == "", NA)
  da1 <- sapply(data, function(x) sum(is.na(x)))
  names(da1[da1>0])
  covs_miss <- names(da1[da1>0])
  findat22 <- data%>%dplyr::select(all_of(covs11))%>%
    tidyr::drop_na()%>%
    dplyr::mutate_if(is.character, as.factor)
  covs_miss <- colnames(data)[apply(is.na(data), 2, any)]
  findat2 <- findat22
  findat2 <- as.data.frame(findat2)
  covs <- colnames(findat2)[!colnames(findat2)%in%c(resp[1], resp[2])]
  findat2a <- findat2%>%
    dplyr::mutate(evnt=1-PFSISDECNSR, time=PFSISDEAVAL)
  findat2a$status <- findat2a$evnt
  if(step==1){
    class(findat2a) <- c("step1", "data.frame")
  }else if(step==2){
    class(findat2a) <- c("step2", "data.frame")
  }else if(step==3){
    class(findat2a) <- c( "step3", "data.frame")
  }else{
    class(findat2a) <- c( "data.frame")
  }
  return(findat2a)
}