cfor_imp <- function(mod, cond, seedini){
  imp <- suppressMessages({set.seed(seedini); party::varimp(mod, conditional=cond)})
  return(imp)
}
