

source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll/func/rsf_func.R")
#Mean c-index for one tuning parameter across all inner folds
resd_crsf <- function( dat=dat, fold=fold, num_folds=num_folds, 
                 parm=parm, seedini=seedini, iter=j, out_fld=iter_, rep=rep, num_outer_fld=num_outer_fld){

  cindex_values <- c()
  crsf_model <- NULL
  model_prms <- data.frame()
  for(k in 1:num_folds){
    modtot <-  num_repeats*num_outer_fld*num_folds*nrow(parm)
    modnum <- k+num_folds*(iter-1) + nrow(parm)*num_folds*(out_fld-1) + nrow(parm)*num_folds*num_outer_fld*(rep-1)
    
    #Split into inner training and validation sets
    #cat("Running param_grid", iter, "of", nrow(parm),"in inner fold", k, "of", num_folds,  "in outer fold", i, "of", num_outer_folds, "in repeat", rep, "of", num_repeats,"Model", modnum, "of", modtot, "\n")
    cat("Running param_grid", iter, "of", nrow(parm),"in inner fold", k, "of", num_folds,  "in outer fold", out_fld, "of", num_outer_fld, "in repeat", rep, "of", num_repeats, "Model", modnum, "of", modtot, "\n")
    
    inner_train <- dat[-fold[[k]],]
    inner_valid <- dat[fold[[k]],]
    #Train RSF model with current hyperparameters
    
    args <- list(form=Surv(time, status)~., dat=inner_train,
                 ntree = parm$ntree[iter],
                 mtry = parm$mtry[iter],
                 mincriterion = parm$mincriterion[iter],
                 minbucket=parm$minbucket[iter], seedini=seedini)
    crsf_model <- do.call("predmodcrsf", args)
    # rsf_model <- {set.seed(seedini); rfsrc(Surv(time, status)~., data=inner_train,
    #                                        ntree = params$ntree[iter],
    #                                        mtry = params$mtry[iter],
    #                                        nodesize = params$nodesize[iter], seedini=seedini)}
    # rsf_model
    # 
    model <- rfsrc(Surv(time, status)~., data = inner_train)
    distime <- model$time.interest  #get the survival time of events
    med_index <- median(1:length(distime)) 
    # Extract C-index (last error rate)
    mat_cforest <- suppressMessages(predictSurvProb(crsf_model, newdata = inner_valid, times = distime))
    vec_rsf <- mat_cforest[ ,med_index]  #median survival probability of all samples
    times <- inner_valid$time
    status <- inner_valid$status
    cindex_crsf <- SurvMetrics::Cindex(Surv(times, status), vec_rsf)[[1]]
    cindex_values <- c(cindex_values, cindex_crsf)
   
  }

  return(list(cindex_values, crsf_model,  mean(cindex_values, na.rm=T), data.frame(ntree=parm$ntree[iter], mtry= parm$mtry[iter],   mincriterion = parm$mincriterion[iter],
                                                                                   minbucket=parm$minbucket[iter])))
}

# resd_crsf(dat=dat, fold=fold, num_folds=num_folds,
#           parm=parm, seedini=seedini, iter=j, out_fld=iter_, rep=rep)
#Mean c-index values for all tuning parameters across inner fold and best tuning param
resb_crsf <- function(dat=outer_train, parm=param, num_folds=num_inner_folds, fold=inner_folds, 
                seedini=seedini,iter_=i, rep=rep, num_outer_fld=num_outer_fld){

  best_model <- NULL
  best_cindex <- 0
  m_cin <- c()
  # mod <- list()
  best_params <- data.frame()
  for(j in 1:nrow(parm)){
    cat("Running param_grid", j, "of", nrow(parm), "in outer fold", iter_, "of", num_outer_fld, "in repeat", rep, "of", num_repeats, "\n")
    param_res <- resd_crsf(dat=dat, fold=fold, num_folds=num_folds,
                      parm=parm, seedini=seedini, iter=j, out_fld=iter_, rep=rep, num_outer_fld=num_outer_fld)
    #cindex_values <- param_res[[1]]
    rsf_model <- param_res[[2]]
    #Mean C-index for this hyperparameter set
    mean_cindex <- param_res[[3]]
    mod_prm <- param_res[[4]]
    m_cin[j] <- mean_cindex
    # mod[[j]] <- rsf_model
    #Track best model
    if(mean_cindex > best_cindex){
      best_cindex <- mean_cindex
      best_prm <- mod_prm
      best_params <- data.frame(ntree= mod_prm$ntree, mtry=  mod_prm$mtry,
                                mincriterion=  mod_prm$mincriterion, 
                                minbucket =  mod_prm$minbucket, seedini=seedini)
    }
  }
  return(list(best_cindex, best_params, mean_cindex, mod_prm, m_cin))
}
# resb_crsf(dat=outer_train, parm=param, num_folds=num_inner_folds, fold=inner_folds, 
#           seedini=seedini, iter_=i, rep=rep)
# resb(dat=outer_train, parm=param, num_folds=num_inner_folds, fold=inner_folds,
#      seedini=seedini, iter_=i)[[2]]

# res_f <- resb(dat=outer_train, param=param_grid, num_folds=num_inner_folds, fold=inner_folds,
#      params=param_grid, seedini=seedini)
# max(res_f$m_ci, na.rm=T)

# Get best c-index across all outer folds
resbd_crsf <- function(dat=dat, fold_indx=outer_folds_indx, num_outer_fld=num_outer_folds, 
                  num_inner_fld=num_inner_folds, param = params, seedini=seedini, rep=rep){
  final_results <- data.frame()
  for(i in 1:num_outer_fld){
    cat("Running outer fold", i, "of", num_outer_fld, "in repeat", rep, "of", num_repeats, "\n")
    outer_train <- dat[-fold_indx[[i]],]
    outer_test <- dat[fold_indx[[i]], ]
    # Select best hyperparameters from Inner loop: Hyperparameter tuning using cross-validation
    if(length(unique(outer_train$status))==1){
      inner_folds <- {set.seed(seedini); createFolds(outer_train$time, k=num_inner_fld)}
      
    }else{
      inner_folds <- {set.seed(seedini); createFolds(outer_train$status, k=num_inner_fld)}
    }
   
    best_params <-resb_crsf(dat=outer_train, parm=param, num_folds=num_inner_folds, fold=inner_folds, 
                        seedini=seedini, iter_=i, rep=rep, num_outer_fld=num_outer_fld)[[2]]
    #Train the best model on outer train set
    # best_model <- {set.seed(seedini); rfsrc(Surv(time, status)~., data=outer_train,
    #                                         ntree = best_params$ntree,
    #                                         mtry = best_params$mtry,
    #                                         nodesize = best_params$nodesize, seedini=seedini)}
   
    args <- list(form=Surv(time, status)~., dat=outer_train,
                 ntree = best_params$ntree,
                 mtry = best_params$mtry,
                 mincriterion = best_params$mincriterion, 
                 minbucket=best_params$minbucket, seedini=seedini)
    best_model <- do.call("predmodcrsf", args)
    #Evaluate the best model on the outer test set
    model <- rfsrc(Surv(time, status)~., data = outer_train)
    distime <- model$time.interest  #get the survival time of events
    med_index <- median(1:length(distime)) 
    # Extract C-index (last error rate)
    mat_cforest <- suppressMessages(predictSurvProb(best_model, newdata = outer_test, times = distime))
    vec_rsf <- mat_cforest[ ,med_index]  #median survival probability of all samples
    times <- outer_test$time
    status <- outer_test$status
    final_cindex <- SurvMetrics::Cindex(Surv(times, status), vec_rsf)[[1]]
    #final_ibs <- SurvMetrics::IBS(Surv(times, status), vec_rsf)[[1]]#errors
    perror <- suppressMessages(pec(object=best_model,
        formula = Surv(time, status)~., cens.model="marginal",
        data=outer_test, verbose=F, maxtime=200))
    final_ibs <- ibs(perror, times=max(distime))[[2]]
    # cindex <- cin$AppCindex[[1]]
    #Store results
    final_results <- rbind(final_results, data.frame(Repeat=rep, Fold=i, mtry=best_params$mtry,
                                                     ntree=best_params$ntree, mincriterion = best_params$mincriterion, 
                                                     minbucket = best_params$minbucket,
                                                     C_index = final_cindex, ibs = final_ibs, seedini=seedini))
  }
  return(final_results)
}
# resbd_crsf(dat=dat, fold_indx=outer_folds_indx, num_outer_fld=num_outer_fld, 
#            num_inner_fld=num_inner_fld, param=param_grid_crsf, seedini=seedini, rep=rep)
# Get best c-index across all folds and repeats

resfin_crsf <- function(dat=dat, num_rept=num_repeats, num_outer_fld = num_outer_folds,
                   num_inner_fld=num_inner_folds, params = NULL, seedini=seedini, ...){
  
  param_grid_crsf <- expand.grid(
    ntree = params$ntree,  # Number of trees
    mtry = params$mtry,          # Number of features to split at each node
    mincriterion = params$mincriterion,
    minbucket = params$minbucket
  )
  
  final_results <- data.frame()
  for(rep in 1:num_rept){
    #Outer loop: Split dataset into k folds
    cat("Running repeat", rep, "of", num_repeats, "\n")
    outer_folds_indx <- {set.seed(seedini+rep); createFolds(dat$status, k = num_outer_fld)}
    
    final_results <- rbind(final_results, resbd_crsf(dat=dat, fold_indx=outer_folds_indx, num_outer_fld=num_outer_fld, 
                                                num_inner_fld=num_inner_fld, param=param_grid_crsf, seedini=seedini, rep=rep))
    
  }
  return(final_results)
}
# num_repeats <- 1
# resfin_crsf(dat=fin, num_rept=num_repeats, num_outer_fld = 5,
#             num_inner_fld=5, params=crfs_params, seedini=1234)
