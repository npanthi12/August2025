

source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll/func/rsf_func.R")

# Get best c-index across all folds and repeats

resfin_cox <- function(dat=dat, num_rept=num_repeats, num_outer_fld = num_outer_folds,
                       num_inner_fld=num_inner_folds, params = NULL, seedini=seedini, ...){
  
  final_results <- data.frame()
  for(rep in 1:num_rept){
    #Outer loop: Split dataset into k folds
    cat("Running repeat", rep, "of", num_repeats, "\n")
    outer_folds_indx <- {set.seed(seedini+rep); createFolds(dat$status, k = num_outer_fld)}
    
    final_results <- rbind(final_results, resbd_cox(dat=dat, fold_indx=outer_folds_indx, num_outer_fld=num_outer_fld, 
                                                    num_inner_fld=num_inner_fld, param=NULL, seedini=seed, rep=rep))
    
  }
  return(final_results)
}
# num_repeats <- 1
# resfin_cox(dat=fin, num_rept=num_repeats, num_outer_fld = 5,
#              num_inner_fld=5, params=NULL, seedini=1234)

# Get best c-index across all outer folds
resbd_cox <- function(dat=dat, fold_indx=outer_folds, num_outer_fld=num_outer_folds, 
                          num_inner_fld=num_inner_folds, param = NULL, seedini=seed, rep=rep){
  final_results <- data.frame()
  for(i in 1:num_outer_fld){
    cat("Running outer fold", i, "of", num_outer_fld, "in repeat", rep, "of", num_repeats, "\n")
    outer_train <- dat[-fold_indx[[i]],]
    outer_test <- dat[fold_indx[[i]], ]
    # Select best hyperparameters from Inner loop: Hyperparameter tuning using cross-validation
    if(length(unique(outer_train$status))==1){
      inner_folds <- {set.seed(seedini); createFolds(outer_train$time, k=num_inner_fld)}
      
    }else{
      inner_folds <- {set.seed(seedini); createFolds(outer_train$status, k=num_inner_fld)}
    }
    
    args <- list(form=Surv(time, status)~., dat=outer_train)
    best_model <- do.call("predmodcox", args)
    
    #c_index= SurvMetrics::Cindex(best_model, as.data.frame(dat))
    args_tes <- list(form=Surv(time, status)~., dat=outer_test)
    modl <- rfsrc(Surv(time, status)~., data = outer_train)
    distime <- modl$time.interest  #get the survival time of events
    med_index <- median(1:length(distime)) 
    #
    c_index <- NULL
    model_cox_trnew <- do.call("predmodcox", args)
    
    model_cox_tenew <- do.call("predmodcox", args_tes)
    datrain <- cbind(model_cox_trnew$y, model_cox_trnew$x)
    datest <- cbind(model_cox_tenew$y, model_cox_tenew$x)
    
    coeff_fixed <- model_cox_trnew$coefficients
    a <- row.names(as.data.frame(coeff_fixed[!is.na(coeff_fixed)]))
    if(sum(colnames(datrain)[-c(1, 2)]!=a)==0){
      c_index= SurvMetrics::Cindex( model_cox_trnew, outer_test)[[1]]
      perror <- suppressMessages(pec(object=model_cox_trnew,
                                     formula = Surv(time, status)~., cens.model="marginal",
                                     data=outer_test, verbose=F, maxtime=200))
      final_ibs <- ibs(perror, times=max(distime))[[2]]
      
    }else{
      form_new <- f.build("Surv(time, status)",a)
      model_coxnew<- coxph(form_new, data=as.data.frame(datrain), ties="breslow", x=TRUE)
      c_index= SurvMetrics::Cindex(model_coxnew, as.data.frame(datest))[[1]]
      perror <- suppressMessages(pec(object=model_coxnew,
                                     formula = Surv(time, status)~., cens.model="marginal",
                                     data= as.data.frame(datest), verbose=F, maxtime=200))
      final_ibs <- ibs(perror, times=max(distime))[[2]]
    }
    
    #Evaluate the best model on the outer test set
    final_cindex <- c_index
    #final_ibs <- SurvMetrics::IBS(Surv(times, status), vec_rsf)[[1]]#errors
   
  
    # cindex <- cin$AppCindex[[1]]
    #Store results
    final_results <- rbind(final_results, data.frame(Repeat=rep, Fold=i, 
                                                     C_index = final_cindex, ibs = final_ibs))
  }
  return(final_results)
}
# resbd_crsf(dat=dat, fold_indx=outer_folds_indx, num_outer_fld=num_outer_fld, 
#            num_inner_fld=num_inner_fld, param=param_grid_crsf, seedini=seed, rep=rep)

