predmodrsf <- function(form, dat, ntree, mtry, nodesize, seedini, importance){

  rsf_model <- rfsrc(form, data=dat,
                           ntree = ntree,
                           mtry = mtry,
                           nodesize = nodesize, seed=seedini, block.size=1, 
                     importance=importance)
  return(rsf_model)
}

predmodcrsf <- function(form, dat, ntree, mtry, mincriterion, minbucket, seedini){
model_crsf <- {set.seed(seedini); pecCforest(form, data = dat,  
                                         controls = cforest_control(ntree = ntree, 
                                                                    mtry= mtry, 
                                                                    mincriterion= mincriterion,
                                                                    minbucket = minbucket))}
return(model_crsf)
}

predmodcrsfd <- function(form, dat, ntree, mtry, mincriterion, minbucket, seedini){
  model_crsf <- {set.seed(seedini); party::cforest(form, data = dat,  
                                            controls = cforest_control(ntree = ntree, 
                                                                       mtry= mtry, 
                                                                       mincriterion= mincriterion,
                                                                       minbucket = minbucket))}
  return(model_crsf)
}

predmodlassocv <- function(form, dat, alpha, lam, seedini){
  modl <- rfsrc(form, dat)
  x1 <- model.matrix( ~ .,   dat[, colnames(modl$xvar)])[,-1]
  # x1_mean <- apply(x1, 2, mean)
  # x1_sd <- apply(x1, 2, sd)
  # x1_scaled <- scale(x1, center=x1_mean, scale=x1_sd)
  y1 <- Surv(dat$time, dat$status)
  cvfit <- {set.seed(seedini); cv.glmnet(x1, y1, family = "cox", type.measure = "C", nfolds=5)}
  lamb <- cvfit$lambda.min
  fit <-  {set.seed(seedini);glmnet(x1, y1, family = "cox", lambda=lamb)}
  return(fit)
}

predmodlasso <- function(form, dat, alpha, lam, seedini){
  modl <- rfsrc(form, dat)
  x1 <- model.matrix( ~ .,   dat[, colnames(modl$xvar)])[,-1]
  # x1_mean <- apply(x1, 2, mean)
  # x1_sd <- apply(x1, 2, sd)
  # x1_scaled <- scale(x1, center=x1_mean, scale=x1_sd)
  y1 <- Surv(dat$time, dat$status)
  lamb <- lam
  fit <-  {set.seed(seedini);glmnet(x1, y1, family = "cox", lambda=lam)}
  return(fit)
}

predmodcrsfunb <- function(form, dat, seedini){
  model_crsfunb <- {set.seed(seedini); pecCforest(form, data = dat,  
                                            controls = cforest_unbiased())}
  return(model_crsfunb)
}

predmodcrsfunbd <- function(form, dat, seedini){
  model_crsfunb <- {set.seed(seedini); party::cforest(form, data = dat,  
                                               controls = cforest_unbiased())}
  return(model_crsfunb)
}

predmodcox <- function(form, dat){
  model_cox <- coxph(form, data=dat, ties="breslow", x=TRUE)
  return(model_cox)
}

create_plt <- function(rsf_res=rsf_res, crsf_res = crsf_res, 
                       lasso_res=lasso_res, cox_res=cox_res, crsfunb_res=crsfunb_res){
  finres_rsf <- rsf_res
  finres_crsf <- crsf_res
  finres_lasso <- lasso_res
  finres_cox <- crsfunb_res
  finres_crsfunbias <- cox_res
  #cindex 
  finres1crsf <-  cbind(model=rep("cRSF", nrow(finres_crsf)), finres_crsf%>%arrange(desc(C_index)))
  finres1rsf <- cbind(model=rep("RSF", nrow(finres_rsf)), finres_rsf%>%arrange(desc(C_index)))
  finres1lasso <- cbind(model=rep("LASSO", nrow(finres_lasso)), finres_lasso%>%arrange(desc(C_index)))
  finres1cox <- cbind(model=rep("Cox", nrow(finres_cox)), as.data.frame(finres_cox)%>%arrange(desc(C_index)))
  finres1crsfunbias <-  cbind(model=rep("cRSF(unbiased)", nrow(finres_crsfunbias)), finres_crsfunbias%>%arrange(desc(C_index)))
  
  data_cindex = data.frame('Cindex' = c(finres1crsf$C_index, finres1rsf$C_index, finres1crsfunbias$C_index, finres1lasso$C_index, finres1cox$C_index),
                           'model' = c(rep('cRSF', nrow(finres1crsf)), rep('RSF', nrow(finres1rsf)), rep('cRSF(unbias)', nrow(finres1crsfunbias)),
                                       rep('Lasso', nrow(finres1lasso)), rep('Cox', nrow(finres1cox))))
  data_exp <- data.frame(rsf_cindex=finres1rsf$C_index, crsf_cindex=finres1crsf$C_index, lasso_cindex = finres1lasso$C_index,
                         cox_cindex = finres1cox$C_index, crsfunbias_cindex=finres1crsfunbias$C_index)
  
  plt <- ggplot(data_cindex, aes(x = model, y = Cindex, fill = model)) +
    geom_boxplot() +
    stat_summary(fun=mean, geom="point", shape=20, size=3, color="red")+
    #stat_summary(fun=mean, geom="crossbar", width=0.5, color="red")+
    scale_fill_manual(values = c("#FFBBCC", "#88CCFF", "green", "orange","blue"))+scale_y_continuous(breaks = seq(0, 1, by = 0.1)) +
    coord_cartesian(ylim = c(0, 1)) 
  #ibs  
  finres1crsf <-  cbind(model=rep("cRSF", nrow(finres_crsf)), finres_crsf%>%arrange(desc(ibs)))
  finres1rsf <- cbind(model=rep("RSF", nrow(finres_rsf)), finres_rsf%>%arrange(desc(ibs)))
  finres1lasso <- cbind(model=rep("LASSO", nrow(finres_lasso)), finres_lasso%>%arrange(desc(ibs)))
  finres1cox <- cbind(model=rep("Cox", nrow(finres_cox)), as.data.frame(finres_cox)%>%arrange(desc(ibs)))
  finres1crsfunbias <-  cbind(model=rep("cRSF(unbiased)", nrow(finres_crsfunbias)), finres_crsfunbias%>%arrange(desc(ibs)))
  
  # data_ibs = data.frame('IBS' = c(finres1crsf$ibs, finres1rsf$ibs, finres1crsfunbias$ibs, finres1lasso$ibs, finres1cox$ibs),
  #                       'model' = c(rep('cRSF', nrow(finres1crsf)), rep('RSF', nrow(finres1rsf)), rep('cRSF(unbias)', nrow(finres1crsfunbias)),
  #                                   rep('Lasso', nrow(finres1lasso)), rep('Cox', nrow(finres1cox))))
  data_ibs = data.frame('IBS' = c(finres1crsf$ibs, finres1rsf$ibs, finres1crsfunbias$ibs, finres1cox$ibs),
                        'model' = c(rep('cRSF', nrow(finres1crsf)), rep('RSF', nrow(finres1rsf)), rep('cRSF(unbias)', nrow(finres1crsfunbias)),
                                    rep('Cox', nrow(finres1cox))))
  
  data_expibs <- data.frame(rsf_ibs=finres1rsf$ibs, crsf_ibs=finres1crsf$ibs, lasso_ibs = finres1lasso$ibs,
                            cox_ibs = finres1cox$ibs, crsfunbias_ibs=finres1crsfunbias$ibs)
  
  plt_ibs <- ggplot(data_ibs, aes(x = model, y = IBS, fill = model)) +
    geom_boxplot() +
    stat_summary(fun=mean, geom="point", shape=20, size=3, color="red")+
    #stat_summary(fun=mean, geom="crossbar", width=0.5, color="red")+
    scale_fill_manual(values = c("#FFBBCC", "#88CCFF", "green","blue"))+scale_y_continuous(breaks = seq(0, 1, by = 0.1)) +
    coord_cartesian(ylim = c(0, 1)) 
  return(list(cindex_dat=data_exp, cindex_plt=plt, ibs_dat=data_expibs, ibs_plt=plt_ibs))
}

predictProb.lasso__ <- function(object=fit, test_x=x2_scaled, train_x=x1_scaled, times=dis_time,y=y1){
  lp_test <- predict(object, newx=test_x, s="lambda.min", type="link")
  cox_base <- coxph(y ~ offset(predict(object, newx=train_x, s="lambda.min", type="link")))
  base_surv <- survfit(cox_base)
  s0_at_times <- summary(base_surv, times=times)$surv
  surv_probs <-(outer(s0_at_times, exp(lp_test), `^`))
  return(data.matrix(as.data.frame(surv_probs)))
}
#########
# # After fitting training coxph model
# train_lp <- predict(fit, newx = x1_scaled, type = "link")
# cox_train <- coxph(Surv(train_dat$time, train_dat$status) ~ offset(train_lp))
# # Get baseline survival from training
# train_baseline <- survfit(cox_train)
# survest <- stepfun(train_baseline$time, c(1,  train_baseline$surv))
# da_surv <- data.frame(surv=survest(dis_time), time=dis_time)
# 
# 
# lp_new <- predict(fit, newx = x2_scaled, type = "link", times=dis_time)
# rows <- length(dis_time)
# cols <- nrow(lp_new)
# res <- matrix(0, nrow = rows, ncol = cols)
# 
# # Fill the matrix using a for loop
# for (i in 1:cols) {
#   res[,i] <- (da_surv$surv)^exp(lp_new[i,])
# }
# km_data <- data.frame(time = da_surv$time, 
#                       survival = res)

predictProb.lasso.old <- function(object=fit, test_x=x2_scaled, train_x=x1_scaled, times=dis_time,y=y1){
  lasso_coefs <- coef(object, s = "lambda.min")
  selected_vars <- rownames(lasso_coefs)[as.numeric(lasso_coefs) != 0]
  
  # If any variables selected, fit a standard Cox model
  if (length(selected_vars) > 0) {
    # Subset standardized training data to selected variables
    x_selected <- train_x[, selected_vars, drop = FALSE]
    x_selected_df <- as.data.frame(x_selected)
    
    # Fit Cox model
    df <- data.frame(y = y, x_selected_df)
    formula <- as.formula(paste("y ~", paste(colnames(x_selected_df), collapse = "+")))
    cox_fit <- coxph(formula, data = df, ties = "breslow")
    
    # Estimate baseline survival
    base_surv <- survfit(cox_fit)
    s0_at_times <- summary(base_surv, times=times)$surv
    # Predict linear predictor for new data
    x_new_selected <- test_x[, selected_vars, drop = FALSE]
    linpred_new <- as.vector(as.matrix(x_new_selected) %*% coef(cox_fit))
    surv_probs <-(outer(s0_at_times, exp(linpred_new), `^`))
  }else{
    surv_probs <- NA
  }
  
  return(data.matrix(as.data.frame(surv_probs)))
}


pred_las <- function(object, data=newdata){
  modl <- rfsrc(Surv(time, status)~., data = data)
  distime <- modl$time.interest
  cov <- colnames(modl$xvar)
  x1 <- object$xvar
  x1_mean <- apply(x1, 2, mean)
  x1_sd <- apply(x1, 2, sd)
  
  x2 <-  model.matrix( ~ ., data[,cov])[,-1]
  x2_scaled <- scale(x2, center=x1_mean, scale=x1_sd)
  y2 <-  Surv(data$time, data$status)
  
  lambd <- object$lambda
  # pr <- predictProb.glmnet(object= object,response=y2, x=x2_scaled, 
  #                          times= distime, complexity=lambd)
  
  pr <- predictProb.lasso(object=object, x2_scaled=x2_scaled, 
                          x1_scaled=x1_scaled, times=distime,y=object$resp)
    
  return(data.matrix(t(pr)))
}
predmodlasso1<-function(form, dat, alpha, lam, seedini){
  modl <- rfsrc(form, dat)
  x1 <- model.matrix( ~ .,   data.frame(dat[, colnames(modl$xvar)]))[,-1]
  x1_mean <- apply(x1, 2, mean)
  x1_sd <- apply(x1, 2, sd)
  x1_scaled <- scale(x1, center=x1_mean, scale=x1_sd)
  y1 <- Surv(dat$time, dat$status)
  lamb <- lam
  fit <-  {set.seed(seedini);glmnet(x1_scaled, y1, family = "cox", lambda=lam)}
  fit$resp <- y1
  fit$xvarscaled <- x1_scaled
  fit$xvar <- x1
  return(fit)
}
#predictSurvProb.coxnet(object=best_model, newdata=outer_test, times=c(0, 200), x=x1, y=y1)
predictSurvProb.coxnet <- function (object, newdata, times, ...) {
  ptemp <- pred_las(object, data = newdata)
  modl <- rfsrc(Surv(time, status)~., data = newdata)
  distime <- modl$time.interest
  
  pos <- prodlim::sindex(jump.times = distime, 
                         eval.times = times)
  p <- cbind(1, ptemp)[, pos + 1, drop = FALSE]
  if (NROW(p) != NROW(newdata) || NCOL(p) != length(times)) 
    stop(paste("\nPrediction matrix has wrong dimensions:\nRequested newdata x times: ", 
               NROW(newdata), " x ", length(times), "\nProvided prediction matrix: ", 
               NROW(p), " x ", NCOL(p), "\n\n", sep = ""))
  p
}

#Lasso

predictProb.lasso <- function(object=fit, x2_scaled=x2_scaled, x1_scaled=x1_scaled, times=dis_time,y=y1
){
  train_lp <- predict(object, newx = x1_scaled, type = "link")
  cox_train <- coxph(y ~ offset(train_lp))
  # Get baseline survival from training
  train_baseline <- survfit(cox_train)
  survest <- stepfun(train_baseline$time, c(1,  train_baseline$surv))
  da_surv <- data.frame(surv=survest(times), time=times)
  
  
  lp_new <- predict(object, newx = x2_scaled, type = "link", times=times)
  res <- matrix(0, nrow = length(times), ncol = nrow(lp_new))
  
  # Fill the matrix using a for loop
  for (i in 1:nrow(lp_new)) {
    res[,i] <- (da_surv$surv)^exp(lp_new[i,])
  }
  
  return(data.matrix(as.data.frame(res)))
}

lassofit <- function(train_dat=train_data, test_dat=test_data, covslas=covsnew, lambda=res1$lambda, formlas=formnew){
  covin <- covslas
  # Store lasso results
  if(length(dim(train_dat[,covin]))==0){
    x1 <- data.matrix(model.matrix(~.,as.data.frame(train_dat[,covin]))[, -1])
  }else{
  x1 <- model.matrix( ~ ., train_dat[,covin])[,-1]
  }
  x1_mean <- apply(x1, 2, mean)
  x1_sd <- apply(x1, 2, sd)
  x1_scaled <- scale(x1, center=x1_mean, scale=x1_sd)
  y1 <- Surv(train_dat$time, train_dat$status)
  
  if(length(dim(test_dat[,covin]))==0){
    x2 <- data.matrix(model.matrix(~.,as.data.frame(test_dat[,covin]))[, -1])
  }else{
    x2 <- model.matrix( ~ ., test_dat[,covin])[,-1]
  }
  x2_mean <- apply(x2, 2, mean)
  x2_sd <- apply(x2, 2, sd)
  x2_scaled <- scale(x2, center=x1_mean, scale=x1_sd)
  y2 <- Surv(test_dat$time, test_dat$status)
  
  if(dim(x1)[2]==1){
    c_index_lasso <- NA
  }else{
  lasso_model <- glmnet(x1, y1, family = "cox", lambda=lambda)
  model <- rfsrc(formlas, data = train_dat)
  distime <- model$time.interest  #get the survival time of events
  med_index <- median(1:length(distime))
  times <- test_dat$time
  status <- test_dat$status
  
  mat_lasso <- predictProb.lasso(object=lasso_model, 
                                 x2_scaled=x2_scaled, x1_scaled=x1_scaled, 
                                 times=distime,y=y1)
  
  
  mat_lasso1 <- t(data.matrix(mat_lasso))
  
  vec_glmnet <- mat_lasso1[ ,med_index]
  c_index_lasso <- SurvMetrics::Cindex(Surv(times, status), vec_glmnet)[[1]]
  }
  return(c_index_lasso)
}


if(TRUE){
  library(glmnet)
  basesurv <- function (response, lp, times.eval = NULL, centered = FALSE)
  {
    if (is.null(times.eval)) times.eval <- sort(unique(response[,1]))
    
    t.unique <- sort(unique(response[,1][response[,2] == 1]))
    alpha    <- length(t.unique)
    
    for (i in 1:length(t.unique)) {
      alpha[i] <- sum(response[,1][response[,2] == 1] == t.unique[i])/sum(exp(lp[response[,1] >=  t.unique[i]]))
    }
    
    obj   <- approx(t.unique, cumsum(alpha), yleft=0, xout = times.eval, rule=2)
    
    if (centered) obj$y <- obj$y * exp(mean(lp))
    obj$z <- exp(-obj$y)
    
    names(obj) <- c("times","cumBaseHaz","BaseSurv")
    return(obj)
  }
  fit.glmnet <- function (response, x, cplx, ...) 
  {
    #require(glmnet)
    res <- NULL
    tryerr <- try(res <- glmnet(y = response, x = data.matrix(x), lambda = cplx,  ...), silent=TRUE)
    
    if(!is(tryerr, 'try-error') && is(res,"coxnet")) {
      res$linear.predictor  <- as.numeric(predict(res, newx=data.matrix(x), type="link"))
      res$response          <- response
    }
    class(res) <- class(res)[1]
    res
  }
  complexity.glmnet <- function (response, x, full.data, ...) 
  {
    #require(glmnet)
    lambda <- NULL
    tryerr <- try(cv <- cv.glmnet(y = response, x = data.matrix(x),  ...), silent=TRUE)
    
    if(!is(tryerr, 'try-error')){
      lambda <-cv$lambda.min
    }    
    lambda
  }
  predictProb.coxnet <- predictProb.glmnet <- function (object, response, x, times, complexity) 
  {
    #require(glmnet)    
    lp       <- as.numeric(predict(object, newx=data.matrix(x),s=complexity, type="link"))
    basesurv1 <- basesurv(response,lp, sort(unique(times)))
    p        <- exp(exp(lp) %*% -t(basesurv1$cumBaseHaz))
    
    if (NROW(p) != NROW(x) || NCOL(p) != length(times)) 
      stop("Prediction failed")
    p
  }
  Cindexn <- function (object, predicted, t_star = -1) 
  {
    if (inherits(object, "coxph")) {
      obj <- object
      test_data <- predicted
      t_star0 <- t_star
      distime <- sort(unique(as.vector(obj$y[obj$y[, 2] == 
                                               1])))
      if (t_star0 <= 0) {
        t_star0 <- median(distime)
      }
      vec_coxph <- predictSurvProb(obj, test_data, t_star0)
      object_coxph <- Surv(test_data$time, test_data$status)
      object <- object_coxph
      predicted <- vec_coxph
    }
    if (inherits(object, c("rfsrc"))) {
      obj <- object
      test_data <- predicted
      t_star0 <- t_star
      distime <- obj$time.interest
      if (t_star0 <= 0) {
        t_star0 <- median(distime)
      }
      med_index <- order(abs(distime - t_star0))[1]
      mat_rsf <- predict(obj, test_data)$survival
      vec_rsf <- mat_rsf[, med_index]
      object_rsf <- Surv(test_data$time, test_data$status)
      object <- object_rsf
      predicted <- vec_rsf
    }
    if (inherits(object, c("survreg"))) {
      obj <- object
      test_data <- predicted
      t_star0 <- t_star
      distime <- sort(unique(as.vector(obj$y[obj$y[, 2] == 
                                               1])))
      if (t_star0 <= 0) {
        t_star0 <- median(distime)
      }
      predicted <- predictSurvProb2survreg(obj, test_data, 
                                           t_star0)
      object <- Surv(test_data$time, test_data$status)
    }
    time <- object[, 1]
    status <- object[, 2]
    if (length(time) != length(status)) {
      stop("The lengths of time and status are not equal")
    }
    if (length(time) != length(predicted)) {
      stop("The lengths of time and predicted are not equal")
    }
    if (any(is.na(time) | is.na(status) | is.na(predicted))) {
      stop("The input vector cannot have NA")
    }
    permissible <- 0
    concord <- 0
    par_concord <- 0
    n <- length(time)
    for (i in 1:(n - 1)) {
      for (j in (i + 1):n) {
        if ((time[i] < time[j] & status[i] == 0) | (time[j] < 
                                                    time[i] & status[j] == 0)) {
          next
        }
        if (time[i] == time[j] & status[i] == 0 & status[j] == 
            0) {
          next
        }
        permissible <- permissible + 1
        if (time[i] != time[j]) {
          if ((time[i] < time[j] & predicted[i] < predicted[j]) | 
              (time[j] < time[i] & predicted[j] < predicted[i])) {
            concord <- concord + 1
          }
          else if (predicted[i] == predicted[j]) {
            par_concord <- par_concord + 0.5
          }
        }
        if (time[i] == time[j] & status[i] == 1 & status[j] == 
            1) {
          if (predicted[i] == predicted[j]) {
            concord <- concord + 1
          }
          else {
            par_concord <- par_concord + 0.5
          }
        }
        if (time[i] == time[j] & ((status[i] == 1 & status[j] == 
                                   0) | (status[i] == 0 & status[j] == 1))) {
          if ((status[i] == 1 & predicted[i] < predicted[j]) | 
              (status[j] == 1 & predicted[j] < predicted[i])) {
            concord <- concord + 1
          }
          else {
            par_concord <- par_concord + 0.5
          }
        }
      }
    }
    C_index <- (concord + par_concord)/permissible
    names(C_index) <- "C index"
    return(round(C_index, 6))
  }
}
