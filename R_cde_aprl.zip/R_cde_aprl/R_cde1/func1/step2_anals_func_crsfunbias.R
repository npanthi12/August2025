

source("Z:/Private/npanthi/April analysis/rsf_func.R")
# Get best c-index across all folds and repeats

resfin_crsfunb <- function(dat=dat, num_rept=num_repeats, num_outer_fld = num_outer_folds,
                           num_inner_fld=num_inner_folds, params = NULL, seedini=seedini, ...){
  
  param_grid_crsfunb <- expand.grid(
    seedini = params$seedini  # Number of trees
    # mtry = params$mtry,          # Number of features to split at each node
    # mincriterion = params$mincriterion,
    # minbucket = params$minbucket
  )
  
  final_results <- data.frame()
  for(rep in 1:num_rept){
    #Outer loop: Split dataset into k folds
    cat("Running repeat", rep, "of", num_repeats, "\n")
    outer_folds_indx <- {set.seed(seedini+rep); createFolds(dat$status, k = num_outer_fld)}
    
    final_results <- rbind(final_results, resbd_crsfunb(dat=dat, fold_indx=outer_folds_indx, num_outer_fld=num_outer_fld, 
                                                        num_inner_fld=num_inner_fld, param=param_grid_crsfunbias, seedini=seedini, rep=rep))
    
  }
  return(final_results)
}
# num_repeats <- 1
# resfin_crsfunb(dat=fin, num_rept=num_repeats, num_outer_fld = 5,
#             num_inner_fld=5, params=crfs_params, seedini=1234)
# Get best c-index across all outer folds
resbd_crsfunb <- function(dat=dat, fold_indx=outer_folds, num_outer_fld=num_outer_folds, 
                       num_inner_fld=num_inner_folds, param = params, seedini=seedini, rep=rep){
  final_results <- data.frame()
  for(i in 1:num_outer_fld){
    cat("Running outer fold", i, "of", num_outer_fld, "in repeat", rep, "of", num_repeats, "\n")
    outer_train <- dat[-fold_indx[[i]],]
    outer_test <- dat[fold_indx[[i]], ]
    # Select best hyperparameters from Inner loop: Hyperparameter tuning using cross-validation
    if(length(unique(outer_train$status))==1){
      inner_folds <- {set.seed(seedini); createFolds(outer_train$time, k=num_inner_fld)}
      
    }else{
      inner_folds <- {set.seed(seedini); createFolds(outer_train$status, k=num_inner_fld)}
    }
    
    args <- list(form=Surv(time, status)~., dat=outer_train, seedini=seedini)
    best_model <- do.call("predmodcrsfunb", args)
    
    #Evaluate the best model on the outer test set
    model <- rfsrc(Surv(time, status)~., data = outer_train)
    distime <- model$time.interest  #get the survival time of events
    med_index <- median(1:length(distime)) 
    # Extract C-index (last error rate)
    mat_cforest <- suppressMessages(predictSurvProb(best_model, newdata = outer_test, times = distime))
    vec_rsf <- mat_cforest[ ,med_index]  #median survival probability of all samples
    times <- outer_test$time
    status <- outer_test$status
    final_cindex <- SurvMetrics::Cindex(Surv(times, status), vec_rsf)[[1]]
    #final_ibs <- SurvMetrics::IBS(Surv(times, status), vec_rsf)[[1]]#errors
    perror <- suppressMessages(pec(object=best_model,
                                   formula = Surv(time, status)~., cens.model="marginal",
                                   data=outer_test, verbose=F, maxtime=200))
    final_ibs <- ibs(perror, times=max(distime))[[2]]
    # cindex <- cin$AppCindex[[1]]
    #Store results
    final_results <- rbind(final_results, data.frame(Repeat=rep, Fold=i, 
                                                     C_index = final_cindex, ibs = final_ibs, seedini=seedini))
  }
  return(final_results)
}
# resbd_crsf(dat=dat, fold_indx=outer_folds_indx, num_outer_fld=num_outer_fld, 
#            num_inner_fld=num_inner_fld, param=param_grid_crsf, seedini=seedini, rep=rep)

