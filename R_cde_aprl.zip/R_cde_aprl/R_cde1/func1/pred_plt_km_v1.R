

pred_plt <- function(train_dat=fintrain, test_dat=fintest,covs=covs, best_lamb =1e-04,
                     seedini=seedini, usecvlamb=FALSE, 
                     rsf_best=list(ntree=300, mtry=4, nodesize=11, seed=1234),
                     crsf_best = list(ntree=100, mtry=5, minbucket=3, mincriterion=0, seed=1234),
                     appr=1){
  
  #Model fit
  fitrsf = rfsrc(Surv(time, status)~., data = train_dat)
  
  ##Exact
  dis_time <- seq(0, round(max(train_dat$time), 0), 0.01)
  fit <- survfit(Surv(test_dat$time, test_dat$status)~1)

  survest <- stepfun(fit$time, c(1, fit$surv))
  da <- data.frame(surv=survest(dis_time), time=dis_time, group="Observed(KM)")
  
  #rsf
  args_rsf <- list(form=Surv(time, status)~., dat=train_dat,
               ntree = rsf_best$ntree,
               mtry = rsf_best$mtry,
               nodesize = rsf_best$nodesize, seedini=rsf_best$seed, importance=FALSE)
  best_model_rsf <- do.call("predmodrsf", args_rsf)
  mat_rsf <- suppressMessages(predictSurvProb(best_model_rsf, newdata = test_dat, times = dis_time))
  km_data_rsf <- data.frame(time = dis_time, survival = t(mat_rsf))
  
  plt_data_rsf <- km_data_rsf%>%mutate(surv= rowMeans(km_data_rsf[,-1]))
  da_rsf <- data.frame(surv=plt_data_rsf$surv, time=km_data_rsf$time, group="Predicted(RSF)")
  #cforest
  args_crsf <- list(form=Surv(time, status)~., dat=train_dat,
               ntree = crsf_best$ntree,
               mtry = crsf_best$mtry,
               minbucket = crsf_best$minbucket, 
               mincriterion = crsf_best$mincriterion, seedini=crsf_best$seed)
  best_model_crsf <- do.call("predmodcrsf", args_crsf)
  mat_crsf <- suppressMessages(predictSurvProb(best_model_crsf, newdata = test_dat, times = dis_time))
  km_data_crsf <- data.frame(time = dis_time, survival = t(mat_crsf))
  
  plt_data_crsf <- km_data_crsf%>%mutate(surv= rowMeans(km_data_crsf[,-1]))
  da_crsf <- data.frame(surv=plt_data_crsf$surv, time=km_data_crsf$time, group="Predicted(CRSF)")
  
  #cox
   args_cox <- list(form=Surv(time, status)~., dat=train_dat)
  # best_model_cox <- do.call("predmodcox", args_cox)
  args_tes_cox <- list(form=Surv(time, status)~., dat=test_dat)
  model_cox_trnew <- do.call("predmodcox", args_cox)
  
  model_cox_tenew <- do.call("predmodcox", args_tes_cox)
  datrain <- cbind(model_cox_trnew$y, model_cox_trnew$x)
  datest <- cbind(model_cox_tenew$y, model_cox_tenew$x)
  
  coeff_fixed <- model_cox_trnew$coefficients
  a <- row.names(as.data.frame(coeff_fixed[!is.na(coeff_fixed)]))
  if(sum(colnames(datrain)[-c(1, 2)]!=a)==0){
    mat_cox <- suppressMessages(predictSurvProb(model_cox_trnew, newdata = test_dat, times = dis_time))
  }else{
    form_new <- f.build("Surv(time, status)",a)
    model_coxnew<- coxph(form_new, data=as.data.frame(datrain), ties="breslow", x=TRUE)
    colnames(datest)
    mat_cox <- suppressMessages(predictSurvProb(model_coxnew, newdata = as.data.frame(datest), times = dis_time))

  }
  km_data_cox <- data.frame(time = dis_time, survival = t(mat_cox))
  
  plt_data_cox <- km_data_cox%>%mutate(surv= rowMeans(km_data_cox[,-1]))
  da_cox <- data.frame(surv=plt_data_cox$surv, time=km_data_cox$time, group="Predicted(Cox)")
  #cforestunbiased
  args_crsfunb <- list(form=Surv(time, status)~., dat=train_dat, seedini=seedini)
  fitcforest <- do.call("predmodcrsfunb", args_crsfunb)
  mat_cforest <- suppressMessages(predictSurvProb(fitcforest, newdata = test_dat, times = dis_time))
  
  km_data <- data.frame(time = dis_time, survival = t(mat_cforest))

  plt_data <- km_data%>%mutate(surv= rowMeans(km_data[,-1]))
  da1 <- data.frame(surv=plt_data$surv, time=km_data$time, group="Predicted(CRSF unbiased)")

 
  #glmnet
  covs <- colnames(fitrsf$xvar)
  x1 <- model.matrix( ~ ., train_dat[, covs])[,-1]
  x1_mean <- apply(x1, 2, mean)
  x1_sd <- apply(x1, 2, sd)
  x1_scaled <- scale(x1, center=x1_mean, scale=x1_sd)
  y1 <- Surv(train_dat$time, train_dat$status)
  ###
  lamb <- c()
  if(usecvlamb){
    cvfit <- {set.seed(seedini); cv.glmnet(x1_scaled, y1, family = "cox", type.measure = "C", nfolds=5)}
    lamb <- cvfit$lambda.min
  }else{
    lamb = best_lamb
  }
  
  fit <- glmnet(x1_scaled, y1, family = "cox", lambda=lamb)
  x2 <-  model.matrix( ~ ., test_dat[,covs])[,-1]
  x2_mean <- apply(x2, 2, mean)
  x2_sd <- apply(x2, 2, sd)
  x2_scaled <- scale(x2, center=x1_mean, scale=x1_sd)
  y2 <- Surv(test_dat$time, test_dat$status)
  
  # # After fitting training coxph model
  train_lp <- predict(fit, newx = x1_scaled, type = "link")
  cox_train <- coxph(Surv(train_dat$time, train_dat$status) ~ offset(train_lp))
  # Get baseline survival from training
  train_baseline <- survfit(cox_train)
  survest <- stepfun(train_baseline$time, c(1,  train_baseline$surv))
  da_surv <- data.frame(surv=survest(dis_time), time=dis_time)


  lp_new <- predict(fit, newx = x2_scaled, type = "link", times=dis_time)
  rows <- length(dis_time)
  cols <- nrow(lp_new)
  res <- matrix(0, nrow = rows, ncol = cols)
  
  # Fill the matrix using a for loop
    for (i in 1:cols) {
      res[,i] <- (da_surv$surv)^exp(lp_new[i,])
    }
  km_data <- data.frame(time = da_surv$time, 
                        survival = res)

  plt_data <- km_data%>%mutate(surv= rowMeans(km_data[,-1]))
  da2 <- data.frame(surv=plt_data$surv, time= plt_data$time, 
                    group="Predicted(Lasso)")
  
  daf <- rbind( da, da1, da2, da_rsf, da_crsf, da_cox)
  #daf <- da2
  p <-   ggplot(daf, aes(x = time, y = surv, color=group)) +
    geom_step(lwd=1.5) +
    labs(title = "Predicted KM Curves",
         x = "Time",
         y = "Survival Probability")+ scale_color_manual(values=c("red", "black", "green", "orange", "purple",
                                                                  "yellow"))+
    theme_classic2()

  daf1 <- daf%>%arrange(surv)%>%filter(surv <= 0.5)%>%arrange(desc(surv))
  # dplyr::summarize(med_surv=max(surv))%>%
  # left_join(daf%>%arrange(surv)%>%filter(surv>0.48 & surv <= 0.5))%>%arrange(time)
  daf2 <- daf1[!duplicated(daf1$group),]
  med <- daf2%>%dplyr::select(group, median_time=time)
  return(list(p, med, lamb, daf))
}


pred_plt_ <- function(train_dat=fintrain, test_dat=fintest,covs=covs, best_lamb =1e-04,
                     seedini=seedini, usecvlamb=FALSE, appr=1){
  
  #Model fit
  fitrsf = rfsrc(Surv(time, status)~., data = train_dat)
  #mat_rsf = predict(fitrsf, test_data)$survival
  #dis_time0 = c(0, fitrsf$time.interest)
  
  ##Exact
  fit <- survfit(Surv(test_dat$time, test_dat$status)~1)
  
  #survest <- stepfun(fit$time, c(1, fit$surv))
  #da <- data.frame(surv=survest(dis_time), time=dis_time, group="Observed(KM)")
  da <- data.frame(surv=c(1,fit$surv), time=c(0,fit$time), group="Observed(KM)")
  #dis_time = test_dat$time
  #dis_time <- seq(0, round(max(fitrsf$time.interest), 0), 1)
  dis_time = test_dat$time
  #cforest
  args <- list(form=Surv(time, status)~., dat=train_dat, seedini=seedini)
  fitcforest <- do.call("predmodcrsfunb", args)
  mat_cforest <- suppressMessages(predictSurvProb(fitcforest, newdata = test_dat, times = dis_time))
  km_data <- data.frame(time = dis_time, survival = t(mat_cforest))
  plt_data <- km_data%>%mutate(surv= rowMeans(km_data[,-1]))
  #apply(km_data[,-1], 1, mean, na.rm=T)
  da2 <- data.frame(surv=plt_data$surv, time=km_data$time, group="Predicted(cforest)")
  #glmnet
  covs <- colnames(fitrsf$xvar)
  x1 <- model.matrix( ~ ., train_dat[, covs])[,-1]
  x1_mean <- apply(x1, 2, mean)
  x1_sd <- apply(x1, 2, sd)
  x1_scaled <- scale(x1, center=x1_mean, scale=x1_sd)
  y1 <- Surv(train_dat$time, train_dat$status)
  ###
  if(usecvlamb){
    cvfit <- {set.seed(seedini); cv.glmnet(x1_scaled, y1, family = "cox", type.measure = "C", nfolds=5)}
    lamb <- cvfit$lambda.min
  }else{
    lamb = best_lamb
  }
  
  fit <- glmnet(x1_scaled, y1, family = "cox", lambda=lamb)
  x2 <-  model.matrix( ~ ., test_dat[,covs])[,-1]
  x2_mean <- apply(x2, 2, mean)
  x2_sd <- apply(x2, 2, sd)
  x2_scaled <- scale(x2, center=x1_mean, scale=x1_sd)
  y2 <- Surv(test_dat$time, test_dat$status)
  
  
  #mat_glmnet<-predictProb.lasso(object=fit, test_x=x2_scaled, train_x=x1_scaled, times=dis_time,y=y1)
  # After fitting training coxph model
  train_lp <- predict(fit, newx = x1, type = "link")
  cox_train <- coxph(Surv(train_dat$time, train_dat$status) ~ offset(train_lp))
  # Get baseline survival from training
  train_baseline <- survfit(cox_train)
  # Now predict on new data
  lp_new <- predict(fit, newx = x2, type = "link", times=dis_time)
  # Survival at time t for a subject = (baseline survival at t) ^ exp(lp_new)
  # Example: survival at time = 100
  time_point <- test_dat$time
  base_surv_t <- summary(train_baseline, times = time_point)$surv
  # Predicted survival probability at time t for each new subject
  surv_probs <- base_surv_t ^ exp(lp_new)
  surv_probs 
  
  da1 <- data.frame(surv=as.data.frame(surv_probs)$s0, time=time_point, group="Predicted(Lasso)")
  # 5. Estimate survival curve
  # Get the baseline survival function
  # base_surv <- survfit(cox_offset_model)
  # survest <- stepfun(base_surv$time, c(1, base_surv$surv))
  #da <- data.frame(surv=survest(dis_time), time=dis_time, group="Observed(KM)")
  
  # km_dataglm <- data.frame(time = time_point, 
  #                          survival = da1$s0)
  # 
  # #plt_dataglm <- km_dataglm%>%mutate(surv= rowMeans(km_dataglm[,-1]))
  # plt_dataglm <- km_dataglm
  # #km_data$surv <- rowMeans(km_data[,-1])
  # da3 <- data.frame(surv=plt_dataglm$surv, time=plt_dataglm$time, group="Predicted(Lasso)")
  
  daf <- rbind(da2, da1)
  #daf <- rbind( da2, da1)
  p <-   ggplot(daf, aes(x = time, y = surv, color=group)) +
    geom_step(lwd=1.5) +
    labs(title = "Predicted KM Curves",
         x = "Time",
         y = "Survival Probability")+ scale_color_manual(values=c("red", "black", "green"))+
    theme_classic2()
  p
  daf1 <- daf%>%arrange(surv)%>%filter(surv <= 0.5)%>%arrange(desc(surv))
  # dplyr::summarize(med_surv=max(surv))%>%
  # left_join(daf%>%arrange(surv)%>%filter(surv>0.48 & surv <= 0.5))%>%arrange(time)
  daf2 <- daf1[!duplicated(daf1$group),]
  med <- daf2%>%dplyr::select(group, median_time=time)
  return(list(p, med, lamb))
}



predictProb.lasso <- function(object=fit, test_x=x2_scaled, train_x=x1_scaled, times=dis_time,y=y1){
  lasso_coefs <- coef(object, s = "lambda.min")
  selected_vars <- rownames(lasso_coefs)[as.numeric(lasso_coefs) != 0]
  
  # If any variables selected, fit a standard Cox model
  if (length(selected_vars) > 0) {
    # Subset standardized training data to selected variables
    x_selected <- train_x[, selected_vars, drop = FALSE]
    x_selected_df <- as.data.frame(x_selected)
    
    # Fit Cox model
    df <- data.frame(y = y, x_selected_df)
    formula <- as.formula(paste("y ~", paste(colnames(x_selected_df), collapse = "+")))
    cox_fit <- coxph(formula, data = df, ties = "breslow")
    
    # Estimate baseline survival
    base_surv <- survfit(cox_fit)
    s0_at_times <- summary(base_surv, times=times)$surv
    # Predict linear predictor for new data
    x_new_selected <- test_x[, selected_vars, drop = FALSE]
    linpred_new <- as.vector(as.matrix(x_new_selected) %*% coef(cox_fit))
    surv_probs <-(outer(s0_at_times, exp(linpred_new), `^`))
  }else{
    surv_probs <- NA
  }
  
  return(data.matrix(as.data.frame(surv_probs)))
}

predictProb.lasso_ <- function(object=fit, test_x=x2_scaled, train_x=x1_scaled, times=dis_time,y=y1){
  lasso_coefs <- coef(object, s = "lambda.min")
  selected_vars <- rownames(lasso_coefs)[as.numeric(lasso_coefs) != 0]
  
  # If any variables selected, fit a standard Cox model
  if (length(selected_vars) > 0) {
    # Subset standardized training data to selected variables
    x_selected <- train_x[, selected_vars, drop = FALSE]
    x_selected_df <- as.data.frame(x_selected)
    
    # Fit Cox model
    df <- data.frame(y = y, x_selected_df)
    formula <- as.formula(paste("y ~", paste(colnames(x_selected_df), collapse = "+")))
    cox_fit <- coxph(formula, data = df, ties = "breslow")
    
    # Estimate baseline survival
    base_surv <- survfit(cox_fit)
    s0_at_times <- summary(base_surv, times=times)$surv
    # Predict linear predictor for new data
    x_new_selected <- test_x[, selected_vars, drop = FALSE]
    linpred_new <- as.vector(as.matrix(x_new_selected) %*% coef(cox_fit))
    surv_probs <-(outer(s0_at_times, exp(linpred_new), `^`))
  }else{
    surv_probs <- NA
  }
  
  return(data.matrix(as.data.frame(surv_probs)))
}

#' #' Run the boot function. Set a seed to obtain reproducibility
#' #' #' Run the boot function. Set a seed to obtain reproducibility
#' bootfunc <- function(data,index){
#'   boot_dat <- data[index,]
#'   # tryCatch({
#'   pred <- suppressMessages(pred_plt_boot(train_dat=boot_dat, test_dat=fintest,covs=covs, 
#'                                          seedini=seedini))
#'   
#'   # },
#'   # error = function(e) {
#'   #   message("An Error Occurred")
#'   #   
#'   #   #print(e)
#'   # },
#'   # warning = function(w) {
#'   #   message("A Warning Occurred")
#'   #   #print(w)
#'   #   
#'   # })
#'   res1<- NA
#'   res2<-NA
#'   res3<-NA
#'   res1<-pred$median_time[1]
#'   res2 <-pred$median_time[2]
#'   res3<-pred$median_time[3]
#'   res <- c(res1, res2, res3)
#'   return(res)
#' }
#' library(boot)
#' boot_res <- {set.seed(1234); boot::boot(data=fintrain,bootfunc,R=10)}
#' boot_cforest <- boot.ci(boot_res,index=1)
#' boot_observ <- boot.ci(boot_res,index=2)
#' boot_laso <- boot.ci(boot_res,index=3)
#' ci_cforest <- paste(round(as.matrix(boot_cforest$bca[4]), 4), ",", 
#'                     round(as.matrix(boot_cforest$bca[5]), 4))
#' ci_observ <- paste(round(as.matrix(boot_observ$bca[4]), 4), ",", 
#'                    round(as.matrix(boot_observ$bca[5]), 4))
#' ci_laso <- paste(round(as.matrix(boot_laso$bca[4]), 4), ",", 
#'                  round(as.matrix(boot_laso$bca[5]), 4))
#' res_cforest <- paste(round(esttrt, 4), "(", ci_trt, ")")
#' res_observ <- paste(round(estref, 4), "(", ci_ref, ")")
#' res_lasso <- paste(round(estdiff, 4), "(", ci_diff, ")")
#' out <- list(res_cforest, res_observ, res_lasso)
#' 
#' 
redmodlassocv <- function(form, dat, alpha, lam, seedini){
  modl <- rfsrc(form, dat)
  x1 <- model.matrix( ~ .,   dat[, colnames(modl$xvar)])[,-1]
  x1_mean <- apply(x1, 2, mean)
  x1_sd <- apply(x1, 2, sd)
  x1_scaled <- scale(x1, center=x1_mean, scale=x1_sd)
  y1 <- Surv(dat$time, dat$status)
  cvfit <- {set.seed(seedini); cv.glmnet(x1_scaled, y1, family = "cox", type.measure = "C", nfolds=5)}
  lamb <- cvfit$lambda.min
  fit <-  {set.seed(seedini);glmnet(x1_scaled, y1, family = "cox", lambda=lamb)}
  return(fit)
}

predmodlasso <- function(form, dat, alpha, lam, seedini){
  modl <- rfsrc(form, dat)
  x1 <- model.matrix( ~ .,   dat[, colnames(modl$xvar)])[,-1]
  x1_mean <- apply(x1, 2, mean)
  x1_sd <- apply(x1, 2, sd)
  x1_scaled <- scale(x1, center=x1_mean, scale=x1_sd)
  y1 <- Surv(dat$time, dat$status)
  lamb <- lam
  fit <-  {set.seed(seedini);glmnet(x1_scaled, y1, family = "cox", lambda=lam)}
  return(fit)
}

pred_plt_crsf <- function(train_dat=fintrain, test_dat=fintest,covs=covs, best_lamb =1e-04,
                     seedini=seedini, usecvlamb=FALSE, 
                     rsf_best=list(ntree=300, mtry=4, nodesize=11, seed=1234),
                     crsf_best = list(ntree=100, mtry=5, minbucket=3, mincriterion=0, seed=1234),
                     appr=1){
  
  #Model fit
  fitrsf = rfsrc(Surv(time, status)~., data = train_dat)
  
  ##Exact
  dis_time <- seq(0, round(max(train_dat$time), 0), 0.01)
  fit <- survfit(Surv(test_dat$time, test_dat$status)~1)
  
  survest <- stepfun(fit$time, c(1, fit$surv))
  da <- data.frame(surv=survest(dis_time), time=dis_time, group="Observed(KM)")
  
  #rsf
  # args_rsf <- list(form=Surv(time, status)~., dat=train_dat,
  #                  ntree = rsf_best$ntree,
  #                  mtry = rsf_best$mtry,
  #                  nodesize = rsf_best$nodesize, seedini=rsf_best$seed, importance=FALSE)
  # best_model_rsf <- do.call("predmodrsf", args_rsf)
  # mat_rsf <- suppressMessages(predictSurvProb(best_model_rsf, newdata = test_dat, times = dis_time))
  # km_data_rsf <- data.frame(time = dis_time, survival = t(mat_rsf))
  # 
  # plt_data_rsf <- km_data_rsf%>%mutate(surv= rowMeans(km_data_rsf[,-1]))
  # da_rsf <- data.frame(surv=plt_data_rsf$surv, time=km_data_rsf$time, group="Predicted(RSF)")
  #cforest
  args_crsf <- list(form=Surv(time, status)~., dat=train_dat,
                    ntree = crsf_best$ntree,
                    mtry = crsf_best$mtry,
                    minbucket = crsf_best$minbucket, 
                    mincriterion = crsf_best$mincriterion, seedini=crsf_best$seed)
  best_model_crsf <- do.call("predmodcrsf", args_crsf)
  mat_crsf <- suppressMessages(predictSurvProb(best_model_crsf, newdata = test_dat, times = dis_time))
  km_data_crsf <- data.frame(time = dis_time, survival = t(mat_crsf))
  
  plt_data_crsf <- km_data_crsf%>%mutate(surv= rowMeans(km_data_crsf[,-1]))
  da_crsf <- data.frame(surv=plt_data_crsf$surv, time=km_data_crsf$time, group="Predicted(CRSF)")
  # 
  # #cox
  # args_cox <- list(form=Surv(time, status)~., dat=train_dat)
  # # best_model_cox <- do.call("predmodcox", args_cox)
  # args_tes_cox <- list(form=Surv(time, status)~., dat=test_dat)
  # model_cox_trnew <- do.call("predmodcox", args_cox)
  # 
  # model_cox_tenew <- do.call("predmodcox", args_tes_cox)
  # datrain <- cbind(model_cox_trnew$y, model_cox_trnew$x)
  # datest <- cbind(model_cox_tenew$y, model_cox_tenew$x)
  # 
  # coeff_fixed <- model_cox_trnew$coefficients
  # a <- row.names(as.data.frame(coeff_fixed[!is.na(coeff_fixed)]))
  # if(sum(colnames(datrain)[-c(1, 2)]!=a)==0){
  #   mat_cox <- suppressMessages(predictSurvProb(model_cox_trnew, newdata = test_dat, times = dis_time))
  # }else{
  #   form_new <- f.build("Surv(time, status)",a)
  #   model_coxnew<- coxph(form_new, data=as.data.frame(datrain), ties="breslow", x=TRUE)
  #   colnames(datest)
  #   mat_cox <- suppressMessages(predictSurvProb(model_coxnew, newdata = as.data.frame(datest), times = dis_time))
  #   
  # }
  # km_data_cox <- data.frame(time = dis_time, survival = t(mat_cox))
  # 
  # plt_data_cox <- km_data_cox%>%mutate(surv= rowMeans(km_data_cox[,-1]))
  # da_cox <- data.frame(surv=plt_data_cox$surv, time=km_data_cox$time, group="Predicted(Cox)")
  # #cforestunbiased
  # args_crsfunb <- list(form=Surv(time, status)~., dat=train_dat, seedini=seedini)
  # fitcforest <- do.call("predmodcrsfunb", args_crsfunb)
  # mat_cforest <- suppressMessages(predictSurvProb(fitcforest, newdata = test_dat, times = dis_time))
  # 
  # km_data <- data.frame(time = dis_time, survival = t(mat_cforest))
  # 
  # plt_data <- km_data%>%mutate(surv= rowMeans(km_data[,-1]))
  # da1 <- data.frame(surv=plt_data$surv, time=km_data$time, group="Predicted(CRSF unbiased)")
  # 
  # 
  # #glmnet
  # covs <- colnames(fitrsf$xvar)
  # x1 <- model.matrix( ~ ., train_dat[, covs])[,-1]
  # x1_mean <- apply(x1, 2, mean)
  # x1_sd <- apply(x1, 2, sd)
  # x1_scaled <- scale(x1, center=x1_mean, scale=x1_sd)
  # y1 <- Surv(train_dat$time, train_dat$status)
  # ###
  lamb <- c()
  if(usecvlamb){
    cvfit <- {set.seed(seedini); cv.glmnet(x1_scaled, y1, family = "cox", type.measure = "C", nfolds=5)}
    lamb <- cvfit$lambda.min
  }else{
    lamb = best_lamb
  }
  # 
  # fit <- glmnet(x1_scaled, y1, family = "cox", lambda=lamb)
  # x2 <-  model.matrix( ~ ., test_dat[,covs])[,-1]
  # x2_mean <- apply(x2, 2, mean)
  # x2_sd <- apply(x2, 2, sd)
  # x2_scaled <- scale(x2, center=x1_mean, scale=x1_sd)
  # y2 <- Surv(test_dat$time, test_dat$status)
  # 
  # # # After fitting training coxph model
  # train_lp <- predict(fit, newx = x1_scaled, type = "link")
  # cox_train <- coxph(Surv(train_dat$time, train_dat$status) ~ offset(train_lp))
  # # Get baseline survival from training
  # train_baseline <- survfit(cox_train)
  # survest <- stepfun(train_baseline$time, c(1,  train_baseline$surv))
  # da_surv <- data.frame(surv=survest(dis_time), time=dis_time)
  # 
  # 
  # lp_new <- predict(fit, newx = x2_scaled, type = "link", times=dis_time)
  # rows <- length(dis_time)
  # cols <- nrow(lp_new)
  # res <- matrix(0, nrow = rows, ncol = cols)
  # 
  # # Fill the matrix using a for loop
  # for (i in 1:cols) {
  #   res[,i] <- (da_surv$surv)^exp(lp_new[i,])
  # }
  # km_data <- data.frame(time = da_surv$time, 
  #                       survival = res)
  # 
  # plt_data <- km_data%>%mutate(surv= rowMeans(km_data[,-1]))
  # da2 <- data.frame(surv=plt_data$surv, time= plt_data$time, 
  #                   group="Predicted(Lasso)")
  
  daf <- rbind(da, da_crsf)
  #daf <- da2
  p <-   ggplot(daf, aes(x = time, y = surv, color=group)) +
    geom_step(lwd=1.5) +
    labs(title = "Predicted KM Curves",
         x = "Time",
         y = "Survival Probability")+ scale_color_manual(values=c( "blue", "green"))+
    theme_classic2()
  
  daf1 <- daf%>%arrange(surv)%>%filter(surv <= 0.5)%>%arrange(desc(surv))
  # dplyr::summarize(med_surv=max(surv))%>%
  # left_join(daf%>%arrange(surv)%>%filter(surv>0.48 & surv <= 0.5))%>%arrange(time)
  daf2 <- daf1[!duplicated(daf1$group),]
  med <- daf2%>%dplyr::select(group, median_time=time)
  return(list(p, med, lamb, daf))
}

pred_plt_rsf <- function(train_dat=fintrain, test_dat=fintest,covs=covs, best_lamb =1e-04,
                          seedini=seedini, usecvlamb=FALSE, 
                          rsf_best=list(ntree=300, mtry=4, nodesize=11, seed=1234),
                          crsf_best = list(ntree=100, mtry=5, minbucket=3, mincriterion=0, seed=1234),
                          appr=1){
  
  #Model fit
  fitrsf = rfsrc(Surv(time, status)~., data = train_dat)
  
  ##Exact
  dis_time <- seq(0, max(train_dat$time), 0.01)
  dis_time_test <- seq(0, max(test_dat$time), 0.01)
  fit <- survfit(Surv(test_dat$time, test_dat$status)~1)
  
  survest <- stepfun(fit$time, c(1, fit$surv))
  da <- data.frame(surv=survest(dis_time_test), time=dis_time_test, group="Observed(KM)")
  
  #rsf
  args_rsf <- list(form=Surv(time, status)~., dat=train_dat,
                   ntree = rsf_best$ntree,
                   mtry = rsf_best$mtry,
                   nodesize = rsf_best$nodesize, seedini=rsf_best$seed, importance=FALSE)
  best_model_rsf <- do.call("predmodrsf", args_rsf)
  cindex_rsf <- SurvMetrics::Cindex(best_model_rsf, test_dat)[[1]]
  

  perror <- suppressMessages(pec(object=best_model_rsf,
                                 formula = Surv(time, status)~., cens.model="marginal",
                                 data=test_dat, verbose=F, maxtime=max(best_model_rsf$time.interest)))
  ibs_rsf <- ibs(perror, times=max(best_model_rsf$time.interest))[[2]]
  
  mat_rsf <- suppressMessages(predictSurvProb(best_model_rsf, newdata = test_dat, times = dis_time))
  km_data_rsf <- data.frame(time = dis_time, survival = t(mat_rsf))

  plt_data_rsf <- km_data_rsf%>%mutate(surv= rowMeans(km_data_rsf[,-1]))
  da_rsf <- data.frame(surv=plt_data_rsf$surv, time=km_data_rsf$time, group="Predicted(RSF)")
  # #cforest
  # args_crsf <- list(form=Surv(time, status)~., dat=train_dat,
  #                   ntree = crsf_best$ntree,
  #                   mtry = crsf_best$mtry,
  #                   minbucket = crsf_best$minbucket, 
  #                   mincriterion = crsf_best$mincriterion, seedini=crsf_best$seed)
  # best_model_crsf <- do.call("predmodcrsf", args_crsf)
  # mat_crsf <- suppressMessages(predictSurvProb(best_model_crsf, newdata = test_dat, times = dis_time))
  # km_data_crsf <- data.frame(time = dis_time, survival = t(mat_crsf))
  # 
  # plt_data_crsf <- km_data_crsf%>%mutate(surv= rowMeans(km_data_crsf[,-1]))
  # da_crsf <- data.frame(surv=plt_data_crsf$surv, time=km_data_crsf$time, group="Predicted(CRSF)")
  # 
  # #cox
  # args_cox <- list(form=Surv(time, status)~., dat=train_dat)
  # # best_model_cox <- do.call("predmodcox", args_cox)
  # args_tes_cox <- list(form=Surv(time, status)~., dat=test_dat)
  # model_cox_trnew <- do.call("predmodcox", args_cox)
  # 
  # model_cox_tenew <- do.call("predmodcox", args_tes_cox)
  # datrain <- cbind(model_cox_trnew$y, model_cox_trnew$x)
  # datest <- cbind(model_cox_tenew$y, model_cox_tenew$x)
  # 
  # coeff_fixed <- model_cox_trnew$coefficients
  # a <- row.names(as.data.frame(coeff_fixed[!is.na(coeff_fixed)]))
  # if(sum(colnames(datrain)[-c(1, 2)]!=a)==0){
  #   mat_cox <- suppressMessages(predictSurvProb(model_cox_trnew, newdata = test_dat, times = dis_time))
  # }else{
  #   form_new <- f.build("Surv(time, status)",a)
  #   model_coxnew<- coxph(form_new, data=as.data.frame(datrain), ties="breslow", x=TRUE)
  #   colnames(datest)
  #   mat_cox <- suppressMessages(predictSurvProb(model_coxnew, newdata = as.data.frame(datest), times = dis_time))
  #   
  # }
  # km_data_cox <- data.frame(time = dis_time, survival = t(mat_cox))
  # 
  # plt_data_cox <- km_data_cox%>%mutate(surv= rowMeans(km_data_cox[,-1]))
  # da_cox <- data.frame(surv=plt_data_cox$surv, time=km_data_cox$time, group="Predicted(Cox)")
  # #cforestunbiased
  # args_crsfunb <- list(form=Surv(time, status)~., dat=train_dat, seedini=seedini)
  # fitcforest <- do.call("predmodcrsfunb", args_crsfunb)
  # mat_cforest <- suppressMessages(predictSurvProb(fitcforest, newdata = test_dat, times = dis_time))
  # 
  # km_data <- data.frame(time = dis_time, survival = t(mat_cforest))
  # 
  # plt_data <- km_data%>%mutate(surv= rowMeans(km_data[,-1]))
  # da1 <- data.frame(surv=plt_data$surv, time=km_data$time, group="Predicted(CRSF unbiased)")
  # 
  # 
  # #glmnet
  # covs <- colnames(fitrsf$xvar)
  # x1 <- model.matrix( ~ ., train_dat[, covs])[,-1]
  # x1_mean <- apply(x1, 2, mean)
  # x1_sd <- apply(x1, 2, sd)
  # x1_scaled <- scale(x1, center=x1_mean, scale=x1_sd)
  # y1 <- Surv(train_dat$time, train_dat$status)
  # ###
  lamb <- c()
  if(usecvlamb){
    cvfit <- {set.seed(seedini); cv.glmnet(x1_scaled, y1, family = "cox", type.measure = "C", nfolds=5)}
    lamb <- cvfit$lambda.min
  }else{
    lamb = best_lamb
  }
  # 
  # fit <- glmnet(x1_scaled, y1, family = "cox", lambda=lamb)
  # x2 <-  model.matrix( ~ ., test_dat[,covs])[,-1]
  # x2_mean <- apply(x2, 2, mean)
  # x2_sd <- apply(x2, 2, sd)
  # x2_scaled <- scale(x2, center=x1_mean, scale=x1_sd)
  # y2 <- Surv(test_dat$time, test_dat$status)
  # 
  # # # After fitting training coxph model
  # train_lp <- predict(fit, newx = x1_scaled, type = "link")
  # cox_train <- coxph(Surv(train_dat$time, train_dat$status) ~ offset(train_lp))
  # # Get baseline survival from training
  # train_baseline <- survfit(cox_train)
  # survest <- stepfun(train_baseline$time, c(1,  train_baseline$surv))
  # da_surv <- data.frame(surv=survest(dis_time), time=dis_time)
  # 
  # 
  # lp_new <- predict(fit, newx = x2_scaled, type = "link", times=dis_time)
  # rows <- length(dis_time)
  # cols <- nrow(lp_new)
  # res <- matrix(0, nrow = rows, ncol = cols)
  # 
  # # Fill the matrix using a for loop
  # for (i in 1:cols) {
  #   res[,i] <- (da_surv$surv)^exp(lp_new[i,])
  # }
  # km_data <- data.frame(time = da_surv$time, 
  #                       survival = res)
  # 
  # plt_data <- km_data%>%mutate(surv= rowMeans(km_data[,-1]))
  # da2 <- data.frame(surv=plt_data$surv, time= plt_data$time, 
  #                   group="Predicted(Lasso)")
  
  daf <- rbind(da, da_rsf)
  #daf <- da2
  
  p <-   ggplot(daf, aes(x = time, y = surv, color=group)) +
    geom_step(lwd=1.5) +
    labs(title = "Predicted KM Curves",
         x = "Time",
         y = "Survival Probability")+ scale_color_manual(values=c( "blue", "green"))+
    scale_y_continuous(expand = c(0, 0), breaks = seq(0, 1, by = 0.1)) +
    scale_x_continuous(expand = c(0, 0), breaks = seq(0,ceiling(max(daf$time)) , by = 2)) +
    coord_cartesian(ylim = c(0, 1))+
    theme_classic2()+
    theme(legend.position = "bottom")
  
  daf1 <- daf%>%arrange(surv)%>%filter(surv <= 0.5)%>%arrange(desc(surv))
  # dplyr::summarize(med_surv=max(surv))%>%
  # left_join(daf%>%arrange(surv)%>%filter(surv>0.48 & surv <= 0.5))%>%arrange(time)
  daf2 <- daf1[!duplicated(daf1$group),]
  med <- daf2%>%dplyr::select(group, median_time=time)
  return(list(p, med, lamb, daf, cindex_rsf, ibs_rsf))
}

pred_plt_rsf_ <- function(train_dat=fintrain, test_dat=fintest,covs=covs, best_lamb =1e-04,
                     seedini=seedini, usecvlamb=FALSE, 
                     rsf_best=list(ntree=300, mtry=4, nodesize=11, seed=1234),
                     crsf_best = list(ntree=100, mtry=5, minbucket=3, mincriterion=0, seed=1234),
                     appr=1){
  
  #Model fit
  fitrsf = rfsrc(Surv(time, status)~., data = train_dat)
  
  ##Exact
  dis_time <- seq(0, max(train_dat$time), 0.01)
  dis_time_test <- seq(0, max(test_dat$time), 0.01)
  fit <- survfit(Surv(test_dat$time, test_dat$status)~1)
  
  survest <- stepfun(fit$time, c(1, fit$surv))
  da <- data.frame(surv=survest(dis_time_test), time=dis_time_test, group="Observed(KM)")
  
  #rsf
  args_rsf <- list(form=Surv(time, status)~., dat=train_dat,
                   ntree = rsf_best$ntree,
                   mtry = rsf_best$mtry,
                   nodesize = rsf_best$nodesize, seedini=rsf_best$seed, importance=FALSE)
  best_model_rsf <- do.call("predmodrsf", args_rsf)
  mat_rsf <- suppressMessages(predictSurvProb(best_model_rsf, newdata = test_dat, times = dis_time))
  km_data_rsf <- data.frame(time = dis_time, survival = t(mat_rsf))
  
  plt_data_rsf <- km_data_rsf%>%mutate(surv= rowMeans(km_data_rsf[,-1]))
  da_rsf <- data.frame(surv=plt_data_rsf$surv, time=km_data_rsf$time, group="Predicted(RSF)")
  #cforest
  args_crsf <- list(form=Surv(time, status)~., dat=train_dat,
                    ntree = crsf_best$ntree,
                    mtry = crsf_best$mtry,
                    minbucket = crsf_best$minbucket, 
                    mincriterion = crsf_best$mincriterion, seedini=crsf_best$seed)
  best_model_crsf <- do.call("predmodcrsf", args_crsf)
  mat_crsf <- suppressMessages(predictSurvProb(best_model_crsf, newdata = test_dat, times = dis_time))
  km_data_crsf <- data.frame(time = dis_time, survival = t(mat_crsf))
  
  plt_data_crsf <- km_data_crsf%>%mutate(surv= rowMeans(km_data_crsf[,-1]))
  da_crsf <- data.frame(surv=plt_data_crsf$surv, time=km_data_crsf$time, group="Predicted(CRSF)")
  
  # #cox
  # args_cox <- list(form=Surv(time, status)~., dat=train_dat)
  # # best_model_cox <- do.call("predmodcox", args_cox)
  # args_tes_cox <- list(form=Surv(time, status)~., dat=test_dat)
  # model_cox_trnew <- do.call("predmodcox", args_cox)
  # 
  # model_cox_tenew <- do.call("predmodcox", args_tes_cox)
  # datrain <- cbind(model_cox_trnew$y, model_cox_trnew$x)
  # datest <- cbind(model_cox_tenew$y, model_cox_tenew$x)
  # 
  # coeff_fixed <- model_cox_trnew$coefficients
  # a <- row.names(as.data.frame(coeff_fixed[!is.na(coeff_fixed)]))
  # if(sum(colnames(datrain)[-c(1, 2)]!=a)==0){
  #   mat_cox <- suppressMessages(predictSurvProb(model_cox_trnew, newdata = test_dat, times = dis_time))
  # }else{
  #   form_new <- f.build("Surv(time, status)",a)
  #   model_coxnew<- coxph(form_new, data=as.data.frame(datrain), ties="breslow", x=TRUE)
  #   colnames(datest)
  #   mat_cox <- suppressMessages(predictSurvProb(model_coxnew, newdata = as.data.frame(datest), times = dis_time))
  #   
  # }
  # km_data_cox <- data.frame(time = dis_time, survival = t(mat_cox))
  # 
  # plt_data_cox <- km_data_cox%>%mutate(surv= rowMeans(km_data_cox[,-1]))
  # da_cox <- data.frame(surv=plt_data_cox$surv, time=km_data_cox$time, group="Predicted(Cox)")
  # #cforestunbiased
  # args_crsfunb <- list(form=Surv(time, status)~., dat=train_dat, seedini=seedini)
  # fitcforest <- do.call("predmodcrsfunb", args_crsfunb)
  # mat_cforest <- suppressMessages(predictSurvProb(fitcforest, newdata = test_dat, times = dis_time))
  # 
  # km_data <- data.frame(time = dis_time, survival = t(mat_cforest))
  # 
  # plt_data <- km_data%>%mutate(surv= rowMeans(km_data[,-1]))
  # da1 <- data.frame(surv=plt_data$surv, time=km_data$time, group="Predicted(CRSF unbiased)")
  # 
  # 
  # #glmnet
  # covs <- colnames(fitrsf$xvar)
  # x1 <- model.matrix( ~ ., train_dat[, covs])[,-1]
  # x1_mean <- apply(x1, 2, mean)
  # x1_sd <- apply(x1, 2, sd)
  # x1_scaled <- scale(x1, center=x1_mean, scale=x1_sd)
  # y1 <- Surv(train_dat$time, train_dat$status)
  # ###
  lamb <- c()
  # if(usecvlamb){
  #   cvfit <- {set.seed(seedini); cv.glmnet(x1_scaled, y1, family = "cox", type.measure = "C", nfolds=5)}
  #   lamb <- cvfit$lambda.min
  # }else{
  #   lamb = best_lamb
  # }
  # 
  # fit <- glmnet(x1_scaled, y1, family = "cox", lambda=lamb)
  # x2 <-  model.matrix( ~ ., test_dat[,covs])[,-1]
  # x2_mean <- apply(x2, 2, mean)
  # x2_sd <- apply(x2, 2, sd)
  # x2_scaled <- scale(x2, center=x1_mean, scale=x1_sd)
  # y2 <- Surv(test_dat$time, test_dat$status)
  # 
  # # # After fitting training coxph model
  # train_lp <- predict(fit, newx = x1_scaled, type = "link")
  # cox_train <- coxph(Surv(train_dat$time, train_dat$status) ~ offset(train_lp))
  # # Get baseline survival from training
  # train_baseline <- survfit(cox_train)
  # survest <- stepfun(train_baseline$time, c(1,  train_baseline$surv))
  # da_surv <- data.frame(surv=survest(dis_time), time=dis_time)
  # 
  # 
  # lp_new <- predict(fit, newx = x2_scaled, type = "link", times=dis_time)
  # rows <- length(dis_time)
  # cols <- nrow(lp_new)
  # res <- matrix(0, nrow = rows, ncol = cols)
  # 
  # # Fill the matrix using a for loop
  # for (i in 1:cols) {
  #   res[,i] <- (da_surv$surv)^exp(lp_new[i,])
  # }
  # km_data <- data.frame(time = da_surv$time, 
  #                       survival = res)
  # 
  # plt_data <- km_data%>%mutate(surv= rowMeans(km_data[,-1]))
  # da2 <- data.frame(surv=plt_data$surv, time= plt_data$time, 
  #                   group="Predicted(Lasso)")
  # 
  daf <- rbind( da, da_rsf, da_crsf)
  #daf <- da2
  
  p <-   ggplot(daf, aes(x = time, y = surv, color=group)) +
    geom_step(lwd=1.5) +
    labs(title = "Predicted KM Curves",
         x = "Time",
         y = "Survival Probability")+ scale_color_manual(values=c( "black", "green", "blue"))+
    scale_y_continuous(expand = c(0, 0), breaks = seq(0, 1, by = 0.1)) +
    scale_x_continuous(expand = c(0, 0), breaks = seq(0,ceiling(max(daf$time)) , by = 2)) +
    coord_cartesian(ylim = c(0, 1))+
    theme_classic2()+
    theme(legend.position = "bottom")
  
  daf1 <- daf%>%arrange(surv)%>%filter(surv <= 0.5)%>%arrange(desc(surv))
  # dplyr::summarize(med_surv=max(surv))%>%
  # left_join(daf%>%arrange(surv)%>%filter(surv>0.48 & surv <= 0.5))%>%arrange(time)
  daf2 <- daf1[!duplicated(daf1$group),]
  med <- daf2%>%dplyr::select(group, median_time=time)
  return(list(p, med, lamb, daf))
}

argsdef <- list(train_dat=fintrain, test_dat=fintest,covs=covs, 
                best_lamb =1e-04,
                seedini=1234, usecvlamb=FALSE, 
                rsf_best = rsf_best, crsf_best=crsf_best, appr=2)

pred_plt_crsf_wt <- function(train_dat=fintrain, test_dat=fintest,covs=covs, best_lamb =1e-04,
                          seedini=seedini, usecvlamb=FALSE, 
                          rsf_best=list(ntree=300, mtry=4, nodesize=11, seed=1234),
                          crsf_best = list(ntree=100, mtry=5, minbucket=3, mincriterion=0, seed=1234),
                          appr=1, weight=NULL){
  
  #Model fit
  fitrsf = rfsrc(Surv(time, status)~., data = train_dat)
  
  ##Exact
  dis_time <- seq(0, round(max(train_dat$time), 0), 0.01)
  weight<- c(1, 2, 5, rep(5, nrow(test_dat)-3))
  fit <- survfit(Surv(test_dat$time, test_dat$status)~1, weights=weight)
  
  survest <- stepfun(fit$time, c(1, fit$surv))
  da <- data.frame(surv=survest(dis_time), time=dis_time, group="Observed(KM)")
  
  #cforest
  args_crsf <- list(form=Surv(time, status)~., dat=train_dat,
                    ntree = crsf_best$ntree,
                    mtry = crsf_best$mtry,
                    minbucket = crsf_best$minbucket, 
                    mincriterion = crsf_best$mincriterion, seedini=crsf_best$seed)
  best_model_crsf <- do.call("predmodcrsf", args_crsf)
  mat_crsf <- suppressMessages(predictSurvProb(best_model_crsf, newdata = test_dat, times = dis_time))
  da <- cbind(mat_crsf, weight)
  dim(da)
  km_data_crsf <- data.frame(time = dis_time, survival = t(mat_crsf))
  
  plt_data_crsf <- km_data_crsf%>%
                   mutate(surv= rowMeans(km_data_crsf[,-1]))
  da_crsf <- data.frame(surv=plt_data_crsf$surv, time=km_data_crsf$time, group="Predicted(CRSF)")
  # 
  # #cox
  # args_cox <- list(form=Surv(time, status)~., dat=train_dat)
  # # best_model_cox <- do.call("predmodcox", args_cox)
  # args_tes_cox <- list(form=Surv(time, status)~., dat=test_dat)
  # model_cox_trnew <- do.call("predmodcox", args_cox)
  # 
  # model_cox_tenew <- do.call("predmodcox", args_tes_cox)
  # datrain <- cbind(model_cox_trnew$y, model_cox_trnew$x)
  # datest <- cbind(model_cox_tenew$y, model_cox_tenew$x)
  # 
  # coeff_fixed <- model_cox_trnew$coefficients
  # a <- row.names(as.data.frame(coeff_fixed[!is.na(coeff_fixed)]))
  # if(sum(colnames(datrain)[-c(1, 2)]!=a)==0){
  #   mat_cox <- suppressMessages(predictSurvProb(model_cox_trnew, newdata = test_dat, times = dis_time))
  # }else{
  #   form_new <- f.build("Surv(time, status)",a)
  #   model_coxnew<- coxph(form_new, data=as.data.frame(datrain), ties="breslow", x=TRUE)
  #   colnames(datest)
  #   mat_cox <- suppressMessages(predictSurvProb(model_coxnew, newdata = as.data.frame(datest), times = dis_time))
  #   
  # }
  # km_data_cox <- data.frame(time = dis_time, survival = t(mat_cox))
  # 
  # plt_data_cox <- km_data_cox%>%mutate(surv= rowMeans(km_data_cox[,-1]))
  # da_cox <- data.frame(surv=plt_data_cox$surv, time=km_data_cox$time, group="Predicted(Cox)")
  # #cforestunbiased
  # args_crsfunb <- list(form=Surv(time, status)~., dat=train_dat, seedini=seedini)
  # fitcforest <- do.call("predmodcrsfunb", args_crsfunb)
  # mat_cforest <- suppressMessages(predictSurvProb(fitcforest, newdata = test_dat, times = dis_time))
  # 
  # km_data <- data.frame(time = dis_time, survival = t(mat_cforest))
  # 
  # plt_data <- km_data%>%mutate(surv= rowMeans(km_data[,-1]))
  # da1 <- data.frame(surv=plt_data$surv, time=km_data$time, group="Predicted(CRSF unbiased)")
  # 
  # 
  # #glmnet
  # covs <- colnames(fitrsf$xvar)
  # x1 <- model.matrix( ~ ., train_dat[, covs])[,-1]
  # x1_mean <- apply(x1, 2, mean)
  # x1_sd <- apply(x1, 2, sd)
  # x1_scaled <- scale(x1, center=x1_mean, scale=x1_sd)
  # y1 <- Surv(train_dat$time, train_dat$status)
  # ###
  lamb <- c()
  if(usecvlamb){
    cvfit <- {set.seed(seedini); cv.glmnet(x1_scaled, y1, family = "cox", type.measure = "C", nfolds=5)}
    lamb <- cvfit$lambda.min
  }else{
    lamb = best_lamb
  }
  # 
  # fit <- glmnet(x1_scaled, y1, family = "cox", lambda=lamb)
  # x2 <-  model.matrix( ~ ., test_dat[,covs])[,-1]
  # x2_mean <- apply(x2, 2, mean)
  # x2_sd <- apply(x2, 2, sd)
  # x2_scaled <- scale(x2, center=x1_mean, scale=x1_sd)
  # y2 <- Surv(test_dat$time, test_dat$status)
  # 
  # # # After fitting training coxph model
  # train_lp <- predict(fit, newx = x1_scaled, type = "link")
  # cox_train <- coxph(Surv(train_dat$time, train_dat$status) ~ offset(train_lp))
  # # Get baseline survival from training
  # train_baseline <- survfit(cox_train)
  # survest <- stepfun(train_baseline$time, c(1,  train_baseline$surv))
  # da_surv <- data.frame(surv=survest(dis_time), time=dis_time)
  # 
  # 
  # lp_new <- predict(fit, newx = x2_scaled, type = "link", times=dis_time)
  # rows <- length(dis_time)
  # cols <- nrow(lp_new)
  # res <- matrix(0, nrow = rows, ncol = cols)
  # 
  # # Fill the matrix using a for loop
  # for (i in 1:cols) {
  #   res[,i] <- (da_surv$surv)^exp(lp_new[i,])
  # }
  # km_data <- data.frame(time = da_surv$time, 
  #                       survival = res)
  # 
  # plt_data <- km_data%>%mutate(surv= rowMeans(km_data[,-1]))
  # da2 <- data.frame(surv=plt_data$surv, time= plt_data$time, 
  #                   group="Predicted(Lasso)")
  
  daf <- rbind(da, da_crsf)
  #daf <- da2
  p <-   ggplot(daf, aes(x = time, y = surv, color=group)) +
    geom_step(lwd=1.5) +
    labs(title = "Predicted KM Curves",
         x = "Time",
         y = "Survival Probability")+ scale_color_manual(values=c( "blue", "green"))+
    theme_classic2()
  
  daf1 <- daf%>%arrange(surv)%>%filter(surv <= 0.5)%>%arrange(desc(surv))
  # dplyr::summarize(med_surv=max(surv))%>%
  # left_join(daf%>%arrange(surv)%>%filter(surv>0.48 & surv <= 0.5))%>%arrange(time)
  daf2 <- daf1[!duplicated(daf1$group),]
  med <- daf2%>%dplyr::select(group, median_time=time)
  return(list(p, med, lamb, daf))
}


pred_plt_rsf_wt_tst<- function(train_dat=fintrain, test_dat=fintest,covs=covs, best_lamb =1e-04,
                               seedini=seedini, usecvlamb=FALSE, 
                               rsf_best=list(ntree=300, mtry=4, nodesize=11, seed=1234),
                               crsf_best = list(ntree=100, mtry=5, minbucket=3, mincriterion=0, seed=1234),
                               appr=1, weight=NULL){
  
  #Model fit
  fitrsf = rfsrc(Surv(time, status)~., data = train_dat)
  
  ##Exact
  dis_time <- seq(0, round(max(train_dat$time), 0), 0.01)
  weight<- c(1, 2, 5, rep(0, nrow(test_dat)-3))
  fit <- survfit(Surv(test_dat$time, test_dat$status)~1, weights=weight)
  
  survest <- stepfun(fit$time, c(1, fit$surv))
  da <- data.frame(surv=survest(dis_time), time=dis_time, group="Observed(KM)")
  
  #cforest
  args_crsf <- list(form=Surv(time, status)~., dat=train_dat,
                    ntree = crsf_best$ntree,
                    mtry = crsf_best$mtry,
                    minbucket = crsf_best$minbucket, 
                    mincriterion = crsf_best$mincriterion, seedini=crsf_best$seed)
  best_model_crsf <- do.call("predmodcrsf", args_crsf)
  mat_crsf <- suppressMessages(predictSurvProb(best_model_crsf, newdata = test_dat, times = dis_time))
  mat_crsf_wt <- mat_crsf*weight
  
  da <- cbind(mat_crsf, weight)
  dim(test_dat)
  dim(mat_crsf)
  km_data_crsf <- data.frame(time = dis_time, survival = t(mat_crsf_wt))
  View()
  plt_data_crsf <- km_data_crsf%>%
    mutate(surv= rowMeans(km_data_crsf[,-1]))
  da_crsf <- data.frame(surv=plt_data_crsf$surv, time=km_data_crsf$time, group="Predicted(CRSF)")
  
  lamb <- c()
  if(usecvlamb){
    cvfit <- {set.seed(seedini); cv.glmnet(x1_scaled, y1, family = "cox", type.measure = "C", nfolds=5)}
    lamb <- cvfit$lambda.min
  }else{
    lamb = best_lamb
  }
  
  
  daf <- rbind(da, da_crsf)
  #daf <- da2
  p <-   ggplot(daf, aes(x = time, y = surv, color=group)) +
    geom_step(lwd=1.5) +
    labs(title = "Predicted KM Curves",
         x = "Time",
         y = "Survival Probability")+ scale_color_manual(values=c( "blue", "green"))+
    theme_classic2()
  
  daf1 <- daf%>%arrange(surv)%>%filter(surv <= 0.5)%>%arrange(desc(surv))
  # dplyr::summarize(med_surv=max(surv))%>%
  # left_join(daf%>%arrange(surv)%>%filter(surv>0.48 & surv <= 0.5))%>%arrange(time)
  daf2 <- daf1[!duplicated(daf1$group),]
  med <- daf2%>%dplyr::select(group, median_time=time)
  return(list(p, med, lamb, daf))
}