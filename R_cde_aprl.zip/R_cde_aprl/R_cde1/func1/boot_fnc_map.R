#median_function(testdat=testdat, covs=covs, data=traindat)
source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll_PDAC_v1/func/pred_plt_km_v1.R")
median_function <- function(testdat, covs, data, seedini, usecvlamb=usecvlamb, appr=appr) {
  d <- data
  plt <- pred_plt(train_dat=d, test_dat=testdat,covs=covs, best_lamb =1e-04,
                  seedini=seedini, usecvlamb=usecvlamb, appr=appr)[[2]]
  res11 <- setDT(plt)[group=="Predicted(CRSF)",]
  res12 <- setDT(plt)[group=="Predicted(Lasso)",]
  res13 <- setDT(plt)[group=="Observed(KM)",]
  res14 <- setDT(plt)[group=="Predicted(CRSF unbiased)",]
  res15 <- setDT(plt)[group=="Predicted(Cox)",]
  res16 <- setDT(plt)[group=="Predicted(RSF)",]
  if(nrow(res11)==1){
    rescfor <- res11$median_time
  }else{
    rescfor <- NA
  }
  if(nrow(res12)==1){
    reslaso <- res12$median_time
  }else{
    reslaso <- NA
  }
  if(nrow(res13)==1){
    resobs <- res13$median_time
  }else{
    resobs <- NA
  }
  
  if(nrow(res14)==1){
    rescrsfunb <- res14$median_time
  }else{
    rescrsfunb <- NA
  }
  
  if(nrow(res15)==1){
    rescox <- res15$median_time
  }else{
    rescox <- NA
  }
  
  if(nrow(res16)==1){
    resrsf <- res16$median_time
  }else{
    resrsf <- NA
  }
  
  return(c(rescfor, reslaso, resobs, rescrsfunb, rescox, resrsf)) #return coefficient estimates of model
}



bootres_map <- function(traindat=fintrain, testdat = fintest, covs = covs, 
                    rep=20, seedini=seedini){

  res <- map(1:rep, function(.y){
    cat("Running bootstrap", .y, "\n")
    #Running bootstrap
    model_bootstrap <- median_function(testdat=testdat, covs=covs, 
                                       data=traindat[{set.seed(seedini+.y);sample(1:nrow(traindat), 
                                      nrow(traindat), replace = TRUE)}, ],seedini=seedini,
                                       usecvlamb=TRUE, appr=2)

    return(c(model_bootstrap[1], model_bootstrap[2], model_bootstrap[3],
             model_bootstrap[4], model_bootstrap[5], model_bootstrap[6]))
  })
  res1 <- do.call("rbind", res)
  sample_val1 <- res1[,1]
  sample_val2 <- res1[,2]
  sample_val3 <- res1[,3]
  sample_val4 <- res1[,4]
  sample_val5 <- res1[,5]
  sample_val6 <- res1[,6]
  
  est <- median_function(testdat=testdat, covs=covs, data=traindat, seedini=seedini, usecvlamb=TRUE, appr=2)
  
  if(sum(is.na(sample_val1))==length(sample_val1)){
    intr1=c(NA, NA)}else{
      intr1 <- quantile(sample_val1, c(0.025, 0.975), na.rm=T)
    }
  
  if(sum(is.na(sample_val2))==length(sample_val2)){
    intr2=c(NA, NA)}else{
      intr2 <- quantile(sample_val2, c(0.025, 0.975), na.rm=T)
    }
  
  if(sum(is.na(sample_val3))==length(sample_val3)){
    intr3 <- c(NA, NA)}else{
      intr3 <- quantile(sample_val3, c(0.025, 0.975), na.rm=T)
    }
  
  if(sum(is.na(sample_val4))==length(sample_val4)){
    intr4 <- c(NA, NA)}else{
      intr4 <- quantile(sample_val4, c(0.025, 0.975), na.rm=T)
    }
  if(sum(is.na(sample_val5))==length(sample_val5)){
    intr5 <- c(NA, NA)}else{
      intr5 <- quantile(sample_val5, c(0.025, 0.975), na.rm=T)
    }
  if(sum(is.na(sample_val6))==length(sample_val6)){
    intr6 <- c(NA, NA)}else{
      intr6 <- quantile(sample_val6, c(0.025, 0.975), na.rm=T)
    }
  
  res_cforest<- paste(round(est[1], 2), "(", round(intr1[[1]], 2), ",", round(intr1[[2]], 2), ")")
  res_lasso<- paste(round(est[2], 2), "(", round(intr2[[1]], 2), ",", round(intr2[[2]], 2), ")")
  res_obs <- paste(round(est[3], 2), "(", round(intr3[[1]], 2), ",", round(intr3[[2]], 2), ")")
  res_crsfunb <- paste(round(est[4], 2), "(", round(intr4[[1]], 2), ",", round(intr4[[2]], 2), ")")
  res_cox <- paste(round(est[5], 2), "(", round(intr5[[1]], 2), ",", round(intr5[[2]], 2), ")")
  res_rsf <- paste(round(est[6], 2), "(", round(intr6[[1]], 2), ",", round(intr6[[2]], 2), ")")
  
  return(list(cfres=res_cforest, lassores=res_lasso, obsres = res_obs,
              crsfunbres= res_crsfunb, coxres=res_cox, rsfres=res_rsf))
}
#####################################################
#CRSF/RSF only
#####################################################
median_function_rsf_ <- function(testdat, covs, data, seedini, usecvlamb=usecvlamb, rsf_best= rsf_best,
                                 crsf_best = crsf_best, appr=appr) {
  d <- data
  plt <- pred_plt_rsf_(train_dat=d, test_dat=testdat,covs=covs, best_lamb =1e-04,
                  seedini=seedini, usecvlamb=usecvlamb, rsf_best= rsf_best,
                  crsf_best = crsf_best, appr=appr)[[2]]
  res11 <- setDT(plt)[group=="Predicted(CRSF)",]
  res16 <- setDT(plt)[group=="Predicted(RSF)",]
  if(nrow(res11)==1){
    rescfor <- res11$median_time
  }else{
    rescfor <- NA
  }
  
  if(nrow(res16)==1){
    resrsf <- res16$median_time
  }else{
    resrsf <- NA
  }
  
  return(c(rescfor, resrsf)) #return coefficient estimates of model
}



bootres_map_rsfcrsf <- function(traindat=fintrain, testdat = fintest, covs = covs, 
                        rep=20, rsf_best= rsf_best,
                        crsf_best = crsf_best, usecvlamb=usecvlamb, seedini=seedini){
  
  res <- map(1:rep, function(.y){
    cat("Running bootstrap", .y, "\n")
    #Running bootstrap
    model_bootstrap <- median_function_rsf_(testdat=testdat, covs=covs, 
                                       data=traindat[{set.seed(seedini+.y);sample(1:nrow(traindat), 
                                                                                  nrow(traindat), replace = TRUE)}, ],seedini=seedini,
                                       usecvlamb=usecvlamb, rsf_best= rsf_best,
                                       crsf_best = crsf_best, appr=2)
    
    return(c(model_bootstrap[1], model_bootstrap[2]))
  })
  res1 <- do.call("rbind", res)
  sample_val1 <- res1[,1]
  sample_val2 <- res1[,2]
  
  est <- median_function_rsf_(testdat=testdat, covs=covs, data=traindat, seedini=seedini, usecvlamb=usecvlamb, rsf_best= rsf_best,
                              crsf_best = crsf_best, appr=2)
  
  if(sum(is.na(sample_val1))==length(sample_val1)){
    intr1=c(NA, NA)}else{
      intr1 <- quantile(sample_val1, c(0.025, 0.975), na.rm=T)
    }
  
  if(sum(is.na(sample_val2))==length(sample_val2)){
    intr2=c(NA, NA)}else{
      intr2 <- quantile(sample_val2, c(0.025, 0.975), na.rm=T)
    }
  
  
  res_cforest<- paste(round(est[1], 2), "(", round(intr1[[1]], 2), ",", round(intr1[[2]], 2), ")")
  res_rfs<- paste(round(est[2], 2), "(", round(intr2[[1]], 2), ",", round(intr2[[2]], 2), ")")
  
  return(list(cfres=res_cforest, rfres=res_rfs))
}

##############
##RSF only
################
############
bootres_map_rsf <- function(traindat=fintrain, testdat = fintest, covs = covs, 
                             rep=20, rsf_best= rsf_best,
                             crsf_best = crsf_best, usecvlamb=usecvlamb, seedini=seedini){
  
  res <- map(1:rep, function(.y){
    cat("Running bootstrap", .y, "\n")
    #Running bootstrap
    model_bootstrap <- median_function_rsf(testdat=testdat, covs=covs, 
                                            data=traindat[{set.seed(seedini+.y);sample(1:nrow(traindat), 
                                                                                       nrow(traindat), replace = TRUE)}, ],seedini=seedini,
                                            usecvlamb=usecvlamb, rsf_best= rsf_best,
                                            crsf_best = crsf_best, appr=2)
    
    return(c(model_bootstrap[1]))
  })
  res1 <- do.call("rbind", res)
  sample_val1 <- res1[,1]
  
  
  est <- median_function_crsf(testdat=testdat, covs=covs, data=traindat, seedini=seedini, usecvlamb=usecvlamb, rsf_best= rsf_best,
                              crsf_best = crsf_best, appr=2)
  
  if(sum(is.na(sample_val1))==length(sample_val1)){
    intr1=c(NA, NA)}else{
      intr1 <- quantile(sample_val1, c(0.025, 0.975), na.rm=T)
    }
  
  
  
  res_cforest<- paste(round(est[1], 2), "(", round(intr1[[1]], 2), ",", round(intr1[[2]], 2), ")")
  
  return(list(cfres=res_cforest, med_val=sample_val1))
}