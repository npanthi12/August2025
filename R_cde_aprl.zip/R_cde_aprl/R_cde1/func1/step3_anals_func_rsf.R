
source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll_PDAC_v1/func/rsf_func.R")
library(haven)
library(data.table)
library(dtplyr)
library(survminer)
library(dplyr)
library(Hmisc)
library(AICcmodavg)
library(car)
library(broom)
library(cobalt)
library(ipw)
library(survey)
library(WeightIt)
library(glmtoolbox)
library(MatchIt)
library(MuMIn)
library(purrr)
library("survival")
library("survminer")
library(emmeans)
library(randomForestSRC)
library(ranger)
library(openxlsx)
library(randomForest)
library(dplyr)
library(ggraph)
library(igraph)
library(caret)
library(rpart.plot)
library(rpart)
library(party)
library(ggsurvfit)
library(visdat)
library(plotly)
library(GGally)
library(permimp)
library(DT)
library(ggsurvfit)
library(ggcorrplot)
library(tidyverse)
library(rcompanion)
library(knitr)
library(polycor)
library(StepReg)
library(pec)
library(SurvMetrics)
library(caret)
library(glmnet)


resd_rsf <- function(num_folds=num_inner_folds, datin=findat2a, 
                     params=param_grid, seedini=seedini, iter=j){
  fold <-  {set.seed(seedini); createFolds(datin$status, k=num_folds)}
  cindex_values <- c()
  for(k in 1:num_folds){
    #Split into inner training and validation sets
    cat("Running  param_grid", iter, "of", nrow(params), "in inner fold", k, "of", num_folds, "\n")
    inner_train <- datin[-fold[[k]],]%>%arrange(time, status)
    inner_valid <- datin[fold[[k]],]%>%arrange(time, status)
    #Train RSF model with current hyperparameters
    args <- list(form=Surv(time, status)~., dat=inner_train,
                 ntree = params$ntree[iter],
                 mtry = params$mtry[iter],
                 nodesize = params$nodesize[iter], seedini=seedini, importance=FALSE)
    rsf_model<- do.call("predmodrsf", args)
    cindex_rsf <- SurvMetrics::Cindex(rsf_model, inner_valid)[[1]]
    
    # model <- rfsrc(Surv(time, status)~., data = inner_train)
    # distime <- model$time.interest  #get the survival time of events
    # 
    # med_index <- median(1:length(distime))
    # # # Extract C-index (last error rate)
    # mat_cforest <- suppressMessages(predictSurvProb(rsfm, newdata = inner_valid, times = distime))
    # vec_rsf <- mat_cforest[ ,med_index]  #median survival probability of all samples
    # times <- inner_valid$time
    # status <- inner_valid$status
    # cindex_rsf <- SurvMetrics::Cindex(Surv(times, status), round(vec_rsf,6))[[1]]
    
    # pred <- cdex1(object=rsfm, tes=inner_valid)
    # rescalc <- calc_con(time=inner_valid$time, status= inner_valid$status, predicted=round(pred,6))
    # cindex_rsf <- (rescalc[[1]] + rescalc[[2]])/rescalc[[3]]
    #cindex_rsf <- mean(pred)
    cindex_values <- c(cindex_values, cindex_rsf)
  }
  return(list(cindex_values, rsf_model))
}


predmod.rsf <- function(dat=findat2a, params=NULL, num_inner_folds=num_inner_folds,
                        seedini=seedini, covs=covs,..){
  param_grid <- expand.grid(
    ntree =params$ntree,  # Number of trees
    mtry =  params$mtry,          # Number of features to split at each node
    nodesize =params$nodesize      # Minimum size of terminal nodes
  )
  best_model <- NULL
  best_cindex <- 0
  best_params <- data.frame()
  for(j in 1:nrow(param_grid)){
    cat("Running param_grid", j, "of", nrow(param_grid), "\n")
    param_res <- resd_rsf(num_folds=num_inner_folds, datin=dat, 
                          params=param_grid, seed=seedini, iter=j)
    cindex_values <- param_res[[1]]
    rsf_m <- param_res[[2]]
    #Compute mean C-index for this hyperparameter set
    mean_cindex <- mean(cindex_values, na.rm=T)
    #Track best model
    if(mean_cindex > best_cindex){
      best_cindex <- mean_cindex
      best_model <- rsf_m
    }
    
  }
  
  best_params <- data.frame(ntree=best_model$ntree, mtry=best_model$mtry,
                            nodesize=best_model$nodesize, seed=seedini, cindex=best_cindex)
  
  args_best <- list(form=Surv(time, status)~., dat=dat,
                    ntree =  best_params$ntree,
                    mtry = best_params$mtry,
                    nodesize =  best_params$nodesize, seed=seedini, importance=TRUE)
  best_modelc <- do.call("predmodrsf", args_best)
  
  mod_cindex <- SurvMetrics::Cindex(best_modelc, dat)[[1]]
  
  # distime <- best_modelc$time.interest  #get the survival time of events
  # med_index <- median(1:length(distime)) 
  # # Extract C-index (last error rate)
  # mat_cforest <- suppressMessages(predictSurvProb(best_modelc, newdata = dat, times = distime))
  # vec_rsf <- mat_cforest[ ,med_index]  #median survival probability of all samples
  # times <- dat$time
  # status <- dat$status
  # mod_cindex <- SurvMetrics::Cindex(Surv(times, status), round(vec_rsf,6))[[1]]
  
  
  
  
  
  impt <- as.data.frame(best_modelc$importance)
  #imptvarsel <- var.select(Surv(time, status)~., dat, method="md") 
  imptvarsel <- var.select(best_modelc)
  imptvarsel1 <- imptvarsel$varselect
  imptvarsel2_ <- imptvarsel1%>%arrange(desc(vimp))
  imptvarsel2 <- imptvarsel2_%>%mutate(var=row.names(imptvarsel2_))%>%dplyr::select(var, everything())
  #brier_imp <- vimp(best_model, perf.type = "brier")$importance
  colnames(impt) <- "imp"
  imp1 <- impt%>%mutate(var=row.names(impt))%>%dplyr::select(var, imp)%>%arrange(desc(imp))
  row.names(imp1) <- NULL
  return(list(imp1, imptvarsel2, best_params, data.frame(mod_cindex=mod_cindex, cv_cindex=best_cindex,
                                                         oob_cindex= 1-best_modelc$err.rate[length(best_modelc$err.rate)])))
}

# predmod.crsfunbias <- function(dat=dat, params=NULL, seedini=seedini,  num_inner_folds=num_inner_folds, covs=covs){
#   ##CRF unbiased
#   model <- {set.seed(seedini); party::cforest(f.build("Surv(time, status)", covs), data = dat,
#                                               controls = cforest_unbiased())}
#   imp <- suppressMessages({set.seed(seedini); party::varimp(model, conditional = TRUE)})
#   perimp_crfsrc <- as.data.frame(imp)%>%arrange(desc(imp))
#   perimp_crfsrc_ <- perimp_crfsrc%>%
#     mutate(var=row.names(perimp_crfsrc))%>%dplyr::select(var, imp)
#   row.names(perimp_crfsrc_) <- NULL
#   return(perimp_crfsrc_)
# }

dat_process <- function(dat, covs, resp, step){
  findat21 <- dat%>%dplyr::select(all_of(covs), all_of(resp))
  covs11 <- c(covs[!covs%in%c("")], resp)
  da <- findat21%>%dplyr::select(all_of(covs11))
  data <- replace(da, da == "", NA)
  da1 <- sapply(data, function(x) sum(is.na(x)))
  names(da1[da1>0])
  covs_miss <- names(da1[da1>0])
  findat22 <- data%>%dplyr::select(all_of(covs11))%>%
    tidyr::drop_na()%>%
    dplyr::mutate_if(is.character, as.factor)
  covs_miss <- colnames(data)[apply(is.na(data), 2, any)]
  findat2 <- findat22
  findat2 <- as.data.frame(findat2)
  covs <- colnames(findat2)[!colnames(findat2)%in%c(resp[1], resp[2])]
  findat2a <- findat2%>%
    dplyr::mutate(evnt=1-PFSCNSR, time=PFSAVAL)
  findat2a$status <- findat2a$evnt
  if(step==1){
    class(findat2a) <- c("step1", "data.frame")
  }else if(step==2){
    class(findat2a) <- c("step2", "data.frame")
  }else if(step==3){
    class(findat2a) <- c( "step3", "data.frame")
  }else{
    class(findat2a) <- c( "data.frame")
  }
  return(findat2a%>%dplyr::select(all_of(covs), "time", "status"))
}


prm <- function(param){
  if(param=="rsf"){
    use_param = rfs_params
    class(use_param) <- "rsf"
  }else if(param=="crsf"){
    use_param = crfs_params
    class(use_param) <- "crsf"
  }else if(param=="lasso"){
    use_param=lasso_params
    class(use_param) <- "lasso"
  }else if(param=="cox"){
    use_param <- ""
    class(use_param) <- "cox"
  }else{
    use_param <- crsfunbias_params
    class(use_param) <- "crsfunbias"
  }
  return(use_param)
}

cdex1 <- function (object, tes) {
  mat_rsf <- predict(object, tes)$survival
  vec_rsf <- mat_rsf[,  order(abs(object$time.interest - median(object$time.interest)))[1]]
  return(vec_rsf)
}

calc_con <- function(time=time, status=status, predicted=predicted){
  permissible <- 0
  concord <- 0
  par_concord <- 0
  n <- length(time)
  
  for (i in 1:(n - 1)) {
    for (j in (i + 1):n) {
      if ((time[i] < time[j] & status[i] == 0) | (time[j] < 
                                                  time[i] & status[j] == 0)) {
        next
      }
      if (time[i] == time[j] & status[i] == 0 & status[j] == 
          0) {
        next
      }
      permissible <- permissible + 1
      if (time[i] != time[j]) {
        if ((time[i] < time[j] & predicted[i] < predicted[j]) | 
            (time[j] < time[i] & predicted[j] < predicted[i])) {
          concord <- concord + 1
        }
        else if (predicted[i] == predicted[j]) {
          par_concord <- par_concord + 0.5
        }
      }
      if (time[i] == time[j] & status[i] == 1 & status[j] == 
          1) {
        if (predicted[i] == predicted[j]) {
          concord <- concord + 1
        }
        else {
          par_concord <- par_concord + 0.5
        }
      }
      if (time[i] == time[j] & ((status[i] == 1 & status[j] == 
                                 0) | (status[i] == 0 & status[j] == 1))) {
        if ((status[i] == 1 & predicted[i] < predicted[j]) | 
            (status[j] == 1 & predicted[j] < predicted[i])) {
          concord <- concord + 1
        }
        else {
          par_concord <- par_concord + 0.5
        }
      }
    }
  }
  return(list(concord, par_concord, permissible))
}



