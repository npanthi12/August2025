


source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll_PDAC_v1/func/rsf_func.R")
resfin_lasso(dat=indat, num_rept=num_repeats, num_outer_fld = num_outer_folds,
             num_inner_fld=num_inner_folds, params=lasso_params, seedini=seed)

resfin_lasso <- function(dat=dat, num_rept=num_repeats, num_outer_fld = num_outer_folds,
                         num_inner_fld=num_inner_folds, params = params, seedini=seedini, ...){
  
  param_grid_lasso <- expand.grid(
    lambda =  params$lambda,
    alpha = params$alpha
  )
  
  final_results <- data.frame()
  for(rep in 1:num_rept){
    #Outer loop: Split dataset into k folds

    cat("Running repeat", rep, "of", num_repeats, "\n")
    outer_folds_indx <- {set.seed(seedini+rep); createFolds(dat$status, k = num_outer_fld)}
    
    final_results <- rbind(final_results, resbd_lasso(dat=dat, fold_indx=outer_folds_indx, num_outer_fld=num_outer_fld, 
                                                      num_inner_fld=num_inner_fld, param=param_grid_lasso, 
                                                      seedini=seedini, rep=rep))
    
  }
  return(final_results)
}


resbd_lasso <- function(dat=dat, fold_indx=outer_folds, num_outer_fld=num_outer_folds, 
                        num_inner_fld=num_inner_folds, param = param, seedini=seedini, rep=rep){
  final_results <- data.frame()
  for(i in 1:num_outer_fld){
    cat("Running outer fold", i, "of", num_outer_fld, "in repeat", rep, "of", num_repeats, "\n")
    outer_train <- dat[-fold_indx[[i]],]
    outer_test <- dat[fold_indx[[i]], ]
    # Select best hyperparameters from Inner loop: Hyperparameter tuning using cross-validation
    if(length(unique(outer_train$status))==1){
      inner_folds <- {set.seed(seedini); createFolds(outer_train$time, k=num_inner_fld)}
      
    }else{
      inner_folds <- {set.seed(seedini); createFolds(outer_train$status, k=num_inner_fld)}
    }
    
    best_params <-resb_lasso(dat=outer_train, param=param, num_folds=num_inner_folds, fold=inner_folds, 
                             seedini=seedini, iter_=i, rep=rep, num_outer_fld=num_outer_fld)[[2]]
    #Train the best model on outer train set
    
    ###
    #Evaluate the best model on the outer test set
    model <- rfsrc(Surv(time, status)~., data = outer_train)
    distime <- model$time.interest  #get the survival time of events
    med_index <- median(1:length(distime)) 
    
    args <- list(form=Surv(time, status)~., dat=outer_train,
                 alpha = best_params$alpha,
                 lam = best_params$lambda, seedini=seedini)
  
    best_model <- do.call("predmodlasso", args)
  
    cov <- colnames(model$xvar)
    x1 <-  model.matrix( ~ ., outer_train[,cov])[,-1]
    x1_mean <- apply(x1, 2, mean)
    x1_sd <- apply(x1, 2, sd)
    x1_sd[x1_sd==0] <- 1
    x1_scaled <- scale(x1, center=x1_mean, scale=x1_sd)
    y1 <- Surv(outer_train$time, outer_train$status)
    
    x2 <-  model.matrix( ~ ., outer_test[,cov])[,-1]
    x2_mean <- apply(x2, 2, mean)
    x2_sd <- apply(x2, 2, sd)
    x2_sd[x2_sd==0] <- 1
    x2_scaled <- scale(x2, center=x1_mean, scale=x1_sd)
    y2 <- Surv(outer_test$time, outer_test$status)
  
    # Extract C-index (last error rate)
    # Extract C-index (last error rate)
    mat_lasso <- predictProb.lasso(object=best_model, 
                                   x2_scaled=x2_scaled, x1_scaled=x1_scaled, 
                                   times=distime,y=y1)
    
    mat_lasso1 <- t((mat_lasso))
    
    vec_glmnet <- mat_lasso1[ ,med_index]

    final_cindex <- SurvMetrics::Cindex(Surv(outer_test$time, outer_test$status), vec_glmnet)[[1]]
    frm <- as.formula(paste("Surv(time, status)~",
                            paste(cov, collapse="+")))
    

    # perror <- suppressMessages(pec(object=best_model,
    #                                formula = frm, cens.model="marginal",
    #                                data=outer_test, verbose=F, maxtime=200))
    # 
    # final_ibs <- ibs(perror, times=max(distime))[[2]]
    final_ibs <- NA
    #ibs = final_ibs
    #Store results
    final_results <- rbind(final_results, data.frame(Repeat=rep, Fold=i, alpha=best_params$alpha,
                                                     lambda=best_params$lambda,
                                                     C_index = final_cindex, ibs = final_ibs, seedini=seedini))
  }
  return(final_results)
}


#Mean c-index values for all tuning parameters across inner fold and best tuning param
resb_lasso <- function(dat=outer_train, param=param, num_folds=num_inner_folds, fold=inner_folds, 
                       seedini=seedini,iter_=i, rep=rep, num_outer_fld=num_outer_fld){
  
  best_model <- NULL
  best_cindex <- 0
  m_cin <- c()
  # mod <- list()
  best_params <- data.frame()
  for(j in 1:nrow(param)){
    cat("Running param_grid", j, "of", nrow(param), "in outer fold", iter_, "of", num_outer_fld, "in repeat", rep, "of", num_repeats, "\n")
    param_res <- resd_lasso(dat=dat, fold=fold, num_folds=num_folds,
                            param=param, seedini=seedini, iter=j, out_fld=iter_, rep=rep, num_outer_fld=num_outer_fld)

    #cindex_values <- param_res[[1]]
    rsf_model <- param_res[[2]]
    #Mean C-index for this hyperparameter set
    mean_cindex <- param_res[[3]]
    mod_prm <- param_res[[4]]
    m_cin[j] <- mean_cindex
    # mod[[j]] <- rsf_model
    #Track best model
    if(mean_cindex > best_cindex){
      best_cindex <- mean_cindex
      best_prm <- mod_prm
      best_params <- data.frame(alpha= mod_prm$alpha, lambda=  mod_prm$lambda, seedini=seedini)
    }
  }
  return(list(best_cindex, best_params, m_cin))
}


#Mean c-index for one tuning parameter across all inner folds

resd_lasso <- function( dat=dat, fold=fold, num_folds=num_folds, 
                       param=param, seedini=seedini, iter=j, out_fld=iter_, rep=rep, num_outer_fld=num_outer_fld){
  
  cindex_values <- c()
  crsf_model <- NULL
  model_prms <- data.frame()
  for(k in 1:num_folds){

    modtot <-  num_repeats*num_outer_fld*num_folds*nrow(param)
    modnum <- k+num_folds*(iter-1) + nrow(param)*num_folds*(out_fld-1) + nrow(param)*num_folds*num_outer_fld*(rep-1)
    
    #Split into inner training and validation sets
    cat("Running param_grid", iter, "of", nrow(param),"in inner fold", k, "of", num_folds,  "in outer fold", out_fld, "of", num_outer_fld, "in repeat", rep, "of", num_repeats, "Model", modnum, "of", modtot, "\n")
    
    inner_train <- dat[-fold[[k]],]
    inner_valid <- dat[fold[[k]],]
  
    #Train RSF model with current hyperparameters
    
    model <- rfsrc(Surv(time, status)~., data = inner_train)
    distime <- model$time.interest  #get the survival time of events
    med_index <- median(1:length(distime)) 
 
    args <- list(form=Surv(time, status)~., dat=inner_train,
                 alpha = param$alpha[iter],
                 lam = param$lambda[iter], seedini=seedini)
    lasso_model <- do.call("predmodlasso", args)
    cov <- colnames(model$xvar)
    
    x1 <-  model.matrix( ~ ., inner_train[,cov])[,-1]
    x1_mean <- apply(x1, 2, mean)
    x1_sd <- apply(x1, 2, sd)
    x1_sd[x1_sd==0] <- 1
    x1_scaled <- scale(x1, center=x1_mean, scale=x1_sd)
    y1 <- Surv(inner_train$time, inner_train$status)
    
    x2 <-  model.matrix( ~ ., inner_valid[,cov])[,-1]
    
    x2_mean <- apply(x2, 2, mean)
    x2_sd <- apply(x2, 2, sd)
    x2_sd[x2_sd==0] <- 1
    x2_scaled <- scale(x2, center=x1_mean, scale=x1_sd)
    y2 <- Surv(inner_valid$time, inner_valid$status)
    
    # Extract C-index (last error rate)
    mat_lasso <- predictProb.lasso(object=lasso_model, 
                                   x2_scaled=x2_scaled, x1_scaled=x1_scaled, 
                                   times=distime,y=y1)
    if(dim(mat_lasso)[1]==1){
     cindex_lasso <- 0
    }else{
    mat_lasso1 <- t(data.matrix(mat_lasso))
    
    vec_glmnet <- mat_lasso1[ ,med_index]
    tryCatch({
      cindex_lasso <- SurvMetrics::Cindex(Surv(inner_valid$time, inner_valid$status), vec_glmnet)[[1]]
      
    },
    error = function(e) {
      message("An Error Occurred")
      
      #print(e)
    },
    warning = function(w) {
      message("A Warning Occurred")
      #print(w)
      
    })
    
    
  
  }
  
    cindex_values <- c(cindex_values, cindex_lasso)

  }
  model_prms <- data.frame(alpha=param$alpha[iter], lambda= param$lambda[iter])
  return(list(cindex_values, lasso_model,  mean(cindex_values, na.rm=T), model_prms))
}







