# source("Z:/Private/npanthi/April analysis/rsf_func.R")
# 
# 
# predmod.crsfunb <- function(dat=findat2a, params=NULL, num_inner_folds=num_inner_folds,
#                          seedini=seedini, covs=covs,..){
# 
#   args_best <- list(form=Surv(time, status)~., dat=dat, seed=seedini)
#   best_model <- do.call("predmodcrsfunbd", args_best)
#   impt <- suppressMessages({set.seed(seedini);party::varimp(best_model, conditional=TRUE)})
#   impt1 <- as.data.frame(impt)
#   colnames(impt1) <- "imp"
#   impt2 <- impt1%>%dplyr::arrange(desc(imp))
#   imp1 <- impt2%>%mutate(var=row.names(impt2))%>%dplyr::select(var, imp)%>%arrange(desc(imp))
#   row.names(imp1) <- NULL
#   return(list(imp1))
# }



source("Z:/Private/npanthi/April analysis/rsf_func.R")

resd_crsfunb <- function(num_folds=num_inner_folds, dat=findat2a, 
                      params=NULL, seedini=seedini, iter=j){
  fold <-  {set.seed(seedini); createFolds(dat$status, k=num_folds)}
  cindex_values <- c()
  for(k in 1:num_folds){
    #Split into inner training and validation sets
    cat("Running  param_grid", iter, "of", nrow(params), "in inner fold", k, "of", num_folds, "\n")
    inner_train <- dat[-fold[[k]],]
    inner_valid <- dat[fold[[k]],]
    #Train cRSF model with current hyperparameters
    args <- list(form=Surv(time, status)~., dat=inner_train, seed=seedini)
    crsfunb_model <- do.call("predmodcrsfunb", args)
    
    model <- rfsrc(Surv(time, status)~., data = inner_train)
    distime <- model$time.interest  #get the survival time of events
    med_index <- median(1:length(distime)) 
    # Extract C-index (last error rate)
    mat_cforest <- suppressMessages(predictSurvProb(crsfunb_model, newdata = inner_valid, times = distime))
    vec_rsf <- mat_cforest[ ,med_index]  #median survival probability of all samples
    times <- inner_valid$time
    status <- inner_valid$status
    cindex_crsf <- SurvMetrics::Cindex(Surv(times, status), vec_rsf)[[1]]
    cindex_values <- c(cindex_values, cindex_crsf)
    
  }
  return(list(cindex_values, crsfunb_model))
}


predmod.crsfunb <- function(dat=findat2a, params=NULL, num_inner_folds=num_inner_folds,
                         seedini=seedini, covs=covs,..){

    param_res <- resd_crsfunb(num_folds=num_inner_folds, dat=dat, 
                           params=NULL, seed=seedini, iter=1)
    cindex_values <- param_res[[1]]
    rsf_model <- param_res[[2]]
    #Compute mean C-index for this hyperparameter set
    mean_cindex <- mean(cindex_values, na.rm=T)
  
args_best <- list(form=Surv(time, status)~., dat=dat, seed=seedini)
best_model <- do.call("predmodcrsfunbd", args_best)
best_model_ <- do.call("predmodcrsfunb", args_best)
model <- rfsrc(Surv(time, status)~., data = dat)
distime <- model$time.interest  #get the survival time of events
med_index <- median(1:length(distime)) 
# Extract C-index (last error rate)
mat_cforest <- suppressMessages(predictSurvProb(best_model_, newdata = dat, times = distime))
vec_rsf <- mat_cforest[ ,med_index]  #median survival probability of all samples
times <- dat$time
status <- dat$status
cindex_mod<- SurvMetrics::Cindex(Surv(times, status), vec_rsf)[[1]]
#
impt <- suppressMessages({set.seed(seedini);party::varimp(best_model, conditional=TRUE)})
impt1 <- as.data.frame(impt)
colnames(impt1) <- "imp"
impt2 <- impt1%>%dplyr::arrange(desc(imp))
imp1 <- impt2%>%mutate(var=row.names(impt2))%>%dplyr::select(var, imp)%>%arrange(desc(imp))
row.names(imp1) <- NULL

  return(list(imp1, data.frame(mod_cindex=cindex_mod, cv_cindex=mean_cindex)))
}

















