

resd_cox <- function(num_folds=num_inner_folds, dat=findat2a, 
                       params=param_grid, seedini=seedini, iter=j){
  fold <-  {set.seed(seedini); createFolds(dat$status, k=num_folds)}
  cindex_values <- c()
  for(k in 1:num_folds){
    #Split into inner training and validation sets
    cat("Running  param_grid", iter, "of", nrow(params), "in inner fold", k, "of", num_folds, "\n")
    inner_train <- dat[-fold[[k]],]
    inner_valid <- dat[fold[[k]],]
    #Train cRSF model with current hyperparameters
    
    args <- list(form=Surv(time, status)~., dat=inner_train)
    args_tes <- list(form=Surv(time, status)~., dat=inner_valid)
    model_cox_train <- do.call("predmodcox", args)
    model_cox_test <- do.call("predmodcox", args_tes)
    datrain <- cbind(model_cox_train$y, model_cox_train$x)
    datest <- cbind(model_cox_test$y, model_cox_test$x)
    
    coeff_fixed <- model_cox_train$coefficients
    a <- row.names(as.data.frame(coeff_fixed[!is.na(coeff_fixed)]))
    if(sum(colnames(datrain)[-c(1, 2)]!=a)==0){
      cindex_cox= SurvMetrics::Cindex( model_cox_train, inner_valid)
    }else{
      formnew <- f.build("Surv(time, status)",a)
      model_coxnew<- coxph(formnew, data=as.data.frame(datrain), ties="breslow", x=TRUE)
      cindex_cox= SurvMetrics::Cindex(model_coxnew, as.data.frame(datest))
    }
    # Extract C-index (last error rate)
    
    #cindex_cox <- SurvMetrics::Cindex(cox_model, inner_valid)[[1]]
    
    cindex_values <- c(cindex_values, cindex_cox)
    
  }
  return(list(cindex_values, model_cox_train))
}



predmod.cox <- function(dat=findat2a, params=NULL, num_inner_folds=num_inner_folds,
                          seedini=seedini, covs=covs,..){
 
    param_res <- resd_cox(num_folds=num_inner_folds, dat=dat, 
                            params=NULL, seed=seedini, iter=1)
    cindex_values <- param_res[[1]]
    cox_model <- param_res[[2]]
    #Compute mean C-index for this hyperparameter set
    mean_cindex <- mean(cindex_values, na.rm=T)
    #Track best model
  
  args_best <- list(form=Surv(time, status)~., dat=dat)
  best_model <- do.call("predmodcox", args_best)
  
  #c_index= SurvMetrics::Cindex(best_model, as.data.frame(dat))
  
  c_index <- NULL
  model_cox_trnew <- do.call("predmodcox", args_best)
  
  model_cox_tenew <- do.call("predmodcox", args_best)
  datrain <- cbind(model_cox_trnew$y, model_cox_trnew$x)
  datest <- cbind(model_cox_tenew$y, model_cox_tenew$x)
  
  coeff_fixed <- model_cox_trnew$coefficients
  a <- row.names(as.data.frame(coeff_fixed[!is.na(coeff_fixed)]))
  if(sum(colnames(datrain)[-c(1, 2)]!=a)==0){
    c_index= SurvMetrics::Cindex( model_cox_trnew, dat)
  }else{
    form_new <- f.build("Surv(time, status)",a)
    model_coxnew<- coxph(form_new, data=as.data.frame(datrain), ties="breslow", x=TRUE)
    c_index= SurvMetrics::Cindex(model_coxnew, as.data.frame(datest))
  }
  #Variable ranking
  
  results_rnk <- data.frame(covariate = character(), delta_cindex = integer())
  
  res1 <- map(1:length(covs), function(.x){
    cat("Variable Ranking: Running cox model", .x, "of", length(covs), "\n")
    covsnew <- setdiff(covs, covs[.x])
    if(is.na(covsnew[1])){
      formnew <- Surv(time,status)~1
    }else{
    formnew <- f.build("Surv(time,status)", covsnew)
    }
    args_new <- list(formnew, dat=dat)
    mod_new <- do.call("predmodcox", args_new)
    ##
    model_cox_trnew <- do.call("predmodcox", args_new)
    model_cox_tenew <- do.call("predmodcox", args_new)
    datrain <- cbind(model_cox_trnew$y, model_cox_trnew$x)
    datest <- cbind(model_cox_tenew$y, model_cox_tenew$x)
    # formnew <- f.build("Surv(time, status)",colnames(da0)[-c(1, 2)])
    # coxph(formnew, data=as.data.frame(da0), ties="breslow", x=TRUE)
    # 
    # coxph(form, data=train_dat, ties="breslow", x=TRUE)
    # c_index= SurvMetrics::Cindex(model_coxnew, test_dat)
    
    coeff_fixed <- model_cox_trnew$coefficients
    a <- row.names(as.data.frame(coeff_fixed[!is.na(coeff_fixed)]))
    if(length(a)<1){
      c_indexnew=NA
    }else{
    if(sum(colnames(datrain)[-c(1, 2)]!=a)==0){
      c_indexnew= SurvMetrics::Cindex( model_cox_trnew, dat)
    }else{
      form_new <- f.build("Surv(time, status)",a)
      model_coxnew<- coxph(form_new, data=as.data.frame(datrain), ties="breslow", x=TRUE)
      c_indexnew= SurvMetrics::Cindex(model_coxnew, as.data.frame(datest))
    }
    }
    deltacindex=c_index - c_indexnew
    return(c(covs[.x], deltacindex))
    
  })
  results_rnk <- as.data.frame(do.call("rbind", res1))
  # Rename columns
  colnames(results_rnk) <- c( "covariate", "delta_cindex")
  finres <- results_rnk%>%arrange(desc(delta_cindex))
  ###
  
  return(list(finres, data.frame(mod_cindex=c_index, cv_cindex=mean_cindex)))
}










