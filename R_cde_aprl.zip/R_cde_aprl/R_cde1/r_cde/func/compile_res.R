source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll/func/rsf_func.R")

library(haven)
library(data.table)
library(dtplyr)
library(survminer)
library(dplyr)
library(Hmisc)
library(AICcmodavg)
library(car)
library(broom)
library(cobalt)
library(ipw)
library(survey)
library(WeightIt)
library(glmtoolbox)
library(MatchIt)
library(MuMIn)
library(purrr)
library("survival")
library("survminer")
library(emmeans)
library(randomForestSRC)
library(ranger)
library(openxlsx)
library(randomForest)
library(dplyr)
library(ggraph)
library(igraph)
library(caret)
library(rpart.plot)
library(rpart)
library(party)
library(ggsurvfit)
library(visdat)
library(plotly)
library(GGally)
library(permimp)
library(DT)
library(ggsurvfit)
library(ggcorrplot)
library(tidyverse)
library(rcompanion)
library(knitr)
library(polycor)
library(StepReg)
library(pec)
library(SurvMetrics)
library(caret)
library(glmnet)

prm <- function(param){
  if(param=="rsf"){
    use_param = rfs_params
    class(use_param) <- "rsf"
  }else if(param=="crsf"){
    use_param = crfs_params
    class(use_param) <- "crsf"
  }else if(param=="lasso"){
    use_param=lasso_params
    class(use_param) <- "lasso"
  }else if(param=="cox"){
    use_param <- ""
    class(use_param) <- "cox"
  }else{
    use_param <- crsfunbias_params
    class(use_param) <- "crsfunbias"
  }
  return(use_param)
}
source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll/func/step2_anals_func_rsf.R")
source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll/func/step2_anals_func_crsf.R")
source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll/func/step2_anals_func_lasso.R")
source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll/func/step2_anals_func_crsfunbias.R")
source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll/func/step2_anals_func_cox.R")
source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll/func/rsf_func.R")
options(scipen = 999)
#RSF
# runpred_step2(indat=fin, num_repeats=num_repeats,
#               num_outer_folds=num_outer_folds, num_inner_folds=num_inner_folds,
#               rfs_params=prm("rsf"),
#               crfs_params=prm("crsf"),
#               lasso_params=prm("lasso"),
#               crfsunb_params=prm("crfsunbias"), seed=seed)


runpred_step2 <- function(indat=fin, num_repeats=num_repeats,
                     num_outer_folds=num_outer_folds, num_inner_folds=num_inner_folds,
                     rfs_params=prm("rsf"),
                     crfs_params=prm("crsf"),
                     lasso_params=prm("lasso"),
                     crfsunb_params=prm("crfsunbias"), seed=seed){
  
  cat("Running lasso model", "\n")
  #Lasso
  lasso_res <- resfin_lasso(dat=indat, num_rept=num_repeats, num_outer_fld = num_outer_folds,
                            num_inner_fld=num_inner_folds, params=lasso_params, seedini=seed)
  
  

  #cRSF
  cat("Running cRSF model", "\n")
  crsf_res <- resfin_crsf(dat=indat, num_rept=num_repeats, num_outer_fld = num_outer_folds,
                          num_inner_fld=num_inner_folds, params=crfs_params, seedini=seed)


  #cRSF unbiased
  cat("Running cRSFunbias model", "\n")
  crsfunb_res <- resfin_crsfunb(dat=indat, num_rept=num_repeats, num_outer_fld = num_outer_folds,
                                num_inner_fld=num_inner_folds, params=crsfunbias_params, seedini=seed)



#RSF
cat("Running RSF model", "\n")
rsf_res <- resfin(dat=indat, num_rept=num_repeats, num_outer_fld = num_outer_folds,
                  num_inner_fld=num_inner_folds, params=rfs_params, seedini=seed)

#cox
cat("Running cox model", "\n")
cox_res <- resfin_cox(dat=indat, num_rept=num_repeats, num_outer_fld = num_outer_folds,
                      num_inner_fld=num_inner_folds, params=NULL, seedini=seed)

#Create plot
cat("Creating plot", "\n")
create_plt_ <- create_plt(rsf_res=rsf_res, crsf_res = crsf_res, 
           lasso_res=lasso_res, cox_res=cox_res, crsfunb_res=crsfunb_res)
return(create_plt_)
}

dat_process <- function(dat, covs, resp, step){
  findat21 <- dat%>%dplyr::select(all_of(covs), all_of(resp))
  covs11 <- c(covs[!covs%in%c("")], resp)
  da <- findat21%>%dplyr::select(all_of(covs11))
  data <- replace(da, da == "", NA)
  da1 <- sapply(data, function(x) sum(is.na(x)))
  names(da1[da1>0])
  covs_miss <- names(da1[da1>0])
  findat22 <- data%>%dplyr::select(all_of(covs11))%>%
    tidyr::drop_na()%>%
    dplyr::mutate_if(is.character, as.factor)
  covs_miss <- colnames(data)[apply(is.na(data), 2, any)]
  findat2 <- findat22
  findat2 <- as.data.frame(findat2)
  covs <- colnames(findat2)[!colnames(findat2)%in%c(resp[1], resp[2])]
  findat2a <- findat2%>%
    dplyr::mutate(evnt=1-PFSCNSR, time=PFSAVAL)
  findat2a$status <- findat2a$evnt
  if(step==1){
    class(findat2a) <- c("step1", "data.frame")
  }else if(step==2){
    class(findat2a) <- c("step2", "data.frame")
  }else if(step==3){
    class(findat2a) <- c( "step3", "data.frame")
  }else{
    class(findat2a) <- c( "data.frame")
  }
  return(findat2a%>%dplyr::select(all_of(covs), "time", "status"))
}

cindibs <- function(datrain=fintrain, datest=fintest, rsf_best=rsf_best,
                    crsf_best=crsf_best){
  
  argsrsf <- list(form=Surv(time, status)~., 
                  dat=datrain, 
                  ntree=rsf_best$ntree, mtry=rsf_best$mtry, 
                  nodesize=rsf_best$nodesize, seedini=1234, importance=FALSE)
  rsf_model <- do.call(predmodrsf, argsrsf)
  dis_time <- rsf_model$time.interest
  cind_rsf <- SurvMetrics::Cindex(rsf_model, datest)
  perror_rsf <- suppressMessages(pec(object=rsf_model,
                                     formula = Surv(time, status)~., cens.model="marginal",
                                     data=datest, verbose=F, maxtime=200))
  ibs_rsf <- ibs(perror_rsf, times=max(rsf_model$time.interest))[[2]]
  ##CRSF
  argscrsf <- list(form=Surv(time, status)~., 
                   dat=datrain, 
                   ntree=crsf_best$ntree, mtry=crsf_best$mtry, 
                   mincriterion=crsf_best$mincriterion, minbucket = crsf_best$minbucket, seedini=1234)
  crsf_model <- do.call(predmodcrsf, argscrsf)
  
  med_index <- median(1:length(dis_time))#dist=event times
  mat_crsf <- suppressMessages(predictSurvProb(crsf_model, newdata = datest, times = dis_time))
  vec_crsf <- mat_crsf[ ,med_index]
  cind_crsf <- SurvMetrics::Cindex(Surv(datest$time, datest$status), vec_crsf)
  #cind_crsf <- SurvMetrics::Cindex(crsf_model, fintest102)
  
  perror_crsf <- suppressMessages(pec(object=crsf_model,
                                      formula = Surv(time, status)~., cens.model="marginal",
                                      data=datest, verbose=F, maxtime=200))
  ibs_crsf <- ibs(perror_crsf, times=max(rsf_model$time.interest))[[2]]
  return(list("rsf"=c(cind_rsf, ibs_rsf), "crsf"=c(cind_crsf, ibs_crsf)))
}
