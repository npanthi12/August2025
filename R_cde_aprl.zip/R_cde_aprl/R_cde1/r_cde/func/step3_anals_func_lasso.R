source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll/func/rsf_func.R")

predictProb.lasso <- function(object=fit, x2_scaled=x2_scaled, x1_scaled=x1_scaled, times=dis_time,y=y1
                                 ){
  train_lp <- predict(object, newx = x1_scaled, type = "link")
  cox_train <- coxph(y ~ offset(train_lp))
  # Get baseline survival from training
  train_baseline <- survfit(cox_train)
  survest <- stepfun(train_baseline$time, c(1,  train_baseline$surv))
  da_surv <- data.frame(surv=survest(times), time=times)
  
  
  lp_new <- predict(object, newx = x2_scaled, type = "link", times=times)
  res <- matrix(0, nrow = length(times), ncol = nrow(lp_new))
  
  # Fill the matrix using a for loop
  for (i in 1:nrow(lp_new)) {
    res[,i] <- (da_surv$surv)^exp(lp_new[i,])
  }
  
  return(data.matrix(as.data.frame(res)))
}


predmod.lasso <- function(dat=findat2a, params=lasso_params, num_inner_folds=num_inner_folds,
                          seedini=seedini, covs=covs,..){
  param_grid_lasso <- expand.grid(
    alpha =params$alpha,  
    lambda = params$lambda
  )
  best_model <- NULL
  best_cindex <- 0
  best_params <- data.frame()
  for(j in 1:nrow(param_grid_lasso)){
    
    cat("Running param_grid", j, "of", nrow(param_grid_lasso), "\n")

    param_res <- resd_lasso(num_folds=num_inner_folds, dat=dat, 
                            params=param_grid_lasso, seed=seedini, iter=j)
    cindex_values <- param_res[[1]]
    lasso_model <- param_res[[2]]
    prms <- param_grid_lasso[j,]
    #Compute mean C-index for this hyperparameter set
    mean_cindex <- mean(cindex_values, na.rm=T)
    #Track best model
    if(mean_cindex > best_cindex){
      best_cindex <- mean_cindex
      best_model <- lasso_model
      best_parms <- prms
    }
    
  }
  
  
  best_params <- data.frame(alpha=best_parms$alpha ,
                            lambda=best_parms$lambda, 
                            seed=seedini, cv_cindex =best_cindex)
  
  
  ##
  args <- list(form=Surv(time, status)~., dat=dat,
               alpha=1, lam=best_params$lambda, seedini=1234)
  
  best_model <- do.call("predmodlasso", args)
  
  #best_model coefficients
  # Extract coefficients at the best lambda
  lasso_coefficients <- coef(best_model, s = best_model$lambda.min)
  lasso_imp <- as.data.frame(as.matrix(lasso_coefficients))%>%dplyr::mutate(val=abs(s0))%>%dplyr::arrange(desc(val))
  
  
  #Variable ranking
  modl <- rfsrc(Surv(time, status)~., data = dat)
  covs <- colnames(modl$xvar)
  c_index <- lassofit(train_dat=dat, test_dat=dat, covslas=covs, lambda=best_params$lambda, 
                      formlas=f.build("Surv(time,status)", covs))
  
  results_rnk <- data.frame(covariate = character(), delta_cindex = integer())
  res1 <- map(1:length(covs), function(.x){
    cat("Variable Ranking: Running lasso model", .x, "of", length(covs), "\n")
    covsnew <- setdiff(covs, covs[.x])
    if(is.na(covsnew[1])){
      deltacindex = NA
    }else{
    formnew <- f.build("Surv(time,status)", covsnew)
    
    c_indexnew<-lassofit(train_dat=dat, test_dat=dat, covslas=covsnew, 
                         lambda=best_params$lambda, formlas=formnew)
    deltacindex=c_index - c_indexnew
    }
    return(c(covs[.x], deltacindex))
    
  })
  results_rnk <- as.data.frame(do.call("rbind", res1))
  # Rename columns
  colnames(results_rnk) <- c( "covariate", "delta_cindex")
  finres <- results_rnk%>%arrange(desc(delta_cindex))
  ###
  
  return(list(finres, best_params, data.frame(mod_cindex=c_index, cv_cindex=best_cindex), lasso_imp))
}


resd_lasso <- function(num_folds=num_inner_folds, dat=dat, 
                       params=param_grid_lasso, seedini=seedini, iter=j){
  fold <-  {set.seed(seedini); createFolds(dat$status, k=num_folds)}
  cindex_values <- c()
  for(k in 1:num_folds){
    #Split into inner training and validation sets
    
    cat("Running  param_grid", iter, "of", nrow(params), "in inner fold", k, "of", num_folds, "\n")
    inner_train <- dat[-fold[[k]],]
    inner_valid <- dat[fold[[k]],]
    #Train cRSF model with current hyperparameters
    args <- list(form=Surv(time, status)~., dat=inner_train,
                 alpha = params$alpha[iter],
                 lam = params$lambda[iter], seed=seedini)
    

    lasso_model <- do.call("predmodlasso", args)
    
    modl <- rfsrc(Surv(time, status)~., data = inner_train)
    distime <- modl$time.interest  #get the survival time of events
    med_index <- median(1:length(distime)) 
    
    x1 <- model.matrix( ~ .,   data.frame(inner_train[, colnames(modl$xvar)]))[,-1]
    x1_mean <- apply(x1, 2, mean)
    x1_sd <- apply(x1, 2, sd)
    x1_sd[x1_sd==0] <- 1
    x1_scaled <- scale(x1, center=x1_mean, scale=x1_sd)
    
    y1 <- Surv(inner_train$time, inner_train$status) 
    x2 <-  model.matrix( ~ ., data.frame(inner_valid[,colnames(modl$xvar)]))[,-1]
    x2_scaled <- scale(x2, center=x1_mean, scale=x1_sd)
    y2 <- Surv(inner_valid$time, inner_valid$status)
    
    # Extract C-index (last error rate)
    mat_lasso <-  predictProb.lasso(object=lasso_model,
                                    x2_scaled=x2_scaled, x1_scaled=x1_scaled,
                                    times=distime,y=y1)
    
  
    mat_lasso1 <- t((mat_lasso))
    vec_glmnet <- mat_lasso1[ ,med_index]
    cindex_lasso <- SurvMetrics::Cindex(Surv(inner_valid$time, inner_valid$status), vec_glmnet)[[1]]
    
    cindex_values <- c(cindex_values, cindex_lasso)
    
  }
  return(list(cindex_values, lasso_model))
}







