source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll/func/step3_anals_func_rsf.R")
source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll/func/step3_anals_func_crsf.R")
source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll/func/step3_anals_func_crsfunbias.R")
source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll/func/step3_anals_func_cox.R")
source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll/func/step3_anals_func_lasso.R")

# comp.step3(indat=fin, rfs_params=rfs_params, crfs_params = crfs_params,
#            crsfunbias_params=crsfunbias_params, lasso_params = lasso_params, num_inner_folds=num_inner_folds,
#            seedini=seed, covs=covs)



comp.step3 <- function(indat=fin, rfs_params=rfs_params, crfs_params = crfs_params,
                       crsfunbias_params =crsfunbias_params , lasso_params = lasso_params,
                       num_inner_folds=num_inner_folds,
                       seedini=seed, covs=covs){
  
  #lasso
  fin_out_lasso <- predmod.lasso(dat=indat, params=lasso_params, 
                                 num_inner_folds=num_inner_folds,
                                 seedini=seed, covs=covs)
  #cox
  fin_out_cox <- predmod.cox(dat=indat, params=NULL, num_inner_folds=num_inner_folds,
                             seedini=seed, covs=covs)
  #crsf
  
fin_out_crsf <- predmod.crsf(dat=indat, params=crfs_params, num_inner_folds=num_inner_folds,
                               seedini=seed, covs=covs)
  
#crsfunbias
fin_out_crsfunb <- predmod.crsfunb(dat=indat, params=crsfunbias_params, num_inner_folds=num_inner_folds,
                                     seedini=seed, covs=covs)
#rsf
fin_out_rsf <- predmod.rsf(dat=indat, params=rfs_params, num_inner_folds=num_inner_folds,
                           seedini=seed, covs=covs)


return(list(fin_out_rsf, fin_out_crsf, fin_out_crsfunb, fin_out_lasso, fin_out_cox))

}

# fin <- comp.step3(indat=fin, rfs_params=rfs_params, crfs_params = crfs_params,
#                   crfsunbias_params=crfsunbias_params, num_inner_folds=num_inner_folds,
#                   seedini=seed, covs=covs)
# 
# fin[[2]][[1]]
# fin[[2]][[2]]
# fin[[3]]
