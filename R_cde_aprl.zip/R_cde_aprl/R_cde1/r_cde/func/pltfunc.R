plt <- function(dat, covs){
  fin <- dat_process(dat=dat, covs=covs, resp=c("PFSAVAL", "PFSCNSR"), step=2)
  fitr<- survfit(f.build("Surv(time, status)", covs), dat=fin, conf.type="plain")
  pltr <- ggsurvplot(fitras, pval = FALSE, conf.int = FALSE,
                       risk.table = TRUE, risk.table.y.text.col = TRUE,
                       palette = c("darkgreen", "lightgreen", "lightblue"),
                       ylim = c(0, 1), censor.shape='+',  break.y.by=0.2,
                       break.x.by=2, 
                       ylab="Probability of PFS", xlab="Months")
  return(list(pltr, fitr))
}