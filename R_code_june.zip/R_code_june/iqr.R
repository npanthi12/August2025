#NSCLC
da <- read.xlsx("Z:/Private/npanthi/2025/June Analysis/section_c/cov_rnk_comb_sec_C_full_set_PDAC_all_res.xlsx")
da1 <- read.xlsx("Z:/Private/npanthi/2025/June Analysis/section_c/cov_rnk_comb_sec_C_full_set_PDAC.xlsx")

outname <- "Z:/Private/npanthi/2025/June Analysis/section_c/cov_rnk_comb_sec_C_full_set_PDAC_v1.xlsx"
if(TRUE){
da2 <- da%>%dplyr::group_by(covs_out)%>%
  dplyr::summarise(med_cindex=median(C_index),
            q1_cindex=quantile(C_index, prob=c(0.25, 0.75))[[1]],
            q3_cindex=quantile(C_index, prob=c(0.25, 0.75))[[2]]
            )%>%mutate(IQR_cindex=q3_cindex-q1_cindex)
da3 <- da%>%dplyr::group_by(covs_out)%>%
  dplyr::summarise(med_ibs=median(ibs),
            q1_ibs=quantile(ibs, prob=c(0.25, 0.75))[[1]],
            q3_ibs=quantile(ibs, prob=c(0.25, 0.75))[[2]]
  )%>%mutate(IQR_ibs=q3_ibs-q1_ibs)


da4 <- da1%>%left_join(da2)%>%left_join(da3)%>%
  dplyr::select(covs_out, cind_med, IQR_cindex, ibs_med, IQR_ibs, everything(), -med_cindex, -med_ibs)
#apply(da4[,-c(1,4)], 2, function(x)round(x, 2))
write.xlsx(da4, outname)
}
#NSCLC (old data)
da <- read.xlsx("Z:/Private/npanthi/2025/June Analysis/cov_rnk_singl_sec_B_full_set_NSCLC_all_res.xlsx")
da1 <- read.xlsx("Z:/Private/npanthi/2025/June Analysis/cov_rnk_singl_sec_B_full_set_NSCLC.xlsx")

outname <- "Z:/Private/npanthi/2025/June Analysis/cov_rnk_singl_sec_B_full_set_NSCLC2.xlsx"
if(TRUE){
  da2 <- da%>%dplyr::group_by(covs_out)%>%
    summarise(med_cindex=median(C_index),
              q1_cindex=quantile(C_index, prob=c(0.25, 0.75))[[1]],
              q3_cindex=quantile(C_index, prob=c(0.25, 0.75))[[2]]
    )%>%mutate(IQR_cindex=q3_cindex-q1_cindex)
  da3 <- da%>%dplyr::group_by(covs_out)%>%
    summarise(med_ibs=median(ibs),
              q1_ibs=quantile(ibs, prob=c(0.25, 0.75))[[1]],
              q3_ibs=quantile(ibs, prob=c(0.25, 0.75))[[2]]
    )%>%mutate(IQR_ibs=q3_ibs-q1_ibs)
  
  da4 <- da1%>%left_join(da2)%>%left_join(da3)%>%
    dplyr::select(covs_out, cind_med, IQR_cindex, ibs_med, IQR_ibs, everything(), -med_cindex, -med_ibs)
  #apply(da4[,-c(1,4)], 2, function(x)round(x, 2))
  write.xlsx(da4, outname)
}


#PDAC(old data)
da <- read.xlsx("Z:/Private/npanthi/2025/June Analysis/cov_rnk_singl_sec_B_full_set_PDAC_all_res2.xlsx")
da1 <- read_excel("C:/Users/npanthi/Downloads/cov_rnk_singl_sec_B_full_set_PDAC1.xlsx", 
                 range = "A1:G13")
da1
outname <- "Z:/Private/npanthi/2025/June Analysis/cov_rnk_singl_sec_B_full_set_PDAC2.xlsx"
if(TRUE){
  da2 <- da%>%dplyr::group_by(covs_out)%>%
    summarise(med_cindex=median(C_index, na.rm=T),
              q1_cindex=quantile(C_index, prob=c(0.25, 0.75), na.rm=T)[[1]],
              q3_cindex=quantile(C_index, prob=c(0.25, 0.75), na.rm=T)[[2]]
    )%>%mutate(IQR_cindex=q3_cindex-q1_cindex)
  da3 <- da%>%dplyr::group_by(covs_out)%>%
    summarise(med_ibs=median(ibs, na.rm=T),
              q1_ibs=quantile(ibs, prob=c(0.25, 0.75), na.rm=T)[[1]],
              q3_ibs=quantile(ibs, prob=c(0.25, 0.75), na.rm=T)[[2]]
    )%>%mutate(IQR_ibs=q3_ibs-q1_ibs)
  
  da4 <- da1%>%left_join(da2)%>%left_join(da3)%>%
    dplyr::select(covs_out, cind_med, IQR_cindex, ibs_med, IQR_ibs, everything(), 
                  -med_cindex, -med_ibs)
  #apply(da4[,-c(1,4)], 2, function(x)round(x, 2))
  write.xlsx(da4, outname)
}
da4

