source("Z:/Private/npanthi/2025/April analysis/sterun/cd_rerun2/code_coll_PDAC_v1/func/compile_res.R")
#indat <- read_sas("Z:/Private/npanthi/2025/February analysis/analysis_refresh_02142025/adefpr_6236_02032025.sas7bdat")
indat <- read_sas("Z:/Private/npanthi/2025/June Analysis/adefpr_6236_05262025.sas7bdat")

fin1 <- setDT(indat)
indat<- lazy_dt(indat)

#######################################################
#######################################################
##II. Parameters
#######################################################
#######################################################
# Initial seed for random forest
sed <- 1234


# Full Set analysis

#Data processing

dat <-fin1[PDAC1LFL!="Y"  & PDACWTFL!="Y" & COHORT != "Cohort 11"
][CHDXCLAS =="PANCREATIC" & SAFFL == "Y",][, BLNLR:=as.numeric(round(BLNLR,2)),
][C1D1DS%in%c(160, 200, 220, 300),][FOLLOWUP_W>=20,
]

dat <- as.data.frame(dat)
datuse <- dat


# Covariates considered
covs <- c("CBR", "DCRU", "ORRU", "BESTTLLPCHG" ,"BLLMETS", "BLSOD", "BLNLR", "RASGRPCAT", "AGE", "PTGCMFL",  "SEX", "ORR")

datuse1 <- dat_process(dat=datuse, covs=covs, resp=c("PFSAVAL", "PFSCNSR"), step=2)
 

# Run model
modl <- "RSF"


num_repeats <- 5
num_outer_folds <- 5
num_inner_folds <- 5
seed=1234

rfs_params = list( "mtry"=ceiling(sqrt(length(covs))), "ntree"=c(100, 300, 500), "nodesize" =c(3, 7, 11))
crfs_params = list( "ntree"=c(100, 300, 500), "mtry"=5,
                    "mincriterion" =c(0, 0.2), "minbucket" = c(3, 7, 11))
lasso_params = list("lambda" = 10^seq(-4, 1, length=100), "alpha"=1)
crsfunbias_params <- data.frame(seed=1234)

#rf_model <- rfsrc(f.build("Surv(time, status)",covs), data=datuse1, ntree=5000, seed=1234, block.size = 1)

rf_model <- predmodrsf(form=f.build("Surv(time, status)",covs), dat=datuse1, ntree=500, mtry=4, nodesize=3,
           seedini=1234, importance=FALSE)
X <- datuse1[, covs]
X
library(iml)
predictor <- Predictor$new(model=rf_model,
                           data=X,
                           y=Surv(datuse1$time, datuse1$status),
                           predict.function=function(m, newdata){
                             round(predict(m, newdata)$predicted, 4)
                           })
#{set.seed(1234);Interaction$new(predictor, feature="CBR", grid.size=30)}
if(TRUE){
res <- {set.seed(1234);Interaction$new(predictor, grid.size=30)$results}
res1 <- as.data.frame(res)
colnames(res1)<- c("Feature", "Interaction")
res1%>%arrange(desc(Interaction))
}
res1%>%arrange(desc(Interaction))
features <- colnames(X)
interaction_matrix<- matrix(NA, length(features), length(features),
                            dimnames=list(features, features))
for(f in features){
  fi <- {set.seed(1234); Interaction$new(predictor, feature=f, grid.size=30)}
  result <- fi$results
  interaction_matrix[f, gsub(paste(":", f, sep=""), "", result$.feature)] <- result$.interaction
}
interaction_matrix1<- as.data.frame(interaction_matrix)

names(row.names())
interaction_matrix1%>%
  ggcorrplot(show.diag=FALSE, type="lower", lab=TRUE, lab_size=2)
