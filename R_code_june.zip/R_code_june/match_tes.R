# Load the package
library(MatchIt)

# Display package version
#packageVersion("MatchIt")
#Set 2
covs <-  c("CBR", "ORR", "DCRU", "BESTTLLPCHG", "BESTNLRPCHG", "LNPTCAT", "TLLUNGFL", "BLBMETS")
rsf_best=list(ntree=100, mtry=3, nodesize=7, seed=1234)
crsf_best <- list(ntree=500, mtry=5, minbucket=3, mincriterion=0, seed=1234)
lasso_best <- 0.004132

source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll/func/pred_plt_km_v1.R")
source("Z:/Private/npanthi/April analysis/sterun/cd_rerun2/code_coll/func/compile_res.R")

##6236 train data
indat <- read_sas("Z:/Private/npanthi/February analysis/analysis_refresh_02142025/adefpr_6236_02032025.sas7bdat")
fin1 <- setDT(indat)
indat<- lazy_dt(indat)
#Data processing
dat <-fin1[CHDXCLAS =="LUNG" & SAFFL == "Y" & NXEGFR=="",][, BLNLR:=as.numeric(round(BLNLR,2)),
][C1D1DS%in%c(120, 160, 200, 220, 300),
][FOLLOWUP_W>=20,][,`:=`(LNPTMCAT=factor(LNPTMCAT, levels=c("0/1", "2", ">=3"), ordered=T),
                         LNPTCAT = factor(LNPTCAT, levels=c("0/1", "2", ">=3"), ordered=T))
][, RAS_PERCENTAGE_PRE:=as.numeric(RAS_PERCENTAGE_PRE),
][, RAS_PERCENTAGE_CHANGE:=as.numeric(RAS_PERCENTAGE_CHANGE),]


dat <- as.data.frame(dat)

datuse <- dat
fintrain <- dat_process(dat=datuse, covs=covs, resp=c("PFSAVAL", "PFSCNSR"), step=2)

#6236 test data
fintest2 <- fintrain
fintest2$DCRU <- factor(fintest2$DCRU, levels=c("No", "Yes"))

argsdef <- list(train_dat=fintrain, test_dat=fintest2,covs=covs, best_lamb =1e-04,
                seedini=1234, usecvlamb=FALSE, rsf_best = rsf_best, crsf_best=crsf_best, appr=2)
pltset2def_3 <- do.call(pred_plt_crsf, argsdef)
plotdat3 <- pltset2def_3[[4]]%>%dplyr::select(col=group,
                                              everything())%>%mutate(group=paste(col, ":6236-All RAS", sep=""))
med003 <- pltset2def_3[[2]]%>%mutate(study = "6236-All RAS")
cindx <- cindibs(datrain=fintrain, datest=fintest2, rsf_best=rsf_best,
                 crsf_best=crsf_best)

cindx
###
##Eliron mono test data
indattes <- read_sas("Z:/Private/npanthi/April analysis/adefpr_6291_001_04072025.sas7bdat")

fin1tes <- setDT(indattes)
indattes<- lazy_dt(indattes)
#Data processing
dattes <-fin1tes[CHHISTO== "Non-Small Cell Lung Cancer (NSCLC)" & SAF14WFL == "Y" & C1D1DOSE=="200mg BID" & PRG12CFL=="Y",
][, LNPTCAT:=LNPTMCAT][,`:=`(LNPTCAT = factor(LNPTCAT, levels=c("0/1", "2", ">=3"), ordered=T))]
dattes_elimon <- as.data.frame(dattes)%>%dplyr::mutate(CBR_=ifelse(CBR=="", "No", CBR),
                                                ORR_=ifelse(ORR=="", "No", ORR),
                                                DCRU_=ifelse(DCRU=="", "No", DCRU),
                                                ORRU_=ifelse(ORRU=="", "No", ORRU))%>%
  dplyr::select(everything(), -CBR, -ORR, -DCRU, -ORRU)%>%
  dplyr::select(everything(), CBR=CBR_, ORR=ORR_, DCRU=DCRU_, ORRU=ORRU_)
datusetes <- dattes_elimon
dim(datusetes)
# Baseline+Activity markers
fintest <- dat_process(dat=datusetes, covs=covs, resp=c("PFSAVAL", "PFSCNSR"), step=2)
fintest$DCRU <- factor(fintest$DCRU, levels=c("No", "Yes"))

argsdef <- list(train_dat=fintrain, test_dat=fintest,covs=covs, best_lamb =1e-04,
                seedini=1234, usecvlamb=FALSE, rsf_best = rsf_best, crsf_best=crsf_best, appr=2)
pltset2def_3 <- do.call(pred_plt_crsf, argsdef)
med001 <- pltset2def_3[[2]]%>%mutate(study = "6291-001-PT")

cindx <- cindibs(datrain=fintrain, datest=fintest, rsf_best=rsf_best,
                 crsf_best=crsf_best)

cindx
plotdat1 <- pltset2def_3[[4]]%>%dplyr::select(col=group,
                                              everything())%>%mutate(group=paste(col, ":6291-001-PT", sep=""))

dim(fintrain)
dim(fintest)
#Eliron combo test data
##101 data
indattes <- read_sas("Z:/Private/npanthi/April analysis/sterun/adefpr_6291_101_04072025.sas7bdat")
fin1tes <- setDT(indattes)
indattes<- lazy_dt(indattes)
#Data processing
dattes <-fin1tes[CHHISTO== "Non-Small Cell Lung Cancer (NSCLC)" & SAF14WFL == "Y" & C1D1DOSE%in% c("200mg BID/200mg QD", "200mg BID/140mg QD") & PRG12CFL=="Y",
][, LNPTCAT:=LNPTMCAT][,`:=`(LNPTCAT = factor(LNPTCAT, levels=c("0/1", "2", ">=3"), ordered=T))]



dattes_elicom <- as.data.frame(dattes)%>%dplyr::mutate(CBR_=ifelse(CBR=="", "No", CBR),
                                                ORR_=ifelse(ORR=="", "No", ORR),
                                                DCRU_=ifelse(DCRU=="", "No", DCRU),
                                                ORRU_=ifelse(ORRU=="", "No", ORRU))%>%
  dplyr::select(everything(), -CBR, -ORR, -DCRU, -ORRU)%>%
  dplyr::select(everything(), CBR=CBR_, ORR=ORR_, DCRU=DCRU_, ORRU=ORRU_)
datusetes <- dattes_elicom

fintest101 <- dat_process(dat=datusetes, covs=covs, resp=c("PFSAVAL", "PFSCNSR"), step=2)
fintest101$DCRU <- factor(fintest101$DCRU, levels=c("No", "Yes"))

argsdef <- list(train_dat=fintrain, test_dat=fintest101,covs=covs, best_lamb =1e-04,
                seedini=1234, usecvlamb=FALSE, rsf_best = rsf_best, crsf_best=crsf_best, appr=2)

pltset2def_3 <- do.call(pred_plt_crsf, argsdef)
plotdat2 <- pltset2def_3[[4]]%>%dplyr::select(col=group,
                                              everything())%>%mutate(group=paste(col, ":6291-101-NT", sep=""))
med002 <- pltset2def_3[[2]]%>%mutate(study = "6291-101-NT")
cindx <- cindibs(datrain=fintrain, datest=fintest101, rsf_best=rsf_best,
                 crsf_best=crsf_best)

cindx
##Matching
##Eliron mono test data
indattes <- read_sas("Z:/Private/npanthi/April analysis/adefpr_6291_001_04072025.sas7bdat")

fin1tes <- setDT(indattes)
indattes<- lazy_dt(indattes)
#Data processing
dattes <-fin1tes[CHHISTO== "Non-Small Cell Lung Cancer (NSCLC)" & SAFFL == "Y" & C1D1DOSE=="200mg BID" & PRG12CFL=="Y",
][, LNPTCAT:=LNPTMCAT][,`:=`(LNPTCAT = factor(LNPTCAT, levels=c("0/1", "2", ">=3"), ordered=T),
                             CBR_=ifelse(CBR=="", "No", CBR),
                             ORR_=ifelse(ORR=="", "No", ORR),
                             DCRU_=ifelse(DCRU=="", "No", DCRU),
                             ORRU_=ifelse(ORRU=="", "No", ORRU))]
dattes_elimon <- as.data.frame(dattes)%>%
  dplyr::select(everything(), -CBR, -ORR, -DCRU, -ORRU)%>%
  dplyr::select(everything(), CBR=CBR_, ORR=ORR_, DCRU=DCRU_, ORRU=ORRU_)

##101 data
indattes <- read_sas("Z:/Private/npanthi/April analysis/sterun/adefpr_6291_101_04072025.sas7bdat")
fin1tes <- setDT(indattes)
indattes<- lazy_dt(indattes)
#Data processing
dattes <-fin1tes[CHHISTO== "Non-Small Cell Lung Cancer (NSCLC)" & SAFFL == "Y" & C1D1DOSE%in% c("200mg BID/200mg QD", "200mg BID/140mg QD") & PRG12CFL=="Y",
][, LNPTCAT:=LNPTMCAT][,`:=`(LNPTCAT = factor(LNPTCAT, levels=c("0/1", "2", ">=3"), ordered=T),
                             CBR_=ifelse(CBR=="", "No", CBR),
                             ORR_=ifelse(ORR=="", "No", ORR),
                             DCRU_=ifelse(DCRU=="", "No", DCRU),
                             ORRU_=ifelse(ORRU=="", "No", ORRU))]



dattes_elicom <- as.data.frame(dattes)%>%
  dplyr::select(everything(), -CBR, -ORR, -DCRU, -ORRU)%>%
  dplyr::select(everything(), CBR=CBR_, ORR=ORR_, DCRU=DCRU_, ORRU=ORRU_)
#######
covs <- c("BLALB",  "BLBMETS", "TLLUNGFL", "SMKSTAT2", "LNPTCAT", "ICDY", "WEIGHT")

dat1 <- dattes_elimon%>%dplyr::select(USUBJID, all_of(covs), PFSAVAL, PFSCNSR)%>%dplyr::mutate(treatment="Eli-Mono")
dat2 <- dattes_elicom%>%dplyr::select(USUBJID, all_of(covs), PFSAVAL, PFSCNSR)%>%dplyr::mutate(treatment="Eli-Combo")

datfin <- rbind(dat1, dat2)%>%
          #filter(!is.na(BESTTLLPCHG), !is.na(BESTNLRPCHG))%>%
          filter(!is.na(BLALB), !is.na(ICDY), !is.na(LNPTCAT))%>%
          mutate(treatmentn = ifelse(treatment=="Eli-Combo", 1, 0))
dim(datfin)
dim(dat1)
dim(dat2)
datfin%>%group_by(treatmentn)%>%dplyr::summarise(N=n())
# Matching
# Nearest Neighbour
library(MatchIt)
form <- f.build("treatmentn", covs)
m.out <- matchit(form, data = datfin, method="nearest", ratio=1, 
                 #caliper=0.25,
                 estimand="ATT", replace = F, distance="logit")
m.out$model
m.out <- matchit(form, data = datfin, ratio=1, 
                 #caliper=0.25,
                 estimand="ATT", replace = F, distance="logit")
m.out$model
m.out$distance
prob_ <- predict(glm(form, data=datfin, family="binomial"), type="response")
prob_
1-prob_
m.out <- matchit(form, data = datfin, 
                 estimand="ATT", replace = F, distance="rpart")
m.out <- matchit(form, data = datfin, 
                 estimand="ATT", replace = F, distance="nnet",
                 distance.options = list(size=16))
library(randomForest)
datfin$treatmentn<-factor(datfin$treatmentn, levels=c("0", "1"))
rf.out <- {set.seed(1234);randomForest(form, data=datfin)}
datfin1 <- datfin%>%mutate_if(is.character, as.factor)
datfin1$treatmentn
cfor <-  {set.seed(1278);party::cforest(form, data=datfin1, 
                                 controls=cforest_unbiased(ntree=5000))}
cfor <-  {set.seed(1278);partykit::cforest(form, data=datfin1, ntree=5000)}
probs <- predict(cfor, newdata=datfin1, type="prob")
eps <- do.call("rbind", probs)[,2]
eps <- rf.out$votes[,2]
eps <- probs[,2]
rfs <- rfsrc(form, data=datfin1)
eps <- rfs$predicted[,2]
m.out <- matchit(form, data = datfin1, method="nearest", ratio=1, 
                 #caliper=0.25,
                 estimand="ATT", replace = F, distance=eps,
                 discard="both")
love.plot(m.out, binary="std")
m.out <- matchit(form, data = datfin, method="genetic", ratio=1, 
                 #caliper=0.25,
                 estimand="ATT", pop.size=500)
love.plot(m.out, binary="std")
m.out
summary(m.out)
matched_data <- match.data(m.out)
dim(matched_data)
matched_data
love.plot(m.out, binary="std")

m.out1 <- matchit(form, data = datfin, method="nearest", ratio=2, 
                  distance=eps)
m.out1 <- matchit(form, data = datfin, method="optimal", ratio=2, 
                  distance=eps)
bal.tab(m.out1, m.threshold=0.1, un=TRUE)
m.out1
love.plot(m.out1, binary="std")
bal.tab(m.out1)
bal.tab(m.out1, m.threshold=0.1, un=TRUE)
love.plot(list(NN=m.out, optimal=m.out1),  abs=T,line = TRUE, 
          thresholds = c(m = .1),
               colors=c("blue", "darkgreen"), var.order="unmatched")

m.out2 <- matchit(form, data = datfin, method="quick", ratio=1,
                 estimand="ATT")
m.out2 <- matchit(form, data = datfin, method="nearest", ratio=1,
                  distance="probit",
                  mahvars = ~BLALB+BLBMETS,
                  estimand="ATT")
m.out2
# m.out2 <- matchit(form, data = datfin, , ratio=1,
#                   estimand="ATT")
love.plot(m.out2, binary="std")
bal.tab(m.out1)
love.plot(list(NN=m.out, optimal=m.out1),  abs=T,line = TRUE, 
          thresholds = c(m = .1),
          colors=c("blue", "darkgreen"), var.order="unmatched")


new.names <- c(BESTTLLPCHG = "Best %change in tumor (%)",
               LNPTCAT_2 = "Number of prior lines of therapy (=2)",
               BESTNLRPCHG = "Best %change in NLR (%)",
               `LNPTCAT_>=3` = "Number of prior lines of therapy (>=3)",
               `LNPTCAT_0/1` = "Number of prior lines of therapy (0/1)",
               BLBMETS_Y = "Baseline Brain Metastasis",
               ORR_Yes = "Overall Response Rate",
               CBR_Yes = "Clinical Benefit Rate",
               DCRU_Yes = "Disease Control Rate",
               TLLUNGFL_Y = "Presence of lesion in Lung"
)
love.plot(form,
          data = datfin, estimand = "ATT",
          weights = list(w1 = get.w(m.out),
                         w2 = get.w(m.out1)),
                         thresholds = c(m = .1),
          sample.names = c("Unweighted", "NN", "Optimal"),
          var.order = "unadjusted",
          shapes = c("triangle filled", "circle filled", "square filled"),
          colors = c("red", "blue", "darkgreen"),
          #abs = TRUE,
          line = TRUE,
          var.names = new.names,
          stars = "raw")+
  labs(caption="* indicates variables for which the displayed value is the raw (unstandardized) difference in means.")+
  theme(legend.position = c(0.2, .8),
        legend.box.background = element_rect())
#m.out, m.out1
##Pred-plt KM

