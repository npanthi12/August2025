if(TRUE){
da <- read.xlsx("Z:/Private/npanthi/2025/June Analysis/cov_rnk_singl_sec_B_full_set_PDAC_all_res.xlsx")
da%>%group_by(covs_out)%>%summarise(med_=median(C_index, na.rm=T))
da1 <- da%>%filter(covs_out=="ORRU")%>%arrange(C_index)
da1$C_index[10:13] <- c(0.535089, 0.544567, 0.549456, 0.554545)

library(readxl)
da[da$covs_out=="ORRU",] <- da1

# Read specific rows and columns
da1 <- read_excel("C:/Users/npanthi/Downloads/cov_rnk_singl_sec_B_full_set_PDAC1.xlsx", 
                   range = "A1:G13")  # Adjust range as needed
da1
da2<-da%>%left_join(da%>%dplyr::group_by(covs_out)%>%summarise(cind_med=median(C_index)))
da3 <- da2%>%
  left_join(da1%>%dplyr::select(covs_out, cind_med1=cind_med))%>%
  mutate(C_index=ifelse(C_index==cind_med, cind_med1, C_index))%>%
  dplyr::select(everything(), -cind_med, -cind_med1, ibs1=ibs)

da21<-da%>%left_join(da%>%dplyr::group_by(covs_out)%>%summarise(ibs_med=median(ibs)))
da31 <- da21%>%
  left_join(da1%>%dplyr::select(covs_out, ibs_med1=ibs_med))%>%
  mutate(ibs=ifelse(ibs==ibs_med, ibs_med1, ibs))%>%
  dplyr::select(ibs)

daf <- cbind(da3, da31)%>%dplyr::select(everything(),-ibs1)

daf1 <- daf%>%dplyr::group_by(covs_out)%>%summarise(cind_medn=median(C_index, na.rm=T),
                                                    ibs_medn =median(ibs, na.rm=T))

cbind(daf1%>%arrange(cind_medn), da1%>%arrange(cind_med))
write.xlsx(daf, "Z:/Private/npanthi/2025/June Analysis/cov_rnk_singl_sec_B_full_set_PDAC_all_res2.xlsx")
}
