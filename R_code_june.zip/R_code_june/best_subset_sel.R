library(StepReg)
form

exam1 <- StepReg::stepwise(formula = Surv(time, evnt) ~ CBR + ORR + DCRU + ORRU + BESTTLLPCHG + BESTNLRPCHG + 
                    BLNLR + ICDY + BLALB + SMKSTAT2 + BLBMETS + LNPTCAT + TLLUNGFL + 
                    RASGRPCAT3 + BLSOD,
                  data = data.frame(findat2a),
                  type = "cox",
                  test_method_cox="breslow",
                  strategy = "subset",
                  
                  metric = c("AIC","AICc"), best_n = 2)
exam1
library(BeSS)
findat2a$status <- findat2a$evnt
findat2a$y <- data.matrix(data.frame(time=findat2a$time, status=findat2a$status))
findat2a$x <- data.matrix(findat2a%>%dplyr::select(all_of(covs)))
findat2a$x <- model.matrix(f.build("", covs),findat2a)[,-1]
# Best subset selection
fit3 <- bess(findat2a$x, findat2a$y, s.list = 1:10, method = "sequential",
             family = "cox")
print(fit3)
#coef(fit3, sparse = TRUE)
bestmodel <- fit3$bestmodel
#summary(bestmodel)
bestmodel
# Plot solution path and the loss function
plot(fit3, type = "both", breaks = TRUE, K = 5)



exam2 <- stepwise(formula = form,
                  data = findat2a,
                  type = "cox",
                  
                  strategy = "bidirection",
                  metric = "AIC")
exam2
library("glmulti")
glmulti.cox.ph <- glmulti(f.build("Surv(time, status)", covs), data = findat2a, 
                          level = 1,             # to exclude interactions (use 2 for pairwise interaction terms)
                          method = "h",          # exhaustive method
                          crit = "aic",          # another option is "bic"
                          report = FALSE,        # No interim reports 
                          plotty = FALSE,        # No plot
                          confsetsize = 5,         # Keep 5 best models
                          fitfunction = "coxph") # coxph function
modl <- glmulti.cox.ph
args(modl)
modl@formulas
