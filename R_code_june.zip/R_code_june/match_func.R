tablesum <- function(dat=finda, covs=covs, covs_char=covs_char, strat="treatment", exct=NULL){
  varsToFactor <- covs_char
  dat[varsToFactor] <- lapply(dat[varsToFactor], factor)
  vars <- covs
  tableOne <- CreateTableOne(vars = vars, strata = c(strat), data = dat)
  pr <- print(tableOne, exact = exct)[,-4]
  return(pr)
}

tablesum2<- function(dat=inda, covs_cat =covs_cat, covs=covs,strat="treatment", exct=NULL){
  varsToFactor <- covs_cat
  dat[varsToFactor] <- lapply(dat[varsToFactor], factor)
  vars <-  covs
  vars_cont <- setdiff(covs, covs_cat)
  # Create Table 1 stratified by treatment group
  tableOne <- CreateTableOne(vars = vars, strata = c(strat), data = dat)
  pr <- print(tableOne,nonnormal = vars_cont, exact = exct)[,-4]
  return(pr)
}

tablesum2_<- function(dat=inda, covs_cat =covs_cat, covs=covs,strat="treatment", exct=NULL){
varsToFactor <- covs_cat
dat[varsToFactor] <- lapply(dat[varsToFactor], factor)
vars <-  covs
vars_cont <- setdiff(covs, covs_cat)
# Create Table 1 stratified by treatment group
tableOne <- CreateTableOne(vars = vars, strata = c(strat), data = dat)
pr <- print(tableOne,nonnormal = vars_cont, exact = exct)[,-4]
return(list(pr, summary(tableOne), tableOne))
}


da_process <- function(datr=fintrain, dates=fintest, covs_cat=covs_cat){
  for(i in 1:length(covs_cat)){
    dates[[covs_cat[i]]]<-factor(dates[[covs_cat[i]]], levels=levels(datr[[covs_cat[i]]]))
  }
  return(dates)
}



match_res <- function(model=m.out, raw_dat=datfin, covs=covs, covs_char=covs_char, strat="treatment", exct=NULL){
  summ <- summary(model, improvement=T)
  mdat <- match.data(model)
  pr1 <- tablesum(dat=raw_dat, covs=covs, covs_char=covs_char, strat=strat, exct=exct)
  pr2 <- tablesum(dat=mdat, covs=covs, covs_char=covs_char, strat=strat, exct=exct)
  
  psd <- function(model) {
    plot(model, type = "jitter", interactive=FALSE)
  }
  
  psh <- function(model) {
    plot(model, type = "hist", interactive=FALSE)
  }
  
  psl <- function(summ) {
    plot(summ, var.order = "unmatched", abs=F, threshold = c(0.25, 0.2, 0.1, 0.05))
  }
  psdens <- function(model, covs) {
    plot(model, type = "density", which.xs = f.build("",covs), interactive=F)
  }
  
  psqq <- function(model, covs) {
    plot(model, type = "qq", which.xs = f.build("",covs), interactive=F)
  }
  
  psecdf <- function(model, covs) {
    psecdf <- plot(model, type = "ecdf",  which.xs = f.build("",covs), interactive=F)
  }
  
  
  return(list("sample size before matching"=pr1,
              "sample size after matching"=pr2,
              "Model summary"=summ,
              "Match-model"=model,
              "PS-plot_jitter"=function(){psd(model)},
              "PS-plot_hist"=function(){psh(model)},
              "Cov_plot_loveplot"=function(){psl(summ)},
              "Cov_plot_density"=function(){psdens(model, covs)},
              "Cov_plot_qq"=function(){psqq(model, covs)},
              "Cov_plot_ecdf"=function(){psecdf(model, covs)},
              "matched_data"=mdat))
  
}
#Approximation: Asymptotic for n>20
ksstat <- function(n1=n1, n2=n2, KSstatistic=0.27){
  n      =  n1 * n2 /(n1 + n2);
  lambda =  max((sqrt(n) + 0.12 + 0.11/sqrt(n)) * KSstatistic , 0);
  j       =  (1:101);
  pValue  =  2 * sum(((-1)^(j-1))*exp(-2*lambda*lambda*j^2));
  pValue  =  min(max(pValue, 0), 1);
  return(pValue)
}

resp <- function(dat1=eliron_001un, dat2=eliron_101un, cov="BLALBC>3.6"){
  da1 <- dat1%>%dplyr::select(one_of(cov))
  da2 <- dat2%>%dplyr::select(one_of(cov))
  tes <- ks.test(da1[,1], da2[,1])
  return(data.frame(cov=cov, stat=round(tes$statistic,4), p_value = tes$p.value))
}

ksstat2 <- function(dat=datfin1, covs=covs, trt="treatmentn", ana="Pre-match",
                   matmod=m.out){
  if(ana=="Pre-match"){
    da1 <- model.matrix(f.build("", c(trt, covs)), dat)[,-1]
    form <- f.build(colnames(da1)[1], colnames(da1)[-1])
    da1 <- as.data.frame(data.matrix(da1))
    da1$distance <- matmod$distance
    eliron_001un <- da1[da1[,1]==0,]
    eliron_101un <- da1[da1[,1]==1,]
    
    covs2 <- c("distance", colnames(da1)[-1])
    resfin <- list()
    for(i in 1:length(covs2)){
      resfin[[i]] <- resp(dat1=eliron_001un, dat2=eliron_101un, cov=covs2[i])
    }
    resfin1 <- do.call("rbind", resfin)
    
    summ <- as.data.frame(summary(matmod)[[3]])
    summ$cov <- row.names(summ)
    finout <- summ%>%mutate(stat=round(`eCDF Max`,4))%>%
      left_join(summ%>%left_join(resfin1)%>%unique()%>%
                  filter(!is.na(stat))%>%dplyr::select(stat, cov, kspval0=p_value)%>%unique())%>%
      dplyr::select(cov, everything(), -stat)%>%arrange(desc(cov), kspval0)%>%
      mutate(kspval=na.locf(kspval0))%>%dplyr::select(-kspval0)
  }else{
    mtdat <- match.data(matmod)
    
    da1 <- model.matrix(f.build("", c(trt, covs)), mtdat)[,-1] 
    form <- f.build(colnames(da1)[1], colnames(da1)[-1])
    da1 <- as.data.frame(data.matrix(da1))
    da1$distance <- mtdat$distance
    eliron_001un <- da1[da1[,1]==0,]
    eliron_101un <- da1[da1[,1]==1,]
    
    covs2 <- c(colnames(da1)[-1])
    resfin <- list()
    for(i in 1:length(covs2)){
      resfin[[i]] <- resp(dat1=eliron_001un, dat2=eliron_101un, cov=covs2[i])
    }
    resfin1 <- do.call("rbind", resfin)
    
    summ <- as.data.frame(summary(matmod)[[4]])
    summ$cov <- row.names(summ)
    finout <- summ%>%mutate(stat=round(`eCDF Max`,4))%>%
      left_join(summ%>%left_join(resfin1)%>%unique()%>%
                  filter(!is.na(stat))%>%dplyr::select(stat, cov, kspval0=p_value)%>%unique())%>%
      dplyr::select(cov, everything(), -stat)%>%arrange(desc(cov), kspval0)%>%
      mutate(kspval=na.locf(kspval0))%>%dplyr::select(-kspval0)
  }
  return(finout)
}

summdat <- function(dat=dat, covs=covs_cons){
  `Data summary` <- as.data.frame(dat%>%dplyr::select(all_of(covs)))
  summ<- dfSummary( `Data summary` )
  pr <- print(summ, method = "render", headings = TRUE, silent = TRUE)
  pr$children[[2]][[6]] <- NULL
  return(pr)
}

match_mod <- function(dat, match_vars, trt_var){
  form <- f.build(trt_var, match_vars)
  allmod <- list()
  name <- c()
  allmod[[1]] <- matchit(form, data=dat, method="nearest", caliper=0.2)
  name[1] <- "Nearest"
  allmod[[2]] <- matchit(form, data=dat, method="optimal")
  name[2] <- "optimal"
  allmod[[3]] <- matchit(form, data=dat, method="full")
  name[3] <- "full"
  allmod[[4]] <- {set.seed(1234); matchit(form, data = dat, method="optimal", ratio=1, 
                                          estimand="ATT", replace = F, distance="randomforest", m.order="largest")}
  name[4] <- "optimal_RF"
  allmod[[5]] <- {set.seed(1234); matchit(form, data = dat, method="nearest", ratio=1, 
                                          caliper=0.2, estimand="ATT", replace = F, distance="randomforest", 
                                          m.order="largest")}
  name[5] <- "nearest_RF_caliper0_2"
  
  allmod[[6]] <- matchit(form, data = dat, 
                         estimand="ATT", replace = F, distance="rpart")
  name[6] <- "rpart"
  # allmod[[7]]<- matchit(form, data = dat, 
  #                       estimand="ATT", replace = F, distance="nnet",
  #                       distance.options = list(size=16))
  # name[7] <- "nnet"
  # allmod[[8]]<- matchit(form, data = dat, 
  #                       estimand="ATT", replace = F, distance="ebal")
  # name[8] <- "ebal"
  allmod[[7]] <- matchit(form, data = dat, method="genetic", ratio=1, 
                         #caliper=0.25,
                         estimand="ATT", pop.size=500)
  name[7] <- "genetic"
  # allmod[[9]] <- matchit(form, data = dat, method="cardinality", ratio=1, 
  #                        #caliper=0.25,
  #                        estimand="ATT")
  # name[9] <- "cardinality"
  allmod[[8]] <- matchit(form, data = dat, method="quick", ratio=1, 
                         #caliper=0.25,
                         estimand="ATT")
  name[8] <- "quick"
  dat[[trt_var]]<-factor(dat[[trt_var]], levels=c("0", "1"))
  dat1 <- dat%>%mutate_if(is.character, as.factor)
  cfor <-  {set.seed(1278);party::cforest(form, data=dat1, 
                                          controls=cforest_unbiased())}
  probs <- predict(cfor, newdata=dat1, type="prob")
  eps <- do.call("rbind", probs)[,2]
  allmod[[9]] <- matchit(form, data = dat1, method="nearest", ratio=1, 
                          #caliper=0.25,
                          estimand="ATT", replace = F, distance=eps)
  name[9] <- "CRF_nearest_cal0.25"
  names(allmod) <- name
  return(allmod)
}

compare_match_model2 <- function(match_models, data,
                                 treatment="trt", time="time", status="status", 
                                 smd_stat="mean",
                                 smd_cutoff=0.1,
                                 select_by_sample_size=TRUE,
                                 use_effective_sample_size=TRUE,
                                 plot_km=TRUE,
                                 return_tables=TRUE){
  library(MatchIt)
  library(cobalt)
  library(survival)
  library(dplyr)
  library(survminer)
  library(broom)
  results <- list()
  for(name in names(match_models)){
    #name <-  "nearest"
    m.out <- match_models[[name]]
    message("Evaluating: ", name)
    # tryCatch({
    # Covariate balance
    bal <- bal.tab(m.out, un = FALSE, m.threshold=NULL)
    smd_values <- bal$Balance$Diff.Adj
    # Matched data
    matched_data <- NULL
    matched_data <- MatchIt::match_data(m.out, data = data,
                                        distance = "prop.score")
    weights <- matched_data[["weights"]]%||%rep(1, nrow(matched_data))
    ess <- (sum(weights))^2/sum(weights^2)
    #Survival formula
    surv_formula <- as.formula(paste("Surv(", time, ",", status, ") ~", treatment))
    #surv_formula <- f.build("Surv(time, status)", treatment)
    #Fit cox-model
    cox_fit <- coxph(surv_formula, data=matched_data)
    # Log-rank test
    surv_diff <- survdiff(surv_formula, data=matched_data)
    logrank_p <- 1-pchisq(surv_diff$chisq, df=length(surv_diff$n)-1)
    # Compute smd statistic
    smd_stat_value <- switch(smd_stat,
                             "mean"=mean(abs(smd_values), na.rm=T),
                             "median"=median(abs(smd_values), na.rm=T),
                             "max"=max(abs(smd_values), na.rm=T),
                             stop("Unsupported smd_stat"))
    # KM plot
    km_plot <- NULL
    if(plot_km){
      # Create a survival object
      surv_object <- Surv(time =matched_data$time, event = matched_data$status)
      
      # Fit a survival curve using Kaplan-Meier estimator
      
      fit <- survfit(f.build("Surv(time, status)",colnames(matched_data)[1]), data = matched_data)
      #fit <- survfit(surv_formula, data = matched_data)
      km_plot <- ggsurvplot(fit, data=matched_data,
                            risk.table=TRUE, pval=TRUE,
                            legend.title=colnames(matched_data)[1],
                            ggtheme=theme_minimal(),
                            title=paste("KM Curve:", name))
    }
    #Collect balance and survival summaries
    balance_table <- if(return_tables){
      tibble(variable=rownames(bal$Balance),
             smd=bal$Balance$Diff.Adj)
    }else NULL
    
    survival_table <- if(return_tables){
      broom::tidy(cox_fit)%>%
        mutate(logrank_p=logrank_p)
    }else NULL
    
    # Store results
    results[[name]] <- list(
      match = m.out,
      matched_data=matched_data,
      matched_n = nrow(matched_data),
      effective_sample_size = ess,
      cox_model = cox_fit,
      smds = smd_values,
      all_smd_under_cutoff=all(abs(smd_values)<=smd_cutoff, na.rm=T),
      smd_stat = smd_stat_value,
      logrank_p = logrank_p,
      km_plot=km_plot,
      balance_table=balance_table,
      survival_table=survival_table
    )
    # }, error = function(e){
    #   warning(paste("Failed to evaluate model: ", name, "-", e$message))
    # })
    
  }
  #Identify best model
  smd_summary <- sapply(results, function(res) res$smd_stat)
  valid_models <- results%>%purrr::keep(~!is.null(.)&&.$all_smd_under_cutoff)
  if(length(valid_models)==0){
    warning("No models met the SMD cutoff. Returning all results.")
    best_method <- NULL
    best_model <- NULL
  }else{
    #Use effective sample size or raw n
    sizes <- sapply(valid_models, function(x){
      if(use_effective_sample_size)x$effective_sample_size else x$matched_n
      
    })
    if(select_by_sample_size){
      best_method <- names(which.max(sizes))
    }else{
      smd_means <- sapply(valid_models, function(x) mean(abs(x$smds), na.rm=T))
      best_method <- names(which.min(smd_means))
    }
    best_model <- valid_models[[best_method]]
    message("Best method (SMD < ", smd_cutoff, ") by ",
            if(select_by_sample_size)
              if(use_effective_sample_size) "effective sample size" else "raw sample size"
            else "mean SMD", ": ", best_method)
  }
  # best_method <- names(which.min(smd_summary))
  # message("Best method by ", smd_stat, " SMD: ", best_method)
  return(list(
    best_method = best_method,
    best_model = best_model,
    all_results = results,
    all_smd_summary = sapply(results, function(x) mean(abs(x$smds), na.rm=T)),
    all_sample_sizes = sapply(results, function(x) x$matched_n),
    all_effective_sample_sizes = sapply(results, function(x)x$effective_sample_size)
  ))
}

