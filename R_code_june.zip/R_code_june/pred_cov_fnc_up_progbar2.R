
runpred2 <- function(dat=datuse, covs=covs, resp=c("PFSAVAL", "PFSCNSR"),
                     num_repeats=num_repeats, num_outer_folds=num_outer_folds,
                     num_inner_folds=num_inner_folds, rfs_params=prm("rsf"),
                     crfs_params=prm("crsf"), modl="CRSF", seed=seed, 
                     outname1=outname1, outname2=outname2, 
                     outname3=outname3, outname4=outname4){
  
  pb <- pbapply::timerProgressBar(min = 0, max = length(covs), style = 3)
  
  res <- map(1:length(covs), function(.x){
    setTxtProgressBar(pb, .x)
    covsin <- covs[.x]
    fin <- dat_process(dat=dat, covs=covsin, resp=resp, step=2)
    rfs_params_up = list("mtry" = ceiling(sqrt(length(covsin))), 
                         "ntree"=c(100, 300, 500), "nodesize" =c(3, 7, 11))
    
    invisible(capture.output(resin <- runpred(indat=fin, num_repeats=num_repeats,
                                              num_outer_folds=num_outer_folds, num_inner_folds=num_inner_folds,
                                              rfs_params=rfs_params_up,
                                              crfs_params=crfs_params, modl=modl, seed=seed)))
    
    return(list(data.frame(covs_out=covsin, cind_med = median(resin$results$C_index, na.rm=T),
                      ibs_med = median(resin$results$ibs, na.rm=T),
                      set=paste("Set",.x, sep="")),data.frame(resin$results)%>%
                  mutate(covs_out=covsin, set=paste("Set",.x, sep=""))))
  })
  close(pb)
  
  pred_covs_uni_out <- do.call("rbind", res)
  pred_covs_uni <- do.call("rbind", pred_covs_uni_out[,1])
  pred_covs_uni$`1-ibs_med` <- 1-pred_covs_uni$ibs_med
  pred_covs_uni$rnk_cind <- pred_covs_uni$cind_med/max(pred_covs_uni$cind_med)
  pred_covs_uni$rnk_ibs <- pred_covs_uni$`1-ibs_med`/max(pred_covs_uni$`1-ibs_med`)
  pred_covs_uni$rnk_avg <- (pred_covs_uni$rnk_cind+pred_covs_uni$rnk_ibs)/2
  
  pred_covs_ord <- pred_covs_uni%>%arrange(desc(rnk_avg))
  write.xlsx(pred_covs_ord, outname1)
  covsord <- pred_covs_ord$covs_out
  pb1 <- pbapply::timerProgressBar(min = 0, max = length(covsord), style = 3)
  
  
  res1 <- map(1:length(covsord), function(.y){
    setTxtProgressBar(pb1, .y)
    covsinbest<- covsord[1:.y]
    fin <- dat_process(dat=dat, covs=covsinbest, resp=resp, step=2)
    
    rfs_params_up = list("mtry" = ceiling(sqrt(length(covsinbest))), 
                         "ntree"=c(100, 300, 500), "nodesize" =c(3, 7, 11))
    
    invisible(capture.output(res1in <- runpred(indat=fin, num_repeats=num_repeats,
                                               num_outer_folds=num_outer_folds, num_inner_folds=num_inner_folds,
                                               rfs_params= rfs_params_up,
                                               crfs_params=crfs_params, modl=modl, seed=seed)))
    
    return(list(data.frame(covs_out=paste0(covsinbest, collapse=", "), cind_med = median(res1in$results$C_index, na.rm=T),
                      ibs_med = median(res1in$results$ibs, na.rm=T),
                      set=paste("Set",.y, sep="")), data.frame(res1in$results)%>%
                  mutate(covs_out=paste0(covsinbest, collapse=", "), set=paste("Set",.y, sep=""))))
  })
  close(pb1)
  pred_covs_comb_out <- do.call("rbind", res1)
  pred_covs_comb <- do.call("rbind", pred_covs_comb_out[,1])
  pred_covs_comb$`1-ibs_med` <- 1-pred_covs_comb$ibs_med
  pred_covs_comb$rnk_cind <- pred_covs_comb$cind_med/max(pred_covs_comb$cind_med)
  pred_covs_comb$rnk_ibs <- pred_covs_comb$`1-ibs_med`/max(pred_covs_comb$`1-ibs_med`)
  pred_covs_comb$rnk_avg <- (pred_covs_comb$rnk_cind+pred_covs_comb$rnk_ibs)/2
  
  pred_covs_comb_ord <- pred_covs_comb%>%arrange(desc(rnk_avg))
  write.xlsx(pred_covs_comb_ord, outname2)
  write.xlsx(do.call("rbind", pred_covs_uni_out[,2]), outname3)
  write.xlsx(do.call("rbind", pred_covs_comb_out[,2]), outname4)
  return(list("Single Ranking"=pred_covs_ord,
              "Combined Ranking"=pred_covs_comb_ord,
              "Single All Res"=do.call("rbind", pred_covs_uni_out[,2]),
              "Combined All Res"=do.call("rbind", pred_covs_comb_out[,2])))
}

create_plt2 <- function(values=values, label=labels){
  plt <- ggplot(data.frame(val=values, label=label), 
                aes(x = label, y = val, fill = label)) +
    geom_boxplot() +
    stat_summary(fun=mean, geom="point", shape=20, size=3, color="red")+
    #stat_summary(fun=mean, geom="crossbar", width=0.5, color="red")+
    #scale_fill_manual(values = c("#FFBBCC", "#88CCFF", "green", "orange","blue"))+
    scale_y_continuous(breaks = seq(0, 1, by = 0.1)) +
    coord_cartesian(ylim = c(0, 1))+
    theme_minimal()
return(plt)
}


runpred <- function(indat=fin, num_repeats=num_repeats,
                    num_outer_folds=num_outer_folds, num_inner_folds=num_inner_folds,
                    rfs_params=prm("rsf"),
                    crfs_params=prm("crsf"), modl="CRSF", seed=seed){
  
  if(modl=="CRSF"){
    cat("Running cRSF model", "\n")
    res <- suppressWarnings(resfin_crsf(dat=indat, num_rept=num_repeats, num_outer_fld = num_outer_folds,
                                        num_inner_fld=num_inner_folds, params=crfs_params, seedini=seed))
    
  }
  if(modl=="RSF"){
    cat("Running RSF model", "\n")
    res <- suppressWarnings(resfin(dat=indat, num_rept=num_repeats, num_outer_fld = num_outer_folds,
                                   num_inner_fld=num_inner_folds, params=rfs_params, seedini=seed))
  }
  
  return(list("results"=res))
}

num_repeats <- 5
num_outer_folds <- 5
num_inner_folds <- 5
seed=1234

# num_repeats <- 1
# num_outer_folds <- 3
# num_inner_folds <- 5
# seed=1234

res2 <- runpred2(dat=datuse1, covs=covs, resp=c("PFSAVAL", "PFSCNSR"),
                 num_repeats=num_repeats, num_outer_folds=num_outer_folds,
                 num_inner_folds=num_inner_folds, rfs_params=prm("rsf"),
                 crfs_params=prm("crsf"), modl=modl, seed=1234,
                 outname1=outname1, outname2=outname2, 
                 outname3=outname3, outname4=outname4)
write.xlsx(res2$`Single Ranking`, outname1)
write.xlsx(res2$`Combined Ranking`, outname2)
write.xlsx(res2$`Single All Res`, outname3)
write.xlsx(res2$`Combined All Res`, outname4)
