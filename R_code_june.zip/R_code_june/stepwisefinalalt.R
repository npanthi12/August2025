library(pbapply)
vars_list <- candidate_vars
evaluate_model_ibs <- function(vars_list, data, time, status, parallel=FALSE){
  library(randomForestSRC)
  library(pec)
  library(survival)
  library(prodlim)
  library(pbapply)
  library(parallel)
  #if(is.vector(vars_list[[1]])) vars_list <- list(vars_list)
  single_eval <- function(vars){
    if(length(vars)==0)return(1)
    formula <- as.formula(paste0("Surv(", time, ",", status, ")~", paste(vars, collapse="+")))
    mod <- rfsrc(formula, data=data, ntree=300)
    pec_obj <- pec(list(mod=mod), data=data, formula=formula, exact=FALSE, cens.model="marginal")
    crps(pec_obj)[1]
  }
  if(parallel){
    cl <- makeCluster(detectCores(logical=FALSE))
    clusterExport(cl, varlist=c("data", "time", "status", "rfsrc", "pec", "single_eval", "Surv", "prodlim"))
    ibs_vals <- parLapply(cl, vars_list, single_eval)
  }else{
    ibs_vals <- lapply(vars_list, single_eval)
   
  }
  return(unlist(ibs_vals))
}
stepwise_ibs_rfsrc<- function(data, time, status, covariates,
                              direction=c("both", "forward", "backward"),
                              start=c("null", "full", "custom"),
                              start_vars =NULL,
                              parallel=FALSE,
                              verbose=TRUE){
  direction <- match.arg(direction)
  start <- match.arg(start)
  all_vars <- covariates
  current_vars <- switch(start,
                         null=character(0),
                         full=all_vars,
                         custom={if(is.null(start_vars))stop("start_vars must be specified")
                           start_vars})
  best_ibs <- if(length(current_vars)==0)1 else evaluate_model_ibs(list(current_vars), data, time,
                                                                     status, parallel)
  history <- list()
  done <- FALSE
  while(!done){
    candidates <- list()
    candidate_vars <- list()
    candidate_actions <- c()
    method_flags <- switch(direction,
                           forward=list(add=TRUE, drop=FALSE),
                           backward = list(add=FALSE, drop=TRUE),
                           both=list(add=TRUE, drop=TRUE))
    ##Forward Step
    if(method_flags$add){
      add_vars <- setdiff(all_vars, current_vars)
      for(v in add_vars){
        candidate_vars[[length(candidate_vars)+1]]<- setdiff(v, current_vars)
        candidate_actions <- c(candidate_actions, paste0("-", v))
      }
    }
    if(method_flags$drop && length(current_vars) > 1){
      for(v in current_vars){
        candidate_vars[[length(candidate_vars)+1]]<- setdiff(current_vars, v)
        candidate_actions <- c(candidate_actions, paste0("-", v))
      }
    }
    if(length(candidate_vars)==0)break
    if(verbose) cat("Evaluating candidates...\n")
    pb <- txtProgressBar(min=0, max=length(candidate_vars), style=3)
    for(i in seq_along(candidate_vars)) setTxtProgressBar(pb, i)
    close(pb)
    
    ibs_vals <- evaluate_model_ibs(candidate_vars, data, time, status, parallel)
    best_idx <- which.min(ibs_vals)
    min_ibs <- ibs_vals[best_idx]
    if(min_ibs+1e-6 < best_ibs){
      best_ibs <- min_ibs
      current_vars <- candidate_vars[[best_idx]]
      history[[length(history)+1]]<- list(step=length(history)+1,
                                          action=candidate_actions[best_idx],
                                          ibs=min_ibs,
                                          vars=current_vars)
      if(verbose)cat(sprintf("Step %d: %s -> IBS = %.4f\n", length(history), candidate_actions[best_idx], min_ibs))
    }else{
      done <- TRUE
    }
  }
  return(list(selected_variables=current_vars,
              best_ibs=best_ibs,
              history=history))
  }
plot_ibs_trajectory <- function(stepwise_result){
  steps <- sapply(stepwise_result$history, function(x) x$step)
  ibs_vals <- sapply(stepwise_result$history, function(x) x$ibs)
  actions <- sapply(stepwise_result$history, function(x) x$action)
  plot(steps, ibs_vals, type="b", pch=19, col="blue", xlab="Step", ylab="IBS", 
       main="IBS Trajectory")
  text(steps, ibs_vals, labels=actions, pos=3, cex=0.8)
}

set.seed(123)
sim_data <- data.frame(time=rexp(200, 0.1),
                       status=sample(0:1, 200, replace=TRUE),
                       x1=rnorm(200),
                       x2=runif(200),
                       x3=rbinom(200, 1, 0.5),
                       x4=rnorm(200),
                       x5=factor(sample(letters[1:3], 200, replace=T)))
res <- stepwise_ibs_rfsrc(data=sim_data,
                          time="time",
                          status="status",
                          covariates=c("x1", "x2", "x3", "x4", "x5"),
                          direction="both",
                          start="null",
                          parallel=FALSE,
                          verbose=TRUE)
plot_ibs_trajectory(res)
#Alt


stepwise_ibs_sel <- function(data, time, status, predictors,
                             start="null", direction="both", custom_vars=NULL,
                             parallel=FALSE, verbose=TRUE){

  
  all_combinations <- function(current_vars, direction){
    add_set <- setdiff(predictors, current_vars)
    drop_set <- current_vars
    candidates <- list()
    if(direction%in%c("forward", "both")){
      candidates <- c(candidates, lapply(add_set, function(v) sort(c(current_vars, v))))
      
    }
    if(direction%in%c("backward", "both")){
      candidates <- c(candidates, lapply(drop_set, function(v) setdiff(current_vars, v)))
      
    }
    candidates <- unique(lapply(candidates, sort))
    return(candidates)
    
  }

  eval_single <- function(vars){
    if(length(vars)==0)return(1)
    formula <- as.formula(paste0("Surv(", time, ",", status, ")~", paste(vars, collapse="+")))
    mod <- rfsrc(formula, data=data, ntree=300, seed=1234, block.size=1)
    pec_obj <- 1-SurvMetrics::Cindex(mod, data)[[1]]
    return(pec_obj)
  }
  
  evaluate_model_ibs <- function(vars_list){
    ibs_vals <- pbapply::pbsapply(vars_list, eval_single)
    return(unlist(ibs_vals))
  }
  current_vars <- switch(start,
                          null=c(),
                          full=predictors,
                                           custom={if(is.null(custom_vars))stop("start_vars must be specified")
                                             custom_vars})
  current_ibs <- if(length(current_vars)==0)1 else eval_single(current_vars)
  best_vars <- current_vars
  best_ibs <- current_ibs
  trajectory <- list(list(vars=best_vars, ibs=best_ibs))
  improved <- TRUE
  stp <- list()
  while(improved){
    improved <- FALSE
    candidate_sets <- all_combinations(best_vars, direction)
    var1 <- best_vars
    candidate_sets <- Filter(function(v) !identical(v, best_vars), candidate_sets)
    if(length(candidate_sets)==0)break
    ibs_scores <- evaluate_model_ibs(candidate_sets)
    best_idx <- which.min(ibs_scores)
    if(ibs_scores[best_idx]<best_ibs){
      best_ibs <- ibs_scores[best_idx]
      best_vars <- candidate_sets[[best_idx]]
      trajectory[[length(trajectory)+1]]<-list(vars=best_vars, ibs=best_ibs)
      stp[[ length(trajectory)]] <- data.frame(vars =sapply(candidate_sets, function(x) paste(x, collapse="+")), 
                                               scores=ibs_scores, best_score=round(best_ibs, 4),
                                               best_var=paste(best_vars, collapse=","),
                                               add= sapply(sapply(candidate_sets, function(x) setdiff(x, var1)), function(x) paste(x, collapse=",")),
                                               remove=sapply(sapply(candidate_sets, function(x) setdiff(var1, x)), function(x) paste(x, collapse=",")),
                                               from=paste(var1, collapse=","))
      
      improved <- TRUE
      if(verbose) cat("Step:", length(trajectory), "- Vars:", paste(best_vars, collapse=","),
                      "- IBS:", round(best_ibs, 4), "\n")
    }
  }
 

  return(list(selected_vars=best_vars,
              ibs=best_ibs,
              steps=trajectory,
              stp))
}
library(survival)
dat <- na.omit(survival::veteran)

result <- stepwise_ibs_sel(data=dat,
                           time="time",
                           status="status",
                           predictors=colnames(dat)[-c(3,4)],
                           start="full",
                           direction="both")
result
#number_of_models <- number_of_steps(number of covariates*number_of_predictors