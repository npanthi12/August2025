library(future.apply)
get_subsets <- function(vars, k){
  combn(vars, k, simplify=FALSE)
}

evaluate_subset_ibs <- function(data, subset_vars){
  outcome <- rfsrc(f.build("Surv(time, status)", subset_vars), data=data, seed=1234)
  res <- 1-SurvMetrics::Cindex(outcome, data)[[1]]
  return(res)
}

evaluate_subset_ibs <- function(data, subset_vars){
  outcome <- rfsrc(f.build("Surv(time, status)", subset_vars), data=data, seed=1234)
  res <- 1-SurvMetrics::Cindex(outcome, data)[[1]]
  return(res)
}

best_subset_selection_ibs <- function(data, max_subset_size = 3, allsub=TRUE,
                                      parallel=TRUE,  seed=123, save_results=TRUE,
                                      plot_result=TRUE, result_prefix ="ibs_selection"){
  set.seed(seed)
  vars <- setdiff(names(data), c("time", "status"))
  results <- list()
  # pb <- progress_bar$new(total=sum(sapply(1:max_subset_size, function(k) choose(length(vars), k))),
  #                        format="[:bar] :percent :current/:total :eta")
  pb <- pbapply::timerProgressBar(min = 0, max =
                                    sum(sapply(1:max_subset_size, function(k) choose(length(vars), k)))/2,
                                        style = 3)

  
  if(parallel){
    library(future.apply)
    plan(multisession) 
    par_func <- future_sapply
  }else{
    par_func <- sapply
  }
 start_time <- Sys.time()
 if(allsub){
   outres <- 1:max_subset_size
 }else{
   outres <- max_subset_size
 }
 sub<- list()
  for(k in outres){
   
    subsets <- combn(vars, k, simplify=FALSE)
    sub[[k]] <- subsets

    if(parallel){
      scores <- par_func(subsets, function(subset_vars){
        ibs <- evaluate_subset_ibs(data, subset_vars)
        #pb$tick()
        
        return(ibs)
      }, future.seed=TRUE)}else{
      scores <- par_func(subsets, function(subset_vars){
        ibs <- evaluate_subset_ibs(data, subset_vars)
        #pb$tick()
        return(ibs)
      })}
    setTxtProgressBar(pb, length(subsets))
    best_idx <- which.min(scores)
    results[[paste0("Size_", k)]] <- list(best_vars=subsets[[best_idx]],
                                          ibs = scores[best_idx],
                                          all_scores=scores)
  }
 close(pb)
  all_best <- do.call(rbind, lapply(seq_along(results), function(i){
    data.frame(size=i, ibs=results[[i]]$ibs, vars=paste(results[[i]]$best_vars, collapse=", "))
  }))
  best_row <- all_best[which.min(all_best$ibs), ]
  runtime <- Sys.time()-start_time
  if(plot_result){
    library(ggplot2)
    plt <- ggplot(all_best, aes(x=size, y=ibs))+
      geom_line(color="blue")+
      geom_point(color="red", size=3)+
      ggtitle("IBS vs Number of Predictors")+
      xlab("Number of Predictors")+
      ylab("Integrated Brier Score (IBS)")+
      theme_minimal()
      #ggsave(paste0(result_prefix, "_ibs_plot.png"))
    ggplot2::ggsave(paste0(result_prefix, "_ibs_plot.png"), plot=plt, width=7, height=5, dpi=300)
  }
  if(save_results){
    write.csv(all_best, paste0(result_prefix, "_ibs_summary.csv"), row.names=FALSE)
  }
  list(all_results=results,
       subsets=sub,
       summary_table=all_best,
       best_subset=best_row,
       runtime=runtime)
}
result <- best_subset_selection_ibs(data=veteran1%>%dplyr::select(everything(),-PFSAVAL, -PFSCNSR), 
                                    max_subset_size = 3, allsub=TRUE, parallel=FALSE)
result



veteran1 <- na.omit(veteran)
veteran1$status <- ifelse(veteran1$status==1, 1, 0)
veteran1$PFSAVAL <- veteran1$time
veteran1$PFSCNSR <- 1-veteran1$status
result <- stepwise_cforest_ibs(data=veteran1, 
                               time="time",
                               status = "status",
                               candidate_vars=c("age", "celltype", "karno",
                                                "trt", "diagtime", "prior"), direction="both", 
                               max_vars =NULL, 
                               verbose = TRUE, min_improve=1e-4, plot=TRUE)

result