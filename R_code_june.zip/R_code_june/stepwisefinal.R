source("Z:/Private/npanthi/2025/April analysis/sterun/cd_rerun2/code_coll/func/compile_res.R")
runpred <- function(indat=fin, num_repeats=num_repeats,
                    num_outer_folds=num_outer_folds, num_inner_folds=num_inner_folds,
                    rfs_params=prm("rsf"),
                    crfs_params=prm("crsf"), modl="CRSF", seed=seed){
  
  if(modl=="CRSF"){
    cat("Running cRSF model", "\n")
    res <- suppressWarnings(resfin_crsf(dat=indat, num_rept=num_repeats, num_outer_fld = num_outer_folds,
                                        num_inner_fld=num_inner_folds, params=crfs_params, seedini=seed))
    
  }
  if(modl=="RSF"){
    cat("Running RSF model", "\n")
    res <- suppressWarnings(resfin(dat=indat, num_rept=num_repeats, num_outer_fld = num_outer_folds,
                                   num_inner_fld=num_inner_folds, params=rfs_params, seedini=seed))
  }
  
  return(list("results"=res))
}



evaluate_subset_ibs <- function(data=data, covariates=vars){
  if(length(covariates)>0){
 
    fin <- dat_process(dat=data, covs=covariates, resp=c("PFSAVAL", "PFSCNSR"), step=2)
    
    rfs_params_up = list("mtry" = ceiling(sqrt(length(vars))), 
                         "ntree"=c(100, 300, 500), "nodesize" =c(3, 7, 11))
    crfs_params = list( "ntree"=c(100, 300, 500), "mtry"=5,
                        "mincriterion" =c(0, 0.2), "minbucket" = c(3, 7, 11))
    
    invisible(capture.output(resin <- runpred(indat=fin, num_repeats=5, num_outer_folds=5, 
                                              num_inner_folds=5,
                                              rfs_params= rfs_params_up,
                                              crfs_params=crfs_params, modl="CRSF", seed=1234)))
    #res <- median(resin$results$ibs, na.rm=T)
    res <- 1-median(resin$results$C_index, na.rm=T)
  
  }else{
    res=NA
  }
  return(list(res, paste0(covariates, collapse="+")))
}

library(progress)

library(pbapply)

stepwise_ibs_selection <- function(data,
                                   direction=c("forward",
                                               "backward", "both"),
                                   min_improve=0.001, parallel=TRUE,
                                   verbose=TRUE, seed=1234){
  set.seed(seed)
  start_time <- Sys.time()
  direction <- match.arg(direction)
  vars <- setdiff(names(data), c("PFSAVAL", "PFSCNSR"))
  current_vars <- if(direction=="forward"|direction=="both") character(0) else vars
  history <- list()
  previous_score <- 1
  improved <- TRUE
  stp <- list()
  pb <- pbapply::timerProgressBar(min = 0, max =10,
                                  style = 3)
  eval_func <- if(parallel){
    plan(multisession)
    function(X, FUN) future_sapply(X, FUN, future.seed=TRUE)
  }else{
    function(X, FUN) pbsapply(X, FUN)
  }
  if(verbose) cat("Starting stepwise selection (", direction,
                  ")...\n", sep="")
  while(improved){
    candidates <- switch(direction,
                         forward = setdiff(vars, current_vars),
                         backward = current_vars,
                         both = unique(c(setdiff(vars, current_vars), 
                                         current_vars)))
    if(length(candidates)==0) break
    if(verbose) cat ("Evaluating candidates: ", paste(candidates, collapse=", "), 
                     "\n")
    scores0 <- eval_func(candidates, function(v){
      # v <- candidates[5]
      test_vars<- switch(direction,
                         forward = c(current_vars, v),
                         backward = setdiff(current_vars, v),
                         both = if(v%in% current_vars & length(current_vars)!=2) setdiff(current_vars, v)
                         else if(v%in% current_vars & length(current_vars)==2) character(0)
                         else c(current_vars, v)
                         # both = if(v%in% current_vars) setdiff(current_vars, v)
                         # else c(current_vars, v)
      )
      evaluate_subset_ibs(data=data, covariates=test_vars)
    })
    scores <- do.call(rbind, scores0[1,])[,1]
    scores <-   as.data.frame(scores)[,1]
    modl <- do.call(rbind, scores0[2,])
    stp[[length(history)+1]] <- data.frame(step=length(history)+1,
                                           var = row.names(modl), model=modl[,1],
                                           ibs=scores)%>%mutate(
                                             sel =ifelse(var%in%current_vars, "backward","forward"),
                                             action=ifelse(sel=="forward", "add", "remove"),
                                             best=ifelse(ibs==min(ibs, na.rm=T),"selected",""))
    row.names(stp[[length(history)+1]])<- NULL
    #names(stp[[length(history)+1]]) <-   paste("Selected model=", paste(current_vars, collapse="+"), "; IBS=", best_score)
    
    
    #%>%arrange(desc(ibs))
    
    
    best_idx <- which.min(scores)
    best_var <- candidates[best_idx]
    best_score <- scores[best_idx]
  
    if((previous_score-best_score)>=min_improve){
      current_vars <- switch(direction,
                             forward = c(current_vars, best_var),
                             backward = setdiff(current_vars, best_var),
                             both = if(best_var%in% current_vars) setdiff(current_vars, best_var)
                             else c(current_vars, best_var))
      previous_score <- best_score
      history[[length(history)+1]]<- list(vars=current_vars, ibs=best_score)
      
    }else{
      improved=FALSE
      if(verbose) cat("No further improvement. Stopping.\n")
    }
    cat("Selected model=", paste(current_vars, collapse="+"), "; IBS=", best_score, "\n")
    if(verbose){
      cat("Best candidate:", best_var, "with IBS =", round(best_score, 4), "\n")
    }
    setTxtProgressBar(pb, length(history)+1)
  }
  close(pb)
  history_df <- do.call(rbind, lapply(seq_along(history), function(i){
    data.frame(step=i, ibs=history[[i]]$ibs,
               vars=paste(history[[i]]$vars, collapse=", "))
  }))
  runtime <- Sys.time()-start_time
  return(list(history=history,
       summary_table=history_df,
       best_subset=tail(history_df, 1),
       step=stp,
       runtime=runtime))
}

library(future.apply)
sel <- stepwise_ibs_selection(data=datuse1,
                              direction=c( "both"),
                              min_improve=0.002, parallel=FALSE,
                              verbose=TRUE, seed=1234)
data.frame(do.call(rbind, sel[[4]]))%>%dplyr::filter(best=="selected")
sel
saveRDS(sel, "nsclc_secC_cindex.rds")
outname <- "Z:/Private/npanthi/2025/June Analysis/stepwise_res_nsclc_sec_C.xlsx"
outplot <- "Z:/Private/npanthi/2025/June Analysis/cindex_plot_nsclc_sec_C.png"
write.xlsx(result$trajectory, outname)
ggplot2::ggsave(outplot, plot=result$plot, width=7, height=5, dpi=300)
