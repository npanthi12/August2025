source("Z:/Private/npanthi/2025/April analysis/sterun/cd_rerun2/code_coll/func/compile_res.R")
runpred <- function(indat=fin, num_repeats=num_repeats,
                    num_outer_folds=num_outer_folds, num_inner_folds=num_inner_folds,
                    rfs_params=prm("rsf"),
                    crfs_params=prm("crsf"), modl="CRSF", seed=seed){
  
  if(modl=="CRSF"){
    cat("Running cRSF model", "\n")
    res <- suppressWarnings(resfin_crsf(dat=indat, num_rept=num_repeats, num_outer_fld = num_outer_folds,
                                        num_inner_fld=num_inner_folds, params=crfs_params, seedini=seed))
    
  }
  if(modl=="RSF"){
    cat("Running RSF model", "\n")
    res <- suppressWarnings(resfin(dat=indat, num_rept=num_repeats, num_outer_fld = num_outer_folds,
                                   num_inner_fld=num_inner_folds, params=rfs_params, seedini=seed))
  }
  
  return(list("results"=res))
}

nested_cv_ibs_cforest <- function(data=datuse1, time="time", status ="status",
                                     vars=covs){
  
  fin <- dat_process(dat=data, covs=vars, resp=c("PFSAVAL", "PFSCNSR"), step=2)
  
  rfs_params_up = list("mtry" = ceiling(sqrt(length(vars))), 
                       "ntree"=c(100, 300, 500), "nodesize" =c(3, 7, 11))
  crfs_params = list( "ntree"=c(100, 300, 500), "mtry"=5,
                      "mincriterion" =c(0, 0.2), "minbucket" = c(3, 7, 11))
  
  invisible(capture.output(resin <- runpred(indat=fin, num_repeats=5, num_outer_folds=5, 
                                            num_inner_folds=5,
                                            rfs_params= rfs_params_up,
                                            crfs_params=crfs_params, modl="CRSF", seed=1234)))
  #res <- 1-median(resin$results$ibs, na.rm=T)
  #res <- median(resin$results$ibs, na.rm=T)
  res <- 1-median(resin$results$C_index, na.rm=T)
  return(res)
}

library(progress)
stepwise_cforest_ibs <- function(data, time, status, candidate_vars, direction=c("forward", "backward", "both"),
                                 max_vars =NULL, 
                                 verbose = TRUE, min_improve=1e-4, plot=TRUE){
  direction <- match.arg(direction)
  selected <- if(direction=="backward") candidate_vars else character(0)
  remaining <- setdiff(candidate_vars, selected)
  if(direction=="backward"){
    best_score <- nested_cv_ibs_cforest(data=data, time=time, status=status, covariates=selected)
  }else{
    best_score <- Inf
  }
  
  improved <- TRUE 
  step <- 1
  history <- data.frame(step=integer(), num_vars =integer(), 
                        variable=character(), action=character(), score=numeric(),
                        stringsAsFactors = FALSE)
  pb <- progress_bar$new(format="[:bar] :current/ :total",
                         total=1000)
  while(improved){
    pb$tick()
    improved <- FALSE
    best_step_score <- best_score
    best_var <- NULL
    best_action <- NULL
    
    #Forward step
    if(direction%in%c("forward", "both") && length(remaining) > 0){
      for(var in remaining){
        trial_vars <- union(selected, var)
        score <- nested_cv_ibs_cforest(data, time, status, trial_vars)
        if(verbose) message(sprintf("Step %d: Try ADD %s => IBS: %.4f", step, var, score))
        if(score < best_step_score - min_improve){
          best_step_score <- score
          best_var <- var
          best_action <- "add"
        }
      }
    }
    #Backward step
    if(direction%in%c("backward", "both") && length(selected)>1){
      for(var in selected){
        trial_vars <- setdiff(selected, var)
        score <- nested_cv_ibs_cforest(data, time, status, trial_vars)
        if(verbose) message(sprintf("Step %d: Try REMOVE %s => IBS: %.4f", step, var, score))
        if(score < best_step_score-min_improve){
          best_step_score <- score
          best_var <- var
          best_action<- "remove"
        }
      }
    }
    if(!is.null(best_action)){
      if(best_action=="add"){
        selected <- union(selected, best_var)
        remaining <- setdiff(remaining, best_var)
      }else if(best_action=="remove"){
        selected <- setdiff(selected, best_var)
        remaining <- union(remaining, best_var)
      }
      best_score <- best_step_score
      improved <- TRUE
      if(verbose) message(sprintf("Step %d: %s %s (New IBS: %.4f)", step, toupper(best_action),
                                  best_var, best_score))
      step <- step+1
      history <- rbind(history, data.frame(step=step, num_vars =length(selected), 
                                           variable=best_var, action=best_action, score=best_score))
      
    }
    if(!is.null(max_vars) && length(selected) >= max_vars) break
  }
  #if(!improved && verbose) cat("No further improvement. Selection complete.\n")
  if(plot){
    plt <- ggplot(history, aes(x=num_vars, y=score))+
      geom_line(color="#0072B2")+
      geom_point(aes(color=action), size=3)+
      scale_color_manual(values=c("add"="#009E73", "remove"="#D55E00", start="black"))+
      theme_minimal()+
      labs(title="IBS vs Number of Predictors",
           x="Number of Predictors",
           y="Nested CV IBS(lower is better)",
           color="Step type")
    print(plt)
  }
  return(list(selected_vars=selected, best_score=best_score, trajectory=history, plot=plt))
}


result <- stepwise_cforest_ibs(data=datuse1, 
                               time="time",
                               status = "status",
                               candidate_vars=covs, direction="both", 
                               max_vars =NULL, 
                               verbose = TRUE, min_improve=0.002, plot=TRUE)




outname <- "Z:/Private/npanthi/2025/June Analysis/stepwise_res_nsclc_sec_B.xlsx"
outplot <- "Z:/Private/npanthi/2025/June Analysis/cindex_plot_nsclc_sec_B.png"
write.xlsx(result$trajectory, outname)
ggplot2::ggsave(outplot, plot=result$plot, width=7, height=5, dpi=300)