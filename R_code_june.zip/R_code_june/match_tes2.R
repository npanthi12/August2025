source("Z:/Private/npanthi/2025/April analysis/sterun/cd_rerun2/code_coll/func/pred_plt_km_v1.R")
source("Z:/Private/npanthi/2025/April analysis/sterun/cd_rerun2/code_coll/func/compile_res.R")
source("Z:/Private/npanthi/2025/April analysis/sterun/cd_rerun2/code_coll/func/boot_fnc_map.R")
seedini <- 1234
#Import data
#####################################
##6236 train data
indat <- read_sas("Z:/Private/npanthi/2025/February analysis/analysis_refresh_02142025/adefpr_6236_02032025.sas7bdat")
fin1 <- setDT(indat)
indat<- lazy_dt(indat)
#Data processing
dat <-fin1[CHDXCLAS =="LUNG" & SAFFL == "Y" & NXEGFR=="",][, BLNLR:=as.numeric(round(BLNLR,2)),
][C1D1DS%in%c(120, 160, 200, 220, 300),
][FOLLOWUP_W>=20,][, RAS_PERCENTAGE_PRE:=as.numeric(RAS_PERCENTAGE_PRE),
][, RAS_PERCENTAGE_CHANGE:=as.numeric(RAS_PERCENTAGE_CHANGE),]


dat <- as.data.frame(dat)

datuse <- dat%>%mutate(LNPTCAT = ifelse(LNPTCAT=="0/1", "<=1", ">=2"),
                       LNPTCAT = factor(LNPTCAT, levels=c( "<=1", ">=2")))%>%
  dplyr::mutate(BLALBC=ifelse(BLALB <=3.6, "<=3.6", ">3.6"),
                WEIGHTC = ifelse(WEIGHT <=60, "<=60", ">60"),
                SMKSTAT2= ifelse(SMKSTAT2=="Never", "Never", "Current/Past"))

#####################################
##Matching
#####################################
#####################################
##Eliron mono test data
indattes <- read_sas("Z:/Private/npanthi/2025/April analysis/adefpr_6291_001_04072025.sas7bdat")

fin1tes <- setDT(indattes)
indattes<- lazy_dt(indattes)
#Data processing
dattes <-fin1tes[CHHISTO== "Non-Small Cell Lung Cancer (NSCLC)" & SAF14WFL == "Y" & C1D1DOSE=="200mg BID" & PRG12CFL=="Y",
][, LNPTCAT:=LNPTMCAT][,`:=`(
  CBR_=ifelse(CBR=="", "No", CBR),
  ORR_=ifelse(ORR=="", "No", ORR),
  DCRU_=ifelse(DCRU=="", "No", DCRU),
  ORRU_=ifelse(ORRU=="", "No", ORRU))]

dattes_elimon <- as.data.frame(dattes)%>%
  dplyr::select(everything(), -CBR, -ORR, -DCRU, -ORRU)%>%
  dplyr::select(everything(), CBR=CBR_, ORR=ORR_, DCRU=DCRU_, ORRU=ORRU_)%>%
  filter(!is.na(BLALB),  !is.na(LNPTCAT))%>%
  dplyr::mutate(BLALBC=ifelse(BLALB <=3.6, "<=3.6", ">3.6"),
                WEIGHTC = ifelse(WEIGHT <=60, "<=60", ">60"),
                LNPTCAT = ifelse(LNPTCAT=="0/1", "<=1", ">=2"),
                SMKSTAT2= ifelse(SMKSTAT2=="Never", "Never", "Current/Past"))


##101 data
indattes <- read_sas("Z:/Private/npanthi/2025/April analysis/sterun/adefpr_6291_101_04072025.sas7bdat")
fin1tes <- setDT(indattes)
indattes<- lazy_dt(indattes)
#Data processing
dattes <-fin1tes[CHHISTO== "Non-Small Cell Lung Cancer (NSCLC)" & SAF14WFL == "Y" & C1D1DOSE%in% c("200mg BID/200mg QD", "200mg BID/140mg QD") & PRG12CFL=="Y",
][, LNPTCAT:=LNPTMCAT][,`:=`(
  CBR_=ifelse(CBR=="", "No", CBR),
  ORR_=ifelse(ORR=="", "No", ORR),
  DCRU_=ifelse(DCRU=="", "No", DCRU),
  ORRU_=ifelse(ORRU=="", "No", ORRU))]



dattes_elicom <- as.data.frame(dattes)%>%
  dplyr::select(everything(), -CBR, -ORR, -DCRU, -ORRU)%>%
  dplyr::select(everything(), CBR=CBR_, ORR=ORR_, DCRU=DCRU_, ORRU=ORRU_)%>%
  filter(!is.na(BLALB),  !is.na(LNPTCAT))%>%
  dplyr::mutate(BLALBC=ifelse(BLALB <=3.6, "<=3.6", ">3.6"),
                WEIGHTC = ifelse(WEIGHT <=60, "<=60", ">60"),
                LNPTCAT = ifelse(LNPTCAT=="0/1", "<=1", ">=2"),
                SMKSTAT2= ifelse(SMKSTAT2=="Never", "Never", "Current/Past"))
#######
covs <- c("BLALBC",  "BLBMETS", "TLLUNGFL", "SMKSTAT2", "LNPTCAT",  "WEIGHTC")

dat1 <- dattes_elimon%>%dplyr::select(USUBJID, all_of(covs), PFSAVAL, PFSCNSR)%>%dplyr::mutate(treatment="Eli-Mono")
dat2 <- dattes_elicom%>%dplyr::select(USUBJID, all_of(covs), PFSAVAL, PFSCNSR)%>%dplyr::mutate(treatment="Eli-Combo")

treated <- "Eli-Combo"
control <- "Eli-Mono"
datfin <- rbind(dat1, dat2)%>%
  #filter(!is.na(BESTTLLPCHG), !is.na(BESTNLRPCHG))%>%
  #filter(!is.na(BLALB),  !is.na(LNPTCAT))%>%
  mutate(treatmentn = ifelse(treatment==treated, 1, 0))
# dim(datfin)
# dim(dat1)
# dim(dat2)
# datfin%>%group_by(treatmentn)%>%dplyr::summarise(N=n())

###Matching
#Model 1
form <- f.build("treatmentn", covs)
fit <- glm(form, data=datfin, family="binomial")

predict(fit, data=datfin, type="link")
datfin$ps <- predict(fit, data=datfin, type="response")
datfin$logt <- predict(fit, data=datfin, type="link")
eliron_001un <- datfin%>%dplyr::filter(treatmentn=="0")
eliron_101un <- datfin%>%dplyr::filter(treatmentn=="1")
ks.test(eliron_001un$ps, eliron_101un$ps)

clp <- 0.2
m.out <- matchit(form, data = datfin, method="nearest", ratio=1, 
                  caliper=clp,std.caliper = T,
                  estimand="ATT", replace = F, distance="logit")
summary(m.out)

require(summarytools)
dfSummary(datfin)
# fit logistic regression to estimate propensity scores
PS.fit <- glm(form,family="binomial", data=datfin)
require(jtools)
#install.packages("jtools")
jtools::summ(PS.fit)


clp

# logit of the propensity score
0.2*sd(logitPS, na.rm=T) # suggested in the literature
#clp <- 0.2*sd(log(datfin$ps))
clp <- 0.2*sd(datfin$ps)
m.out <- matchit(form, data = datfin, method="nearest", ratio=1, 
                 caliper=clp,std.caliper = F,
                 estimand="ATT", replace = F, distance="logit")
summary(m.out)

clp=0.2
m.out <- matchit(form, data = datfin, method="nearest", ratio=1, 
                 caliper=clp, std.caliper = T,
                 estimand="ATT", replace = F, distance="logit")
summary(m.out)

clp=0.2
m.out <- matchit(form, data = datfin, method="nearest", ratio=1, 
                 caliper=clp,std.caliper = T, link = "linear.logit",
                 estimand="ATT", replace = F, distance="glm")
m.out
summary(m.out)
0.655

val <- datfin$logt
val <- match.data(m.out)
val <- val$distance
clp <- 0.2*sd(datfin$logt)
#mt <- match.data(m.out)

# logitPS <-  -log(1/mt$distance - 1) 
# clp <- 0.2*sd(logitPS, na.rm=T)
datfin$treatmentn<-factor(datfin$treatmentn, levels=c("0", "1"))
m.out <- matchit(form, data = datfin, method="nearest", ratio=1, 
                 caliper=clp,std.caliper = F,  link = "linear.logit",
                 estimand="ATT", replace = F, distance="glm")
m.out
summary(m.out)
#Alt
da1 <- model.matrix( ~ treatmentn+ BLALBC + BLBMETS + TLLUNGFL + SMKSTAT2 + LNPTCAT + 
                      WEIGHTC, datfin)[,-1]
covs1 <- colnames(da1)[-1]

form <- f.build("treatmentn1", covs1)
da1 <- as.data.frame(data.matrix(da1))
fit <- glm(form, data=da1, family="binomial")

da1$distance <- predict(fit, data=da1)
eliron_001un <- da1%>%dplyr::filter(treatmentn1=="0")
eliron_101un <- da1%>%dplyr::filter(treatmentn1=="1")
tes <- ks.test(eliron_001un$distance,eliron_101un$distance)
tes
resp <- function(dat1=eliron_001un, dat2=eliron_101un, cov="BLALBC>3.6"){
da1 <- dat1%>%dplyr::select(one_of(cov))
da2 <- dat2%>%dplyr::select(one_of(cov))
tes <- ks.test(da1[,1], da2[,1])
return(data.frame(cov=cov, stat=round(tes$statistic,4), p_value = tes$p.value))
}
covs2 <- c("distance", covs1)
resfin <- list()
for(i in 1:length(covs2)){
resfin[[i]] <- resp(dat1=eliron_001un, dat2=eliron_101un, cov=covs2[i])
}
resfin1 <- do.call("rbind", resfin)
m.out <- matchit(form, data = as.data.frame(da1), method="nearest", ratio=1, 
                 caliper=0,
                 estimand="ATT", replace = F, distance="logit")
summout <- summary(m.out)
summ <- as.data.frame(summary(m.out)[[3]])
summ$cov <- row.names(summ)

ecd <- summ$`eCDF Max`
res <- c()
for(i in 1:length(ecd)){
res[i] <- ksstat(n1=nrow(datfin[datfin$treatmentn==0,]), 
       n2=nrow(datfin[datfin$treatmentn==1,]), 
       KSstatistic=ecd[i])
}
summ$kspval <- res
summ%>%dplyr::select(cov, everything())%>%left_join(summ%>%left_join(resfin1)%>%
                   dplyr::select(`eCDF Max`, p_value,stat))
summ
class(summ)
matched_data(m.out)
#Kolmogorov-Smirnov Test Two-Sample
#The null hypothesis assumes that the two samples come from the same distribution.
# If the p-value >0.05, fail to reject null hypothesis, meaning samples are
#likely from same distribution

sel.mod <- m.out1
summ <- summary(sel.mod)

matched_data <- match.data(sel.mod)

eliron_001 <- matched_data%>%dplyr::filter(treatmentn=="0")%>%
  left_join(dattes_elimon%>%dplyr::select(USUBJID, all_of(covsadd), SAF14WFL))
eliron_101 <- matched_data%>%dplyr::filter(treatmentn=="1")%>%
  left_join(dattes_elicom%>%dplyr::select(USUBJID, all_of(covsadd), SAF14WFL))

ks.test(eliron_001$distance, eliron_101$distance)

plot(sel.mod, type = "jitter", interactive = FALSE)
plot(summary(sel.mod), abs = FALSE)










new.names <- c(distance= "Propensity score",
               `BLALBC_>3.6` = "Baseline Albumin (>3.6mm)",
               BLBMETS_Y = "Baseline Brain Metastasis(Y)",
               TLLUNGFL_Y = "Target Lung Lesion at Baseline(Y)",
               SMKSTAT2_Never = "Smoking Status (Never)",
               `LNPTCAT_>=2` = "Number of prior lines of therapy (>=2)",
               `WEIGHTC_>60` = "Body Weight (>60 kg)"
)

sampnm <- c("Unweighted", paste("NN", "(ESS=",summary(m.out1)[[2]][3,1], ")"), 
            paste("Rpart", "(ESS=",summary(m.out2)[[2]][3,1], ")"),
            paste("NNet", "(ESS=",summary(m.out3)[[2]][3,1], ")"),
            paste("NN(CRF)", "(ESS=",summary(m.out4)[[2]][3,1], ")"),
            paste("Genetic", "(ESS=",summary(m.out5)[[2]][3,1], ")"),
            paste("Optimal", "(ESS=",summary(m.out6)[[2]][3,1], ")"),
            paste("Optimal(CRF)", "(ESS=",summary(m.out7)[[2]][3,1], ")"))

# love.plot(m.out7, abs = FALSE,
#           stats = c("mean.diffs"),
# drop.distance = TRUE,
# var.names = new.names,
# thresholds = c(v = 0.1),
# limits = list(m = c(-.9, .9),
#               v = c(.3, 6)),
# shapes = c("circle filled", "circle"),
# position = "none",
# labels = TRUE,
# title = NULL,
# wrap = 20)

plt1 <- love.plot(form,
                  data = datfin, estimand = "ATT",
                  weights = list(w1 = get.w(sel.mod)),
                  thresholds = c(m = .1),
                  binary="std",
                  #sample.names = c("Unweighted", "Optimal(CRF)"),
                  var.order = "unadjusted",
                  # colors = c("red", "blue", "darkgreen",
                  #            "orange", "purple", "yellow",
                  #            "black", "grey"),
                  #abs = TRUE,
                  #line = TRUE,
                  drop.distance = TRUE,
                  #var.names = new.names,
                  limits = list(m = c(-.9, .9),
                                v = c(.3, 6)),
                  shapes = c("circle filled", "circle"),
                  position = "none",
                  labels = TRUE,
                  title = NULL,
                  grid=T,
                  wrap = 20,
                  stars = "raw")+
  labs(caption="* indicates variables for which the displayed value is the raw (unstandardized) difference in means
  \nAbbreviations: NN=Nearest Neighbour, NNet=Neural Network")+
  theme(legend.position = c(0.8, .3), legend.title = element_blank())

plt<- love.plot(form,
                data = datfin, estimand = "ATT",
                weights = list(w1 = get.w(m.out1),
                               w2 = get.w(m.out2),
                               w3 = get.w(m.out3),
                               w4 = get.w(m.out4),
                               w5 = get.w(m.out5),
                               w6 = get.w(m.out6),
                               w7 = get.w(m.out7)),
                thresholds = c(m = .1),
                sample.names = sampnm,
                var.order = "unadjusted",
                shapes = c("triangle filled", "circle filled", "square filled",
                           "triangle filled", "circle filled", "square filled",
                           "triangle filled", "circle filled"),
                colors = c("red", "blue", "darkgreen",
                           "orange", "purple", "yellow",
                           "black", "grey"),
                #abs = TRUE,
                line = TRUE,
                var.names = new.names,
                
                stars = "raw")+
  labs(caption="*indicates variables for which the displayed value is the raw (unstandardized) difference in means
  \nAbbreviations: NN=Nearest Neighbour, NNet=Neural Network")+
  theme(legend.position = "bottom",
        #legend.box.background = element_rect(), 
        legend.title = element_blank())
#m.out, m.out1
##Pred-plt KM

#Matched data
covsadd <-  c("CBR", "ORR", "DCRU", "BESTTLLPCHG", "BESTNLRPCHG")
##Table
# Make categorical variables factors
covs <- c("BLALBC",  "BLBMETS", "TLLUNGFL", "SMKSTAT2", 
          "LNPTCAT",  "WEIGHTC")

finda<- rbind(dattes_elimon%>%dplyr::select(all_of(covs))%>%dplyr::mutate(treatment="Eliron-Mono"), dattes_elicom%>%dplyr::select(all_of(covs))%>%dplyr::mutate(treatment="Eliron-Combo"))

varsToFactor <- c("BLALBC",  "BLBMETS", "TLLUNGFL", "SMKSTAT2", 
                  "LNPTCAT",  "WEIGHTC")
finda[varsToFactor] <- lapply(finda[varsToFactor], factor)

# Create a variable list
vars <- c("BLALBC",  "BLBMETS", "TLLUNGFL", "SMKSTAT2", 
          "LNPTCAT",  "WEIGHTC")
CreateCatTable
CreateContTable(vars = vars, strata = c("treatment"), data = finda)
#Kruskal-Wallis test
#Fisher.test
#Chisq.test
# Create Table 1 stratified by treatment group
tableOne <- CreateTableOne(vars = vars, strata = c("treatment"), data = finda)
pr <- print(tableOne)

dat <- table(finda$BLALBC, finda$treatment)
test <- fisher.test(dat)
chisq.test(dat)[[3]]

dat <- table(finda$BLBMETS, finda$treatment)
fisher.test(dat)
chisq.test(dat)[[3]]

dat <- table(finda$SMKSTAT2, finda$treatment)
fisher.test(dat)[[1]]
chisq.test(dat)[[3]]
