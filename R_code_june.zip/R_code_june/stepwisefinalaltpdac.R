library(pbapply)

stepwise_ibs_sel <- function(data, time, status, predictors,
                             start="null", direction="both", custom_vars=NULL,
                             parallel=FALSE, verbose=TRUE){
  
  start_time <- Sys.time()
  all_combinations <- function(current_vars, direction){
    add_set <- setdiff(predictors, current_vars)
    drop_set <- current_vars
    candidates <- list()
    if(direction%in%c("forward", "both")){
      candidates <- c(candidates, lapply(add_set, function(v) sort(c(current_vars, v))))
      
    }
    if(direction%in%c("backward", "both")){
      candidates <- c(candidates, lapply(drop_set, function(v) setdiff(current_vars, v)))
      
    }
    candidates <- unique(lapply(candidates, sort))
    return(candidates)
    
  }
  
  eval_single <- function(vars){
    if(length(vars)==0)return(1)
  
    fin <- dat_process(dat=data, covs=vars, resp=c("PFSAVAL", "PFSCNSR"), step=2)
    
    rfs_params_up = list("mtry" = ceiling(sqrt(length(vars))), 
                         "ntree"=c(100, 300, 500), "nodesize" =c(3, 7, 11))
    crfs_params = list( "ntree"=c(100, 300, 500), "mtry"=5,
                        "mincriterion" =c(0, 0.2), "minbucket" = c(3, 7, 11))
    
    invisible(capture.output(resin <- runpred(indat=fin, num_repeats=5, num_outer_folds=5, 
                                              num_inner_folds=5,
                                              rfs_params= rfs_params_up,
                                              crfs_params=crfs_params, modl="RSF", seed=1234)))
    res <- 1-median(resin$results$C_index, na.rm=T)
    
    return(res)
  }
  
  evaluate_model_ibs <- function(vars_list){
    ibs_vals <- pbapply::pbsapply(vars_list, eval_single)
    return(unlist(ibs_vals))
  }
  current_vars <- switch(start,
                         null=c(),
                         full=predictors,
                         custom={if(is.null(custom_vars))stop("start_vars must be specified")
                           custom_vars})
  current_ibs <- if(length(current_vars)==0)1 else eval_single(current_vars)
  best_vars <- current_vars
  best_ibs <- current_ibs
  trajectory <- list(list(vars=best_vars, ibs=best_ibs))
  improved <- TRUE
  stp <- list()
  while(improved){
    improved <- FALSE
    candidate_sets <- all_combinations(best_vars, direction)
    var1 <- best_vars
    candidate_sets <- Filter(function(v) !identical(v, best_vars), candidate_sets)
    if(length(candidate_sets)==0)break
    ibs_scores <- evaluate_model_ibs(candidate_sets)
    best_idx <- which.min(ibs_scores)
    if(ibs_scores[best_idx]<best_ibs){
      best_ibs <- ibs_scores[best_idx]
      best_vars <- candidate_sets[[best_idx]]
      trajectory[[length(trajectory)+1]]<-list(vars=best_vars, ibs=best_ibs)
      stp[[ length(trajectory)]] <- data.frame(vars =sapply(candidate_sets, function(x) paste(x, collapse="+")), 
                                               scores=ibs_scores, best_score=round(best_ibs, 4),
                                               best_var=paste(best_vars, collapse=","),
                                               add= sapply(sapply(candidate_sets, function(x) setdiff(x, var1)), function(x) paste(x, collapse=",")),
                                               remove=sapply(sapply(candidate_sets, function(x) setdiff(var1, x)), function(x) paste(x, collapse=",")),
                                               from=paste(var1, collapse=","))
      
      improved <- TRUE
      if(verbose) cat("Step:", length(trajectory), "- Vars:", paste(best_vars, collapse=","),
                      "- IBS:", round(best_ibs, 4), "\n")
    }
  }
  
  runtime <- Sys.time()-start_time
  return(list(selected_vars=best_vars,
              ibs=best_ibs,
              steps=trajectory,
              stp,
              runtime=runtime))
}
library(survival)
#dat <- na.omit(survival::veteran)

datuse1$time <- datuse1$PFSAVAL
datuse1$status <- 1-datuse1$PFSCNSR
result <- stepwise_ibs_sel(data=datuse1,
                           time="time",
                           status="status",
                           predictors=covs,
                           start="full",
                           direction="both", verbose=TRUE)
result

#number_of_models <- number_of_steps(number of covariates*number_of_predictors
dat <- survival::veteran
vars <- c(  "trt", "celltype", "age", "prior", "karno", "diagtime")
res <- {set.seed(1234);pecCforest(f.build("Surv(time, status)", vars), data=dat)}
res1<-predictSurvProb(res, dat, times=5)[,1]
SurvMetrics::Cindex(Surv(dat$time, dat$status), res1)[[1]]
attributes(res)
