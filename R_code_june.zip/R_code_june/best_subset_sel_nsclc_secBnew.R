indat <- read_sas("Z:/Private/npanthi/2025/June Analysis/adefpr_6236_05262025.sas7bdat")

fin1 <- setDT(indat)
indat<- lazy_dt(indat)

dat <-fin1[CHDXCLAS =="LUNG" & SAFFL == "Y" & NXEGFR=="",][, BLNLR:=as.numeric(round(BLNLR,2)),
][C1D1DS%in%c(120, 160, 200, 220, 300),
][FOLLOWUP_W>=20,][,`:=`(LNPTMCAT=factor(LNPTMCAT, levels=c("0/1", "2", ">=3"), ordered=T),
                         LNPTCAT = factor(LNPTCAT, levels=c("0/1", "2", ">=3"), ordered=T))]

dat <- as.data.frame(dat)
datuse <- dat

# Baseline+Activity markers
# Covariates considered
covs <- c("CBR", "ORR", "DCRU", "ORRU", "BESTTLLPCHG", "BESTNLRPCHG", "BLNLR", "ICDY",  "BLALB", "SMKSTAT2", 
          "BLBMETS", "LNPTCAT", "TLLUNGFL", "RASGRPCAT3", "BLSOD")
num_repeats <- 1
num_outer_folds <- 5
num_inner_folds <- 5
seed=1234

rfs_params = list( "mtry"=ceiling(sqrt(length(covs))), "ntree"=c(100, 300, 500), "nodesize" =c(3, 7, 11))
crfs_params = list( "ntree"=c(100, 300, 500), "mtry"=5,
                    "mincriterion" =c(0, 0.2), "minbucket" = c(3, 7, 11))
lasso_params = list("lambda" = 10^seq(-4, 1, length=100), "alpha"=1)
crsfunbias_params <- data.frame(seed=1234)

datuse0 <- datuse%>%dplyr::mutate(RASGRPCAT3=ifelse(RASGRPCAT3=="RAS G12D", "RASG12D",
                                                    ifelse(RASGRPCAT3=="RAS G12V", "RASG12V",   
                                                           ifelse(RASGRPCAT3=="Non-G12", "Non_G12",
                                                                  ifelse(RASGRPCAT3=="RAS G12A", "RASG12A",
                                                                         ifelse(RASGRPCAT3=="Other G12", "OtherG12",""))))))


library(pbapply)
datuse1 <- dat_process(dat=datuse0, covs=covs, resp=c("PFSAVAL", "PFSCNSR"), step=2)

result <- best_subset_selection_ibs(data=datuse1, max_subset_size = 2, allsub=TRUE,
parallel=FALSE,  seed=123, save_results=TRUE,
plot_result=TRUE, result_prefix ="ibs_selection")

result
itfdresult
k <- c()
n=15
for(i in 1:n){
  k[i] <- choose(n, i)
}
k
library(future.apply)
get_subsets <- function(vars, k){
  combn(vars, k, simplify=FALSE)
}

evaluate_subset_ibs <- function(data, subset_vars){
  fin <- dat_process(dat=data%>%mutate(PFSAVAL=time, PFSCNSR=1-status)%>%
                       dplyr::select(everything(),-time,-status), covs=subset_vars, resp=c("PFSAVAL", "PFSCNSR"), step=2)
  invisible(capture.output(crsfunb_res <- suppressWarnings(resfin_crsfunb(dat=fin, num_rept=1, num_outer_fld = 5,
                                num_inner_fld=5, params=data.frame(seed=1234), seedini=1234))))
  res <- 1-median(crsfunb_res$C_index, na.rm=T)
  return(res)
}

best_subset_selection_ibs <- function(data, max_subset_size = 3, allsub=TRUE,
                                      parallel=TRUE,  seed=123, save_results=TRUE,
                                      plot_result=TRUE, result_prefix ="ibs_selection"){
  set.seed(seed)
  vars <- setdiff(names(data), c("time", "status"))
  results <- list()
  # pb <- progress_bar$new(total=sum(sapply(1:max_subset_size, function(k) choose(length(vars), k))),
  #                        format="[:bar] :percent :current/:total :eta")
  # pb <- pbapply::timerProgressBar(min = 0, max =
  #                                   sum(sapply(1:max_subset_size, function(k) choose(length(vars), k)))/2,
  #                                 style = 3)
  
  pb <- pbapply::timerProgressBar(min = 0, max =max_subset_size,
                                  style = 3)
  if(parallel){
    library(future.apply)
    plan(multisession) 
    par_func <- future_sapply
  }else{
    par_func <- pbsapply
  }
  start_time <- Sys.time()
  if(allsub){
    outres <- 1:max_subset_size
  }else{
    outres <- max_subset_size
  }
  sub<- list()
  for(k in outres){
    
    subsets <- combn(vars, k, simplify=FALSE)
    sub[[k]] <- subsets
    # pb1 <- txtProgressBar(min = 0, max =length(subsets),
    #                                 style = 3)
    if(parallel){
      scores <- par_func(subsets, function(subset_vars){
        ibs <- evaluate_subset_ibs(data, subset_vars)
        #pb$tick()
        #setTxtProgressBar(pb1, subset_vars)
        return(ibs)
      }, future.seed=TRUE)}else{
        scores <- par_func(subsets, function(subset_vars){
          ibs <- evaluate_subset_ibs(data, subset_vars)
          #pb$tick()
          #setTxtProgressBar(pb1, subset_vars)
          return(ibs)
        })}
    #close(pb1)
    setTxtProgressBar(pb, k)
    best_idx <- which.min(scores)
    results[[paste0("Size_", k)]] <- list(best_vars=subsets[[best_idx]],
                                          ibs = scores[best_idx],
                                          all_scores=scores)
  }
  close(pb)
  all_best <- do.call(rbind, lapply(seq_along(results), function(i){
    data.frame(size=i, ibs=results[[i]]$ibs, vars=paste(results[[i]]$best_vars, collapse=", "))
  }))
  best_row <- all_best[which.min(all_best$ibs), ]
  runtime <- Sys.time()-start_time
  if(plot_result){
    library(ggplot2)
    plt <- ggplot(all_best, aes(x=size, y=ibs))+
      geom_line(color="blue")+
      geom_point(color="red", size=3)+
      ggtitle("IBS vs Number of Predictors")+
      xlab("Number of Predictors")+
      ylab("Integrated Brier Score (IBS)")+
      theme_minimal()
    #ggsave(paste0(result_prefix, "_ibs_plot.png"))
    ggplot2::ggsave(paste0(result_prefix, "_ibs_plot.png"), plot=plt, width=7, height=5, dpi=300)
  }
  if(save_results){
    write.csv(all_best, paste0(result_prefix, "_ibs_summary.csv"), row.names=FALSE)
  }
  list(all_results=results,
       subsets=sub,  
       summary_table=all_best,
       best_subset=best_row,
       runtime=runtime)
}
result <- best_subset_selection_ibs(data=veteran1%>%dplyr::select(everything(),-PFSAVAL, -PFSCNSR), 
                                    max_subset_size = 3, allsub=TRUE, parallel=FALSE)
result



veteran1 <- na.omit(veteran)
veteran1$status <- ifelse(veteran1$status==1, 1, 0)
veteran1$PFSAVAL <- veteran1$time
veteran1$PFSCNSR <- 1-veteran1$status
result <- stepwise_cforest_ibs(data=veteran1, 
                               time="time",
                               status = "status",
                               candidate_vars=c("age", "celltype", "karno",
                                                "trt", "diagtime", "prior"), direction="both", 
                               max_vars =NULL, 
                               verbose = TRUE, min_improve=1e-4, plot=TRUE)

result