library(randomForestSRC)
library(iml)
library(survival)
library(ggplot2)
library(reshape2)
set.seed(142)
n <- 300
x1 <- rnorm(n)
x2 <- rnorm(n)
x3 <- rnorm(n)
interaction <- x1*x2
lp <- 0.5*x1-0.3*x2+1.2*interaction
hazard <- exp(lp)
time <- rexp(n, rate=hazard)
censor <- rexp(n, rate=0.5)
event_time <- pmin(time, censor)
status <- as.numeric(time <= censor)
data <- data.frame(time=event_time, status=status, x1=x1, x2=x2, x3=x3)
rf_model <- rfsrc(Surv(time, status)~., data=data, ntree=500, seed=1234, block.size = 1)
cf <- {set.seed(1234); cforest(Surv(time, status)~., data=data, 
              control=cforest_unbiased(mtry=2, ntree=300))}
predictSurvProb(cf, data, times=median(data$time))
predict(rf_model, newdata=data[1,])$predicted
as.data.frame(predict(cf, newdata=data[1,], OOB=T))[,1]
X <- data[, c("x1", "x2", "x3")]
predictor_cf <- Predictor$new(model=cf,
                              data=X,
                              y=Surv(data$time, data$status),
                              predict.function = function(model,newdata){
                                as.data.frame(predict(cf, newdata=newdata, OOB=T))[,1]
                              })
interaction_x1 <- Interaction$new(predictor, feature="x1")
Interaction$new(predictor_cf)$results

predictor <- Predictor$new(model=rf_model,
                           data=X,
                           y=Surv(data$time, data$status),
                           predict.function=function(model, newdata){
                             predict(model, newdata)$predicted
                           })
interaction_x1 <- Interaction$new(predictor, feature="x1")
Interaction$new(predictor)$results




features <- colnames(X)
interaction_matrix<- matrix(NA, length(features), length(features),
                            dimnames=list(features, features))
for(f in features){
  fi <- Interaction$new(predictor, feature=f, grid.size=20)
  result <- fi$results
  interaction_matrix[f, gsub(paste(":", f, sep=""), "", result$.feature)] <- result$.interaction
}

for(f in features){
  fi <- Interaction$new(predictor_cf, feature=f, grid.size=20)
  result <- fi$results
  interaction_matrix[f, gsub(paste(":", f, sep=""), "", result$.feature)] <- result$.interaction
}

interaction_matrix
interaction_df <- melt(interaction_matrix, varnames=c("Var1", "Var2"))
interaction_df
ggplot(interaction_df, aes(Var1, Var2, fill=value))+
  geom_tile(color="white")+
  scale_fill_gradient(low="white", high="steelblue", na.value="grey90")+
  geom_text(aes(label=round(value, 2)), size=4)+
  theme_minimal()+
  labs(title="Pairwise Interaction Strength (H-statistic)",
       x="Feature", y="Feature")
