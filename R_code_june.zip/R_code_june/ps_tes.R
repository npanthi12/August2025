#Step 1: Preprocess data: Identification of outliers,
#                         Interpolation of missing values
#Step 2:Propensity score model: Logistic Regression, Random forests, 
#       Artificial neural networks
#Step 3: Matching based on PS: Nearest Neighbour Matching, Optimal Matching,
#        Genetic Matching
#Step 4: Balance statistics and plots: 1) Standardized Mean Difference/Variance Ratio
#                                      2) Statistical Test
#                                      3) Visualization (Histogram, Q-Q plot, Love-plot)
#Step 5: Treatment effect estimation: 1) Average Treatment Effect (ATE)
#                                     2) Average Treatment Effect on the treated (ATT)
#Step 6: Sensitivity analysis: 1) Rosenbaum's sensitivity Analysis
#                              2) Bias Formula
#                              3) Propensity Score Calibration

set.seed(2020)
x.Gender <- rep(0:1, c(400,600)) # 400 females and 600 
#males
x.Age <- round(abs(rnorm(1000, mean=45, sd=15))) 
z <- (x.Age - 45) / 15 - (x.Age-45) ^ 2 / 100 + 2 * x.Gender
tps <- exp(z) / (1+exp(z)) # The true PS
Smoke <- as.numeric(runif(1000) < tps)
z.y <- x.Gender + 0.3*x.Age + 5*Smoke - 20
y <- exp(z.y) / (1+exp(z.y))
CVD <- as.numeric(runif(1000) < y)
x.Age.mask <- rbinom(1000, 1, 0.2) # Missing completely at 
#random
x.Age <- ifelse(x.Age.mask==1, NA, x.Age)
data <- data.frame(x.Age, x.Gender, Smoke, CVD)
head(data)

library(tableone)
table2 <- CreateTableOne(vars = c('x.Age', 'x.Gender', 
                                    'CVD'), 
                           data = data, 
                           factorVars = c('x.Gender', 'CVD'),
                           strata = 'Smoke',
                           smd=TRUE)
table2 <- print(table2, 
                  smd=TRUE,
                  showAllLevels = TRUE,
                  noSpaces = TRUE, 
                  printToggle = FALSE)
table2
kable(table2)
data.complete<-na.omit(data)
m.out <- matchit(Smoke~x.Age+x.Gender, 
                   data=data.complete,
                   distance='logit')

m.out <- matchit(Smoke~I(x.Age^2)+x.Age +x.Gender, 
                 data=data.complete) # Add a quadratic term
m.out$model

m.out <- matchit(Smoke~x.Age+x.Gender, 
                 data=data.complete,
                 distance='rpart')

m.out <- matchit(Smoke~x.Age+x.Gender, 
                 data=data.complete,
                 distance='nnet',
                 distance.options=list(size=16))

library(randomForest)
data.complete$Smoke <- factor(data.complete$Smoke) 
# to call classifier
rf.out <- randomForest(Smoke~x.Age+x.Gender, data=data.complete)
rf.out 
eps <- rf.out$votes[,2] # Estimated PS 

eps <- m.out$distance # Estimated PS
tps.comp <- tps[complete.cases(data)] 
# Because we only use complete cases
Smoke.comp <- as.factor(Smoke[complete.cases(data)])
 df <- data.frame(True=tps.comp, Estimated=eps, 
                   Smoke=Smoke.comp)
ggplot(df, aes(x=True, y=Estimated, colour=Smoke)) +
  geom_point() +
  geom_abline(intercept=0,slope=1, colour="#990000", 
              linetype="dashed") +
  expand_limits(x=c(0,1),y=c(0,1))



matchit(formula=Smoke~x.Age+x.Gender,
        data=data.complete, 
        distance=eps, # our own estimated PS
        method='nearest',
        replace=TRUE,
        discard='both',
        ratio=2)
m.out <- matchit(Smoke~x.Age+x.Gender, 
                 data=data.complete, 
                 distance='logit',
                 method='nearest',
                 replace=TRUE,
                 ratio=2)
m.out$match.matrix
m.out$discarded
# Each row represents matched pairs of a patient in the 
# treatment group. In each row, the first number indicates the 
# serial number of the treated patient; numbers on the right 
# are the controlled patients matched to this patient. 
# The value discarded records whether this patient was 
# discarded. 

m.out <- matchit(Smoke~x.Age+x.Gender, 
                 data=data.complete, 
                 distance='logit',
                 method='nearest',
                 replace=FALSE,ratio=1)
summary(m.out, standardize=TRUE)
mdata <- match.data(m.out)
table5 <- CreateTableOne(vars = c('x.Age', 'x.Gender', 
                                  'CVD'), 
                         data = mdata, 
                         factorVars = c('x.Gender', 'CVD'),
                         strata = 'Smoke',
                         smd=TRUE)
table5 <- print(table5, 
                  smd=TRUE,
                  showAllLevels = TRUE,
                  noSpaces = TRUE, 
                  printToggle = FALSE)
table5
library(cobalt)
bal.tab(m.out, m.threshold = 0.1, un = TRUE)
bal.tab(m.out, v.threshold = 2)
bal.tab(m.out, ks.threshold = 0.2)
mdata <- match.data(m.out)
head(mdata)
m.out <- matchit(Smoke~x.Age+x.Gender, 
                 data=data.complete, 
                 distance='logit',
                 method='nearest',
                 replace=TRUE,
                 ratio=2)
mdata <- match.data(m.out)
 mdata[135,]
library(weights)
age.treat <- mdata[mdata$Smoke==1, 'x.Age']
weight.treat <- mdata[mdata$Smoke==1, 'weights']
age.control <- mdata[mdata$Smoke==0, 'x.Age']
weight.control <- mdata[mdata$Smoke==0, 'weights']
wtd.t.test(x=age.control, y=age.treat, 
              weight=weight.control, weighty=weight.treat) 

m.out <- matchit(Smoke~x.Age+x.Gender, 
                   data=data.complete, 
                   distance='logit',
                   method='nearest',
                   replace=FALSE,
                   ratio=1)
match.treat <- data.complete[row.names(m.out$match.matrix),]
matx <- m.out$match.matrix
dim(matx) <- c(dim(matx)[1]*dim(matx)[2],1) # flatten matrix
match.control <- data.complete[matx,]
age.treat <- match.treat$x.Age
age.control <- match.control$x.Age
t.test(age.treat, age.control, paired=TRUE)

plot(m.out)
plot(m.out, type = 'jitter')
plot(m.out, type = 'hist')

bal.plot(m.out, var.name = 'x.Age', which = 'both', 
           grid=TRUE)
bal.plot(m.out, var.name = 'x.Gender', which = 'both', 
           grid=TRUE)
bal.plot(m.out, var.name = 'x.Age', which = 'both', 
           grid=TRUE, type="ecdf")
love.plot(bal.tab(m.out, m.threshold=0.1),
          stat = "mean.diffs", 
          grid=TRUE,
          stars="raw",
          abs = F)         
# love.plot(bal.tab(m.out, v.threshold=2),
#           stat = "mean.diffs", 
#           grid=TRUE,
#           stars="raw",
#           abs = F)
m.out <- matchit(Smoke~I(x.Age^2)+x.Age+x.Gender, 
                 data=data.complete, 
                 distance='logit',
                 method='nearest',
                 replace=FALSE,
                 ratio=1)
#summary(m.out, interactions = TRUE, addlvariables = TRUE, standardize = TRUE)
m.out <- matchit(Smoke~I(x.Age^2)+x.Age+x.Gender, 
                   data=data.complete, 
                   distance='logit',
                   method='nearest',
                   replace=FALSE,
                   caliper=0.1,
                   ratio=1)
bal.tab(m.out, m.threshold=0.1)

m.out <- matchit(Smoke~I(x.Age^2)+x.Age+x.Gender, 
                   data=data.complete, 
                   distance='logit',
                   method='genetic',
                   pop.size=100)
bal.tab(m.out, m.threshold=0.1)

library(Zelig)
z.out <- zelig(CVD~Smoke+x.Age+x.Gender, data = match.
                 data(m.out),
                 model = "ls")
#Sensitivity analysis
set.seed(2020)
x.Gender <- rep(0:1, c(400,600)) # 400 females and 600males
x.Age <- round(abs(rnorm(1000, mean=45, sd=15))) 
z <- (x.Age - 45) / 15 - (x.Age-45) ^ 2 / 100 + 2 * x.Gender
tps <- exp(z) / (1+exp(z)) # The true PS
Smoke <- as.numeric(runif(1000) < tps)
z.y <- x.Gender + 0.3*x.Age + 5*Smoke - 20
 y <- exp(z.y) / (1+exp(z.y))
CVD <- as.numeric(runif(1000) < y)
data.raw <- data.frame(x.Age, x.Gender, Smoke, CVD)
 sub <- sample(1:nrow(data.raw),round(nrow(data.raw)*8/10)) # 8:2
# without gender information
 data.main <- data.raw[sub, c("x.Age","Smoke","CVD")] 
# with gender information
 data.val <- data.raw[-sub, c("x.Age","x.Gender","Smoke","CVD")] 
 head(data.main)
m.pairs <- cbind(data.main[row.names(m.out$match.matrix), 'CVD'],  data.main[m.out$match.matrix, 'CVD']) 

library(rbounds)
library(MatchIt)
m.out <- matchit(Smoke~x.Age, 
                   data=data.main, 
                   distance='logit',
                   method='optimal',
                   replace=FALSE,
                   ratio=1)
m.pairs <- cbind(data.main[row.names(m.out$match.matrix), 
                             'CVD'], 
                   data.main[m.out$match.matrix, 'CVD'])
x <- sum((m.pairs[,1]==FALSE) & (m.pairs[,2]==TRUE))
y <- sum((m.pairs[,1]==TRUE) & (m.pairs[,2]==FALSE))
 binarysens(x=x, y=y, Gamma = 15, GammaInc = 2)
 psens(x=m.pairs[,1], y=m.pairs[,2], Gamma = 6, GammaInc 
       = 1) 

 matches <- as.data.frame(m.out$match.matrix)
 colnames(matches)<-c("matched_unit")
 matches$matched_unit<-as.numeric(
   as.character(matches$matched_unit))
 matches$treated_unit<-as.numeric(rownames(matches))
 matches.only<-matches[!is.na(matches$matched_unit),]
 head(matches.only) 
 library(igraph)
 matching_matrix <- m.out$match.matrix
 
edges <- data.frame(treated=row.names(matching_matrix), 
                    control=as.vector(matching_matrix)) 
edges <- na.omit(edges)
g <- graph_from_data_frame(edges, directed=FALSE)
V(g)$type <- ifelse(V(g)$name%in%edges$treated, "Treated", "Control")
V(g)$color <-  ifelse(V(g)$type=="Treated", "red", "blue")
V(g)$shape <- ifelse(V(g)$type=="Treated", "square", "circle")
plot(g, vertex.label=NA, vertex.size=6, edge.color="gray80")

m.out <- matchit(Smoke~x.Age, 
                 data=data.main, 
                 distance='logit',
                 method='optimal',
                 replace=FALSE,
                 ratio=3)
matched_matrix <- m.out$match.matrix
edges <- data.frame()
for(treated_id in rownames(matched_matrix)){
  for(control_id in matched_matrix[treated_id, ]){
    edges <- rbind(edges, data.frame(source=treated_id,
                                     target=control_id))
  }
}
all_ids <- unique(c(edges$source, edges$target))
nodes <- data.frame(name=all_ids, 
                    group=ifelse(all_ids%in%rownames(matched_matrix), 
                                 "Treated", "Control"))
edges$source <- match(edges$source, nodes$name)-1
edges$target <- match(edges$target, nodes$name)-1
library(networkD3)
forceNetwork(Links=edges,
             Nodes=nodes,
             Source="source",
             Target="target",
             NodeID="name",
             Group="group",
             opacity=1,
             zoom=TRUE,
             #fontsize=12,
             linkDistance=100,
             charge=-1,
             linkColour="green")

m.out
matched_matrix <- m.out$match.matrix
edges <- data.frame()
for(treated_id in rownames(matched_matrix)){
  for(control_id in matched_matrix[treated_id, ]){
    edges <- rbind(edges, data.frame(source=treated_id,
                                     target=control_id))
  }
}
edges$target <- ifelse(is.na(edges$target), "0", edges$target)
node_ids <- unique(c(edges$source, edges$target))
node <- data.frame(name=node_ids, 
                   group=ifelse(node_ids%in%rownames(matched_matrix), 
                                "Treated", "Control"))
data.main$id <- row.names(data.main)
nodes <- data.main%>%
  filter(id%in%node_ids)%>%
  mutate(group=ifelse(Smoke==1, "Treated", "Control"),
         name=id,
         tooltip=paste0("ID: ", id, "\nAge: ", round(x.Age)))
edges$source <- match(edges$source, nodes$name)-1
edges$target <- match(edges$target, nodes$name)-1
edges$target <- ifelse(is.na(edges$target), 0, edges$target)
library(networkD3)
forceNetwork(Links=edges,
             Nodes=nodes,
             Source="source",
             Target="target",
             NodeID="tooltip",
             Group="group",
             opacity=1,
             zoom=TRUE,
fontSize=18,
linkDistance=100,
charge=-100,
linkColour="green",
Nodesize=1,
colourScale=JS("d3.scaleOrdinal().domain(['Treated', 'Control']).range(['red','blue'])"),
legend=TRUE, height=1000, width=1000)
#arrows=T)

edges


library(tibble)
library(networkD3)
library(htmlwidgets)

node_df <- tibble::tribble(
  ~node_id,  ~node_type,   ~node_size, ~directed,
  "T054717", "irrelevant", 10,       TRUE,
  "T095006", "irrelevant", 10,       FALSE,
  "T088658", "irrelevant", 10,       TRUE,
  "T069179", "irrelevant", 10,       FALSE,
  "T009515", "irrelevant", 10,       TRUE,
  "T152167", "irrelevant", 10,       FALSE,
  "T100447", "irrelevant", 10,       TRUE,
  "T150659", "irrelevant", 10,       FALSE
)

links_df <- tibble::tribble(
  ~tid1, ~tid2, ~edge_dir,
  0,     1,     10,
  0,     2,     10,
  0,     3,     10,
  1,     3,     10,
  2,     4,     5,
  2,     5,     5,
  3,     6,     5,
  4,     5,     5,
  5,     6,     5,
  5,     6,     5
)

network <- forceNetwork (Links = links_df,
                         NodeID = "node_id",
                         Nodesize = "node_size",
                         Group = "node_type",
                         
                         Nodes = node_df,
                         Source = "tid1",
                         Target = "tid2",
                         Value = "edge_dir",
                         
                         colourScale = JS("d3.scaleOrdinal(d3.schemeCategory20);"),
                         fontSize = 10,
                         linkDistance = 100,
                         radiusCalculation = JS(" Math.sqrt(d.nodesize)+6"),
                         charge = -30,
                         linkColour = ifelse(links_df$edge_dir == 10, "black","red"),
                         opacity = 1,
                         zoom = TRUE,
                         arrows = ifelse(links_df$edge_dir == 10, TRUE, FALSE),
                         opacityNoHover = TRUE,
                         clickAction = NULL)

htmlwidgets::onRender(network, '
  function(el) {
    d3.select("svg")
      .selectAll(".link")
      .filter(function(d) { return d.value == 5; })
      .style("marker-end", null);
  }')

#########
library("MatchIt")
data("lalonde", package = "MatchIt")

#1:1 NN matching w/ replacement on a logistic regression PS
m.out <- matchit(treat ~ age + educ + race + married + 
                   nodegree + re74 + re75, data = lalonde,
                 replace = TRUE)
m.out
summary(m.out)
summary(m.out, addlvariables = ~ I(age^2) + I(re74==0) + 
          I(re75==0) + educ:race)
m.sum <- summary(m.out, addlvariables = ~ I(age^2) + I(re74==0) + 
                   I(re75==0) + educ:race)
plot(m.sum, var.order = "unmatched")
plot(m.out, type = "qq", which.xs = ~age + nodegree + re74)
plot(m.out, type = "ecdf", which.xs = ~educ + married + re75)
plot(m.out, type = "density", which.xs = ~age + educ + race)
bal.tab(m.out, un = TRUE, stats = c("m", "v", "ks"))
#Nearest neighbor (NN) matching on the PS
m.out2 <- matchit(treat ~ age + educ + race + married + 
                    nodegree + re74 + re75, data = lalonde)

#Balance on covariates after full and NN matching
bal.tab(treat ~ age + educ + race + married + 
          nodegree + re74 + re75, data = lalonde, 
        un = TRUE, weights = list(full = m.out, nn = m.out2))
love.plot(m.out, binary = "std")
love.plot(m.out, stats = c("m", "ks"), poly = 2, abs = TRUE,
          weights = list(nn = m.out2),
          drop.distance = TRUE, thresholds = c(m = .1),
          var.order = "unadjusted", binary = "std",
          shapes = c("circle filled", "triangle", "square"), 
          colors = c("red", "blue", "darkgreen"),
          sample.names = c("Original", "Full Matching", "NN Matching"),
          position = "bottom")
bal.plot(m.out, var.name = "educ", which = "both")
