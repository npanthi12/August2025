source("Z:/Private/npanthi/2025/April analysis/sterun/cd_rerun2/code_coll/func/compile_res.R")
runpred <- function(indat=fin, num_repeats=num_repeats,
                    num_outer_folds=num_outer_folds, num_inner_folds=num_inner_folds,
                    rfs_params=prm("rsf"),
                    crfs_params=prm("crsf"), modl="CRSF", seed=seed){
  
  if(modl=="CRSF"){
    cat("Running cRSF model", "\n")
    res <- suppressWarnings(resfin_crsf(dat=indat, num_rept=num_repeats, num_outer_fld = num_outer_folds,
                                        num_inner_fld=num_inner_folds, params=crfs_params, seedini=seed))
    
  }
  if(modl=="RSF"){
    cat("Running RSF model", "\n")
    res <- suppressWarnings(resfin(dat=indat, num_rept=num_repeats, num_outer_fld = num_outer_folds,
                                   num_inner_fld=num_inner_folds, params=rfs_params, seedini=seed))
  }
  
  return(list("results"=res))
}


stepwise_ibs_sel <- function(data, time, status, predictors,
                             start="null", direction="both", custom_vars=NULL,
                             parallel=FALSE, verbose=TRUE){
  
  
  all_combinations <- function(current_vars, direction){
    add_set <- setdiff(predictors, current_vars)
    drop_set <- current_vars
    candidates <- list()
    if(direction%in%c("forward", "both")){
      #candidates <- c(candidates, lapply(add_set, function(v) sort(c(current_vars, v))))
      candidates <- c(candidates, lapply(add_set, function(v) c(current_vars, v)))
    }
    if(direction%in%c("backward", "both")){
      candidates <- c(candidates, lapply(drop_set, function(v) setdiff(current_vars, v)))
      
    }
    #candidates <- unique(lapply(candidates, sort))
    candidates <- unique(candidates)
    return(candidates)
    
  }
  
  eval_single <- function(vars){
    if(length(vars)==0)return(1)
    #formula <- as.formula(paste0("Surv(", time, ",", status, ")~", paste(vars, collapse="+")))

    fin <- dat_process(dat=data, covs=vars, resp=c("PFSAVAL", "PFSCNSR"), step=2)
    
    rfs_params_up = list("mtry" = ceiling(sqrt(length(vars))), 
                         "ntree"=c(100, 300, 500), "nodesize" =c(3, 7, 11))
    crfs_params = list( "ntree"=c(100, 300, 500), "mtry"=5,
                        "mincriterion" =c(0, 0.2), "minbucket" = c(3, 7, 11))
    
    invisible(capture.output(resin <- runpred(indat=fin, num_repeats=10, num_outer_folds=5, 
                                              num_inner_folds=5,
                                              rfs_params= rfs_params_up,
                                              crfs_params=crfs_params, modl="RSF", seed=1234)))
    
    pec_obj <- median(resin$results$ibs, na.rm=T)
    ###
    return(pec_obj)
  }
  
  evaluate_model_ibs <- function(vars_list){
    ibs_vals <- pbapply::pbsapply(vars_list, eval_single)
    return(unlist(ibs_vals))
  }
  current_vars <- switch(start,
                         null=c(),
                         full=predictors,
                         custom={if(is.null(custom_vars))stop("start_vars must be specified")
                           custom_vars})
  current_ibs <- if(length(current_vars)==0)1 else eval_single(current_vars)
  best_vars <- current_vars
  best_ibs <- current_ibs
  trajectory <- list(list(vars=best_vars, ibs=best_ibs))
  improved <- TRUE
  stp <- list()
  while(improved){
    improved <- FALSE
    candidate_sets <- all_combinations(best_vars, direction)
    var1 <- best_vars
    candidate_sets <- Filter(function(v) !identical(v, best_vars), candidate_sets)
    if(length(candidate_sets)==0)break
    ibs_scores <- evaluate_model_ibs(candidate_sets)
    best_idx <- which.min(ibs_scores)
    if(ibs_scores[best_idx]<best_ibs){
      best_ibs <- ibs_scores[best_idx]
      best_vars <- candidate_sets[[best_idx]]
      trajectory[[length(trajectory)+1]]<-list(vars=best_vars, ibs=best_ibs)
      stp[[ length(trajectory)]] <- data.frame(vars =sapply(candidate_sets, function(x) paste(x, collapse="+")), 
                                               scores=ibs_scores, best_score=round(best_ibs, 4),
                                               best_var=paste(best_vars, collapse=","),
                                               add= sapply(sapply(candidate_sets, function(x) setdiff(x, var1)), function(x) paste(x, collapse=",")),
                                               remove=sapply(sapply(candidate_sets, function(x) setdiff(var1, x)), function(x) paste(x, collapse=",")),
                                               from=paste(var1, collapse=","))
      
      improved <- TRUE
      if(verbose) cat("Step:", length(trajectory), "- Vars:", paste(best_vars, collapse=","),
                      "- IBS:", round(best_ibs, 4), "\n")
    }else{
      best_ibsfin <- ibs_scores[best_idx]
      best_varsfin <- candidate_sets[[best_idx]]
      trajectory[[length(trajectory)+1]]<-list(vars=best_varsfin, ibs=best_ibsfin)
      stp[[ length(trajectory)]] <- data.frame(vars =sapply(candidate_sets, function(x) paste(x, collapse="+")), 
                                               scores=ibs_scores, best_score=round(best_ibsfin, 4),
                                               best_var=paste(best_varsfin, collapse=","),
                                               add= sapply(sapply(candidate_sets, function(x) setdiff(x, var1)), function(x) paste(x, collapse=",")),
                                               remove=sapply(sapply(candidate_sets, function(x) setdiff(var1, x)), function(x) paste(x, collapse=",")),
                                               from=paste(var1, collapse=","))
      
      improved <- FALSE
      if(verbose) cat("Final Step:", length(trajectory), "- Vars:", paste(best_varsfin, collapse=","),
                      "- IBS:", round(best_ibsfin, 4), "\n")
    }
  }
  
  
  return(list(selected_vars=best_vars,
              ibs=best_ibs,
              steps=trajectory,
              allsteps=stp))
}
library(survival)
datuse1$time <- datuse1$PFSAVAL
datuse1$status <- 1-datuse1$PFSCNSR
result <- stepwise_ibs_sel(data=datuse1,
                           time="time",
                           status="status",
                           predictors=covs,
                           start="null",
                           direction="both")
saveRDS(result, "Z:/Private/npanthi/2025/August Analysis/stepwise_nsclc_secC_10repsibs.rds")
result1 <- sapply(result[[4]], function(x){
  if(!is.null(x)){
  y <- x%>%mutate(best_score=min(scores))
  }else{
    y <-NULL
  }
  return(y)
})

res <- do.call("rbind", result1)
as.data.frame(res)%>%dplyr::group_by(vars)%>%summarise(best_score=min(scores))
finres <- as.data.frame(res)%>%mutate(flg=scores==best_score)%>%
  dplyr::filter(flg==TRUE)
finres1 <-finres%>%mutate(step=1:nrow(finres))%>%dplyr::arrange(step)%>%dplyr::select(step, vars, ibs=scores,
                                                                                    add, remove)
row.names(finres1) <- NULL
finres1
write.xlsx(finres1, "Z:/Private/npanthi/2025/August Analysis/stepwise_nsclc_secC_10repsibs.xlsx")
#number_of_models <- number_of_steps*number of covariates(number_of_predictors)