d0 <- read.xlsx("Z:/Private/npanthi/2025/July Analysis/pdac_secB_set1.xlsx")
d1 <- read.xlsx("Z:/Private/npanthi/2025/July Analysis/pdac_secB_set2.xlsx")
d3 <- read.xlsx("Z:/Private/npanthi/2025/July Analysis/pdac_secB_set3.xlsx")
d0$C_index
d0$ibs
mean(d1$C_index)
mean(d3$C_index)
mean(d1$ibs)
mean(d3$ibs)
# rsf_res=d0$rsf_cindex
# crsf_res = d0$crsf_cindex
# lasso_res=d0$lasso_cindex
# cox_res=d0$cox_cindex
# crsfunb_res=d0$crsfunbias_cindex

data_cindex = data.frame('Cindex' = c(d0$C_index, d1$C_index, d3$C_index),
                         'Model' = c(rep('Set 1', length(d0$C_index)), rep('Set 2', 
                                                                            length(d0$C_index)),
                                     rep('Set 3', 
                                         length(d0$C_index))))
datc <- data_cindex 
datc$Model <- factor(datc$Model, levels=c("Set 1", "Set 2", "Set 3"))
plt <- ggplot(datc, aes(x = Model, y = Cindex, fill = Model)) +
  geom_boxplot() +
  stat_summary(fun=mean, geom="point", shape=20, size=3, color="red")+
  #stat_summary(fun=mean, geom="crossbar", width=0.5, color="red")+
  scale_fill_manual(values = c("#FFBBCC", "#88CCFF","green", "orange","blue", "#88CCFF"))+
  scale_y_continuous(breaks = seq(0, 1, by = 0.1)) +
  coord_cartesian(ylim = c(0, 1))+
  geom_hline(yintercept=0.8, linetype="dashed", color="blue")+
  theme_minimal()+
  theme(legend.title = element_blank())
plt
##

data_ibs = data.frame('IBS' = c(d0$ibs, d1$ibs, d3$ibs),
                      'Model' = c(rep('Set 1', length(d0$ibs)), 
                                  rep('Set 2', 
                                        length(d0$ibs)),
                                  rep('Set 3', 
                                      length(d0$ibs))))
datc <- data_ibs
datc$Model <- factor(datc$Model, levels=c("Set 1", "Set 2", "Set 3"))
plt <- ggplot(datc, aes(x = Model, y = IBS, fill = Model)) +
  geom_boxplot() +
  stat_summary(fun=mean, geom="point", shape=20, size=3, color="red")+
  #stat_summary(fun=mean, geom="crossbar", width=0.5, color="red")+
  scale_fill_manual(values = c("#FFBBCC", "#88CCFF","green", "orange","blue", "#88CCFF"))+
  scale_y_continuous(breaks = seq(0, 1, by = 0.1)) +
  coord_cartesian(ylim = c(0, 0.3))+
  geom_hline(yintercept=0.2, linetype="dashed", color="blue")+
  theme_minimal()+
  theme(legend.title = element_blank())
plt

result_prefix <- "NSCLC_secB_fullset"
ggplot2::ggsave(paste0(result_prefix, "_cindex_plot.pdf"), plot=plt, width=7, height=5, dpi=300)
#ibs  
d1 <- read.xlsx("Z:/Private/npanthi/2025/June Analysis/new_data/ibs_sum_NSCLC_secB.xlsx")
d1
rsf_res=d1$rsf_ibs
crsf_res = d1$crsf_ibs
lasso_res=d1$lasso_ibs
cox_res=d1$cox_ibs
crsfunb_res=d1$crsfunbias_ibs

data_ibs = data.frame('IBS' = c(d0$ibs, d1$ibs),
                      'Model' = c(rep('Set 1', length(d0$C_index)), rep('Optimal Set', 
                                                                        length(d0$C_index))))
datibs <- data_ibs 
datibs$Model <- factor(datibs$Model, levels=c("Set 1", "Optimal Set"))
plt <- ggplot(datibs, aes(x = Model, y = IBS, fill = Model)) +
  geom_boxplot() +
  stat_summary(fun=mean, geom="point", shape=20, size=3, color="red")+
  #stat_summary(fun=mean, geom="crossbar", width=0.5, color="red")+
  scale_fill_manual(values = c( "#88CCFF",  "green", "orange","blue","#FFBBCC"))+
  scale_y_continuous(breaks = seq(0, 1, by = 0.1)) +
  coord_cartesian(ylim = c(0, 0.3))+
  geom_hline(yintercept=0.2, linetype="dashed", color="blue")+
  theme_minimal()+
  theme(legend.title = element_blank())
plt
result_prefix <- "NSCLC_secB_fullset"
ggplot2::ggsave(paste0(result_prefix, "_ibs_plot.pdf"), plot=plt, width=7, height=5, dpi=300)

#PDAC
d0 <- read.xlsx("Z:/Private/npanthi/2025/June Analysis/new_data/cindex_sum_PDAC_secB.xlsx")
d0
rsf_res=d0$rsf_cindex
crsf_res = d0$crsf_cindex
lasso_res=d0$lasso_cindex
cox_res=d0$cox_cindex
crsfunb_res=d0$crsfunbias_cindex

data_cindex = data.frame('Cindex' = c(rsf_res, crsf_res, lasso_res, cox_res, 
                                      crsfunb_res),
                         'model' = c(rep('RSF', length(rsf_res)), rep('CRSF', length(crsf_res)), rep('LASSO', 
                                                                                                     
                                                                                                     length(lasso_res)),
                                     rep('COX', length(cox_res)), rep('CRSF(UNBIAS)', length(crsfunb_res))))
datc <- data_cindex%>%dplyr::filter(model%in%c('COX', 'CRSF', 'RSF'))  
plt <- ggplot(datc, aes(x = model, y = Cindex, fill = model)) +
  geom_boxplot() +
  stat_summary(fun=mean, geom="point", shape=20, size=3, color="red")+
  #stat_summary(fun=mean, geom="crossbar", width=0.5, color="red")+
  scale_fill_manual(values = c("#FFBBCC", "#88CCFF", "green", "orange","blue"))+
  scale_y_continuous(breaks = seq(0, 1, by = 0.1)) +
  coord_cartesian(ylim = c(0, 1))+
  geom_hline(yintercept=0.8, linetype="dashed", color="blue")+
  theme_minimal()
plt
result_prefix <- "PDAC_secB_fullset"
ggplot2::ggsave(paste0(result_prefix, "_cindex_plot.pdf"), plot=plt, width=7, height=5, dpi=300)
#ibs  
d1 <- read.xlsx("Z:/Private/npanthi/2025/June Analysis/new_data/ibs_sum_PDAC_secB.xlsx")
d1
rsf_res=d1$rsf_ibs
crsf_res = d1$crsf_ibs
lasso_res=d1$lasso_ibs
cox_res=d1$cox_ibs
crsfunb_res=d1$crsfunbias_ibs

data_ibs = data.frame('IBS' = c(rsf_res, crsf_res, lasso_res, cox_res, 
                                crsfunb_res),
                      'Model' = c(rep('RSF', length(rsf_res)), rep('CRSF', length(crsf_res)), rep('LASSO', 
                                                                                                  
                                                                                                  length(lasso_res)),
                                  rep('COX', length(cox_res)), rep('CRSF(UNBIAS)', length(crsfunb_res))))
datibs <- data_ibs%>%dplyr::filter(Model%in%c('COX', 'CRSF', 'RSF'))  
plt <- ggplot(datibs, aes(x = Model, y = IBS, fill = Model)) +
  geom_boxplot() +
  stat_summary(fun=mean, geom="point", shape=20, size=3, color="red")+
  #stat_summary(fun=mean, geom="crossbar", width=0.5, color="red")+
  scale_fill_manual(values = c("#FFBBCC", "#88CCFF", "green", "orange","blue"))+
  scale_y_continuous(breaks = seq(0, 1, by = 0.1)) +
  coord_cartesian(ylim = c(0, 0.3))+
  geom_hline(yintercept=0.2, linetype="dashed", color="blue")+
  theme_minimal()
plt
result_prefix <- "PDAC_secB_fullset"
ggplot2::ggsave(paste0(result_prefix, "_ibs_plot.pdf"), plot=plt, width=7, height=5, dpi=300)



create_plt2 <- function(values=values, label=labels){
  plt <- ggplot(data.frame(val=values, label=label), 
                aes(x = label, y = val, fill = label)) +
    geom_boxplot() +
    stat_summary(fun=mean, geom="point", shape=20, size=3, color="red")+
    #stat_summary(fun=mean, geom="crossbar", width=0.5, color="red")+
    #scale_fill_manual(values = c("#FFBBCC", "#88CCFF", "green", "orange","blue"))+
    scale_y_continuous(breaks = seq(0, 1, by = 0.1)) +
    coord_cartesian(ylim = c(0, 1))+
    theme_minimal()
  return(plt)
}