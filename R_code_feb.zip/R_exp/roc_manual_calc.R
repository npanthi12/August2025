set.seed(100)
actuals <- sample(c(TRUE,FALSE), 100, replace = TRUE)
scores <- runif(100,-1,1)
actuals <- actuals[order(scores)]



actuals <- c(0,0, 1,0,1, 0,0,1,1,1)
scores <- c(0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9)
scores <- c(0, 23, 49, 68, 79, 80, 95, 101, 103, 120)
actuals <- actuals[order(scores)]
sens <- (sum(actuals) - cumsum(actuals))/sum(actuals)
spec <- cumsum(!actuals)/sum(!actuals)
sens
spec

plot(1 - spec, sens, type = "l", col = "red", 
     ylab = "Sensitivity", xlab = "1 - Specificity")
abline(c(0,0),c(1,1))

(auc <- sum(spec*diff(c(0, 1 - sens))))
a <- roc(actuals, scores)
coords(a, x="best", best.method="youden")
par(pty = "s") # Make this ROC plot square
plot(a, print.thres = "best", print.thres.best.method = "youden")
a$sensitivities
a$specificities
plot.roc(actuals, scores, percent = TRUE, main="ROC", 
         col="#1c61b6", add=FALSE,print.thres.best.method="youden", print.thres=T)
sens+spec-1

d0<- data.frame(res=actuals, pred=scores)
optimal.cutpoint.Youden <- optimal.cutpoints(X = "pred", status = "res", tag.healthy = 0, methods = "Youden", 
                                             data = d0, pop.prev = NULL,
                                             control = control.cutpoints(), 
                                             ci.fit = FALSE, conf.level = 0.95, 
                                             trace = FALSE)
summary(optimal.cutpoint.Youden)
plot(optimal.cutpoint.Youden)

#

##Example 2
actuals <- c("P", "N", "P", "P", "N", "P", "N", "N", "N", "P")
actuals <- c(1, 0, 1, 1, 0, 1, 0, 0, 0, 1)
scores <- c(0.95, 0.85, 0.78, 0.66, 0.6, 0.55, 0.53, 0.52, 0.51, 0.4)
#actuals <- actuals[order(scores)]
TPR <- 1-(sum(actuals) - cumsum(actuals))/sum(actuals)
FPR <- cumsum(!actuals)/sum(!actuals)
TPR
FPR
TPR-FPR
plot(FPR, TPR, type = "l", col = "red", 
     ylab = "TPR", xlab = "FPR")
abline(c(0,0),c(1,1))
##
a <- roc(actuals, scores)
a
a$sensitivities
a$specificities
1-a$specificities
plot.roc(a, direction="<")
a$sensitivities+a$specificities-1
plot(1-a$specificities, a$sensitivities, type = "l", col = "red", 
     ylab = "TPR", xlab = "FPR")
plot.roc(actuals, scores, percent = TRUE, main="ROC", 
         col="#1c61b6", add=FALSE,print.thres.best.method="youden", print.thres=T)


library(pROC)
test1 <- c(0.95,0.85,0.78,0.66,0.6,0.55,0.53,0.52,0.51,0.4)
result1 <- c(1,0,1,1,0,1,0,0,0,1)
rs <- roc(result1,test1,plot=TRUE,legacy.axes=TRUE, col='#1f77b4')

df0<- data.frame(
  rpr=rs$sensitivities,
  fpp=1-rs$specificities
)
df0
#Example 3
actuals <- c(1,0,1,0,1,0)
scores <- c(0.9,0.85, 0.75, 0.65, 0.55, 0.4)
scores <- c(0, 23, 49, 68, 79, 80, 95, 101, 103, 120)
actuals <- actuals[order(scores)]
sens <- (sum(actuals) - cumsum(actuals))/sum(actuals)
spec <- cumsum(!actuals)/sum(!actuals)
sens
spec

da<- data.frame(id=1:6, actuals = c(1,0,1,0,1,0), scores = c(0.9,0.85, 0.75, 0.65, 0.55, 0.4))
da1<- da%>%mutate(ord=order(da$scores))%>%arrange(actuals)
da2<- da1%>%mutate(sens=(sum(da1$actuals) - cumsum(da1$actuals))/sum(da1$actuals),
                   spec=cumsum(!da1$actuals)/sum(!da1$actuals))
da2%>%arrange(scores)

a <- roc(actuals, )
a
a$sensitivities
a$specificities
1-a$specificities
actuals[order(scores)]
order(scores)
