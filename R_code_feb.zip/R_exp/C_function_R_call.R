#https://stackoverflow.com/questions/28026818/how-to-call-c-function-from-r#:~:text=How%20can%20you%20use%20some%20function
dyn.load("C:/Users/npanthi/Documents/foo.dll")
x = 1:3
ret_val = .C("addOneToVector", n=length(x), vector=as.double(x))
ret_val
