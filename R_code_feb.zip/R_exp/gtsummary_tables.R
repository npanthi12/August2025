# install.packages("gtsummary")
#https://www.danieldsjoberg.com/gtsummary/articles/tbl_summary.html
library(gtsummary)
head(trial)
trial2 <- trial |> select(trt, age, grade)
trial2 |> tbl_summary()
trial2 |>
  tbl_summary(by = trt) |>
  add_p()
trial2 |>
  tbl_summary(
    by = trt,
    statistic = list(
      all_continuous() ~ "{mean} ({sd})",
      all_categorical() ~ "{n} / {N} ({p}%)"
    ),
    digits = all_continuous() ~ 2,
    label = grade ~ "Tumor Grade",
    missing_text = "(Missing)"
  )
trial2 |>
  tbl_summary(by = trt) |>
  add_p(pvalue_fun = label_style_pvalue(digits = 2)) |>
  add_overall() |>
  add_n() |>
  modify_header(label ~ "**Variable**") |>
  modify_spanning_header(c("stat_1", "stat_2") ~ "**Treatment Received**") |>
  modify_footnote(
    all_stat_cols() ~ "Median (IQR) or Frequency (%)"
  ) |>
  modify_caption("**Table 1. Patient Characteristics**") |>
  bold_labels()
trial2 |>
  select(age, trt) |>
  tbl_summary(
    by = trt,
    type = all_continuous() ~ "continuous2",
    statistic = all_continuous() ~ c(
      "{N_nonmiss}",
      "{median} ({p25}, {p75})",
      "{min}, {max}"
    ),
    missing = "no"
  ) |>
  add_p(pvalue_fun = label_style_pvalue(digits = 2))
tbl_summary(trial2) |>
  as_gt(return_calls = TRUE) |>
  head(n = 4)
tbl_summary(trial2, by = trt) |>
  as_gt(include = -cols_align) |>
  gt::tab_source_note(gt::md("*This data is simulated*"))

tbl_summary(trial) |>  # build gtsummary table
  as_gt() |>  # convert to gt table
  gt::gtsave(filename ="Z:/Private/npanthi/October analysis/my_table_image.docx")
library(flextable)
tbl_summary(trial) %>%
  as_flex_table()%>%
  save_as_docx( path = "Z:/Private/npanthi/October analysis/my_table_image.docx")
#as_gt() |>  # convert to gt table

