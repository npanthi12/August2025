#linear-mixed model
t1time <- Sys.time()
t1time<- as.POSIXct(t1time)
library(openxlsx)
library(dplyr)


indat <- openxlsx::read.xlsx("Z:/Private/npanthi/December analysis/predictive_analysis/predictive_analysis_new/predictivepfs.xlsx")%>%
  dplyr::select(USUBJID, CHDXCLAS, SAFFL, PFSSENS1AVAL, PFSSENS1CNSR, RAS_Detected_Pre, RAS_Percentage_Pre, RAS_Percentage_Change, 
                RAS_Complete_Clearance, BLSOD, SOD2MPCHG, DCR2M, BESTTLLPCHG, 
                BLNLR, NLRPCHG, BESTNLRPCHG)

colnames(indat)
tumor_dat <- openxlsx::read.xlsx("Z:/Private/npanthi/December analysis/predictive_analysis/predictive_analysis_new/tumor.xlsx")%>%
  dplyr::select(USUBJID=usubjid, AVISIT, ADY, TLLPCHG, TLCHG, TLCHGC)%>%
  mutate(ADY=ifelse(TLLPCHG=="0.0%", 1, ADY),
         AVISIT=ifelse(TLLPCHG=="0.0%", "Cycle 1 Day 1", AVISIT),
         TLLPCHG_=as.numeric(gsub("%", "", TLLPCHG)))
colnames(tumor_dat)

nlr_dat <- openxlsx::read.xlsx("Z:/Private/npanthi/December analysis/predictive_analysis/predictive_analysis_new/NLR_all.xlsx")%>%
  mutate(ADY=ifelse(baseflag=="Y", 1, ADY))%>%
  filter(ADY>=1)%>%
  dplyr::select(USUBJID=usubjid, VISIT, BLNLR, ADY, NLRCHG, LOGNLRPCHG, NLR, LOGNLR)

nlr15 <- nlr_dat%>%filter(VISIT=="Cycle 1 Day 15")%>%
  mutate(NLRPCHG=(NLRCHG)/BLNLR*100)%>%
  dplyr::select(USUBJID, LOGNLRPCHG)
# 
# nlr_best <- nlr_dat%>%group_by(usubjid)%>%summarise(BESTNLRPCHG=min(NLRPCHG, na.rm=T))%>%
#   dplyr::select(USUBJID=usubjid, BESTNLRPCHG)
colnames(indat)
d0 <- indat%>%filter(CHDXCLAS =="PANCREATIC", SAFFL == "Y")
759712/(915194)

dat <- d0%>%
  mutate(time=PFSSENS1AVAL, evnt=1-PFSSENS1CNSR)

anal_dat <- dat%>%left_join(tumor_dat)
anal_datnlr <- dat%>%left_join(nlr_dat%>%dplyr::select(USUBJID, ADY, LOGNLR))%>%
  filter(!is.na(LOGNLR))
#SLOPETLPCHG
library(lme4)
library(nlme)
mod_cont_ab <- lme(TLLPCHG_ ~ ADY, random=~ADY|USUBJID, data=anal_dat)
random_eff <- ranef(mod_cont_ab)%>%as.data.frame()
random_effects <-  random_eff%>%mutate(USUBJID=row.names(random_eff))%>%dplyr::select(USUBJID, ADY)
fixed_eff <- fixef(mod_cont_ab)%>%as.data.frame()
fixed_effects <- fixed_eff%>%
  mutate(val=row.names(fixed_eff))%>%filter(val=="ADY")


subject_slopes <- random_effects$ADY+fixed_effects[1,1]
slopedat_tllpchg <- data.frame(USUBJID=random_effects$USUBJID, 
                               SLOPETLLPCHG=random_effects$ADY+fixed_effects[1,1])

write.xlsx(slopedat_tllpchg, "Z:/Private/npanthi/January analysis/slopetllpchg_pdac.xlsx")
#SLOPELOGNLR
library(nlme)
mod_cont_ab <- lme(LOGNLR ~ ADY, random=~ADY|USUBJID, data=anal_datnlr)

random_eff <- ranef(mod_cont_ab)%>%as.data.frame()
random_effects <-  random_eff%>%mutate(USUBJID=row.names(random_eff))%>%dplyr::select(USUBJID, ADY)
fixed_eff <- fixef(mod_cont_ab)%>%as.data.frame()
fixed_effects <- fixed_eff%>%
  mutate(val=row.names(fixed_eff))%>%filter(val=="ADY")


subject_slopes <- random_effects$ADY+fixed_effects[1,1]
slopedat_lognlr <- data.frame(USUBJID=random_effects$USUBJID, 
                              SLOPELOGNLR=random_effects$ADY+fixed_effects[1,1])

write.xlsx(slopedat_lognlr, "Z:/Private/npanthi/January analysis/slopelognlr_pdac.xlsx")

#model 1
mod_cont_ab <- lmer(TLLPCHG_ ~ ADY+(ADY|USUBJID), data=anal_dat, REML=TRUE,
                    control=lmerControl(optimizer="bobyqa"))

mod_cont_ab <- lmer(TLCHG ~ ADY+BLSOD+(ADY|USUBJID), data=anal_dat, REML=TRUE,
                    control=lmerControl(optimizer="bobyqa"))

random_effects <- ranef(mod_cont_ab)%>%as.data.frame()%>%
  dplyr::filter(term=="ADY")
fixed_eff <- fixef(mod_cont_ab)%>%as.data.frame()
names(fixed_eff) <- "val"
fixed_effects <- fixed_eff%>%mutate(col=row.names(fixed_eff))%>%dplyr::filter(col=="ADY")

subject_slopes <- random_effects$condval+fixed_effects$val
slopedat_tlpchg <- data.frame(USUBJID=random_effects$grp, SLOPETLPCHG=random_effects$condval+fixed_effects$val)
#SLOPETLLPCHG
library(nlme)
anal_dat$TLLPCHG <- as.numeric(gsub("%", "", anal_dat$TLLPCHG))
# mod_cont_ab <- lmer(TLLPCHG ~ ADY+BLSOD+(ADY|USUBJID), data=anal_dat, REML=TRUE,
#                     control=lmerControl(optimizer="bobyqa"))

# anal_dat <- na.omit(anal_dat%>%dplyr::select(USUBJID, ADY, BLSOD, TLLPCHG))
mod_cont_ab <- lme(TLLPCHG ~ ADY+BLSOD, random=~ADY|USUBJID, data=anal_dat)
# mod_cont_ab1 <- lme(TLLPCHG ~ ADY, random=~ADY|USUBJID, data=anal_dat, method="ML")
# anova(mod_cont_ab, mod_cont_ab1)
# model_performance(mod_cont_ab)
# model_performance(mod_cont_ab1)
# cAIC(mod_cont_ab1)
# cAIC(mod_cont_ab)
random_eff <- ranef(mod_cont_ab)%>%as.data.frame()
random_effects <-  random_eff%>%mutate(USUBJID=row.names(random_eff))%>%dplyr::select(USUBJID, ADY)
fixed_eff <- fixef(mod_cont_ab)%>%as.data.frame()
fixed_effects <- fixed_eff%>%
  mutate(val=row.names(fixed_eff))%>%filter(val=="ADY")


subject_slopes <- random_effects$ADY+fixed_effects[1,1]
slopedat_tllpchg <- data.frame(USUBJID=random_effects$USUBJID, 
                               SLOPETLLPCHG=random_effects$ADY+fixed_effects[1,1])

##NLRdata
#SLOPELOGNLR
nlr_dat <- openxlsx::read.xlsx("Z:/Private/npanthi/December analysis/predictive_analysis/predictive_analysis_new/NLR_all.xlsx")%>%
  dplyr::select(USUBJID=usubjid, VISIT, BLNLR, ADY, NLRCHG, LOGNLRPCHG, NLR, LOGNLR)%>%
  mutate(LOGBLNLR=log(BLNLR))
colnames(nlr_dat)
anal_dat1 <- dat%>%left_join(nlr_dat)%>%
  filter(!VISIT%in%c("Screening"))%>%
  dplyr::select(USUBJID, ADY, LOGBLNLR, LOGNLR)
anal_dat1 <- na.omit(anal_dat1)
# unique(nlr_dat$VISIT)
# str(anal_dat1)
# View(nlr_dat%>%filter(VISIT=="Cycle 1 Day 1"))

mod_cont_ab <- lme(LOGNLR ~ ADY+LOGBLNLR, random=~ADY|USUBJID, data=anal_dat1)
random_eff <- ranef(mod_cont_ab)%>%as.data.frame()
random_effects <-  random_eff%>%mutate(USUBJID=row.names(random_eff))%>%dplyr::select(USUBJID, ADY)
fixed_eff <- fixef(mod_cont_ab)%>%as.data.frame()
fixed_effects <- fixed_eff%>%
  mutate(val=row.names(fixed_eff))%>%filter(val=="ADY")


subject_slopes <- random_effects$ADY+fixed_effects[1,1]
slopedat_lognlr <- data.frame(USUBJID=random_effects$USUBJID, 
                              SLOPELOGNLR=random_effects$ADY+fixed_effects[1,1])


##SLOPEPCHGNLR
nlr_dat <- openxlsx::read.xlsx("Z:/Private/npanthi/December analysis/predictive_analysis/predictive_analysis_new/NLR_all.xlsx")%>%
  dplyr::select(USUBJID=usubjid, VISIT, BLNLR, ADY, NLRCHG, LOGNLRPCHG, NLR, LOGNLR)%>%
  mutate(PCHGNLR=NLRCHG/BLNLR*100)
anal_dat1 <- dat%>%left_join(nlr_dat)%>%
  filter(!VISIT%in%c("Screening"))%>%
  dplyr::select(USUBJID, ADY, PCHGNLR, BLNLR)
anal_dat1 <- na.omit(anal_dat1)
mod_cont_ab <- lme(PCHGNLR ~ ADY+BLNLR, random=~ADY|USUBJID, data=anal_dat1)
random_eff <- ranef(mod_cont_ab)%>%as.data.frame()
random_effects <-  random_eff%>%mutate(USUBJID=row.names(random_eff))%>%dplyr::select(USUBJID, ADY)
fixed_eff <- fixef(mod_cont_ab)%>%as.data.frame()
fixed_effects <- fixed_eff%>%
  mutate(val=row.names(fixed_eff))%>%filter(val=="ADY")


subject_slopes <- random_effects$ADY+fixed_effects[1,1]
slopedat_pchgnlr <- data.frame(USUBJID=random_effects$USUBJID, 
                               SLOPEPCHGNLR=random_effects$ADY+fixed_effects[1,1])




#Final data

findat <- dat%>%left_join(slopedat_tlpchg)%>%
  left_join(slopedat_tllpchg)%>%
  left_join(slopedat_lognlr)%>%
  left_join(slopedat_pchgnlr)%>%
  left_join(nlr15)

write.xlsx(findat, "Z:/Private/npanthi/December analysis/predictive_analysis/predictive_analysis_new/analysis1.xlsx")














##
random_effects <- ranef(mod_cont_ab)%>%as.data.frame()%>%
  dplyr::filter(term=="ADY")
fixed_eff <- fixef(mod_cont_ab)%>%as.data.frame()
names(fixed_eff) <- "val"
fixed_effects <- fixed_eff%>%mutate(col=row.names(fixed_effects))%>%dplyr::filter(col=="ADY")

subject_slopes <- random_effects$condval+fixed_effects$val
slopedat_tlpchg <- data.frame(USUBJID=random_effects$grp, SLOPETLPCHG=random_effects$condval+fixed_effects$val)

library(ggplot2)
slopes_data<- data.frame(subject=random_effects$grp, slope=random_effects$condval)%>%arrange(slope)
ggplot(slopes_data, aes(x=subject, y=slope))+
  geom_bar(stat="identity")+
  labs(title="Subject-specific slopes")+
  theme_minimal()

anal_dat$Predicted <- predict(mod_cont_ab)
ggplot(anal_dat, aes(x=ADY, y=TLCHG, color=factor(USUBJID)))+
  geom_line(aes(group=USUBJID))+
  geom_line(aes(y=Predicted), linetype="dashed")+
  labs(title="Tumor Growth Over Time", x="Time", y="Change in Tumor Size")+
  theme_minimal()+ theme(legend.position="none")

random_effects_cov <- VarCorr(mod_cont_ab)
as.matrix(random_effects_cov$USUBJID)
residual_variance<- attr(random_effects_cov, "sc")^2
res <- ranef(mod_cont_ab)%>%as.data.frame()%>%
  dplyr::filter(term=="ADY")%>%
  mutate(TLLPCHGSLOPE_mod1=ifelse(!is.na(condval), condval+fixef(mod_cont_ab)[[2]],
                                  fixef(mod_cont_ab)[[2]]))%>%
  dplyr::select(USUBJID=grp, TLLPCHGSLOPE_mod1)
#nlme
library(nlme)
model<- lme(TLCHG ~ ADY+BLSOD, random=~ADY|USUBJID, data=anal_dat)
getVarCov(model)
model$sigma^2

model_ar1 <- lme(TLCHG ~ ADY+BLSOD, random=~ADY|USUBJID, data=anal_dat,
                 correlation=corAR1(form=~ADY|USUBJID))
residual_corr <- model_ar1$modelStruct$corStruct
print(residual_corr)
anova(model, model_ar1)
#[var(intercept)  Cov(intercept, slope)]
#[Cov(intercept, slope), Var(slope)]
#Diagonal elements: Variance of random intercept and random slope
#Off Diagonal elements: Covariance between random intercept and slope
library(ggplot2)

#model 2

mod_cont_ab1 <- lmer(TLCHG ~ ADY+(ADY|USUBJID), data=anal_dat, REML=TRUE,
                     control=lmerControl(optimizer="bobyqa"))

res2 <- ranef(mod_cont_ab1)%>%as.data.frame()%>%
  dplyr::filter(term=="ADY")%>%
  mutate(TLLPCHGSLOPE_mod2=ifelse(!is.na(condval), condval+fixef(mod_cont_ab1)[[2]],
                                  fixef(mod_cont_ab1)[[2]]))%>%
  dplyr::select(USUBJID=grp, TLLPCHGSLOPE_mod2)

anova(mod_cont_ab, mod_cont_ab1)
mod_cont_ab2 <- lmer(TLCHG ~ ADY+BLSOD*ADY+(ADY|USUBJID), data=anal_dat, REML=TRUE,
                     control=lmerControl(optimizer="bobyqa"))
anova(mod_cont_ab2, mod_cont_ab1)
mod_cont_ab3 <- lmer(TLCHG ~ ADY+BLSOD*ADY+(0+ADY|USUBJID), data=anal_dat, REML=TRUE,
                     control=lmerControl(optimizer="bobyqa"))
anova(mod_cont_ab2, mod_cont_ab3)
mod_cont_ab4 <- lmer(TLCHG ~ ADY+BLSOD+(ADY|USUBJID), data=anal_dat%>%filter(AVISIT!="Screen" ), REML=TRUE,
                     control=lmerControl(optimizer="bobyqa"))
library(cAIC4)
cAIC(mod_cont_ab2)
cAIC(mod_cont_ab1)
cAIC(mod_cont_ab)
cAIC(mod_cont_ab4)

model_performance(mod_cont_ab2)
model_performance(mod_cont_ab)
model_performance(mod_cont_ab1)
model_performance(mod_cont_ab4)


anova()
ranef(mod_cont_ab2)
fixef(mod_cont_ab2)
residuals <- resid(mod_cont_ab)
fitted_values <- fitted(mod_cont_ab)
ggplot(data.frame(residuals, fitted_values),aes(x=fitted_values, y=residuals))+
  geom_point()+
  geom_hline(yintercept=0, linetype="dashed")+
  labs("Residuals vs fitted values", x="Fitted values", y="Residuals")+
  theme_minimal()
qqnorm(residuals)
qqline(residuals)
qqnorm(random_effects$condval)
qqline(random_effects$condval)

library(influence.ME)
influence <- influence(mod_cont_ab, obs=TRUE)
plot(influence, which="cook")
library(performance)
model_performance(mod_cont_ab)
summary(mod_cont_ab)
#model 3
mod_cont_ab2 <- lmer(TLCHG ~ ADY+BLSOD+(ADY|USUBJID), data=anal_dat%>%filter(AVISIT!="Screen" ), REML=TRUE,
                     control=lmerControl(optimizer="bobyqa"))

res3 <- ranef(mod_cont_ab2)%>%as.data.frame()%>%
  dplyr::filter(term=="ADY")%>%
  mutate(TLLPCHGSLOPE_mod3=ifelse(!is.na(condval), condval+fixef(mod_cont_ab2)[[2]],
                                  fixef(mod_cont_ab2)[[2]]))%>%
  dplyr::select(USUBJID=grp, TLLPCHGSLOPE_mod3)


res%>%left_join(res2)%>%left_join(res3)
anal_dat%>%filter(USUBJID=="RMC-6236-001-007-0565")
#SLOPETLLPCHG

#NLRCHGSLOPE
nlr_dat1 <- nlr_dat%>%filter(!VISIT%in%c("Screening", "Cycle 1 Day 1", "Unscheduled Visit"))
nlr_dat1[,"NLRCHG"] <- scale(nlr_dat1[,"NLRCHG"])
nlr_dat1[,"BLNLR"] <- scale(nlr_dat1[,"BLNLR"])
nlr_dat1[,"ADY"] <- scale(nlr_dat1[,"ADY"])
mod_cont_abnlr <- lmer(NLRCHG ~ ADY+BLNLR+(0+ADY|usubjid), data=nlr_dat1, REML=FALSE,
                       control=lmerControl(optimizer="bobyqa", optCtrl=list(maxfun=2e5)))

res1 <- ranef(mod_cont_abnlr)%>%as.data.frame()%>%dplyr::select(USUBJID=grp, NLRCHGSLOPE=condval)

#Combine data
findat <- dat%>%left_join(res)%>%left_join(res1)%>%left_join(nlr15)%>%left_join(nlr_best)

write.xlsx(findat, "Z:/Private/npanthi/December analysis/predictive_analysis/predictive_analysis_new/analysis.xlsx")

RAS_Detected_Pre
RAS_Percentage_Pre
RAS_Percentage_Change
RAS_Complete_Clearance

BLSOD
SOD2MPCHG
DCR2M
BESTTLLPCHG
SLOPETLPCHG
SLOPETLPPCHG

BLNLR
NLRPCHG 
BESTNLRPCHG
LogNLRPCHG(note:( Log NLR - logBLNLR)/logBLNLR)
SLOPELOGNLR
SLOPEPCHGNLR

#Mixed effect model
library(lme4)
mod_cont <- lmer(TLCHG ~ ADY+(ADY|USUBJID), data=anal_dat, REML=FALSE)
mod_cont_b <- lmer(TLCHG ~ BLSOD+ADY+(ADY|USUBJID), data=anal_dat, REML=FALSE)
anova(mod_cont, mod_cont_b)
mod_cat <- lmer(TLCHG ~ factor(AVISIT)+(1|USUBJID), data=anal_dat, REML=FALSE)
mod_cat_b <- lmer(TLCHG ~ BLSOD+factor(AVISIT)+(1|USUBJID), data=anal_dat, REML=FALSE)
anova(mod_cat, mod_cat_b)
mod_comb <- lmer(TLCHG ~ BLSOD+ADY+factor(AVISIT)+(ADY|USUBJID), data=anal_dat, REML=FALSE)
mod_comb <- lmer(TLCHG ~ BLSOD+ADY+factor(AVISIT)+(1|USUBJID), data=anal_dat, REML=FALSE)
anova(mod_cat_b, mod_comb)
plot(residuals(mod_comb)~fitted(mod_comb))
library(ggplot2)
ggplot(anal_dat, aes(ADY, y=TLCHG, color=factor(USUBJID)))+geom_point()+
  geom_line(aes(group=USUBJID))+
  geom_smooth(method="lm", se=FALSE)
fixef(mod_comb)
ranef(mod_comb)
ranef(mod_cont)
mod_cont_a <- lmer(TLCHG ~ ADY+(1+ADY|USUBJID), data=anal_dat, REML=FALSE)
ranef(mod_cont_a)
mod_cont_aa <- lmer(TLCHG ~ ADY+BLSOD+(1+ADY|USUBJID), data=anal_dat, REML=FALSE)
ranef(mod_cont_aa)
fixef(mod_cont_aa)
qqnorm(residuals(mod_cont_aa))
qqline(residuals(mod_cont_aa))
install.packages("brms")
library(brms)
bayes_mod <- brm(TLCHG ~ ADY+BLSOD+(1+ADY|USUBJID), data=anal_dat)
summary(bayes_mod)

anal_dat$ady_centered <- scale(anal_dat$ADY, center=TRUE, scale=FALSE)
mod_cont_aa <- lmer(TLCHG ~ ady_centered+BLSOD+(1+ady_centered|USUBJID), data=anal_dat, REML=FALSE)

mod_cont_ab <- lmer(TLCHG ~ ADY+BLSOD+(1+ADY|USUBJID), data=anal_dat, REML=FALSE,
                    control=lmerControl(optimizer="bobyqa"))
ranef(mod_cont_ab)
#Step 1
mod_cont_ab <- lmer(TLCHG ~ ADY+BLSOD+(0+ADY|USUBJID), data=anal_dat, REML=FALSE,
                    control=lmerControl(optimizer="bobyqa"))
res <- ranef(mod_cont_ab)%>%as.data.frame()%>%dplyr::select(USUBJID=grp, NLRCHGSLOPE=condval)
#Step 2

mod_cont_ab <- lmer(TLCHG ~ ADY+BLSOD+(1+ADY|USUBJID), data=anal_dat, REML=FALSE,
                    control=lmerControl(optimizer="bobyqa"))
ranef(mod_cont_ab)