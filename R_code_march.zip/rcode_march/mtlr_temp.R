library(survival)
#Looking at the top 6 rows...
head(lung)
library(MTLR)
formula <- Surv(time,status)~.
fullMod <- mtlr(formula = formula, data = lung)
plot(fullMod)
survivalProbs <- predict(fullMod, lung, type = "prob_event")
head(survivalProbs)
lung$time[as.numeric(lung$status==2),]

mtlr
dat <- survival::lung
library(mlr3proba)
learner <- lrn("surv.mtlr")








