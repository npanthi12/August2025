
runlasso <- function(dat){
train_data <- dat%>%dplyr::select(time, status=evnt, all_of(covs))
x1 <- model.matrix( ~ ., train_data[,-c(1, 2)])
y1 <- Surv(train_data$time, train_data$status)
set.seed(1234)
cvfit <- cv.glmnet(x1, y1, family = "cox", type.measure = "C")
lamb <- cvfit$lambda.min
fit <- glmnet(x1, y1, family = "cox", lambda=lamb, alpha=1)
cf<-coef(fit)
cfdf <- as.data.frame(as.matrix(cf[]))
options(scipen=99999999)
vars_glmnet <- cfdf%>%mutate(col=row.names(cfdf))%>%arrange(s0)
distime<- sort(unique(train_data[train_data$status==1,]$time))#get the survival time of #events
med_index <- median(1:length(distime))  #the index of median survival time of events
x2 <-  model.matrix( ~ ., train_data[,-c(1, 2)])
y2 <- Surv(train_data$time, train_data$status)
mat_glmnet<-predictProb.glmnet(object=fit,response=y2, x=x2, times=distime, complexity=lamb)
vec_glmnet <- mat_glmnet[ ,med_index]
time <- train_data$time
status <-  train_data$status
Cindex_glmnet <- Cindex(Surv(time, status), vec_glmnet)
IBS_glmnet <- IBS(Surv(time, status), mat_glmnet, distime)
return(list(vars_glmnet, Cindex_glmnet, IBS_glmnet))
}