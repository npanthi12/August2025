t1time <- Sys.time()
t1time<- as.POSIXct(t1time)
library(openxlsx)
library(dplyr)
library(SurvMetrics)
library(haven)
source("~/runfrst.R")

indat <- read_sas("~/adefpr_integrated.sas7bdat")


d0 <- indat

dat0 <- d0%>%
  mutate(PFSAVAL=PFSISDEAVAL, PFSCNSR=PFSISDECNSR)%>%
  mutate(time=PFSAVAL, evnt=1-PFSCNSR)
#filter(!is.na(RAS_Percentage_Change))


# dat$C1D1DS_quart <- cut(dat$C1D1DS, breaks=4)
# dat$BLWTKG_quart <- cut(dat$BLWTKG, breaks=4)
# dat$BLNLR_quart <- cut(dat$BLNLR, breaks=4)
# dat$BLALB_quart <- cut(dat$BLALB, breaks=4)
# dat$ICDY_quart <- cut(dat$ICDY, breaks=4)
# dat$AGE_quart <- cut(dat$AGE, breaks=4)
# dat$LNPTM_quart <- cut(dat$LNPTM, breaks=4)
# dat$BLSOD_quart <- cut(dat$BLSOD, breaks=4)

# dat$C1D1DS_quart <- paste("Q", ntile(dat$C1D1DS, 4), sep="")
# dat$BLWTKG_quart <- paste("Q", ntile(dat$BLWTKG, 4), sep="")
# dat$BLNLR_quart <- paste("Q", ntile(dat$BLNLR, 4), sep="")
# dat$BLALB_quart <- paste("Q", ntile(dat$BLALB, 4), sep="")
# dat$ICDY_quart <- paste("Q", ntile(dat$ICDY, 4), sep="")
# dat$AGE_quart <- paste("Q", ntile(dat$AGE, 4), sep="")
# dat$LNPTM_quart <- paste("Q", ntile(dat$LNPTM, 4), sep="")
# dat$BLSOD_quart <- paste("Q", ntile(dat$BLSOD, 4), sep="")

# dat<- dat0%>%
#   mutate(ICDY_quart=ifelse(!is.na(ICDY),paste("Q", ntile(ICDY, 4), sep=""), NA),
#          C1D1DS_quart=ifelse(!is.na(C1D1DS),paste("Q", ntile(C1D1DS, 4), sep=""), NA),
#          BLWTKG_quart=ifelse(!is.na(BLWTKG),paste("Q", ntile(BLWTKG, 4), sep=""), NA),
#          BLNLR_quart=ifelse(!is.na(BLNLR),paste("Q", ntile(BLNLR, 4), sep=""), NA),
#          BLALB_quart=ifelse(!is.na(BLALB),paste("Q", ntile(BLALB, 4), sep=""), NA),
#          AGE_quart=ifelse(!is.na(AGE),paste("Q", ntile(AGE, 4), sep=""), NA),
#          LNPTM_quart=ifelse(!is.na(LNPTM),paste("Q", ntile(LNPTM, 4), sep=""), NA),
#          BLSOD_quart=ifelse(!is.na(BLSOD),paste("Q", ntile(BLSOD, 4), sep=""), NA))

dat <- dat0


covs <-c( "COMPOUND", "AGE", "AGEDIAG", "BLALB", "BLECOGN", "BLLMETS", "BLNLR", 
          "BLSOD", "CHSTGGRP", "METASTNC", "MMLNPTM",
          "PT5CMFL", "PTGCMFL", "PTGEMCFL", "SEX", "SMKSTAT2", "TLAPANFL", "DOSSCH", "PMELESFL")



# covs <- c("C1D1DS_quart", "C1D1DGP", "C1D1DGP1",  "LNPTM_quart","LNPTMCT4","LNPTCAT6","BLLMETS","BLBNMETS","BLECOGN", "SEX", "AGE_quart", "AGEGR1", "BLSOD_quart", "SMKSTAT2", "BLBMETS", "TLLUNGFL", "CHSTGGRP", "CPI90FLA",
#  "ICDY_quart", "BLALB_quart", "BLNLR_quart", "RAS_Detected_Pre", "RASGRPCAT2", "RASGRPCAT3",  "BLWTKG_quart")

exp_variable <- c("")
exp_variable_derived <- c("")
resp <- c("PFSISDEAVAL", "PFSISDECNSR")
resp_char <- "Progression-Free Survival"
pop <- 'CHDXCLAS =="PANCREATIC" & SAFFL == "Y"'
pop_char <- "all treated PDAC subjects in 9805/6236 study data"
corv <- 0.8
mincrit <- 0
minbuc <-20
minspl <- 20
ntre <- 500
sed <- 1234

library(haven)
library(survminer)
library(dplyr)
library(Hmisc)
library(AICcmodavg)
library(car)
library(broom)
library(cobalt)
library(ipw)
library(survey)
library(WeightIt)
library(glmtoolbox)
library(MatchIt)
library(MuMIn)
library(purrr)
library("survival")
library("survminer")
library(emmeans)
library(randomForestSRC)
library(ranger)
library(openxlsx)
library(randomForest)
library(dplyr)
library(ggraph)
library(igraph)
library(caret)
library(rpart.plot)
library(rpart)
library(party)
library(ggsurvfit)
library(visdat)
library(plotly)
library(GGally)
library(permimp)
library(DT)
library(ggsurvfit)
library(ggcorrplot)
library(tidyverse)
library(rcompanion)
library(knitr)
library(polycor)
library(StepReg)
library(pec)
#Import dataset
fin <- dat
findat20 <- fin%>%
  dplyr::filter_(pop)%>%
  dplyr::select(everything())

findat21 <- findat20%>%dplyr::select(all_of(covs), all_of(resp))
#Step1: Describe fin1 to get missing covariates
#Step2: Make a note of missing covaritaes
#Step3: Change missing covariates into factor
#Step1
covs11 <- c(covs[!covs%in%c("")], resp)
covs11
describe(findat21%>%dplyr::select(all_of(covs11)))
da <- findat21%>%dplyr::select(all_of(covs11))
data <- replace(da, da == "", NA)
da1 <- sapply(data, function(x) sum(is.na(x)))
names(da1[da1>0])
#cont <- c("BLALB", "ICDY", "BLSOD",  "AGE", "LNPTM", "C1D1DS", "BLNLR") 

#Step2
covs_miss <- names(da1[da1>0])

#Step3


findat22 <- data%>%dplyr::select(all_of(covs11))%>%
  drop_na()%>%
  dplyr::mutate_if(is.character, as.factor)


set.seed(sed)
tree.output <- party::ctree(form, data = findat2a, controls = ctree_control(mincriterion = mincrit, minbucket=minbuc, minsplit=minspl, testtype = "Univariate"))


condres <- runfrst(dat=findat2a, ntre=ntre, resp="Surv(time,evnt)", covs=covs, sed=sed)

#Selection Frequency
sel_imp <- as.data.frame(condres[[1]][[1]])%>%dplyr::arrange(desc(`condres[[1]][[1]]`))
sel_imp1 <- sel_imp%>%dplyr::arrange(`condres[[1]][[1]]`)

freq_max <- max(sel_imp1$`condres[[1]][[1]]`)
sel_imp1$rnk <- sel_imp1$`condres[[1]][[1]]`/freq_max
sel_imp1$col <- row.names(sel_imp1)
row.names(sel_imp1) <- NULL

#Importance
imp <- condres[[2]]%>%dplyr::mutate(col=row.names(condres[[2]]))%>%
  dplyr::arrange(desc(Overall))%>%dplyr::select(col, Overall)
forest.importance <- condres[[2]]%>%dplyr::arrange(Overall)
imp1 <- forest.importance%>%dplyr::mutate(Overall=round(Overall, 9))%>%dplyr::arrange(desc(Overall))
imp_max <- max(imp1$Overall)
imp1$rnk1 <- imp1$Overall/imp_max
imp1$col <- row.names(imp1)
row.names(imp1) <- NULL
forest.importance <-condres[[2]]%>%dplyr::arrange(Overall)

sel_imp1 <- as.data.frame(condres[[1]][[1]])%>%dplyr::arrange(`condres[[1]][[1]]`)
par(mfrow = c(1, 2))
dotchart(x=sel_imp1$`condres[[1]][[1]]`, labels=row.names(sel_imp1), main="Variable importance by selection frequency \n(Using all variables)")

dotchart(x=forest.importance$Overall, labels=row.names(forest.importance), main="Conditional importance of variables \n(Using all variables)")
