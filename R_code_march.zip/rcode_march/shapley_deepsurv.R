pec::predictSurvProb(model, data, dat$time[1:20])

explain.deepsurv <- function(model,
                             data = NULL,
                             y = NULL,
                             predict_function = NULL,
                             predict_function_target_column = NULL,
                             residual_function = NULL,
                             weights = NULL,
                             ...,
                             label = NULL,
                             verbose = TRUE,
                             colorize = !isTRUE(getOption("knitr.in.progress")),
                             model_info = NULL,
                             type = NULL,
                             times = NULL,
                             times_generation = "survival_quantiles",
                             predict_survival_function = NULL,
                             predict_cumulative_hazard_function = NULL) {
  if (is.null(data)) {
    data <- as.data.frame(model$x)
    attr(data, "verbose_info") <- "extracted"
  }
  
  if (is.null(y)) {
    tmp_y <- model$y
    y <- survival::Surv(tmp_y[, 1], tmp_y[, 2])
    attr(y, "verbose_info") <- "extracted"
  }

 
  # mod$surv
  # pec::predictSurvProb(model, newdata, times=c(2, 3))
  # predictSurvProb.deepsurv <- function(object, newdata, times, ...){
  #   N <- NROW(newdata)
  #   sfit <- get_indivsurv(object, newdata = newdata)
  #   S <- sfit$surv
  #   Time <- sfit$time
  #   S <- matrix(S, ncol=length(Time))
  #   if(N == 1) S <- matrix(S, nrow = 1)
  #   p <-  cbind(1, S)[, 1 + prodlim::sindex(Time, times),drop = FALSE]
  #   if (NROW(p) != NROW(newdata) || NCOL(p) != length(times))
  #     stop("Prediction failed")
  #   p
  # }
  # 
  if (is.null(predict_survival_function)) {
    predict_survival_function <- function(model, newdata, times) {
      #pec::predictSurvProb(model, newdata, times)
      sfit <- predict(model, newdata, type="survival")
      S <- sfit
      Time <- as.numeric(colnames(S))
      S <- matrix(S, ncol=length(Time))
      p <-  cbind(1, S)[, 1 + prodlim::sindex(Time, times),drop = FALSE]
      p
    }
    attr(predict_survival_function, "verbose_info") <- "predictSurvProb.coxph will be used"
    attr(predict_survival_function, "is.default") <- TRUE
  } else {
    attr(predict_survival_function, "verbose_info") <- deparse(substitute(predict_survival_function))
  }
  
  if (is.null(predict_cumulative_hazard_function)) {
    predict_cumulative_hazard_function <-
      function(model, newdata, times) {
        survival_to_cumulative_hazard(predict_survival_function(model, newdata, times))
      }
    attr(predict_cumulative_hazard_function, "verbose_info") <- "-log(predict_survival_function) will be used"
    attr(predict_cumulative_hazard_function, "is.default") <- TRUE
  } else {
    attr(predict_cumulative_hazard_function, "verbose_info") <- deparse(substitute(predict_cumulative_hazard_function))
  }
  
  if (is.null(predict_function)) {
    predict_function <- function(model, newdata) {
      predict(model, newdata, type = "risk")
    }
    attr(predict_function, "verbose_info") <- "predict.coxph with type = 'risk' will be used"
    attr(predict_function, "is.default") <- TRUE
  } else {
    attr(predict_function, "verbose_info") <- deparse(substitute(predict_function))
  }
  
  explain_survival(
    model,
    data = data,
    y = y,
    predict_function = predict_function,
    predict_function_target_column = predict_function_target_column,
    residual_function = residual_function,
    weights = weights,
    ... = ...,
    label = label,
    verbose = verbose,
    colorize = colorize,
    model_info = model_info,
    type = type,
    times = times,
    times_generation = times_generation,
    predict_survival_function = predict_survival_function,
    predict_cumulative_hazard_function = predict_cumulative_hazard_function
  )
}

deepexp <- explain.deepsurv(model)
modprt <- model_parts(deepexp)
survex::surv_shap(deepexp)
imp <- surv_feature_importance(deepexp)
plot(imp)
plot(modprt)
class(deepexp)
prof <- model_profile(deepexp)
prt <- predict_parts(deepexp, new_observation = dat[1:3,])
plot(prt)
prprof <- predict_profile(deepexp, dat[1,])
plot(prprof)
mod <- model_performance(deepexp)
plot(mod)
plot(mod, metrics_type="scalar")
predict_survival_function <- function(model, newdata, times) {
  #pec::predictSurvProb(model, newdata, times)
   pred <- predict(model, newdata, type="survival")
   pred[,as.character(times)]
}
sort(unique(dat$time))
sort(as.numeric(colnames(pred)))
sort(times)
predict_survival_function(model, newdata=sampled_data, times)
explainer <- deepexp
deepexp
model_parts.surv_explainer <- function(explainer,
                                       loss_function = survex::loss_brier_score,
                                       ...,
                                       type = "difference",
                                       output_type = "survival",
                                       N = 1000) {
  if (!(type %in% c("difference", "ratio", "raw", "variable_importance"))) stop("Type shall be one of 'variable_importance', 'difference', 'ratio', 'raw'")
  if (!(output_type %in% c("survival", "risk"))) stop("output_type should be 'survival' or 'risk'")
  if (type == "variable_importance") type <- "raw" # it's an alias
  
  switch(output_type,
         "risk" = DALEX::model_parts(
           explainer = explainer,
           loss_function = loss_function,
           ... = ...,
           type = type,
           N = N
         ),
         "survival" = {
           test_explainer(explainer, has_data = TRUE, has_y = TRUE, has_survival = TRUE, function_name = "model_parts")
           
           if (attr(loss_function, "loss_type") == "integrated") {
             res <- surv_integrated_feature_importance(
               x = explainer,
               loss_function = loss_function,
               type = type,
               N = N,
               ...
             )
             class(res) <- c("model_parts_survival", class(res))
             return(res)
           } else {
             res <- surv_feature_importance(
               x = explainer,
               loss_function = loss_function,
               type = type,
               N = N
              # ...
             )
             res$event_times <- explainer$y[explainer$y[, 1] <= max(explainer$times), 1]
             res$event_statuses <- explainer$y[explainer$y[, 1] <= max(explainer$times), 2]
             class(res) <- c("model_parts_survival", class(res))
             res
           }
         },
         stop("Type should be either `survival` or `risk`")
  )
}

##ipred
library("survival")
library(ipred)
data("DLBCL", package = "ipred")
smod <- Surv(DLBCL$time, DLBCL$cens)

KM <- survfit(smod ~ 1)
# integrated Brier score up to max(DLBCL$time)
sbrier(smod, KM)
library(pec)
perror_all=pec(list("coxm"=KM), 
               formula=Surv(time,cens)~1,data=na.omit(DLBCL))
ibres <- ibs(perror_all)
ibres

mod <- bagging(Surv(time, cens) ~ MGEc.1 + IPI, data=DLBCL, nbagg=1)

# this is a list of survfit objects (==KM-curves), one for each observation
# in DLBCL
pred <- predict(mod, newdata=DLBCL)

# integrated Brier score up to max(time)
sbrier(smod, pred)
perror_all=pec(list("coxm"=mod), 
               formula=Surv(time,cens)~1,data=na.omit(DLBCL))
ibres <- ibs(perror_all)
ibres
