

library(haven)
indat <- read_sas("~/adefpr_integrated.sas7bdat")
#Slide 18
# 2L+ PFS
#1200
indat2Lplus1200 <- indat%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200))

findat<- indat2Lplus1200%>%
  mutate(PFSAVAL=PFSISDEAVAL, PFSCNSR=PFSISDECNSR)%>%
  mutate(time=PFSAVAL, evnt=1-PFSCNSR)

covs <-c( "COMPOUND", "AGE",  "BLLMETS", "BLNLR", 
          "BLSOD", "CHSTGGRP",  "MMLNPTM")
form <- f.build("Surv(time,evnt)", covs)
#mPFS (95% CI)
fit <- survfit(Surv(time,evnt) ~ COMPOUND, data = findat, conf.type="plain")
print(ggsurvplot(fit, risk.table = TRUE, pval=paste("Log-rank p=", round(surv_pvalue(fit)[1,2], 2)),
                 title="KM-plot of covariates based on all-covariate analysis"))

# ggsurvfit(survfit2(Surv(time,evnt) ~ strata(node), data = findat2r), surv.median.line="hv")
# fit <- summary(survfit(Surv(time,evnt) ~ strata(node), data = findat2r))
kable(as.data.frame(summary(fit)$table))
#HR (unadjusted)
cpmod <- coxph(Surv(time,evnt) ~ COMPOUND, data = findat, ties="breslow")
Publish::publish(cpmod)
#HR (adjusted)
cpmod <- coxph(form, data = findat, ties="breslow")
Publish::publish(cpmod)
#900
indat2Lplus1200 <- indat%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200, 900))

findat<- indat2Lplus1200%>%
  mutate(PFSAVAL=PFSISDEAVAL, PFSCNSR=PFSISDECNSR)%>%
  mutate(time=PFSAVAL, evnt=1-PFSCNSR)

covs <-c( "COMPOUND", "AGE",  "BLLMETS", "BLNLR", 
          "BLSOD", "CHSTGGRP",  "MMLNPTM")
form <- f.build("Surv(time,evnt)", covs)
#mPFS (95% CI)
fit <- survfit(Surv(time,evnt) ~ COMPOUND, data = findat, conf.type="plain")
print(ggsurvplot(fit, risk.table = TRUE, pval=paste("Log-rank p=", round(surv_pvalue(fit)[1,2], 2)),
                 title="KM-plot of covariates based on all-covariate analysis"))

# ggsurvfit(survfit2(Surv(time,evnt) ~ strata(node), data = findat2r), surv.median.line="hv")
# fit <- summary(survfit(Surv(time,evnt) ~ strata(node), data = findat2r))
kable(as.data.frame(summary(fit)$table))
#HR (unadjusted)
cpmod <- coxph(Surv(time,evnt) ~ COMPOUND, data = findat, ties="breslow")
Publish::publish(cpmod)
#HR (adjusted)
cpmod <- coxph(form, data = findat, ties="breslow")
Publish::publish(cpmod)

#Slide 19
# 3L+ PFS
#1200
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="RMC-6236" & MMPDA3FL== "Y")|(COMPOUND=="RMC-9805" & MMLNPTM== ">1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200))
dim(indat2Lplus1200)


findat<- indat2Lplus1200%>%
  mutate(PFSAVAL=PFSISDEAVAL, PFSCNSR=PFSISDECNSR)%>%
  mutate(time=PFSAVAL, evnt=1-PFSCNSR)

covs <-c( "COMPOUND", "AGE",  "BLLMETS", "BLNLR", 
          "BLSOD", "CHSTGGRP",  "MMLNPTM")
form <- f.build("Surv(time,evnt)", covs)
#mPFS (95% CI)
fit <- survfit(Surv(time,evnt) ~ COMPOUND, data = findat, conf.type="plain")
print(ggsurvplot(fit, risk.table = TRUE, pval=paste("Log-rank p=", round(surv_pvalue(fit)[1,2], 2)),
                 title="KM-plot of covariates based on all-covariate analysis"))

# ggsurvfit(survfit2(Surv(time,evnt) ~ strata(node), data = findat2r), surv.median.line="hv")
# fit <- summary(survfit(Surv(time,evnt) ~ strata(node), data = findat2r))
kable(as.data.frame(summary(fit)$table))
#HR (unadjusted)
cpmod <- coxph(Surv(time,evnt) ~ COMPOUND, data = findat, ties="breslow")
Publish::publish(cpmod)
#HR (adjusted)
cpmod <- coxph(form, data = findat, ties="breslow")
Publish::publish(cpmod)
#900
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="RMC-6236" & MMPDA3FL== "Y")|(COMPOUND=="RMC-9805" & MMLNPTM== ">1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200, 900))
dim(indat2Lplus1200)

findat<- indat2Lplus1200%>%
  mutate(PFSAVAL=PFSISDEAVAL, PFSCNSR=PFSISDECNSR)%>%
  mutate(time=PFSAVAL, evnt=1-PFSCNSR)

covs <-c( "COMPOUND", "AGE",  "BLLMETS", "BLNLR", 
          "BLSOD", "CHSTGGRP",  "MMLNPTM")
form <- f.build("Surv(time,evnt)", covs)
#mPFS (95% CI)
fit <- survfit(Surv(time,evnt) ~ COMPOUND, data = findat, conf.type="plain")
print(ggsurvplot(fit, risk.table = TRUE, pval=paste("Log-rank p=", round(surv_pvalue(fit)[1,2], 2)),
                 title="KM-plot of covariates based on all-covariate analysis"))

# ggsurvfit(survfit2(Surv(time,evnt) ~ strata(node), data = findat2r), surv.median.line="hv")
# fit <- summary(survfit(Surv(time,evnt) ~ strata(node), data = findat2r))
kable(as.data.frame(summary(fit)$table))
#HR (unadjusted)
cpmod <- coxph(Surv(time,evnt) ~ COMPOUND, data = findat, ties="breslow")
Publish::publish(cpmod)
#HR (adjusted)
cpmod <- coxph(form, data = findat, ties="breslow")
Publish::publish(cpmod)

#Slide 20
# 2L PFS
#1200
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="RMC-6236" & MMP3PPFL== "Y")|(COMPOUND=="RMC-9805" & MMLNPTM== "<=1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200))
dim(indat2Lplus1200)


findat<- indat2Lplus1200%>%
  mutate(PFSAVAL=PFSISDEAVAL, PFSCNSR=PFSISDECNSR)%>%
  mutate(time=PFSAVAL, evnt=1-PFSCNSR)

covs <-c( "COMPOUND", "AGE",  "BLLMETS", "BLNLR", 
          "BLSOD", "CHSTGGRP",  "MMLNPTM")
form <- f.build("Surv(time,evnt)", covs)
#mPFS (95% CI)
fit <- survfit(Surv(time,evnt) ~ COMPOUND, data = findat, conf.type="plain")
print(ggsurvplot(fit, risk.table = TRUE, pval=paste("Log-rank p=", round(surv_pvalue(fit)[1,2], 2)),
                 title="KM-plot of covariates based on all-covariate analysis"))

# ggsurvfit(survfit2(Surv(time,evnt) ~ strata(node), data = findat2r), surv.median.line="hv")
# fit <- summary(survfit(Surv(time,evnt) ~ strata(node), data = findat2r))
kable(as.data.frame(summary(fit)$table))
#HR (unadjusted)
cpmod <- coxph(Surv(time,evnt) ~ COMPOUND, data = findat, ties="breslow")
Publish::publish(cpmod)
#HR (adjusted)
cpmod <- coxph(form, data = findat, ties="breslow")
Publish::publish(cpmod)
#900
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="RMC-6236" & MMP3PPFL== "Y")|(COMPOUND=="RMC-9805" & MMLNPTM== "<=1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200, 900))
dim(indat2Lplus1200)

findat<- indat2Lplus1200%>%
  mutate(PFSAVAL=PFSISDEAVAL, PFSCNSR=PFSISDECNSR)%>%
  mutate(time=PFSAVAL, evnt=1-PFSCNSR)

covs <-c( "COMPOUND", "AGE",  "BLLMETS", "BLNLR", 
          "BLSOD", "CHSTGGRP",  "MMLNPTM")
form <- f.build("Surv(time,evnt)", covs)
#mPFS (95% CI)
fit <- survfit(Surv(time,evnt) ~ COMPOUND, data = findat, conf.type="plain")
print(ggsurvplot(fit, risk.table = TRUE, pval=paste("Log-rank p=", round(surv_pvalue(fit)[1,2], 2)),
                 title="KM-plot of covariates based on all-covariate analysis"))

# ggsurvfit(survfit2(Surv(time,evnt) ~ strata(node), data = findat2r), surv.median.line="hv")
# fit <- summary(survfit(Surv(time,evnt) ~ strata(node), data = findat2r))
kable(as.data.frame(summary(fit)$table))
#HR (unadjusted)
cpmod <- coxph(Surv(time,evnt) ~ COMPOUND, data = findat, ties="breslow")
Publish::publish(cpmod)
#HR (adjusted)
cpmod <- coxph(form, data = findat, ties="breslow")
Publish::publish(cpmod)

#Slide 22
#2L+ ORR
#1200
indat2Lplus1200 <- indat%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200), SAF14WFL=="Y")%>%
  mutate(orrn=ifelse(ORR=="Yes", 1, 0))
dim(indat2Lplus1200)
dat <- indat2Lplus1200%>%
  filter(CHSTGGRP!="")
rdres <- rd_res(dat=dat, respn="orrn", pred="COMPOUND", covs=c("AGE", "PMELESFL", "CHSTGGRP"), 
                predlevtrt="RMC-9805", predlevref=  "RMC-6236")
res1 <- data.frame(pop="2Lplus1200", `RMC-6236 (ORR(95%CI))`=rdres[[1]], `RMC-9805 (ORR(95%CI))`=rdres[[2]],
           `RMC-6236 - RMC-9805(Diff(95%CI))`=rdres[[3]])
#' resp <- "ORR"
#' respc <- "ORR"
#' pred <- "COMPOUND"
#' covs1 <-  c("AGE", "PMELESFL", "CHSTGGRP")
#' covs <- c("AGE", "PMELESFL", "CHSTGGRP")
#' 
#' options(scipen=99999)
#' form <- f.build("orrn", c(pred, covs))
#' form
#' dat$COMPOUND <- factor(dat$COMPOUND, levels=c("RMC-9805", "RMC-6236"))
#' dat$PMELESFL <- factor(dat$PMELESFL, levels=c("Y", "N"))
#' dat$CHSTGGRP <- factor(dat$CHSTGGRP, levels=c("IV", "<=III"))
#' fit1 <- glm(form, data = dat, family=binomial)
#' fit1
#' Publish::publish(fit1)
#' fit11 <- glm(f.build("orrn", c(pred)), data = dat, family=binomial)
#' fit11
#' Publish::publish(fit11)
#' require(MASS)
#' exp(cbind(coef(fit1), confint.default(fit1)))  
#' #Predicted values
#' 
#' pred_y_6236 <- stats::predict.glm(fit1, newdata=data.frame(dat%>%mutate(COMPOUND="RMC-6236")), type="response")
#' est6236<- mean(pred_y_6236, na.rm=T)
#' est6236
#' pred_y_9805 <- predict(fit1, newdata=data.frame(dat%>%mutate(COMPOUND="RMC-9805")), type="response")
#' est9805<- mean(pred_y_9805, na.rm=T)
#' est9805
#' estdiff <- est6236 - est9805
#' estdiff
#' #95% CI using bootstrapping
#' #' Run the boot function. Set a seed to obtain reproducibility
#' bootfunc <- function(data,index){
#'   boot_dat <- data[index,]
#'   fit1 <- glm(form, data = boot_dat, family="binomial")
#'   pred_y_6236 <- stats::predict.glm(fit1, newdata=data.frame(boot_dat%>%mutate(COMPOUND="RMC-6236")), type="response")
#'   pred_y_9805 <- predict(fit1, newdata=data.frame(boot_dat%>%mutate(COMPOUND="RMC-9805")), type="response")
#'   est_6236 <-  mean(pred_y_6236, na.rm=T)
#'   est_9805 <-  mean(pred_y_9805, na.rm=T)
#'   diff <- est_6236 - est_9805
#'   res <- c(est_6236, est_9805, diff)
#'   return(res)
#' }
#' set.seed(1234)
#' library(boot)
#' boot_res <- boot::boot(dat,bootfunc,R=2000)
#' boot_RD_6236 <- boot.ci(boot_res,index=1)
#' boot_RD_9805 <- boot.ci(boot_res,index=2)
#' boot_RD_diff <- boot.ci(boot_res,index=3)
#' ci_6236 <- paste(round(as.matrix(boot_RD_6236$bca[4]), 4), ",", 
#'                 round(as.matrix(boot_RD_6236$bca[5]), 4))
#' ci_9805 <- paste(round(as.matrix(boot_RD_9805$bca[4]), 4), ",", 
#'                 round(as.matrix(boot_RD_9805$bca[5]), 4))
#' ci_diff <- paste(round(as.matrix(boot_RD_diff$bca[4]), 4), ",", 
#'                 round(as.matrix(boot_RD_diff$bca[5]), 4))
#' res_6236 <- paste(round(est6236, 4), "(", ci_6236, ")")
#' res_9805 <- paste(round(est9805, 4), "(", ci_9805, ")")
#' res_diff <- paste(round(estdiff, 4), "(", ci_diff, ")")
#' res_6236
#' res_9805
#' res_diff
#' 
#' #Automated
#' dat$COMPOUND <- factor(dat$COMPOUND, levels=c("RMC-9805", "RMC-6236"))
#' dat$PMELESFL <- factor(dat$PMELESFL, levels=c("Y", "N"))
#' dat$CHSTGGRP <- factor(dat$CHSTGGRP, levels=c("IV", "<=III"))
source("Z:/Private/npanthi/February analysis/analysis_9805/rd.R")

#900
indat2Lplus1200 <- indat%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200, 900), SAF14WFL=="Y")%>%
  mutate(orrn=ifelse(ORR=="Yes", 1, 0))
dim(indat2Lplus1200)
dat2 <- indat2Lplus1200%>%
  filter(CHSTGGRP!="")
rdres <- rd_res(dat=dat2, respn="orrn", pred="COMPOUND", covs=c("AGE", "PMELESFL", "CHSTGGRP"), 
                predlevtrt="RMC-9805", predlevref=  "RMC-6236")
res2 <- data.frame(pop="2Lplus900", `RMC-6236 (ORR(95%CI))`=rdres[[1]], `RMC-9805 (ORR(95%CI))`=rdres[[2]],
           `RMC-6236 - RMC-9805(Diff(95%CI))`=rdres[[3]])
#Slide 23
#3L Plus
#1200
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="RMC-6236" & MMPDA3FL== "Y")|(COMPOUND=="RMC-9805" & MMLNPTM== ">1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200), SAF14WFL=="Y")%>%
  mutate(orrn=ifelse(ORR=="Yes", 1, 0))
dim(indat2Lplus1200)
dat3 <- indat2Lplus1200%>%
  filter(CHSTGGRP!="")
rdres <- rd_res(dat=dat3, respn="orrn", pred="COMPOUND", covs=c("AGE", "PMELESFL", "CHSTGGRP"), 
                predlevtrt="RMC-9805", predlevref=  "RMC-6236")
res3 <- data.frame(pop="3Lplus1200", `RMC-6236 (ORR(95%CI))`=rdres[[1]], `RMC-9805 (ORR(95%CI))`=rdres[[2]],
           `RMC-6236 - RMC-9805(Diff(95%CI))`=rdres[[3]])
#900
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="RMC-6236" & MMPDA3FL== "Y")|(COMPOUND=="RMC-9805" & MMLNPTM== ">1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200, 900), SAF14WFL=="Y")%>%
  mutate(orrn=ifelse(ORR=="Yes", 1, 0))
dim(indat2Lplus1200)
dat4 <- indat2Lplus1200%>%
  filter(CHSTGGRP!="")
rdres <- rd_res(dat=dat4, respn="orrn", pred="COMPOUND", covs=c("AGE", "PMELESFL", "CHSTGGRP"), 
                predlevtrt="RMC-9805", predlevref=  "RMC-6236")
res4 <- data.frame(pop="3Lplus900", `RMC-6236 (ORR(95%CI))`=rdres[[1]], `RMC-9805 (ORR(95%CI))`=rdres[[2]],
           `RMC-6236 - RMC-9805(Diff(95%CI))`=rdres[[3]])
#Slide 24-2L
#2L
#1200
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="RMC-6236" & MMP3PPFL== "Y")|(COMPOUND=="RMC-9805" & MMLNPTM== "<=1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200), SAF14WFL=="Y")%>%
  mutate(orrn=ifelse(ORR=="Yes", 1, 0))

dim(indat2Lplus1200)
dim(indat2Lplus1200)
dat5 <- indat2Lplus1200%>%
  filter(CHSTGGRP!="")
rdres <- rd_res(dat=dat5, respn="orrn", pred="COMPOUND", covs=c("AGE", "PMELESFL", "CHSTGGRP"), 
                predlevtrt="RMC-9805", predlevref=  "RMC-6236")
res5 <- data.frame(pop="2L900", `RMC-6236 (ORR(95%CI))`=rdres[[1]], `RMC-9805 (ORR(95%CI))`=rdres[[2]],
           `RMC-6236 - RMC-9805(Diff(95%CI))`=rdres[[3]])
#900
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="RMC-6236" & MMP3PPFL== "Y")|(COMPOUND=="RMC-9805" & MMLNPTM== "<=1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200, 900), SAF14WFL=="Y")%>%
  mutate(orrn=ifelse(ORR=="Yes", 1, 0))
dim(indat2Lplus1200)
dat6 <- indat2Lplus1200%>%
  filter(CHSTGGRP!="")
rdres <- rd_res(dat=dat6, respn="orrn", pred="COMPOUND", covs=c("AGE", "PMELESFL", "CHSTGGRP"), 
                predlevtrt="RMC-9805", predlevref=  "RMC-6236")
res6 <- data.frame(pop="2Lplus900", `RMC-6236 (ORR(95%CI))`=rdres[[1]], `RMC-9805 (ORR(95%CI))`=rdres[[2]],
           `RMC-6236 - RMC-9805(Diff(95%CI))`=rdres[[3]])
final <- rbind(res1, res2, res3, res4, res5, res6)
final
write.xlsx(final, "ORR_diff_6236ref.xlsx")
