##ORR
#Slide 22
#2L+ ORR
#1200

library(haven)
library(boot)
indat <- read_sas("~/adefpr_integrated.sas7bdat")
source("~/analysis_9805/rd.R")
##
resp <- "orrn"
trtvar <- "COMPOUND"
cov <- c("AGEC", "TLAPANFL", "CHSTGGRP", "BLECOGN")
trt <-  "Daraxon"
ref <-  "Zoldon"
##
indat2Lplus1200 <- indat%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200), SAF14WFL=="Y")%>%
  mutate(orrn=ifelse(ORR=="Yes", 1, 0),
         AGEC=ifelse(AGE<=65, "<=65", ">65"))
dim(indat2Lplus1200)
dat <- indat2Lplus1200%>%
  filter(CHSTGGRP!="")
dat$COMPOUND
rdres <- rd_res(dat=dat, respn=resp, pred=trtvar, 
                covs=cov, 
                predlevtrt=trt, predlevref= ref)

res1 <- data.frame(pop="2Lplus1200", `trt (ORR(95%CI))`=rdres[[1]], `ref (ORR(95%CI))`=rdres[[2]],
                   `trt - ref(Diff(95%CI))`=rdres[[3]])
res1
source("~/rundelta.R")
##Delta method
form <- f.build(resp, c(trtvar, cov))
dat$COMPOUND <- factor(dat$COMPOUND, levels=c( "Zoldon", "Daraxon"))
fit1 <- glm(form, data = dat, family=binomial)
rdresd <- deltares(fit1)
resd1 <- data.frame(pop="2Lplus1200", `trt (ORR(95%CI))`=rdresd[[1]], `ref (ORR(95%CI))`=rdresd[[2]],
                    `trt - ref(Diff(95%CI))`=rdresd[[3]])
resd1
##
# form <- f.build(resp, c(trtvar, cov))
# fit1 <- glm(form, data = dat, family=binomial)
# margins<- marg(
#   fit1, var_interest = "COMPOUND",
#   at = NULL, at_var_interest=c("Zoldon"))
# marg(
#   fit1, var_interest = "COMPOUND")
# 
# lmargins <- log((margins[[1]][2])/(1-margins[[1]][2]))
# selmargin <- margins[[1]][3]/((margins[[1]][2]*(1-margins[[1]][2])))
# lomargin <- lmargins-1.96*selmargin
# upmargin <- lmargins+1.96*selmargin
# 
# lowerm<- exp(lomargin)/(1+exp(lomargin))
# upperm <- exp(upmargin)/(1+exp(upmargin))
# #paste(margins[[1]][2], lowerm
# upperm
# margins
# ##
# 
# 
# 
# 
# marg(
#   fit1, var_interest = "COMPOUND",
#   at = NULL, at_var_interest=c("Daraxon"))
# 
# 
# # ##Alt
# pred_y_log_i <- stats::predict(fit1, newdata=data.frame(dat%>%mutate(COMPOUND="Zoldon")), type="response")
# prob <-  mean(pred_y_log_i, na.rm=T)
# prob
# df<-fit1$model
# vc<-vcov(fit1)
# mat<-model.matrix(fit1$formula,data=df)
# mat[,2] <-1
# phat<-plogis(mat%*%coef(fit1))
# pbar<-mean(phat)
# prob1 <- pbar
# prob1
# pderiv<-t(phat*(1-phat))%*%mat/nrow(mat)
# sepbar<-sqrt(pderiv%*%vc%*%t(pderiv))
# sepbar
# lmargins <- log((pbar)/(1-pbar))
# selmargin <- sepbar/((pbar*(1-pbar)))
# lomargin <- lmargins-1.96*selmargin
# upmargin <- lmargins+1.96*selmargin
# lowerm<- exp(lomargin)/(1+exp(lomargin))
# uperm <- exp(upmargin)/(1+exp(upmargin))
# lowerm
# uperm
# paste(round(pbar, 4), "(", round(lowerm, 4), ",", round(uperm, 4), ")")


#900
indat2Lplus1200 <- indat%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200, 900), SAF14WFL=="Y")%>%
  mutate(orrn=ifelse(ORR=="Yes", 1, 0),
         AGEC=ifelse(AGE<=65, "<=65", ">65"))
dim(indat2Lplus1200)
dat2 <- indat2Lplus1200%>%
  filter(CHSTGGRP!="")
rdres <- rd_res(dat=dat2, respn=resp, pred=trtvar, 
                covs=cov, 
                predlevtrt=trt, predlevref= ref)
res2 <- data.frame(pop="2Lplus900", `trt (ORR(95%CI))`=rdres[[1]], `ref (ORR(95%CI))`=rdres[[2]],
                   `trt - ref(Diff(95%CI))`=rdres[[3]])

##Delta method
form <- f.build(resp, c(trtvar, cov))
dat2$COMPOUND <- factor(dat2$COMPOUND, levels=c("Zoldon", "Daraxon"))
fit1 <- glm(form, data = dat2, family=binomial)
rdresd <- deltares(fit1)
resd2 <- data.frame(pop="2Lplus900", `trt (ORR(95%CI))`=rdresd[[1]], `ref (ORR(95%CI))`=rdresd[[2]],
                    `trt - ref(Diff(95%CI))`=rdresd[[3]])
resd2
#Slide 23
#3L Plus
#1200
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="Daraxon" & MMPDA3FL== "Y")|(COMPOUND=="Zoldon" & MMLNPTM== ">1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200), SAF14WFL=="Y")%>%
  mutate(orrn=ifelse(ORR=="Yes", 1, 0),
         AGEC=ifelse(AGE<=65, "<=65", ">65"))
dim(indat2Lplus1200)
dat3 <- indat2Lplus1200%>%
  filter(CHSTGGRP!="")
rdres <- rd_res(dat=dat3, respn=resp, pred=trtvar, 
                covs=cov, 
                predlevtrt=trt, predlevref= ref)
res3 <- data.frame(pop="3Lplus1200", `trt (ORR(95%CI))`=rdres[[1]], `ref (ORR(95%CI))`=rdres[[2]],
                   `trt - ref(Diff(95%CI))`=rdres[[3]])
##Delta method
form <- f.build(resp, c(trtvar, cov))
dat3$COMPOUND <- factor(dat3$COMPOUND, levels=c("Zoldon", "Daraxon"))
fit1 <- glm(form, data = dat3, family=binomial)
rdresd <- deltares(fit1)
resd3 <- data.frame(pop="3Lplus1200", `trt (ORR(95%CI))`=rdresd[[1]], `ref (ORR(95%CI))`=rdresd[[2]],
                    `trt - ref(Diff(95%CI))`=rdresd[[3]])
resd3
#900
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="Daraxon" & MMPDA3FL== "Y")|(COMPOUND=="Zoldon" & MMLNPTM== ">1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200, 900), SAF14WFL=="Y")%>%
  mutate(orrn=ifelse(ORR=="Yes", 1, 0),
         AGEC=ifelse(AGE<=65, "<=65", ">65"))
dim(indat2Lplus1200)
dat4 <- indat2Lplus1200%>%
  filter(CHSTGGRP!="")
rdres <- rd_res(dat=dat4, respn=resp, pred=trtvar, 
                covs=cov, 
                predlevtrt=trt, predlevref= ref)
res4 <- data.frame(pop="3Lplus900", `trt (ORR(95%CI))`=rdres[[1]], `ref (ORR(95%CI))`=rdres[[2]],
                   `trt - ref(Diff(95%CI))`=rdres[[3]])
##Delta method
form <- f.build(resp, c(trtvar, cov))
dat4$COMPOUND <- factor(dat4$COMPOUND, levels=c("Zoldon", "Daraxon"))
fit1 <- glm(form, data = dat4, family=binomial)
rdresd <- deltares(fit1)
resd4 <- data.frame(pop="3Lplus900", `trt (ORR(95%CI))`=rdresd[[1]], `ref (ORR(95%CI))`=rdresd[[2]],
                    `trt - ref(Diff(95%CI))`=rdresd[[3]])
resd4
#2L
#1200
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="Daraxon" & MMP3PPFL== "Y")|(COMPOUND=="Zoldon" & MMLNPTM== "<=1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200), SAF14WFL=="Y")%>%
  mutate(orrn=ifelse(ORR=="Yes", 1, 0),
         AGEC=ifelse(AGE<=65, "<=65", ">65"))

dim(indat2Lplus1200)
dim(indat2Lplus1200)
dat5 <- indat2Lplus1200%>%
  filter(CHSTGGRP!="")
rdres <- rd_res(dat=dat5, respn=resp, pred=trtvar, 
                covs=cov, 
                predlevtrt=trt, predlevref= ref)
res5 <- data.frame(pop="2L1200", `trt (ORR(95%CI))`=rdres[[1]], `ref (ORR(95%CI))`=rdres[[2]],
                   `trt - ref(Diff(95%CI))`=rdres[[3]])
##Delta method
form <- f.build(resp, c(trtvar, cov))
dat5$COMPOUND <- factor(dat5$COMPOUND, levels=c("Zoldon", "Daraxon"))
fit1 <- glm(form, data = dat5, family=binomial)
rdresd <- deltares(fit1)
resd5 <- data.frame(pop="2L1200", `trt (ORR(95%CI))`=rdresd[[1]], `ref (ORR(95%CI))`=rdresd[[2]],
                    `trt - ref(Diff(95%CI))`=rdresd[[3]])
resd5
#900
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="Daraxon" & MMP3PPFL== "Y")|(COMPOUND=="Zoldon" & MMLNPTM== "<=1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200, 900), SAF14WFL=="Y")%>%
  mutate(orrn=ifelse(ORR=="Yes", 1, 0),
         AGEC=ifelse(AGE<=65, "<=65", ">65"))
dim(indat2Lplus1200)
dat6 <- indat2Lplus1200%>%
  filter(CHSTGGRP!="")
rdres <- rd_res(dat=dat6, respn=resp, pred=trtvar, 
                covs=cov, 
                predlevtrt=trt, predlevref= ref)
res6 <- data.frame(pop="2L900", `trt (ORR(95%CI))`=rdres[[1]], `ref (ORR(95%CI))`=rdres[[2]],
                   `trt - ref(Diff(95%CI))`=rdres[[3]])
##Delta method
form <- f.build(resp, c(trtvar, cov))
dat6$COMPOUND <- factor(dat6$COMPOUND, levels=c("Zoldon", "Daraxon"))
fit1 <- glm(form, data = dat6, family=binomial)
rdresd <- deltares(fit1)
resd6 <- data.frame(pop="2L900", `trt (ORR(95%CI))`=rdresd[[1]], `ref (ORR(95%CI))`=rdresd[[2]],
                    `trt - ref(Diff(95%CI))`=rdresd[[3]])
resd6
final <- rbind(res1, res2, res3, res4, res5, res6)
final
#write.xlsx(final, "ORR_diff_9805ref.xlsx")
finald <- rbind(resd1, resd2, resd3, resd4, resd5, resd6)
finald
write.xlsx(finald, "ORR_diff_9805ref_delta.xlsx")
