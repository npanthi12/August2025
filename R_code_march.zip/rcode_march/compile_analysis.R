library(readxl)
outdir <- "~/outputs/"
out <- list.files(outdir)
for (i in 1:12){
outfile <- out[i]
if(TRUE){

sheetnm <- "Final covariate list - Avg10"
sheetnm1 <- "Final covariate list - Max10"

file <- paste(outdir,
              outfile, sep="")
dat1<- NULL
dat2<- NULL
dat3<- NULL
dat4<- NULL
dat5<- NULL
dat6<- NULL
datfin <- NULL
dat1 <- read_excel(file, sheet = "variable_importance_rsf")%>%dplyr::select(Variable, rnk1=imp_rnk)
dat2 <- read_excel(file, sheet = "single_covariate_imp")%>%dplyr::select(Variable=param, rnk2=rnkavg)
dat3 <- read_excel(file, sheet = "loto_imp")%>%dplyr::select(Variable=param, rnk3=rnkcind)
dat4 <- read_excel(file, sheet = "gradient_boosting_imp")%>%dplyr::select(Variable=Feature, rnk4=rnksgboost)
dat5 <- read_excel(file, sheet = "Deep learning in Python")%>%dplyr::select(Variable, Importance)
dat5$rnk5 <- dat5$Importance/max(dat5$Importance, na.rm=T)
dat6 <- read_excel(file, sheet = "variable_importance")%>%dplyr::select(Variable=col, rnk6=imp_rnk)%>%
  arrange(desc(rnk6))
dat1
dat2
dat3
dat4
dat5
dat6
datfin <- dat1%>%left_join(dat2)%>%left_join(dat3)%>%left_join(dat4)%>%left_join(dat5)%>%left_join(dat6)%>%
          dplyr::select(-Importance)

datfin$rnkfinal_avg <- apply(datfin[,-1], 1, mean, na.rm=T)
datfin$rnkfinal_max <- apply(datfin[,-1], 1, max, na.rm=T)
datexp <- datfin%>%arrange(desc(rnkfinal_avg))
datexp_ <- datexp[1:10, ]
datexp1 <- datfin%>%arrange(desc(rnkfinal_max))
datexp1_ <- datexp1[1:10, ]

#Write the first data set in a new workbook
file_path <- paste(outdir, outfile, sep="")
if(file.exists(file_path)){
  wb <- loadWorkbook(file_path)
}else{
  wb <- createWorkbook()
}
addWorksheet(wb, sheetnm)
writeData(wb, sheet=sheetnm, x=datexp_)
saveWorkbook(wb, file=file_path, overwrite=TRUE)

#Write the first data set in a new workbook
file_path <- paste(outdir, outfile, sep="")
if(file.exists(file_path)){
  wb <- loadWorkbook(file_path)
}else{
  wb <- createWorkbook()
}
addWorksheet(wb, sheetnm1)
writeData(wb, sheet=sheetnm1, x=datexp1_)
saveWorkbook(wb, file=file_path, overwrite=TRUE)
}
}
selcovs<- list()
##Intersection
library(readxl)
outdir <- "Z:/Private/npanthi/March analysis/analysis_refresh_03112025/outputs/"
out <- list.files(outdir)
for (i in 1:12){
  outfile <- out[i]
  if(TRUE){
    
    sheetnm <- "Top 10 covs_Frequency"
    
    file <- paste(outdir,
                  outfile, sep="")
    dat1<- NULL
    dat2<- NULL
    dat3<- NULL
    dat4<- NULL
    dat5<- NULL
    dat6<- NULL
    datfin <- NULL
    dat1 <- read_excel(file, sheet = "variable_importance_rsf")%>%dplyr::select(Variable, rnk1=imp_rnk)
    dat2 <- read_excel(file, sheet = "single_covariate_imp")%>%dplyr::select(Variable=param, rnk2=rnkavg)
    dat3 <- read_excel(file, sheet = "loto_imp")%>%dplyr::select(Variable=param, rnk3=rnkcind)
    dat4 <- read_excel(file, sheet = "gradient_boosting_imp")%>%dplyr::select(Variable=Feature, rnk4=rnksgboost)
    dat5 <- read_excel(file, sheet = "Deep learning in Python")%>%dplyr::select(Variable, Importance)
    dat5$rnk5 <- dat5$Importance/max(dat5$Importance, na.rm=T)
    dat6 <- read_excel(file, sheet = "variable_importance")%>%dplyr::select(Variable=col, rnk6=imp_rnk)%>%
      arrange(desc(rnk6))
    # my_vectors <- list(dat1$Variable[1:10], dat2$Variable[1:10],
    #                    dat3$Variable[1:10], dat4$Variable[1:10],
    #                    dat5$Variable[1:10], dat6$Variable[1:10])
    # 
    # Reduce(intersect, my_vectors)
   vars <- c(dat1$Variable[1:10], dat2$Variable[1:10], dat3$Variable[1:10],
                 dat4$Variable[1:10], dat5$Variable[1:10], dat6$Variable[1:10])
   b <- data.frame(param=vars, freqy=rep(1, length(vars)))
   sel_freq <- b%>%group_by(param)%>%dplyr::summarise(N=n())%>%arrange(desc(N))%>%
               as.data.frame()
    selcovs[[i]] <- sel_freq
    # #Write the first data set in a new workbook
    # file_path <- paste(outdir, outfile, sep="")
    # if(file.exists(file_path)){
    #   wb <- loadWorkbook(file_path)
    # }else{
    #   wb <- createWorkbook()
    # }
    # addWorksheet(wb, sheetnm)
    # writeData(wb, sheet=sheetnm, x=sel_freq[1:10, ])
    # saveWorkbook(wb, file=file_path, overwrite=TRUE)
    
    #Write the first data set in a new workbook
    # file_path <- paste(outdir, outfile, sep="")
    # if(file.exists(file_path)){
    #   wb <- loadWorkbook(file_path)
    # }else{
    #   wb <- createWorkbook()
    # }
    # addWorksheet(wb, sheetnm1)
    # writeData(wb, sheet=sheetnm1, x=datexp1_)
    # saveWorkbook(wb, file=file_path, overwrite=TRUE)
  }
}
selcovs
names(selcovs) <- out[1:12]
selcovs
