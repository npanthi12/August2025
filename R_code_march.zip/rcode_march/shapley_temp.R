library(shapviz)
library(iml)
library(randomForestSRC)
library(survivalmodels)

dat <- survival::lung
dat$status <- as.numeric(dat$status==2)
dat <- na.omit(dat)
rsf_model <- rfsrc(Surv(time,status)~., data=dat)
coxph_model<-coxph(Surv(time,status)~., data=dat, x=TRUE, model=TRUE)
coxexp <- explain(coxph_model)
exp <- model_parts(coxexp)
plot(exp)

surexp <- survex::explain(rsf_model)

surexp <- explain.rfsrc(rsf_model)
modprt <- model_parts(surexp)
plot(modprt)

deepsurv_model <- deepsurv(na.omit(dat), formula=Surv(time,status)~., epochs = 100)
deepexp <- explain.deepsurv(deepsurv_model)
model <- deepsurv_model
model <- rsf_model
model<- coxph_model

deepexp <- explain.deepsurv(deepsurv_model)
model <- deepsurv_model
model <- rsf_model
model$time.interest
attributes(model)
pred <- predict(model, newdata, type="survival")
pred[,as.character(dat[,"time"])]
colnames(pred)

dim()
pred$chf
predict.rfsrc
-log(pred$survival)
dim(pred)
sort(unique(dat$time))
k <- model$y
model$time.interest <- tmp_y[, 1]
explain.deepsurv <- function(model,
                          data = NULL,
                          y = NULL,
                          predict_function = NULL,
                          predict_function_target_column = NULL,
                          residual_function = NULL,
                          weights = NULL,
                          ...,
                          label = NULL,
                          verbose = TRUE,
                          colorize = !isTRUE(getOption("knitr.in.progress")),
                          model_info = NULL,
                          type = NULL,
                          times = NULL,
                          times_generation = "survival_quantiles",
                          predict_survival_function = NULL,
                          predict_cumulative_hazard_function = NULL) {
  if (is.null(label)) {
    label <- class(model)[1]
    attr(label, "verbose_info") <- "default"
  }
 
  if (is.null(data)) {
    data <- model$x
    attr(data, "verbose_info") <- "extracted"
  }
  
  if (is.null(y)) {
    tmp_y <- model$y
    y <- survival::Surv(tmp_y[, 1], tmp_y[, 2])
    attr(y, "verbose_info") <- "extracted"
  }
  
  if (is.null(predict_survival_function)) {
    predict_survival_function <- transform_to_stepfunction(predict,
                                                           type = "survival",
                                                           times_element = "time.interest",
                                                           prediction_element = "survival"
    )
    attr(predict_survival_function, "verbose_info") <- "stepfun based on predict.deepsurv()$survival will be used"
    attr(predict_survival_function, "is.default") <- TRUE
  } else {
    attr(predict_survival_function, "verbose_info") <- deparse(substitute(predict_survival_function))
  }
  
  if (is.null(predict_cumulative_hazard_function)) {
    predict_cumulative_hazard_function <- transform_to_stepfunction(predict,
                                                                    type = "chf",
                                                                    times_element = "time.interest",
                                                                    prediction_element = "chf"
    )
    attr(predict_cumulative_hazard_function, "verbose_info") <- "stepfun based on predict.deepsurv()$chf will be used"
    attr(predict_cumulative_hazard_function, "is.default") <- TRUE
  } else {
    attr(predict_cumulative_hazard_function, "verbose_info") <- deparse(substitute(predict_cumulative_hazard_function))
  }
  

  if (is.null(predict_function)) {
    predict_function <- function(model, newdata, times) {
      rowSums(predict_cumulative_hazard_function(model, newdata, times = times))
    }
    attr(predict_function, "verbose_info") <- "sum over the predict_cumulative_hazard_function will be used"
    attr(predict_function, "is.default") <- TRUE
    attr(predict_function, "use.times") <- TRUE
  } else {
    attr(predict_function, "verbose_info") <- deparse(substitute(predict_function))
  }
  
  explain_survival(
    model,
    data = data,
    y = y,
    predict_function = predict_function,
    predict_function_target_column = predict_function_target_column,
    residual_function = residual_function,
    weights = weights,
  #  ... = ...,
    label = label,
    verbose = verbose,
    colorize = colorize,
    model_info = model_info,
    type = type,
    times = times,
    times_generation = times_generation,
    predict_survival_function = predict_survival_function,
    predict_cumulative_hazard_function = predict_cumulative_hazard_function
  )
}
predict_function<- predict
type = "chf"
times_element = "time.interest"
prediction_element = "chf"
model <- model
newdata <- dat
times <- dat$time
predict_function(model, newdata)
model
sort(unique(dat$time))
transform_to_stepfunction <- function (predict_function, eval_times = NULL, ..., type = NULL, 
          prediction_element = NULL, times_element = NULL) {
  function(model, newdata, times) {
    raw_prediction <- predict_function(model, newdata)
    if (!is.null(times_element)) 
      eval_times <- raw_prediction[[times_element]]
    if (!is.null(prediction_element)) 
      prediction <- raw_prediction[[prediction_element]]
    n_rows <- ifelse(is.null(dim(prediction)), 1, nrow(prediction))
    return_matrix <- matrix(nrow = n_rows, ncol = length(times))
    if (is.null(dim(prediction))) {
      padding <- switch(type, survival = 1, chf = 0, prediction[1])
      stepfunction <- stepfun(eval_times, c(padding, prediction))
      return_matrix[1, ] <- stepfunction(times)
    }
    else {
      for (i in 1:n_rows) {
        padding <- switch(type, survival = 1, chf = 0, 
                          prediction[i, 1])
        stepfunction <- stepfun(eval_times, c(padding, 
                                              prediction[i, ]))
        return_matrix[i, ] <- stepfunction(times)
      }
    }
    return_matrix
  }
}

X <- dat[, !(names(dat)%in%c("time", "status"))]

model <- rsf_model
X=X
instance_id=1
num_samples=100
compute_shap <- function(model, X, instance_id, num_samples=100){
  instance <- X[instance_id, , drop=FALSE]
  feature_names <- colnames(X)
  num_features <- ncol(X)
  shap_values <- numeric(num_features)
  baseline <- mean(predict(model, newdata=X)$predicted)
  for(j in 1:num_features){
    j=1
    feature <- feature_names[j]
    subset_size <- sample(1:(num_features-1), num_samples, replace=TRUE)
    shap_contrib <- numeric(num_samples)
    
    for(s in 1:num_samples){
      s=1
      subset_features <- sample(setdiff(feature_names, feature), subset_size[s])
      X_with_j <- instance[, c(subset_features, feature), drop=FALSE]
      X_without_j <- instance[, subset_features, drop=FALSE]
      #Predict survival risk
      pred_with_j <- mean(predict(model, newdata=X_with_j)$predicted)
      shap_contrib[s] <- pred_with_j - pred_without_j
    }
    shap_values[j] <- feature_names
  }
  names(shap_values) <- feature_names
  return(shap_values)
}
shap_values <- compute_shap(rsf_model, X, instance_id=1, num_samples=100)


predict_survival <-function(model, newdata, times){
  if ("rfsrc" %in% class(model)){
    return(predict(model, newdata=newdata)$survival)
  }else{
    return(predict(model, newdata=newdata, type="survival")[times])
  }
}
predict(deepsurv_model, newdata=X, type="survival")
predict(deepsurv_model, newdata=X, type="survival", time=dat$time[1:5])
exp <- explain_survival(deepsurv_model, data=X, y=Surv(dat$time,dat$status), 
               predict_survival_function=predict_survival)
predict_parts(exp, dat[1,-c(3,4)], type="survshap")
model_parts(exp)
predictor <- Predictor$new(rsf_model, data=X, predict.function=predict_survival)
shapley_values <- Shapley$new(predictor, newdata=X[1,])
print(shapley_values)
plot(shapley_values)
##
 data("Boston", package = "MASS")
 rf <- rpart(medv ~ ., data = Boston)
X <- Boston[-which(names(Boston) == "medv")]
 mod <- Predictor$new(rf, data = X)
#'
#' # Then we explain the first instance of the dataset with the Shapley method:
 x.interest <- X[1, ]
 shapley <- Shapley$new(mod, x.interest = x.interest)
 shapley

 compute_shap <- function(model, X, instance_id, num_samples=100){
   
 }
 
 
###
 cph <- coxph(Surv(time, status) ~ ., data = veteran, x=TRUE)
 predict(cph, newdata=veteran, type = "risk")
 veteran_data <- veteran[, -c(3, 4)]
 veteran_y <- Surv(veteran$time, veteran$status)
 risk_pred <- function(model, newdata) predict(model, newdata, type = "risk")
 surv_pred <- function(model, newdata, times) pec::predictSurvProb(model, newdata, times)
 chf_pred <- function(model, newdata, times) -log(surv_pred(model, newdata, times))

 manual_cph_explainer <- survex::explain_survival(
     model = cph,
     data = veteran_data,
     y = veteran_y,
     predict_function = risk_pred,
     predict_survival_function = surv_pred,
     predict_cumulative_hazard_function = chf_pred,
     label = "manual coxph"
 )
 library(survex)
 survex::model_parts(manual_cph_explainer)
##
 cph <- deepsurv(Surv(time, status) ~ ., data = veteran)
 # predict(cph, newdata=veteran, type = "risk")
 # 
 # pec::predictSurvProb(cph, newdata=veteran, times=veteran$time)
 veteran_data <- veteran[, -c(3, 4)]
 veteran_y <- Surv(veteran$time, veteran$status)
 risk_pred <- function(model, newdata) predict(model, newdata, type = "risk")
 #surv_pred <- function(model, newdata, times) pec::predictSurvProb(model, newdata, times)
 surv_pred <- function(model, newdata, times) predict(model, newdata, type="survival", times)
 chf_pred <- function(model, newdata, times) -log(surv_pred(model, newdata, times))
 
 manual_cph_explainer <- survex::explain_survival(
   model = cph,
   data = veteran_data,
   y = veteran_y,
   predict_function = risk_pred,
   predict_survival_function = surv_pred,
   predict_cumulative_hazard_function = chf_pred,
   label = "manual coxph"
 )
 library(survex)
 survex::model_parts(manual_cph_explainer)
 