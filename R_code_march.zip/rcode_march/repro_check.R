
pgmname <- "Random_classification_forest"

covs <- c("C1D1DS", "AGE", "AGEDIAG", "BLALB", "BLECOGN", "BLLMETS", "BLNLR", 
          "BLSOD", "CHSTGGRP", "METASTNC", "MMLNPTM",
          "PMELESFL", "PT5CMFL", "PTGCMFL", "PTGEMCFL", "SEX", "SMKSTAT2", "TLAPANFL")



resp <- "ORR"
corv <- 0.8
library(haven)
library(survminer)
library(dplyr)
library(Hmisc)
library(AICcmodavg)
library(car)
library(broom)
library(cobalt)
library(ipw)
library(survey)
library(WeightIt)
library(glmtoolbox)
library(MatchIt)
library(MuMIn)
library(purrr)
library("survival")
library("survminer")
library(emmeans)
library(randomForestSRC)
library(ranger)
library(openxlsx)
library(randomForest)
library(dplyr)
library(ggraph)
library(igraph)
library(caret)
library(rpart.plot)
library(rpart)
library(party)
library(ggsurvfit)
library(visdat)
library(plotly)
library(GGally)
library(permimp)
library(DT)
library(ggsurvfit)
library(ggcorrplot)
library(tidyverse)
library(rcompanion)
library(gridExtra)
library(binom)
library(kableExtra)
library(pROC)

indat <- read_sas("Z:/Private/npanthi/February analysis/integrated/adefpr_integrated.sas7bdat")%>%
  filter(CHDXCLAS =="PANCREATIC", SAFFL == "Y", KRAG12FL=="Y", RASTYPE=="KRAS G12D", MMP3PPFL=="Y"|MMPDA3FL=="Y")%>%
  dplyr::filter(FOLLOWUP_W>=14)%>%
  filter(C1D1DS%in%c(160, 200, 220, 300))


d0 <- indat

dat0 <- d0


dat <- dat0


findat21 <- dat

fin <- indat
findat20 <- d0
#Step1: Describe fin1 to get missing covariates
#Step2: Make a note of missing covaritaes
#Step3: Change missing covariates into factor

#Step1
covs11 <- covs[!covs%in%c("")]
describe(findat21%>%dplyr::select(all_of(covs11), ORR))
#Step2
da <- findat21%>%dplyr::select(all_of(covs11), one_of(resp))
data <- replace(da, da == "", NA)
da1 <- sapply(data, function(x) sum(is.na(x)))
names(da1[da1>0])
#cont <- c("BLALB", "ICDY", "BLSOD",  "AGE", "LNPTM", "C1D1DS", "BLNLR") 

#Step2
covs_miss <- names(da1[da1>0])

#Step3


findat22 <- data%>%dplyr::select(all_of(covs11), one_of(resp))%>%
  drop_na()%>%
  dplyr::mutate_if(is.character, as.factor)

findat2 <- as.data.frame(findat22)
B <- 50000
dim(findat2)
colnames(findat22)
form <- f.build(resp, covs)
form

tree.output <- party::ctree(form, data = findat2, controls = ctree_control(mincriterion = 0.8, 
               minbucket=20, minsplit=10, testtype = "Univariate"))


source("~/runfrst.R")
condres <- runfrst(dat=findat2, ntre=500, resp=resp, covs=covs)

form


sel_imp <- as.data.frame(condres[[1]][[1]])%>%arrange(desc(`condres[[1]][[1]]`))
sel_imp1 <- as.data.frame(condres[[1]][[1]])%>%arrange(`condres[[1]][[1]]`)

freq_max <- max(sel_imp1$`condres[[1]][[1]]`)
sel_imp1$rnk <- sel_imp1$`condres[[1]][[1]]`/freq_max
sel_imp1$col <- row.names(sel_imp1)
row.names(sel_imp1) <- NULL

imp <- condres[[2]]%>%mutate(col=row.names(condres[[2]]))%>%
  arrange(desc(Overall))%>%dplyr::select(col, Overall)
forest.importance <- condres[[2]]%>%arrange(Overall)
imp1 <- forest.importance%>%mutate(Overall=round(Overall, 9))%>%arrange(desc(Overall))
imp_max <- max(imp1$Overall)
imp1$rnk1 <- imp1$Overall/imp_max
imp1$col <- row.names(imp1)
row.names(imp1) <- NULL

varimpfin <- sel_imp1%>%dplyr::left_join(imp1)%>%mutate(av_rnk = (rnk+rnk1)/2)%>%arrange(desc(av_rnk))%>%
  dplyr::select(col, sel_rank = rnk, imp_rnk=rnk1, av_rnk, everything())%>%
  mutate(N_=1:n())
varimpfin

vari1 <- varimpfin%>%dplyr::select(col, N_)%>%left_join(assn3)%>%arrange(N_dup, N_)%>%
  filter(!is.na(N_dup))%>%
  distinct(N_dup, .keep_all = T)

vari1rm <- varimpfin%>%dplyr::select(col, N_)%>%left_join(assn3)%>%arrange(N_dup, desc(N_))%>%
  filter(!is.na(N_dup))%>%
  distinct(N_dup, .keep_all = T)

vari1fin <- setdiff(vari1$col, vari1rm$col)
vari1fin

vari2 <- varimpfin%>%dplyr::select(col, N_)%>%left_join(assn3)%>%filter(is.na(N_dup))
covs1 <- c(vari1fin, vari2$col)
covs1
form2 <- f.build(resp, covs1)
form2
#covs_miss


findat2r <- findat2a



findat2r <- as.data.frame(findat2r)
colnames(findat2r)
###
sel_imp <- as.data.frame(freq[[1]])%>%arrange(desc(`freq[[1]]`))
kable(sel_imp)
sel_imp1 <- sel_imp%>%arrange(`freq[[1]]`)

imp <- forest.importance%>%mutate(col=row.names(forest.importance))%>%
  arrange(desc(Overall))%>%dplyr::select(col, Overall)
forest.importance <- forest.importance%>%arrange(Overall)
imp1 <- forest.importance%>%mutate(Overall=round(Overall, 9))%>%arrange(desc(Overall))
kable(imp1)

par(mfrow = c(1, 2))
dotchart(x=sel_imp1$`freq[[1]]`, labels=row.names(sel_imp1), main="Variable importance by selection frequency \n(Using all variables)")

dotchart(x=forest.importance$Overall, labels=row.names(forest.importance), main="Conditional importance of variables \n(Using all variables)")

plt1 <- varimpfin%>%dplyr::arrange(`freq[[1]]`)
plt1$col <- factor(plt1$col, levels=plt1$col)
p1 <- ggplot(plt1, aes(x = `freq[[1]]`, 
                                                          y = col)) + geom_dotplot(binaxis = "y", stackdir = "center", 
                                                                                   binwidth = diff(range(varimpfin$`freq[[1]]`))/30, 
                                                                                   #dotsize = 0.3
                                                                                   ) + ggtitle("Figure 1: Variable importance \n(Using all variables)") + 
  xlab("Selection Frequency") + ylab("") + 
  theme_bw()
p1
plt2 <- varimpfin%>%dplyr::arrange(Overall)
plt2$col <- factor(plt2$col, levels=plt2$col)
p2 <- ggplot(plt2, aes(x = Overall, y = col)) + 
  geom_dotplot(binaxis = "y", stackdir = "center", 
               binwidth = diff(range(varimpfin$`freq[[1]]`))/30, 
               dotsize = 0.3) + xlab("Overall Importance") + 
  ylab("") + theme_bw()
p2
km_plt3 <- p1 | p2
km_plt3
p1
sel_imp1%>%arrange(desc(`freq[[1]]`))

