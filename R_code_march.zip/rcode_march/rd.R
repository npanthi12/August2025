rd_res <- function(dat, respn, pred, covs, predlevtrt, predlevref){
  
  form <- f.build(respn, c(pred, covs))
  fit1 <- glm(form, data = dat, family=binomial)
  #Predicted values
  
  pred_y_trt <- stats::predict.glm(fit1, newdata=data.frame(dat%>%mutate(COMPOUND=predlevtrt)), type="response")
  esttrt<- mean(pred_y_trt, na.rm=T)
  esttrt
  pred_y_ref <- predict(fit1, newdata=data.frame(dat%>%mutate(COMPOUND=predlevref)), type="response")
  estref<- mean(pred_y_ref, na.rm=T)
  estref
  estdiff <- esttrt - estref
  estdiff
  #95% CI using bootstrapping
  #' Run the boot function. Set a seed to obtain reproducibility
  bootfunc <- function(data,index){
    boot_dat <- data[index,]
    tryCatch({
    fit1 <- glm(form, data = boot_dat, family="binomial")
    },
    error = function(e) {
      message("An Error Occurred")
      
      #print(e)
    },
    warning = function(w) {
      message("A Warning Occurred")
      #print(w)
      
    })
    pred_y_trt <- stats::predict.glm(fit1, newdata=data.frame(boot_dat%>%mutate(COMPOUND=predlevtrt)), type="response")
    pred_y_ref <- predict(fit1, newdata=data.frame(boot_dat%>%mutate(COMPOUND=predlevref)), type="response")
    est_trt <-  mean(pred_y_trt, na.rm=T)
    est_ref <-  mean(pred_y_ref, na.rm=T)
    diff <- est_trt - est_ref
    res <- c(est_trt, est_ref, diff)
    return(res)
  }
  set.seed(1234)
  boot_res <- boot::boot(dat,bootfunc,R=2000)
  boot_RD_trt <- boot.ci(boot_res,index=1)
  boot_RD_ref <- boot.ci(boot_res,index=2)
  boot_RD_diff <- boot.ci(boot_res,index=3)
  ci_trt <- paste(round(as.matrix(boot_RD_trt$bca[4]), 4), ",", 
                  round(as.matrix(boot_RD_trt$bca[5]), 4))
  ci_ref <- paste(round(as.matrix(boot_RD_ref$bca[4]), 4), ",", 
                  round(as.matrix(boot_RD_ref$bca[5]), 4))
  ci_diff <- paste(round(as.matrix(boot_RD_diff$bca[4]), 4), ",", 
                   round(as.matrix(boot_RD_diff$bca[5]), 4))
  res_trt <- paste(round(esttrt, 4), "(", ci_trt, ")")
  res_ref <- paste(round(estref, 4), "(", ci_ref, ")")
  res_diff <- paste(round(estdiff, 4), "(", ci_diff, ")")
  out <- list(res_trt, res_ref, res_diff)
  return(out)
}