#' @export
explain_survival <-
  function(model,
           data = NULL,
           y = NULL,
           predict_function = NULL,
           predict_function_target_column = NULL,
           residual_function = NULL,
           weights = NULL,
           ...,
           label = NULL,
           verbose = TRUE,
           colorize = !isTRUE(getOption("knitr.in.progress")),
           model_info = NULL,
           type = NULL,
           times = NULL,
           times_generation = "survival_quantiles",
           predict_survival_function = NULL,
           predict_cumulative_hazard_function = NULL) {
    if (!colorize) {
      color_codes <- list(
        yellow_start = "", yellow_end = "",
        red_start = "", red_end = "",
        green_start = "", green_end = ""
      )
    }
    
    
    if (is.null(predict_survival_function) &&
        !is.null(predict_cumulative_hazard_function)) {
      predict_survival_function <- function(model, newdata, times) cumulative_hazard_to_survival(predict_cumulative_hazard_function(model, newdata, times))
      attr(predict_survival_function, "verbose_info") <- "exp(-predict_cumulative_hazard_function) will be used"
      attr(predict_survival_function, "is.default") <- TRUE
    }
    
    if (is.null(predict_cumulative_hazard_function) &&
        !is.null(predict_survival_function)) {
      predict_cumulative_hazard_function <-
        function(model, newdata, times) survival_to_cumulative_hazard(predict_survival_function(model, newdata, times))
      attr(predict_cumulative_hazard_function, "verbose_info") <- "-log(predict_survival_function) will be used"
      attr(predict_cumulative_hazard_function, "is.default") <- TRUE
    }
    
    # verbose start
    verbose_cat("Preparation of a new explainer is initiated", verbose = verbose)
    
    # verbose label
    if (is.null(label)) {
      label <- tail(class(model), 1)
      verbose_cat("  -> model label       : ", label, is.default = TRUE, verbose = verbose)
    } else {
      if (!is.character(label)) {
        label <- substr(as.character(label), 1, 15)
        verbose_cat("  -> model label       : 'label' was not a string class object. Converted. (", color_codes$red_start, "WARNING", color_codes$red_end, ")", verbose = verbose)
        warning("'label' was not a string class object")
      } else if (!is.null(attr(label, "verbose_info")) && attr(label, "verbose_info") == "default") {
        verbose_cat("  -> model label       : ", label, is.default = TRUE, verbose = verbose)
        attr(label, "verbose_info") <- NULL
      } else {
        verbose_cat("  -> model label       : ", label, verbose = verbose)
      }
    }
    
    # verbose data
    if (is.null(data)) {
      possible_data <- try(model.frame(model), silent = TRUE)
      if (class(possible_data)[1] != "try-error") {
        data <- possible_data
        data <- possible_data[, -1]
        if (is.null(y)) {
          y <- possible_data[, 1]
          attr(y, "verbose_info") <- "extracted"
        }
        n <- nrow(data)
        verbose_cat("  -> data              : ", n, " rows ", ncol(data), " cols", "(", color_codes$yellow_start, "extracted from the model", color_codes$yellow_end, ")", verbose = verbose)
      } else {
        # Setting 0 as value of n if data is not present is necessary for future checks
        n <- 0
        verbose_cat("  -> no data available! (", color_codes$red_start, "WARNING", color_codes$red_end, ")", verbose = verbose)
        warning("No data available")
      }
    } else {
      n <- nrow(data)
      if (!is.null(attr(data, "verbose_info")) && attr(data, "verbose_info") == "extracted") {
        verbose_cat("  -> data              : ", n, " rows ", ncol(data), " cols", "(", color_codes$yellow_start, "extracted from the model", color_codes$yellow_end, ")", verbose = verbose)
        attr(data, "verbose_info") <- NULL
      } else if (!is.null(attr(data, "verbose_info")) && attr(data, "verbose_info") == "colnames_changed") {
        verbose_cat("  -> data              : ", n, " rows ", ncol(data), " cols", "(", color_codes$yellow_start, "colnames changed to comply with the model", color_codes$yellow_end, ")", verbose = verbose)
        attr(data, "verbose_info") <- NULL
      }
      else {
        verbose_cat("  -> data              : ", n, " rows ", ncol(data), " cols", verbose = verbose)
      }
    }
    if ("tbl" %in% class(data)) {
      data <- as.data.frame(data)
      verbose_cat("  -> data              :  tibble converted into a data.frame", verbose = verbose)
    }
    
    # verbose target variable
    if (is.null(y)) {
      verbose_cat("  -> target variable   :  not specified! (", color_codes$red_start, "WARNING", color_codes$red_end, ")", verbose = verbose)
      warning("Target variable not specified")
    } else {
      n_events <- sum(y[, 2])
      n_censored <- length(y) - n_events
      frac_censored <- round(n_censored / n, 3)
      if (!is.null(attr(y, "verbose_info")) && attr(y, "verbose_info") == "extracted") {
        verbose_cat("  -> target variable   : ", length(y), " values (", n_events, "events and", n_censored, "censored , censoring rate =", frac_censored, ")", "(", color_codes$yellow_start, "extracted from the model", color_codes$yellow_end, ")", verbose = verbose)
        attr(y, "verbose_info") <- NULL
      } else {
        verbose_cat("  -> target variable   : ", length(y), " values (", n_events, "events and", n_censored, "censored )", verbose = verbose)
      }
      if (length(y) != n) {
        verbose_cat("  -> target variable   :  length of 'y' is different than number of rows in 'data' (", color_codes$red_start, "WARNING", color_codes$red_end, ")", verbose = verbose)
        warning("Length of 'y' is different than number of rows in 'data'")
      }
      if (is.null(data)) {
        verbose_cat("  -> target variable   :  'y' present while 'data' is NULL. (", color_codes$red_start, "WARNING", color_codes$red_end, ")", verbose = verbose)
        warning("'y' present while 'data' is NULL")
      }
    }
    
    # verbose times
    median_survival_time <- NULL
    if (is.null(times)) {
      if (!is.null(y)) {
        switch(times_generation,
               "survival_quantiles" = {
                 survobj <- Surv(y[,1], y[,2])
                 sfit <- survival::survfit(survobj ~ 1, type="kaplan-meier")
                 
                 max_sf <- max(sfit$surv[sfit$surv!=1]) # without 1 (for time = 0)
                 min_sf <- min(sfit$surv)
                 quantiles <- 1 - seq(max_sf, min_sf, length.out=50)
                 
                 if(min_sf <= 0.5) median_survival_time <- as.numeric(quantile(sfit, 0.5)$quantile)
                 raw_times <- quantile(sfit, quantiles)$quantile
                 
                 times <- sort(na.omit(unique(c(raw_times, median_survival_time))))
                 method_description <- "uniformly distributed survival quantiles based on Kaplan-Meier estimator"
               },
               "uniform" = {
                 times <- seq(min(y[, 1]), max(y[, 1]), length.out = 50)
                 method_description <- "uniformly distributed time points from min to max observed time"
               },
               "quantiles" = {
                 times <- quantile(y[, 1], seq(0, 0.98, 0.02))
                 method_description <- "time points being consecutive quantiles (0.00, 0.02, ..., 0.98) of observed times"
               },
               stop("times_generation needs to be 'survival_quantiles', 'uniform' or 'quantiles'")
        )
        times <- sort(unique(times))
        verbose_cat("  -> times             : ", length(times), "unique time points", get_times_stats(times, median_survival_time), verbose = verbose)
        verbose_cat("  -> times             : ", "(", color_codes$yellow_start, paste("generated from y as", method_description), color_codes$yellow_end, ")", verbose = verbose)
      } else {
        verbose_cat("  -> times   :  not specified and automatic generation is impossible ('y' is NULL)! (", color_codes$red_start, "WARNING", color_codes$red_end, ")", verbose = verbose)
        warning("'times' not specified and automatic generation is impossible ('y' is NULL)")
      }
    } else {
      times <- sort(unique(times))
      times_stats <- get_times_stats(times)
      verbose_cat("  -> times             : ", length(times), "unique time points", get_times_stats(times, median_survival_time), verbose = verbose)
    }
    
    # verbose predict function
    if (is.null(predict_function)) {
      if (!is.null(predict_cumulative_hazard_function)) {
        predict_function <- risk_from_chf(predict_cumulative_hazard_function, times)
        verbose_cat("  -> predict function  : ", "sum over the predict_cumulative_hazard_function will be used", is.default = TRUE, verbose = verbose)
      } else {
        verbose_cat("  -> predict function   :  not specified! (", color_codes$red_start, "WARNING", color_codes$red_end, ")", verbose = verbose)
        warning("Prediction function not specified")
      }
    } else {
      if (!is.null(attr(predict_function, "verbose_info"))) {
        verbose_cat("  -> predict function  : ", attr(predict_function, "verbose_info"), is.default = attr(predict_function, "is.default"), verbose = verbose)
        attr(predict_function, "verbose_info") <- NULL
        attr(predict_function, "is.default") <- NULL
      } else {
        verbose_cat("  -> predict function  : ", deparse(substitute(predict_function)), verbose = verbose)
      }
      if (!is.null(attr(predict_function, "use.times")) && attr(predict_function, "use.times") == TRUE) {
        predict_function_old <- predict_function
        predict_function <- function(model, newdata) predict_function_old(model, newdata, times = times)
      }
      if (!"function" %in% class(predict_function)) {
        verbose_cat("  -> predict function  :  'predict_function' is not a 'function' class object! (", color_codes$red_start, "WARNING", color_codes$red_end, ")", verbose = verbose)
        warning("Prediction function not available")
      }
    }
    
    # verbose predict survival function
    if (is.null(predict_survival_function)) {
      verbose_cat("  -> predict survival function   :  not specified! (", color_codes$red_start, "WARNING", color_codes$red_end, ")", verbose = verbose)
      warning("Survival function not available")
    } else {
      if (!is.null(attr(predict_survival_function, "verbose_info"))) {
        verbose_cat("  -> predict survival function  : ", attr(predict_survival_function, "verbose_info"), is.default = attr(predict_survival_function, "is.default"), verbose = verbose)
        attr(predict_survival_function, "verbose_info") <- NULL
        attr(predict_survival_function, "is.default") <- NULL
      } else {
        verbose_cat("  -> predict survival function  : ", deparse(substitute(predict_survival_function)), verbose = verbose)
      }
      if (!"function" %in% class(predict_survival_function)) {
        verbose_cat("  -> predict survival function  :  'predict_survival_function' is not a 'function' class object! (", color_codes$red_start, "WARNING", color_codes$red_end, ")", verbose = verbose)
        warning("Survival function not available")
      }
    }
    
    # verbose predict cumulative hazard function
    if (is.null(predict_cumulative_hazard_function)) {
      verbose_cat("  -> predict cumulative hazard function   :  not specified! (", color_codes$red_start, "WARNING", color_codes$red_end, ")", verbose = verbose)
      warning("Cumulative hazard function not available")
    } else {
      if (!is.null(attr(predict_cumulative_hazard_function, "verbose_info"))) {
        verbose_cat("  -> predict cumulative hazard function  : ", attr(predict_cumulative_hazard_function, "verbose_info"), is.default = attr(predict_cumulative_hazard_function, "is.default"), verbose = verbose)
        attr(predict_cumulative_hazard_function, "verbose_info") <- NULL
        attr(predict_cumulative_hazard_function, "is.default") <- NULL
      } else {
        verbose_cat("  -> predict cumulative hazard function  : ", deparse(substitute(predict_cumulative_hazard_function)), verbose = verbose)
      }
      if (!"function" %in% class(predict_cumulative_hazard_function)) {
        verbose_cat("  -> predict cumulative hazard function  :  'predict_cumulative_hazard_function' is not a 'function' class object! (", color_codes$red_start, "WARNING", color_codes$red_end, ")", verbose = verbose)
        warning("'predict_cumulative_hazard_function' is not a 'function' class object")
      }
    }
    
    # verbose model info
    if (is.null(model_info)) {
      model_info <- surv_model_info(model)
      verbose_cat("  -> model_info        :  package", model_info$package[1], ", ver.", model_info$ver[1], ", task", model_info$type, is.default = TRUE, verbose = verbose)
    } else {
      verbose_cat("  -> model_info        :  package", model_info$package[1], ", ver.", model_info$ver[1], ", task", model_info$type, verbose = verbose)
    }
    # if type specified then it overwrite the type in model_info
    if (!is.null(type)) {
      model_info$type <- type
      verbose_cat("  -> model_info        :  type set to ", type, verbose = verbose)
    }
    if (class(y)[1] != "Surv") {
      verbose_cat("  -> model_info        :  survival task detected but 'y' is a", class(y)[1], "  (", color_codes$red_start, "WARNING", color_codes$red_end, ")", verbose = verbose)
      verbose_cat("  -> model_info        :  by deafult survival tasks supports only 'y' parameter of 'survival::Surv' class", verbose = verbose)
    }
    
    explainer <- DALEX::explain(
      model = model,
      data = data,
      y = y,
      predict_function = predict_function,
      predict_function_target_column = NULL,
      residual_function = NULL,
      weights = NULL,
      label = label,
      verbose = FALSE,
      precalculate = FALSE,
      colorize = colorize,
      model_info = model_info,
      type = type,
      times = times,
      median_survival_time = median_survival_time,
      predict_survival_function = predict_survival_function,
      predict_cumulative_hazard_function = predict_cumulative_hazard_function,
      ... = ...
    )
    
    class(explainer) <- c("surv_explainer", class(explainer))
    
    # verbose end - everything went OK
    verbose_cat("", color_codes$green_start, "A new explainer has been created!", color_codes$green_end, verbose = verbose)
    explainer
  }

#' @rdname explain_survival
#' @export
explain <- function(model,
                    data = NULL,
                    y = NULL,
                    predict_function = NULL,
                    predict_function_target_column = NULL,
                    residual_function = NULL,
                    weights = NULL,
                    ...,
                    label = NULL,
                    verbose = TRUE,
                    colorize = !isTRUE(getOption("knitr.in.progress")),
                    model_info = NULL,
                    type = NULL) {
  UseMethod("explain", model)
}

#' @rdname explain_survival
#' @export
explain.default <- function(model,
                            data = NULL,
                            y = NULL,
                            predict_function = NULL,
                            predict_function_target_column = NULL,
                            residual_function = NULL,
                            weights = NULL,
                            ...,
                            label = NULL,
                            verbose = TRUE,
                            colorize = !isTRUE(getOption("knitr.in.progress")),
                            model_info = NULL,
                            type = NULL) {
  supported_models <- c("aalen", "riskRegression", "cox.aalen", "cph", "coxph", "selectCox", "pecCforest", "prodlim", "psm", "survfit", "pecRpart")
  if (inherits(model, supported_models)) {
    return(
      explain_survival(
        model,
        data = data,
        y = y,
        predict_function = predict_function,
        predict_function_target_column = predict_function_target_column,
        residual_function = residual_function,
        weights = weights,
        ...,
        label = label,
        verbose = verbose,
        colorize = colorize,
        model_info = model_info,
        type = type,
        predict_survival_function = pec::predictSurvProb
      )
    )
  }
  if (inherits(model, "sksurv.base.SurvivalAnalysisMixin")){
    return(
      explain.sksurv(model,
                     data = data,
                     y = y,
                     predict_function = predict_function,
                     predict_function_target_column = predict_function_target_column,
                     residual_function = residual_function,
                     weights = weights,
                     ...,
                     label = label,
                     verbose = verbose,
                     colorize = colorize,
                     model_info = model_info,
                     type = type
      )
    )
  }
  
  DALEX::explain(model,
                 data = data,
                 y = y,
                 predict_function = predict_function,
                 predict_function_target_column = predict_function_target_column,
                 residual_function = residual_function,
                 weights = weights,
                 ... = ...,
                 label = label,
                 verbose = verbose,
                 colorize = !isTRUE(getOption("knitr.in.progress")),
                 model_info = model_info,
                 type = type
  )
  
}

#' @export
explain.coxph <- function(model,
                          data = NULL,
                          y = NULL,
                          predict_function = NULL,
                          predict_function_target_column = NULL,
                          residual_function = NULL,
                          weights = NULL,
                          ...,
                          label = NULL,
                          verbose = TRUE,
                          colorize = !isTRUE(getOption("knitr.in.progress")),
                          model_info = NULL,
                          type = NULL,
                          times = NULL,
                          times_generation = "survival_quantiles",
                          predict_survival_function = NULL,
                          predict_cumulative_hazard_function = NULL) {
  if (is.null(data)) {
    data <- model$model[, attr(model$terms, "term.labels")]
    if (is.null(data)) {
      stop(
        "use `model=TRUE` and `x=TRUE` while creating coxph model or provide `data` manually"
      )
    }
    attr(data, "verbose_info") <- "extracted"
  }
  
  if (is.null(y)) {
    y <- model$y
    if (is.null(y)) {
      stop("use `y=TRUE` while creating coxph model or provide `y` manually")
    }
    attr(y, "verbose_info") <- "extracted"
  }
  
  if (is.null(predict_survival_function)) {
    predict_survival_function <- function(model, newdata, times) {
      pec::predictSurvProb(model, newdata, times)
    }
    attr(predict_survival_function, "verbose_info") <- "predictSurvProb.coxph will be used"
    attr(predict_survival_function, "is.default") <- TRUE
  } else {
    attr(predict_survival_function, "verbose_info") <- deparse(substitute(predict_survival_function))
  }
  
  if (is.null(predict_cumulative_hazard_function)) {
    predict_cumulative_hazard_function <-
      function(model, newdata, times) {
        survival_to_cumulative_hazard(predict_survival_function(model, newdata, times))
      }
    attr(predict_cumulative_hazard_function, "verbose_info") <- "-log(predict_survival_function) will be used"
    attr(predict_cumulative_hazard_function, "is.default") <- TRUE
  } else {
    attr(predict_cumulative_hazard_function, "verbose_info") <- deparse(substitute(predict_cumulative_hazard_function))
  }
  
  if (is.null(predict_function)) {
    predict_function <- function(model, newdata) {
      predict(model, newdata, type = "risk")
    }
    attr(predict_function, "verbose_info") <- "predict.coxph with type = 'risk' will be used"
    attr(predict_function, "is.default") <- TRUE
  } else {
    attr(predict_function, "verbose_info") <- deparse(substitute(predict_function))
  }
  
  explain_survival(
    model,
    data = data,
    y = y,
    predict_function = predict_function,
    predict_function_target_column = predict_function_target_column,
    residual_function = residual_function,
    weights = weights,
    ... = ...,
    label = label,
    verbose = verbose,
    colorize = colorize,
    model_info = model_info,
    type = type,
    times = times,
    times_generation = times_generation,
    predict_survival_function = predict_survival_function,
    predict_cumulative_hazard_function = predict_cumulative_hazard_function
  )
}


#' @export
explain.ranger <- function(model,
                           data = NULL,
                           y = NULL,
                           predict_function = NULL,
                           predict_function_target_column = NULL,
                           residual_function = NULL,
                           weights = NULL,
                           ...,
                           label = NULL,
                           verbose = TRUE,
                           colorize = !isTRUE(getOption("knitr.in.progress")),
                           model_info = NULL,
                           type = NULL,
                           times = NULL,
                           times_generation = "survival_quantiles",
                           predict_survival_function = NULL,
                           predict_cumulative_hazard_function = NULL) {
  if (is.null(predict_survival_function)) {
    predict_survival_function <- transform_to_stepfunction(predict,
                                                           type = "survival",
                                                           times_element = "unique.death.times",
                                                           prediction_element = "survival"
    )
    attr(predict_survival_function, "verbose_info") <- "stepfun based on predict.ranger()$survival will be used"
    attr(predict_survival_function, "is.default") <- TRUE
  } else {
    attr(predict_survival_function, "verbose_info") <- deparse(substitute(predict_survival_function))
  }
  
  if (is.null(predict_cumulative_hazard_function)) {
    predict_cumulative_hazard_function <- transform_to_stepfunction(predict,
                                                                    type = "chf",
                                                                    times_element = "unique.death.times",
                                                                    prediction_element = "chf"
    )
    attr(predict_cumulative_hazard_function, "verbose_info") <- "stepfun based on predict.ranger()$chf will be used"
    attr(predict_cumulative_hazard_function, "is.default") <- TRUE
  } else {
    attr(predict_cumulative_hazard_function, "verbose_info") <- deparse(substitute(predict_cumulative_hazard_function))
  }
  
  if (is.null(predict_function)) {
    predict_function <- function(model, newdata, times) {
      rowSums(predict_cumulative_hazard_function(model, newdata, times))
    }
    attr(predict_function, "verbose_info") <- "sum over the predict_cumulative_hazard_function will be used"
    attr(predict_function, "is.default") <- TRUE
    attr(predict_function, "use.times") <- TRUE
  } else {
    attr(predict_function, "verbose_info") <- deparse(substitute(predict_function))
  }
  
  explain_survival(
    model,
    data = data,
    y = y,
    predict_function = predict_function,
    predict_function_target_column = predict_function_target_column,
    residual_function = residual_function,
    weights = weights,
    ... = ...,
    label = label,
    verbose = verbose,
    colorize = colorize,
    model_info = model_info,
    type = type,
    times = times,
    times_generation = times_generation,
    predict_survival_function = predict_survival_function,
    predict_cumulative_hazard_function = predict_cumulative_hazard_function
  )
}


#' @export
explain.rfsrc <- function(model,
                          data = NULL,
                          y = NULL,
                          predict_function = NULL,
                          predict_function_target_column = NULL,
                          residual_function = NULL,
                          weights = NULL,
                          ...,
                          label = NULL,
                          verbose = TRUE,
                          colorize = !isTRUE(getOption("knitr.in.progress")),
                          model_info = NULL,
                          type = NULL,
                          times = NULL,
                          times_generation = "survival_quantiles",
                          predict_survival_function = NULL,
                          predict_cumulative_hazard_function = NULL) {
  if (is.null(label)) {
    label <- class(model)[1]
    attr(label, "verbose_info") <- "default"
  }
  
  if (is.null(data)) {
    data <- model$xvar
    attr(data, "verbose_info") <- "extracted"
  }
  
  if (is.null(y)) {
    tmp_y <- model$yvar
    y <- survival::Surv(tmp_y[, 1], tmp_y[, 2])
    attr(y, "verbose_info") <- "extracted"
  }
  
  if (is.null(predict_survival_function)) {
    predict_survival_function <- transform_to_stepfunction(predict,
                                                           type = "survival",
                                                           times_element = "time.interest",
                                                           prediction_element = "survival"
    )
    attr(predict_survival_function, "verbose_info") <- "stepfun based on predict.rfsrc()$survival will be used"
    attr(predict_survival_function, "is.default") <- TRUE
  } else {
    attr(predict_survival_function, "verbose_info") <- deparse(substitute(predict_survival_function))
  }
  
  if (is.null(predict_cumulative_hazard_function)) {
    predict_cumulative_hazard_function <- transform_to_stepfunction(predict,
                                                                    type = "chf",
                                                                    times_element = "time.interest",
                                                                    prediction_element = "chf"
    )
    attr(predict_cumulative_hazard_function, "verbose_info") <- "stepfun based on predict.rfsrc()$chf will be used"
    attr(predict_cumulative_hazard_function, "is.default") <- TRUE
  } else {
    attr(predict_cumulative_hazard_function, "verbose_info") <- deparse(substitute(predict_cumulative_hazard_function))
  }
  
  if (is.null(predict_function)) {
    predict_function <- function(model, newdata, times) {
      rowSums(predict_cumulative_hazard_function(model, newdata, times = times))
    }
    attr(predict_function, "verbose_info") <- "sum over the predict_cumulative_hazard_function will be used"
    attr(predict_function, "is.default") <- TRUE
    attr(predict_function, "use.times") <- TRUE
  } else {
    attr(predict_function, "verbose_info") <- deparse(substitute(predict_function))
  }
  
  explain_survival(
    model,
    data = data,
    y = y,
    predict_function = predict_function,
    predict_function_target_column = predict_function_target_column,
    residual_function = residual_function,
    weights = weights,
    ... = ...,
    label = label,
    verbose = verbose,
    colorize = colorize,
    model_info = model_info,
    type = type,
    times = times,
    times_generation = times_generation,
    predict_survival_function = predict_survival_function,
    predict_cumulative_hazard_function = predict_cumulative_hazard_function
  )
}


#' @export
explain.model_fit <- function(model,
                              data = NULL,
                              y = NULL,
                              predict_function = NULL,
                              predict_function_target_column = NULL,
                              residual_function = NULL,
                              weights = NULL,
                              ...,
                              label = NULL,
                              verbose = TRUE,
                              colorize = !isTRUE(getOption("knitr.in.progress")),
                              model_info = NULL,
                              type = NULL,
                              times = NULL,
                              times_generation = "survival_quantiles",
                              predict_survival_function = NULL,
                              predict_cumulative_hazard_function = NULL) {
  if (is.null(label)) {
    label <- paste(rev(class(model)), collapse = "")
    attr(label, "verbose_info") <- "default"
  }
  
  if (is.null(predict_survival_function)) {
    predict_survival_function <- function(model, newdata, times) {
      prediction <- predict(model, new_data = newdata, type = "survival", eval_time = times)$.pred
      return_matrix <- t(sapply(prediction, function(x) x$.pred_survival))
      return_matrix[is.na(return_matrix)] <- 0
      return_matrix
    }
    attr(predict_survival_function, "verbose_info") <- "predict.model_fit with type = 'survival' will be used"
    attr(predict_survival_function, "is.default") <- TRUE
  } else {
    attr(predict_survival_function, "verbose_info") <- deparse(substitute(predict_survival_function))
  }
  
  if (is.null(predict_cumulative_hazard_function)) {
    predict_cumulative_hazard_function <-
      function(object, newdata, times) survival_to_cumulative_hazard(predict_survival_function(object, newdata, times))
    attr(predict_cumulative_hazard_function, "verbose_info") <- "-log(predict_survival_function) will be used"
    attr(predict_cumulative_hazard_function, "is.default") <- TRUE
  } else {
    attr(predict_cumulative_hazard_function, "verbose_info") <- deparse(substitute(predict_cumulative_hazard_function))
  }
  
  if (is.null(predict_function)) {
    if (model$spec$engine %in% c("mboost", "survival", "glmnet", "flexsurv", "flexsurvspline")) {
      predict_function <- function(model, newdata, times) predict(model, new_data = newdata, type = "linear_pred")$.pred_linear_pred
      attr(predict_function, "verbose_info") <- "predict.model_fit with type = 'linear_pred' will be used"
    } else {
      predict_function <- function(model, newdata, times) rowSums(predict_cumulative_hazard_function(model, newdata, times = times))
      attr(predict_function, "verbose_info") <- "sum over the predict_cumulative_hazard_function will be used"
    }
    attr(predict_function, "use.times") <- TRUE
    attr(predict_function, "is.default") <- TRUE
  } else {
    attr(predict_function, "verbose_info") <- deparse(substitute(predict_function))
  }
  
  explain_survival(
    model,
    data = data,
    y = y,
    predict_function = predict_function,
    predict_function_target_column = predict_function_target_column,
    residual_function = residual_function,
    weights = weights,
    ... = ...,
    label = label,
    verbose = verbose,
    colorize = colorize,
    model_info = model_info,
    type = type,
    times = times,
    times_generation = times_generation,
    predict_survival_function = predict_survival_function,
    predict_cumulative_hazard_function = predict_cumulative_hazard_function
  )
}


#' @export
explain.LearnerSurv <- function(model,
                                data = NULL,
                                y = NULL,
                                predict_function = NULL,
                                predict_function_target_column = NULL,
                                residual_function = NULL,
                                weights = NULL,
                                ...,
                                label = NULL,
                                verbose = TRUE,
                                colorize = !isTRUE(getOption("knitr.in.progress")),
                                model_info = NULL,
                                type = NULL,
                                times = NULL,
                                times_generation = "survival_quantiles",
                                predict_survival_function = NULL,
                                predict_cumulative_hazard_function = NULL) {
  if (is.null(label)) {
    label <- class(model)[1]
    attr(label, "verbose_info") <- "default"
  }
  
  if (is.null(predict_survival_function)) {
    if ("distr" %in% model$predict_types) {
      predict_survival_function <- function(model, newdata, times) t(model$predict_newdata(newdata)$distr$survival(times))
      attr(predict_survival_function, "verbose_info") <- "predict_newdata()$distr$survival will be used"
      attr(predict_survival_function, "is.default") <- TRUE
    }
  } else {
    attr(predict_survival_function, "verbose_info") <- deparse(substitute(predict_survival_function))
  }
  
  if (is.null(predict_cumulative_hazard_function)) {
    if ("distr" %in% model$predict_types) {
      predict_cumulative_hazard_function <- function(model, newdata, times) t(model$predict_newdata(newdata)$distr$cumHazard(times))
      attr(predict_cumulative_hazard_function, "verbose_info") <- "predict_newdata()$distr$cumHazard will be used"
      attr(predict_cumulative_hazard_function, "is.default") <- TRUE
    }
  } else {
    attr(predict_cumulative_hazard_function, "verbose_info") <- deparse(substitute(predict_cumulative_hazard_function))
  }
  
  if (is.null(predict_function)) {
    if ("crank" %in% model$predict_types) {
      predict_function <- function(model, newdata, times) model$predict_newdata(newdata)$crank
      attr(predict_function, "verbose_info") <- "predict_newdata()$crank will be used"
    } else {
      predict_function <- function(model, newdata, times) {
        rowSums(predict_cumulative_hazard_function(model, newdata, times))
      }
      attr(predict_function, "verbose_info") <- "sum over the predict_cumulative_hazard_function will be used"
    }
    attr(predict_function, "is.default") <- TRUE
    attr(predict_function, "use.times") <- TRUE
  } else {
    attr(predict_function, "verbose_info") <- deparse(substitute(predict_function))
  }
  
  explain_survival(
    model,
    data = data,
    y = y,
    predict_function = predict_function,
    predict_function_target_column = predict_function_target_column,
    residual_function = residual_function,
    weights = weights,
    ... = ...,
    label = label,
    verbose = verbose,
    colorize = colorize,
    model_info = model_info,
    type = type,
    times = times,
    times_generation = times_generation,
    predict_survival_function = predict_survival_function,
    predict_cumulative_hazard_function = predict_cumulative_hazard_function
  )
}

#' @export
explain.sksurv <- function(model,
                           data = NULL,
                           y = NULL,
                           predict_function = NULL,
                           predict_function_target_column = NULL,
                           residual_function = NULL,
                           weights = NULL,
                           ...,
                           label = NULL,
                           verbose = TRUE,
                           colorize = !isTRUE(getOption("knitr.in.progress")),
                           model_info = NULL,
                           type = NULL,
                           times = NULL,
                           times_generation = "survival_quantiles",
                           predict_survival_function = NULL,
                           predict_cumulative_hazard_function = NULL){
  if (is.null(label)) {
    label <- class(model)[1]
    attr(label, "verbose_info") <- "default"
  }
  
  if (is.null(predict_survival_function)) {
    if (reticulate::py_has_attr(model, "predict_survival_function")) {
      predict_survival_function <- function(model, newdata, times){
        raw_preds <- model$predict_survival_function(newdata)
        t(sapply(raw_preds, function(sf) as.vector(sf(times))))
      }
      attr(predict_survival_function, "verbose_info") <- "predict_survival_function from scikit-survival will be used"
      attr(predict_survival_function, "is.default") <- TRUE
    }
  } else {
    attr(predict_survival_function, "verbose_info") <- deparse(substitute(predict_survival_function))
  }
  
  if (is.null(predict_cumulative_hazard_function)) {
    if (reticulate::py_has_attr(model, "predict_cumulative_hazard_function")) {
      predict_cumulative_hazard_function <- function(model, newdata, times){
        raw_preds <- model$predict_cumulative_hazard_function(newdata)
        t(sapply(raw_preds, function(chf) as.vector(chf(times))))
      }
      attr(predict_cumulative_hazard_function, "verbose_info") <- "predict_cumulative_hazard_function from scikit-survival will be used"
      attr(predict_cumulative_hazard_function, "is.default") <- TRUE
    }
  } else {
    attr(predict_cumulative_hazard_function, "verbose_info") <- deparse(substitute(predict_cumulative_hazard_function))
  }
  
  if (is.null(predict_function)) {
    if (reticulate::py_has_attr(model, "predict")) {
      predict_function <- function(model, newdata) model$predict(newdata)
      attr(predict_function, "verbose_info") <- "predict from scikit-survival will be used"
      attr(predict_function, "is.default") <- TRUE
    } else {
      attr(predict_function, "verbose_info") <- deparse(substitute(predict_function))
    }
  }
  
  if (!is.null(data) & any(colnames(data) != model$feature_names_in_)) {
    colnames(data) <- sub("[.]", "=", colnames(data))
    attr(data, "verbose_info") <- "colnames_changed"
  }
  
  if (class(model)[1] != "sksurv"){
    class(model) <- c("sksurv", class(model))
  }
  
  explain_survival(
    model,
    data = data,
    y = y,
    predict_function = predict_function,
    predict_function_target_column = predict_function_target_column,
    residual_function = residual_function,
    weights = weights,
    ... = ...,
    label = label,
    verbose = verbose,
    colorize = colorize,
    model_info = model_info,
    type = type,
    times = times,
    times_generation = times_generation,
    predict_survival_function = predict_survival_function,
    predict_cumulative_hazard_function = predict_cumulative_hazard_function
  )
}


#' @export
explain.flexsurvreg <- function(model,
                                data = NULL,
                                y = NULL,
                                predict_function = NULL,
                                predict_function_target_column = NULL,
                                residual_function = NULL,
                                weights = NULL,
                                ...,
                                label = NULL,
                                verbose = TRUE,
                                colorize = !isTRUE(getOption("knitr.in.progress")),
                                model_info = NULL,
                                type = NULL,
                                times = NULL,
                                times_generation = "survival_quantiles",
                                predict_survival_function = NULL,
                                predict_cumulative_hazard_function = NULL) {
  if (is.null(label)) {
    label <- class(model)[1]
    attr(label, "verbose_info") <- "default"
  }
  
  if (is.null(predict_survival_function)) {
    predict_survival_function <-  function(model, newdata, times){
      raw_preds <- predict(model, newdata = newdata, times = times, type = "survival")
      preds <- do.call(rbind, lapply(raw_preds[[1]], function(x) t(x[".pred_survival"])))
      rownames(preds) <- NULL
      preds
    }
    attr(predict_survival_function, "verbose_info") <- "predict.flexsurvreg with type = 'survival' will be used"
    attr(predict_survival_function, "is.default") <- TRUE
  } else {
    attr(predict_survival_function, "verbose_info") <- deparse(substitute(predict_survival_function))
  }
  
  if (is.null(predict_cumulative_hazard_function)) {
    predict_cumulative_hazard_function <- function(model, newdata, times){
      raw_preds <- predict(model, newdata = newdata, times = times, type = "cumhaz")
      preds <- do.call(rbind, lapply(raw_preds[[1]], function(x) t(x[".pred_cumhaz"])))
      rownames(preds) <- NULL
      preds
    }
    attr(predict_cumulative_hazard_function, "verbose_info") <- "predict.flexsurvreg with type = 'cumhaz' will be used"
    attr(predict_cumulative_hazard_function, "is.default") <- TRUE
  } else {
    attr(predict_cumulative_hazard_function, "verbose_info") <- deparse(substitute(predict_cumulative_hazard_function))
  }
  
  if (is.null(predict_function)) {
    predict_function <- function(model, newdata){
      predict(model, newdata = newdata, type = "link")[[".pred_link"]]
    }
    attr(predict_function, "verbose_info") <- "predict.flexsurvreg with type = 'link' will be used"
    attr(predict_function, "is.default") <- TRUE
  } else {
    attr(predict_function, "verbose_info") <- deparse(substitute(predict_function))
  }
  
  possible_data <- model.frame(model)
  if (is.null(data)) {
    data <- possible_data[,-c(1, ncol(possible_data))]
    attr(data, "verbose_info") <- "extracted"
  }
  
  if (is.null(y)) {
    y <- possible_data[,1]
    attr(y, "verbose_info") <- "extracted"
  }
  
  explain_survival(
    model,
    data = data,
    y = y,
    predict_function = predict_function,
    predict_function_target_column = predict_function_target_column,
    residual_function = residual_function,
    weights = weights,
    ... = ...,
    label = label,
    verbose = verbose,
    colorize = colorize,
    model_info = model_info,
    type = type,
    times = times,
    times_generation = times_generation,
    predict_survival_function = predict_survival_function,
    predict_cumulative_hazard_function = predict_cumulative_hazard_function
  )
}

verbose_cat <- function(..., is.default = NULL, verbose = TRUE) {
  if (verbose) {
    if (!is.null(is.default)) {
      txt <- paste(..., "(", color_codes$yellow_start, "default", color_codes$yellow_end, ")")
      cat(txt, "\n")
    } else {
      cat(..., "\n")
    }
  }
}

get_times_stats <- function(times, median_survival_time=NULL) {
  median_survival_time_str <- ifelse(is.null(median_survival_time), "", paste0(" , median survival time = ", median_survival_time))
  paste0(", min = ", min(times), median_survival_time_str, " , max = ", max(times))
}

#
# colors for WARNING, NOTE, DEFAULT
#
color_codes <- list(
  yellow_start = "\033[33m", yellow_end = "\033[39m",
  red_start = "\033[31m", red_end = "\033[39m",
  green_start = "\033[32m", green_end = "\033[39m"
)

model_parts <- function(explainer, ...) UseMethod("model_parts", explainer)

#' @rdname model_parts.surv_explainer
#' @export
model_parts.surv_explainer <- function(explainer,
                                       loss_function = survex::loss_brier_score,
                                       ...,
                                       type = "difference",
                                       output_type = "survival",
                                       N = 1000) {
  if (!(type %in% c("difference", "ratio", "raw", "variable_importance"))) stop("Type shall be one of 'variable_importance', 'difference', 'ratio', 'raw'")
  if (!(output_type %in% c("survival", "risk"))) stop("output_type should be 'survival' or 'risk'")
  if (type == "variable_importance") type <- "raw" # it's an alias
  
  switch(output_type,
         "risk" = DALEX::model_parts(
           explainer = explainer,
           loss_function = loss_function,
           ... = ...,
           type = type,
           N = N
         ),
         "survival" = {
           test_explainer(explainer, has_data = TRUE, has_y = TRUE, has_survival = TRUE, function_name = "model_parts")
           
           if (attr(loss_function, "loss_type") == "integrated") {
             res <- surv_integrated_feature_importance(
               x = explainer,
               loss_function = loss_function,
               type = type,
               N = N,
               ...
             )
             class(res) <- c("model_parts_survival", class(res))
             return(res)
           } else {
             res <- surv_feature_importance(
               x = explainer,
               loss_function = loss_function,
               type = type,
               N = N,
               ...
             )
             res$event_times <- explainer$y[explainer$y[, 1] <= max(explainer$times), 1]
             res$event_statuses <- explainer$y[explainer$y[, 1] <= max(explainer$times), 2]
             class(res) <- c("model_parts_survival", class(res))
             res
           }
         },
         stop("Type should be either `survival` or `risk`")
  )
}

#' @export
model_parts.default <- DALEX::model_parts


cumulative_hazard_to_survival <- function(hazard_functions) {
  return(exp(-hazard_functions))
}

#' Transform Survival to Cumulative Hazard
#'
#' Helper function to transform between survival function and CHF
#' @param survival_functions matrix or vector, with each row representing a survival function
#' @param epsilon a positive numeric number to add, so that the logarithm can be taken
#'
#' @return A matrix or vector transformed to the form of a cumulative hazard function.
#'
#' @examples
#' library(survex)
#'
#' vec <- c(1, 0.9, 0.8, 0.7, 0.6)
#' matr <- matrix(c(1, 0.9, 0.8, 1, 0.8, 0.6), ncol = 3)
#'
#' survival_to_cumulative_hazard(vec)
#'
#' survival_to_cumulative_hazard(matr)
#'
#' @export
survival_to_cumulative_hazard <- function(survival_functions, epsilon = 0) {
  return(-log(survival_functions))
}

# tests if the explainer has all the required fields
test_explainer <- function(explainer,
                           function_name,
                           has_data = FALSE,
                           has_y = FALSE,
                           has_survival = FALSE,
                           has_chf = FALSE,
                           has_predict = FALSE) {
  if (!("surv_explainer" %in% class(explainer))) {
    stop(paste0("The ", function_name, " function requires an object created with survex::explain() function."))
  }
  if (has_data && is.null(explainer$data)) {
    stop(paste0("The ", function_name, " function requires explainers with specified `data` parameter"))
  }
  if (has_y && is.null(explainer$y)) {
    stop(paste0("The ", function_name, " function requires explainers with specified `y` parameter"))
  }
  if (has_survival && is.null(explainer$predict_survival_function)) {
    stop(paste0("The ", function_name, " function requires explainers with specified `predict_survival_function` parameter"))
  }
  if (has_chf && is.null(explainer$predict_cumulative_hazard_function)) {
    stop(paste0("The ", function_name, " function requires explainers with specified `predict_cumulative_hazard_function` parameter"))
  }
  if (has_predict && is.null(explainer$predict_function)) {
    stop(paste0("The ", function_name, " function requires explainers with specified `predict_risk` parameter"))
  }
}


#' @importFrom DALEX colors_discrete_drwhy
generate_discrete_color_scale <- function(n, colors = NULL) {
  if (is.null(colors) || length(colors) < n) {
    return(colors_discrete_drwhy(n))
  } else {
    return(colors[(0:(n - 1) %% length(colors)) + 1])
  }
}

#' Transform Fixed Point Prediction into a Stepfunction
#'
#' Some models return the survival function or cumulative hazard function prediction at the times of events present in the training data set. This is a convenient utility to allow the prediction to be evaluated at any time.
#'
#' @param predict_function a function making the prediction based on `model` and `newdata` arguments, the `...` parameter is also passed to this function. It has to return either a numeric vector of the same length as `eval_times`, a matrix with this number of columns and the same number of rows as `nrow(newdata)`. It can also return a list, with one of the elements containing such an object.
#' @param eval_times a numeric vector of times, at which the fixed predictions are made. This can be `NULL`, if `predict_function` returns a list which contains such a vector.
#' @param ... other parameters passed to predict_function
#' @param type the type of function to be returned, either `"survival"`, `"chf"` or `NULL` this chooses the value of the step function before the first prediction time. If `"survival"` then it is 1, if `"chf"` then 0, otherwise, it is the value of the prediction for the first time in numerical order.
#' @param prediction_element if `predict_function` returns a list with the matrix as one of its elements, this parameter should contain the name of this element
#' @param times_element if `predict_function` returns a list with the matrix as one of its elements, this parameter should contain the name of this element
#'
#' @return The function returns a function with three arguments, (`model`, `newdata`, `times`), ready to supply it to an explainer.
#'
#' @examples
#' \donttest{
#' library(survex)
#' library(survival)
#'
#' rsf_src <- randomForestSRC::rfsrc(Surv(time, status) ~ ., data = veteran)
#'
#' chf_function <- transform_to_stepfunction(predict,
#'     type = "chf",
#'     prediction_element = "chf",
#'     times_element = "time.interest"
#' )
#'
#' explainer <- explain(rsf_src, predict_cumulative_hazard_function = chf_function)
#' }
#' @export
transform_to_stepfunction <- function(predict_function, eval_times = NULL, ..., type = NULL, prediction_element = NULL, times_element = NULL) {
  function(model, newdata, times) {
    raw_prediction <- predict_function(model, newdata, ...)
    if (!is.null(times_element)) eval_times <- raw_prediction[[times_element]]
    if (!is.null(prediction_element)) prediction <- raw_prediction[[prediction_element]]
    n_rows <- ifelse(is.null(dim(prediction)), 1, nrow(prediction))
    return_matrix <- matrix(nrow = n_rows, ncol = length(times))
    
    
    if (is.null(dim(prediction))) {
      padding <- switch(type,
                        "survival" = 1,
                        "chf" = 0,
                        prediction[1]
      )
      stepfunction <- stepfun(eval_times, c(padding, prediction))
      return_matrix[1, ] <- stepfunction(times)
    } else {
      for (i in 1:n_rows) {
        padding <- switch(type,
                          "survival" = 1,
                          "chf" = 0,
                          prediction[i, 1]
        )
        stepfunction <- stepfun(eval_times, c(padding, prediction[i, ]))
        return_matrix[i, ] <- stepfunction(times)
      }
    }
    
    return_matrix
  }
}

#' Generate Risk Prediction based on the Survival Function
#'
#' Some models do not come with a ready to use risk prediction. This function allows for its generation based on the cumulative hazard function.
#'
#' @param predict_cumulative_hazard_function a function of three arguments (`model`, `newdata`, `times`) that allows for making cumulative hazard predictions.
#' @param times a numeric vector of times at which the function should be evaluated.
#'
#' @return A function of two arguments (`model`, `newdata`) returning a vector of risks.
#'
#' @examples
#' \donttest{
#' library(survex)
#' library(survival)
#'
#' rsf_src <- randomForestSRC::rfsrc(Surv(time, status) ~ ., data = veteran)
#'
#' chf_function <- transform_to_stepfunction(predict,
#'     type = "chf",
#'     prediction_element = "chf",
#'     times_element = "time.interest"
#' )
#' risk_function <- risk_from_chf(chf_function, unique(veteran$time))
#'
#' explainer <- explain(rsf_src,
#'     predict_cumulative_hazard_function = chf_function,
#'     predict_function = risk_function
#' )
#' }
#' @export
risk_from_chf <- function(predict_cumulative_hazard_function, times) {
  function(model, newdata) rowSums(predict_cumulative_hazard_function(model, newdata, times))
}

#' Extract Local SurvSHAP(t) from Global SurvSHAP(t)
#'
#' Helper function to extract local SurvSHAP(t) explanation from global one.
#' Can be can be useful for creating SurvSHAP(t) plots for single observations.
#'
#' @param aggregated_survshap an object of class `aggregated_surv_shap` containing the computed global SHAP values
#' @param index a numeric value, position of an observation to be extracted in the result of global explanation
#'
#' @return An object of classes `c("predict_parts_survival", "surv_shap")`. It is a list with the element `result` containing the results of the explanation.
#'
#' @examples
#' \donttest{
#' veteran <- survival::veteran
#' rsf_ranger <- ranger::ranger(
#'     survival::Surv(time, status) ~ .,
#'     data = veteran,
#'     respect.unordered.factors = TRUE,
#'     num.trees = 100,
#'     mtry = 3,
#'     max.depth = 5
#' )
#' rsf_ranger_exp <- explain(
#'     rsf_ranger,
#'     data = veteran[, -c(3, 4)],
#'     y = survival::Surv(veteran$time, veteran$status),
#'     verbose = FALSE
#' )
#'
#' ranger_global_survshap <- model_survshap(
#'     explainer = rsf_ranger_exp,
#'     new_observation = veteran[
#'         c(1:4, 17:20, 110:113, 126:129),
#'         !colnames(veteran) %in% c("time", "status")
#'     ]
#' )
#'
#' local_survshap_1 <- extract_predict_survshap(ranger_global_survshap, index = 1)
#' plot(local_survshap_1)
#' }
#'
#' @export
extract_predict_survshap <- function(aggregated_survshap, index) {
  if (!inherits(aggregated_survshap, "aggregated_surv_shap")) {
    stop("`aggregated_survshap` object must be of class 'aggregated_surv_shap'")
  }
  
  if (index > aggregated_survshap$n_observations) {
    stop(paste("Incorrect `index`, number of observations in `aggregated_survshap` is", aggregated_survshap$n_observations))
  }
  
  
  res <- list()
  res$eval_times <- aggregated_survshap$eval_times
  res$event_times <- aggregated_survshap$event_times
  res$event_statuses <- aggregated_survshap$event_statuses
  res$variable_values <- aggregated_survshap$variable_values[index, ]
  res$result <- aggregated_survshap$result[[index]]
  res$aggregate <- aggregated_survshap$aggregate[[index]]
  class(res) <- c("predict_parts_survival", "surv_shap")
  attr(res, "label") <- attr(aggregated_survshap, "label")
  
  res
}


#' @keywords internal
add_rug_to_plot <- function(base_plot, rug_df, rug, rug_colors) {
  if (rug == "all") {
    return_plot <- with(rug_df, {
      base_plot +
        geom_rug(data = rug_df[rug_df$statuses == 1, ], mapping = aes(x = times, color = statuses), inherit.aes = F, color = rug_colors[1]) +
        geom_rug(data = rug_df[rug_df$statuses == 0, ], mapping = aes(x = times, color = statuses), inherit.aes = F, color = rug_colors[2])
    })
  } else if (rug == "events") {
    return_plot <- with(rug_df, {
      base_plot +
        geom_rug(data = rug_df[rug_df$statuses == 1, ], mapping = aes(x = times, color = statuses), inherit.aes = F, color = rug_colors[1])
    })
  } else if (rug == "censors") {
    return_plot <- with(rug_df, {
      base_plot +
        geom_rug(data = rug_df[rug_df$statuses == 0, ], mapping = aes(x = times, color = statuses), inherit.aes = F, color = rug_colors[2])
    })
  } else {
    return_plot <- base_plot
  }
}


#' @keywords internal
calculate_integral <- function(values, times, normalization = "t_max", ...) {
  n <- length(values)
  
  if (is.null(normalization)) {
    tmp <- (values[1:(n - 1)] + values[2:n]) * diff(times) / 2
    integrated_metric <- sum(tmp) / (max(times) - min(times))
    return(integrated_metric)
  } else if (normalization == "t_max") {
    tmp <- (values[1:(n - 1)] + values[2:n]) * diff(times) / 2
    integrated_metric <- sum(tmp)
    return(integrated_metric / max(times))
  } else if (normalization == "survival") {
    y_true <- list(...)$y_true
    km <- survival::survfit(y_true ~ 1)
    estimator <- stepfun(km$time, c(1, km$surv))
    
    dwt <- 1 - estimator(times)
    
    tmp <- (values[1:(n - 1)] + values[2:n]) * diff(dwt) / 2
    integrated_metric <- sum(tmp)
    return(integrated_metric / (1 - estimator(max(times))))
  }
}

# based on iml::order_levels
#' @importFrom stats ecdf xtabs cmdscale
#' @keywords internal
order_levels <- function(data, variable_values, variable_name) {
  feature <- droplevels(variable_values)
  x.count <- as.numeric(table(feature))
  x.prob <- x.count / sum(x.count)
  K <- nlevels(feature)
  
  dists <- lapply(setdiff(colnames(data), variable_name), function(x) {
    feature.x <- data[, x]
    dists <- expand.grid(levels(feature), levels(feature))
    colnames(dists) <- c("from.level", "to.level")
    if (inherits(feature.x, "factor")) {
      A <- table(feature, feature.x) / x.count
      dists$dist <- rowSums(abs(A[dists[, "from.level"], ] - A[dists[, "to.level"], ])) / 2
    } else {
      quants <- quantile(feature.x, probs = seq(0, 1, length.out = 100), na.rm = TRUE, names = FALSE)
      ecdfs <- data.frame(lapply(levels(feature), function(lev) {
        x.ecdf <- ecdf(feature.x[feature == lev])(quants)
      }))
      colnames(ecdfs) <- levels(feature)
      ecdf.dists.all <- abs(ecdfs[, dists$from.level] - ecdfs[, dists$to.level])
      dists$dist <- apply(ecdf.dists.all, 2, max)
    }
    dists
  })
  
  dists.cumulated.long <- Reduce(function(d1, d2) {
    d1$dist <- d1$dist + d2$dist
    d1
  }, dists)
  dists.cumulated <- xtabs(dist ~ from.level + to.level, dists.cumulated.long)
  scaled <- cmdscale(dists.cumulated, k = 1)
  order(scaled)
}

surv_feature_importance <- function(x, ...) UseMethod("surv_feature_importance", x)


#' @rdname surv_feature_importance
x = explainer
loss_function = loss_function
type = type
N = N
  
surv_feature_importance.surv_explainer <- function(x,
                                                   loss_function = NULL,
                                                   ...,
                                                   type = c("raw", "ratio", "difference"),
                                                   B = 10,
                                                   variables = NULL,
                                                   variable_groups = NULL,
                                                   N = NULL,
                                                   label = NULL) {
  test_explainer(x, "feature_importance", has_data = TRUE, has_y = TRUE, has_survival = TRUE)
  
  model <- x$model
  data <- x$data
  predict_function <- x$predict_function
  predict_survival_function <- x$predict_survival_function
  if (is.null(label)) {
    label <- x$label
  }
  y <- x$y
  times <- x$times
  
  
  surv_feature_importance.default(model,
                                  data,
                                  y,
                                  times,
                                  predict_function = predict_function,
                                  predict_survival_function = predict_survival_function,
                                  loss_function = loss_function,
                                  label = label,
                                  type = type,
                                  N = N,
                                  B = B,
                                  variables = variables,
                                  variable_groups = variable_groups,
                                  ...
  )
}


surv_feature_importance.default <- function(x,
                                            data,
                                            y,
                                            times,
                                            predict_function = NULL,
                                            predict_survival_function = NULL,
                                            loss_function = DALEX::loss_root_mean_square,
                                            ...,
                                            label = class(x)[1],
                                            type = c("raw", "ratio", "difference"),
                                            B = 10,
                                            variables = NULL,
                                            N = NULL,
                                            variable_groups = NULL) {
  if (!is.null(variable_groups)) {
    if (!inherits(variable_groups, "list")) stop("variable_groups should be of class list")
    
    wrong_names <- !all(sapply(variable_groups, function(variable_set) {
      all(variable_set %in% colnames(data))
    }))
    
    if (!all(sapply(variable_groups, class) == "character")) stop("Elements of variable_groups argument should be of class character")
    if (wrong_names) stop("You have passed wrong variables names in variable_groups argument")
    if (is.null(names(variable_groups))) warning("You have passed an unnamed list. The names of variable groupings will be created from variables names.")
  }
  
  type <- match.arg(type)
  B <- max(1, round(B))
  
  # Adding names for variable_groups if not specified
  if (!is.null(variable_groups) && is.null(names(variable_groups))) {
    names(variable_groups) <- sapply(variable_groups, function(variable_set) {
      paste0(variable_set, collapse = "; ")
    })
  }
  
  # if `variable_groups` are not specified, then extract from `variables`
  if (is.null(variable_groups)) {
    # if `variables` are not specified, then extract from data
    if (is.null(variables)) {
      variables <- colnames(data)
      names(variables) <- colnames(data)
    }
  } else {
    variables <- variable_groups
  }
  
  # start: actual calculations
  # one permutation round: subsample data, permute variables and compute losses
  if (requireNamespace("progressr", quietly = TRUE)) {
    prog <- progressr::progressor(steps = (length(variables) + 2) * B)
  } else {
    prog <- function() NULL
  }
  sampled_rows <- 1:nrow(data)
  loss_after_permutation <- function() {
    if (!is.null(N)) {
      if (N < nrow(data)) {
        # sample N points
        sampled_rows <- sample(1:nrow(data), N)
      }
    }

    sampled_data <- data[sampled_rows, , drop = FALSE]
    observed <- y[sampled_rows]
    
    surv_true <- predict_survival_function(x, sampled_data, times)
    
    risk_true <- predict_function(x, sampled_data)
    # loss on the full model or when outcomes are permuted
    loss_full <- loss_function(observed, risk_true, surv_true, times)
    prog()
    chosen <- sample(1:nrow(observed))
    loss_baseline <- loss_function(observed[chosen, ], risk_true, surv_true, times)
    prog()
    # loss upon dropping a single variable (or a single group)
    loss_variables <- sapply(variables, function(variables_set) {
      ndf <- sampled_data
      ndf[, variables_set] <- ndf[sample(1:nrow(ndf)), variables_set]
      predicted <- predict_function(x, ndf)
      predicted_surv <- predict_survival_function(x, ndf, times)
      prog()
      loss_function(observed, predicted, predicted_surv, times)
    })
    
    times_temp_df <- data.frame("times" = times)
    colnames(times_temp_df) <- "_times_"
    cbind(times_temp_df, "_full_model_" = loss_full, loss_variables, "_baseline_" = loss_baseline)
  }
  # permute B times, collect results into single matrix
  raw <- do.call("rbind", replicate(B, loss_after_permutation(), simplify = FALSE))
  raw$`_permutation_` <- rep(1:B, each = length(times))
  tmp <- aggregate(. ~ `_times_`, raw, mean)
  tmp$`_permutation_` <- rep(0, times = nrow(tmp))
  
  res <- rbind(tmp, raw)
  res$label <- rep(label, times = nrow(res))
  
  if (type %in% c("ratio", "difference")) {
    res_full <- res[res$`_permutation_` == 0, c("_times_", "_full_model_")]
    colnames(res_full) <- c("_times_", "_reference_")
    res <- merge(res, res_full, by = "_times_")
    res <- res[order(res$`_permutation_`, res$`_times_`), ]
  }
  if (type == "ratio") {
    res[, 2:(ncol(res) - 3)] <- res[, 2:(ncol(res) - 3)] / res[["_reference_"]]
    res$`_reference_` <- NULL
  }
  if (type == "difference") {
    res[, 2:(ncol(res) - 3)] <- res[, 2:(ncol(res) - 3)] - res[["_reference_"]]
    res$`_reference_` <- NULL
  }
  
  # record details of permutations
  attr(res, "B") <- B
  
  ret <- list(result = res, eval_times = unique(res$times))
  class(ret) <- c("surv_feature_importance", "list")
  
  if (!is.null(attr(loss_function, "loss_name"))) {
    attr(ret, "loss_name") <- attr(loss_function, "loss_name")
  }
  
  attr(ret, "type") <- type
  
  ret
}
