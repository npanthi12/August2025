## Example for deep learning proportional hazards survival model
install.packages("dnn")
library(dnn)
set.seed(101)
### define model layers
model = dNNmodel(units = c(4, 3, 1), activation = c("elu", "sigmoid", "sigmoid"), 
                 input_shape = 3)
x = matrix(runif(15), nrow = 5, ncol = 3)
time = exp(x[, 1])
status = c(1, 0, 1, 1, 1)
fit = deepSurv(Surv(time, status) ~ x, model = model)
fit

pycox <- reticulate::import("pycox")
torchtuples <- reticulate::import("torchtuples")
tor <- reticulate::import("torch")
reticulate::py_install("pycox")
reticulate::py_install("torchtuples")
reticulate::py_install("torch")

tor <- reticulate::import("torch")
pip install --default-timeout=100 pycox

deepsurv(data = simsurvdata(50))

# common parameters
deepsurv(data = simsurvdata(50), frac = 0.3, activation = "relu",
         num_nodes = c(4L, 8L, 4L, 2L), dropout = 0.1, early_stopping = TRUE, epochs = 100L,
         batch_size = 32L)
library(survival)
library(reticulate)
library(survivalmodels)
reticulate::py_install("torch")
remove.packages("torch")
install.packages("torch")
install_torch()
survivalmodels::install_torch(method = "auto", conda = "auto", pip = TRUE)
library(torch)
data <- lung
data <- na.omit(data)
data$sex <- as.numeric(data$sex)
library(dplyr)
data$status <- as.numeric(data$status==2)
x <- data%>%select(-time, -status)
y_time <- data$time
y_event <- data$status
X <- scale(as.matrix(x))
df_surv <- data.frame(X, time=y_time, status=y_event)
library(vip)
library(survex)
model_parts(
  explainer,
  loss_function = survex::loss_brier_score,
  ...,
  type = "difference",
  output_type = "survival",
  N = 1000
)
rsf_ranger_exp <- explain(rsf_ranger,
                          data = veteran[, -c(3, 4)],
                          y = Surv(veteran$time, veteran$status)
)
# Assuming you have a trained DeepSurv model called `deepsurv_model`
vip::list_metrics()
vip(deepsurv_model, method = "permute", target = "cindex", train=data, metric="")
deepsurv_model <- deepsurv(formula=Surv(time, status)~., data=data, epochs=100, batch_size = 32,
         early_stopping = TRUE)
custom_pred <- function(model, newdata){
  predict(model, newdata = newdata, type = "risk",)
}
custom_residual_func <- function(model, newdata, y){
  risk_scores <- predict(model, newdata, type = "risk")
  residuals <- mean(-risk_scores)
  return(residuals)
}
deepsurv_exp<- explain(deepsurv_model,  data = data[, -c(2, 3)],
                       y = Surv(data$time, data$status), 
                                predict_function=custom_pred,
                       residual_function = custom_residual_func)


model_parts(
  deepsurv_exp,
  loss_function = survex::loss_brier_score,
  type = "difference",
  output_type = "survival",
  N = 1000
)
predict(deepsurv_model, newdata=data)
explainer <- explain(model=deepsurv_model, data=data, y=as.numeric(data$status))
risk_scores <- predict(deepsurv_model, newdata=df_surv)
head(risk_scores)
deepsurv_model$model$net
library(survcomp)
c_index <- concordance.index(-risk_scores, surv.time=y_time, surv.event=y_event)
library(ggplot2)
deepsurv_model$model$net
first_layer_weights <- deepsurv_model$model$net[[1]]$weight$detach()$numpy()
# Define the architecture
# architecture <- list(
#   layers = list(
#     list(units = 32, activation = "relu"),
#     list(units = 32, activation = "relu")
#   ),
#   output = list(units = 1, activation = "linear")
# )

model <- deepsurv(
  formula = Surv(time, status) ~ age + sex + ph.ecog,
  data = data,
  #architecture = architecture,
  epochs = 100,
  batch_size = 32,
  verbose = 1
)


custom_pred <- function(model, newdata){
  predict(model, newdata = newdata)
}
library(DALEX)
explainer <- DALEX::explain(model=model, data=data,
                            y=as.numeric(data$time))
explainer <- DALEX::explain(model=model,
        data=data,
        y=as.numeric(data$status),
        predict_function=custom_pred)
custom_residual_func <- function(model, newdata, y){
  risk_scores <- predict(model, newdata)
  residuals <- mean(-risk_scores)
  return(residuals)
}
custom_residual_func(model, data, y=Surv(data$time, data$status))
deepsurv_exp <- survex::explain(model,
                                data = data,
                                y = Surv(data$time, data$status),
                                residual_function = custom_residual_func,
                                predict_function=custom_pred
)
shap(deepsurv_exp)
importance(deepsurv_exp)
survex::model_parts(
  deepsurv_exp)
vi <- variable_importance(explainer, loss_function = loss_yardstick("concordance_survival"))
vi[order(vi$dropout_loss, decreasing=TRUE),]
predict(model, newdata=data)
.pycox_prep <- function(formula, data, time_variable, status_variable, x, y, reverse,
                        activation, frac, ...) {
  
  if (!requireNamespace("reticulate", quietly = TRUE)) {
    stop("Package 'reticulate' required but not installed.") # nocov
  }
  
  pycox <- reticulate::import("pycox")
  torch <- reticulate::import("torch")
  torchtuples <- reticulate::import("torchtuples")
  
  data <- clean_train_data(formula, data, time_variable, status_variable, x, y,
                           reverse)
  data$activation <- get_pycox_activation(activation, construct = FALSE)
  
  c(data, pycox_prepare_train_data(data$x, data$y, frac, ...))
}
clean_train_data <- function(formula = NULL, data = NULL, time_variable = NULL,
                             status_variable = NULL, x = NULL, y = NULL, reverse = FALSE) {
  
  if (!is.null(x) | !is.null(y)) {
    if (is.null(x) | is.null(y)) {
      stop("Both 'x' and 'y' must be provided if either non-NULL.")
    } else {
      if (is.null(ncol(x))) {
        stop("'x' should be a data.frame like object.")
      }
    }
    stopifnot(inherits(y, "Surv"))
  } else if (!is.null(formula)) {
    f <- stats::as.formula(formula, env = data)
    y <- eval(f[[2]], envir = data)
    stopifnot(inherits(y, "Surv"))
    
    if (deparse(f[[3]]) == ".") {
      if (is.null(data)) {
        stop("'.' in formula and no 'data' argument")
      } else {
        x <- data[, setdiff(colnames(data), c(deparse(f[[2]][[2]]), deparse(f[[2]][[3]]))),
                  drop = FALSE
        ]
      }
    } else {
      x <- data[, strsplit(deparse(f[[3]]), " + ", TRUE)[[1]], drop = FALSE]
    }
  } else if (!is.null(time_variable) | !is.null(status_variable)) {
    if (is.null(time_variable) | is.null(status_variable) | is.null(data)) {
      stop("'time_variable', 'status_variable', and 'data' must be provided if either 'time_variable' or 'status_variable' non-NULL.") # nolint
    } else {
      stopifnot(time_variable %in% colnames(data))
      stopifnot(status_variable %in% colnames(data))
      x <- data[, setdiff(colnames(data), c(time_variable, status_variable)), drop = FALSE]
      y <- data.frame(time = data[, time_variable], status = data[, status_variable])
    }
  }
  
  y <- as.matrix(y)
  x <- stats::model.matrix(~., x)[, -1, drop = FALSE]
  
  if (reverse) {
    y[, 2] <- 1 - y[, 2]
  }
  
  return(list(x = x, y = y))
}

clean_test_data <- function(object, newdata) {
  
  if (missing(newdata)) {
    newdata <- object$x[, !(colnames(object$x) %in% "(Intercept)")]
    colnames(newdata) <- gsub("data$x", "", colnames(newdata), fixed = TRUE)
    return(newdata)
  }
  
  newdata <- stats::model.matrix(~., newdata)[, -1, drop = FALSE]
  old_features <- setdiff(colnames(object$x), "(Intercept)")
  # fix for passing formula as data directly
  old_features <- gsub("data$x", "", old_features, fixed = TRUE)
  ord <- match(old_features, colnames(newdata), nomatch = NULL)
  newdata <- newdata[, ord[!is.na(ord)], drop = FALSE]
  if (!all(suppressWarnings(colnames(newdata) == old_features))) {
    stop(sprintf(
      "Names in newdata should be identical to {%s}.",
      paste0(colnames(object$x), collapse = ", ")
    ))
  }
  
  newdata
}
deepsurv(data = simsurvdata(50), frac = 0.3, activation = "relu",
         num_nodes = c(4L, 8L, 4L, 2L), dropout = 0.1, early_stopping = TRUE, epochs = 100L,
         batch_size = 32L)

data = simsurvdata(50)
time_variable = "time"
status_variable = "status"
x = NULL
y = NULL
reverse = FALSE
activation = "relu"
frac = 0.3
num_nodes = c(4L, 8L, 4L, 2L)
batch_norm = TRUE
dropout = NULL
device = NULL
early_stopping = FALSE
best_weights = FALSE
min_delta = 0
patience = 10L
batch_size = 256L
epochs = 1L
verbose = FALSE
num_workers = 0L
shuffle = TRUE
deepsurv <- function(formula = NULL, data = NULL, reverse = FALSE,
                     time_variable = "time", status_variable = "status",
                     x = NULL, y = NULL, frac = 0,
                     activation = "relu", num_nodes = c(32L, 32L), batch_norm = TRUE,
                     dropout = NULL, device = NULL, early_stopping = FALSE,
                     best_weights = FALSE,  min_delta = 0, patience = 10L, batch_size = 256L,
                     epochs = 1L, verbose = FALSE, num_workers = 0L, shuffle = TRUE, ...) {
  
  if (!requireNamespace("reticulate", quietly = TRUE)) {
    stop("Package 'reticulate' required but not installed.") # nocov
  }
  
  call <- match.call()
  
  data <- .pycox_prep(formula, data, time_variable, status_variable, x, y, reverse, activation,
                      frac)
  
  pycox <- reticulate::import("pycox")
  torchtuples <- reticulate::import("torchtuples")
  
  net <- torchtuples$practical$MLPVanilla(
    in_features = data$x_train$shape[1],
    num_nodes = reticulate::r_to_py(as.integer(num_nodes)),
    out_features = 1L,
    activation = data$activation,
    output_bias = FALSE,
    batch_norm = batch_norm,
    dropout = dropout
  )
  
  # Get optimizer and set-up model
  model <- pycox$models$CoxPH(
    net = net,
    optimizer = get_pycox_optim(net = net, ...),
    device = device
  )
  
  model$fit(
    input = data$x_train,
    target = data$y_train,
    callbacks = get_pycox_callbacks(early_stopping, best_weights, min_delta, patience),
    val_data = data$val,
    batch_size = as.integer(batch_size),
    epochs = as.integer(epochs),
    verbose = verbose,
    num_workers = as.integer(num_workers),
    shuffle = shuffle
  )
  
  structure(list(y = data$y, x = data$x,
                 xnames = colnames(data$x),
                 model = model,
                 call = call),
            name = "DeepSurv Neural Network",
            class = c("deepsurv", "pycox", "survivalmodel")
  )
}

