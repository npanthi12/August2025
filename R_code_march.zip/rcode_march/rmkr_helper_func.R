library(glmnet)
basesurv <- function (response, lp, times.eval = NULL, centered = FALSE)
{
  if (is.null(times.eval)) times.eval <- sort(unique(response[,1]))
  
  t.unique <- sort(unique(response[,1][response[,2] == 1]))
  alpha    <- length(t.unique)
  
  for (i in 1:length(t.unique)) {
    alpha[i] <- sum(response[,1][response[,2] == 1] == t.unique[i])/sum(exp(lp[response[,1] >=  t.unique[i]]))
  }
  
  obj   <- approx(t.unique, cumsum(alpha), yleft=0, xout = times.eval, rule=2)
  
  if (centered) obj$y <- obj$y * exp(mean(lp))
  obj$z <- exp(-obj$y)
  
  names(obj) <- c("times","cumBaseHaz","BaseSurv")
  return(obj)
}
fit.glmnet <- function (response, x, cplx, ...) 
{
  #require(glmnet)
  res <- NULL
  tryerr <- try(res <- glmnet(y = response, x = data.matrix(x), lambda = cplx,  ...), silent=TRUE)
  
  if(!is(tryerr, 'try-error') && is(res,"coxnet")) {
    res$linear.predictor  <- as.numeric(predict(res, newx=data.matrix(x), type="link"))
    res$response          <- response
  }
  class(res) <- class(res)[1]
  res
}
complexity.glmnet <- function (response, x, full.data, ...) 
{
  #require(glmnet)
  lambda <- NULL
  tryerr <- try(cv <- cv.glmnet(y = response, x = data.matrix(x),  ...), silent=TRUE)
  
  if(!is(tryerr, 'try-error')){
    lambda <-cv$lambda.min
  }    
  lambda
}
predictProb.coxnet <- predictProb.glmnet <- function (object, response, x, times, complexity) 
{
  #require(glmnet)    
  lp       <- as.numeric(predict(object, newx=data.matrix(x),s=complexity, type="link"))
  basesurv1 <- basesurv(response,lp, sort(unique(times)))
  p        <- exp(exp(lp) %*% -t(basesurv1$cumBaseHaz))
  
  if (NROW(p) != NROW(x) || NCOL(p) != length(times)) 
    stop("Prediction failed")
  p
}

Cindex <- function (object, predicted, t_star = -1) 
{
  if (inherits(object, "coxph")) {
    obj <- object
    test_data <- predicted
    t_star0 <- t_star
    distime <- sort(unique(as.vector(obj$y[obj$y[, 2] == 
                                             1])))
    if (t_star0 <= 0) {
      t_star0 <- median(distime)
    }
    vec_coxph <- predictSurvProb(obj, test_data, t_star0)
    object_coxph <- Surv(test_data$time, test_data$status)
    object <- object_coxph
    predicted <- vec_coxph
  }
  if (inherits(object, c("rfsrc"))) {
    obj <- object
    test_data <- predicted
    t_star0 <- t_star
    distime <- obj$time.interest
    if (t_star0 <= 0) {
      t_star0 <- median(distime)
    }
    med_index <- order(abs(distime - t_star0))[1]
    mat_rsf <- predict(obj, test_data)$survival
    vec_rsf <- mat_rsf[, med_index]
    object_rsf <- Surv(test_data$time, test_data$status)
    object <- object_rsf
    predicted <- vec_rsf
  }
  if (inherits(object, c("survreg"))) {
    obj <- object
    test_data <- predicted
    t_star0 <- t_star
    distime <- sort(unique(as.vector(obj$y[obj$y[, 2] == 
                                             1])))
    if (t_star0 <= 0) {
      t_star0 <- median(distime)
    }
    predicted <- predictSurvProb2survreg(obj, test_data, 
                                         t_star0)
    object <- Surv(test_data$time, test_data$status)
  }
  time <- object[, 1]
  status <- object[, 2]
  if (length(time) != length(status)) {
    stop("The lengths of time and status are not equal")
  }
  if (length(time) != length(predicted)) {
    stop("The lengths of time and predicted are not equal")
  }
  if (any(is.na(time) | is.na(status) | is.na(predicted))) {
    stop("The input vector cannot have NA")
  }
  permissible <- 0
  concord <- 0
  par_concord <- 0
  n <- length(time)
  for (i in 1:(n - 1)) {
    for (j in (i + 1):n) {
      if ((time[i] < time[j] & status[i] == 0) | (time[j] < 
                                                  time[i] & status[j] == 0)) {
        next
      }
      if (time[i] == time[j] & status[i] == 0 & status[j] == 
          0) {
        next
      }
      permissible <- permissible + 1
      if (time[i] != time[j]) {
        if ((time[i] < time[j] & predicted[i] < predicted[j]) | 
            (time[j] < time[i] & predicted[j] < predicted[i])) {
          concord <- concord + 1
        }
        else if (predicted[i] == predicted[j]) {
          par_concord <- par_concord + 0.5
        }
      }
      if (time[i] == time[j] & status[i] == 1 & status[j] == 
          1) {
        if (predicted[i] == predicted[j]) {
          concord <- concord + 1
        }
        else {
          par_concord <- par_concord + 0.5
        }
      }
      if (time[i] == time[j] & ((status[i] == 1 & status[j] == 
                                 0) | (status[i] == 0 & status[j] == 1))) {
        if ((status[i] == 1 & predicted[i] < predicted[j]) | 
            (status[j] == 1 & predicted[j] < predicted[i])) {
          concord <- concord + 1
        }
        else {
          par_concord <- par_concord + 0.5
        }
      }
    }
  }
  C_index <- (concord + par_concord)/permissible
  names(C_index) <- "C index"
  return(round(C_index, 6))
}