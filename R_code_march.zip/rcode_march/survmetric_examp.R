#1. data preparation
library(survival)        # to fit a Cox model
library(randomForestSRC) # to fit an RSF model
library(SurvMetrics) # to get all the metrics
library(pec)         # to make predictions based on Cox model
set.seed(1)
mydata <- kidney[, -1]
train_index <- sample(1:nrow(mydata), 0.7 * nrow(mydata))
train_data <- mydata[train_index, ]
test_data <- mydata[-train_index, ]

#2. fit the RSF model and Cox model to predict the testing set
#2.1 RSF model
fit_rsf <- rfsrc(Surv(time,status)~., data = train_data)  #fit the RSF model
distime <- fit_rsf$time.interest  #get the survival time of events
med_index <- median(1:length(distime))  #the index of median survival time of events
mat_rsf <- predict(fit_rsf, test_data)$survival  #get the survival probability matrix
vec_rsf <- mat_rsf[ ,med_index]  #median survival probability of all samples
vec_rsf1 <- mat_rsf[ ,med_index] 
#2.2 Cox model
fit_cox <- coxph(Surv(time,status)~., data = train_data, x = TRUE)  #fit the Cox model
mat_cox <- predictSurvProb(fit_cox, test_data, distime)  #get the survival probability matrix
vec_cox <- mat_cox[ ,med_index]
mat_cox
#3. get all the metrics by SurvMetrics
#3.1 CI BS IBS IAE ISE based on RSF model: standard model input methods
Cindex_rsf <- Cindex(fit_rsf, test_data)
BS_rsf <- Brier(fit_rsf, test_data, distime[med_index])
IBS_rsf <- IBS(fit_rsf, test_data)
IAE_rsf <- IAEISE(fit_rsf, test_data)[1]
ISE_rsf <- IAEISE(fit_rsf, test_data)[2]

#CI BS IBS IAE ISE based on Cox model: standard model input methods
Cindex_cox <- Cindex(fit_cox, test_data)
Cindex_cox 
BS_cox <- Brier(fit_cox, test_data, distime[med_index])
IBS_cox <- IBS(fit_cox, test_data)
IAE_cox <- IAEISE(fit_cox, test_data)[1]
ISE_cox <- IAEISE(fit_cox, test_data)[2]

#3.2 CI BS IBS IAE ISE based on RSF model: Non-standard model input methods
times <- test_data$time
status <- test_data$status
Cindex_rsf <- Cindex(Surv(times, status), vec_rsf)
BS_rsf <- Brier(Surv(times, status), vec_rsf, distime[med_index])
IBS_rsf <- IBS(Surv(times, status), mat_rsf, distime)  # distime can be replaced by range(distime)
IAE_rsf <- IAEISE(Surv(times, status), mat_rsf, distime)[1]
ISE_rsf <- IAEISE(Surv(times, status), mat_rsf, distime)[2]

#CI BS IBS IAE ISE based on Cox model: Non-standard model input methods
#0.751185
concordance(Surv(train_data$time, train_data$status) ~predict(fit_cox, type="lp", train_data))
(126+7/2)/(126+725+7)
126/(126+725)

379/(504)
1-summary(fit_cox)$concordance[[1]]
pec::cindex(list("coxm"=fit_cox),
            formula=Surv(time, status) ~ .,
            data=na.omit(test_data))[[1]]
vec_cox <- mat_cox[ ,4]
Cindex_cox <- Cindex(Surv(times, status), vec_cox)
Cindex_cox
dis_time
val <- NA
for(i in 1:length(distime)){
val[i]=pec::cindex(list("coxm"=fit_cox),
            formula=Surv(time, status) ~ .,
            data=na.omit(test_data), eval.times = dis_time[i], splitMethod="BootCv", B=5)[[1]][[1]]
}
val
BS_cox <- Brier(Surv(times, status), vec_cox, distime[med_index])
IBS_cox <- IBS(Surv(times, status), mat_cox, distime)
IAE_cox <- IAEISE(Surv(times, status), mat_cox, distime)[1]
ISE_cox <- IAEISE(Surv(times, status), mat_cox, distime)[2]

library(survival)
time <- c(1, 1, 2, 2, 2, 2, 2, 2)
status <- c(0, 1, 1, 0, 1, 1, 0, 1)
predicted <- c(2, 3, 3, 3, 4, 2, 4, 3)
Cindex(Surv(time, status), predicted)
concordance(Surv(time, status)~ predicted)
pec::cindex(predicted,
            formula=Surv(time, status)~1)
