runfrst <- function(dat, ntre, resp, covs, sed, mincrit, thres){
  form <- f.build(resp, covs)
  set.seed(sed)
  forest.output <- party::cforest(form,
                                  data = dat, controls= cforest_unbiased(ntree=ntre))
  freq<- selFreq(forest.output , whichxnames = NULL)
  forest.importance <- varImp(forest.output, conditional=T, mincriterion = mincrit, threshold = thres)
  return(list(freq, forest.importance))
}


