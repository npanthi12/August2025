t1 <- Sys.time()
# Data Processing
library(randomForestSRC)
library(survival)
library(ggplot2)
t2 <- Sys.time()
tm <- (t2-t1)/60
print(paste("Time difference of ", tm[[1]], " minutes"))

dat <- veteran  # Load the dataset
head(dat) 
dat$status <- as.numeric(dat$status)  # Convert status (1 = alive, 0 = dead)
dat$trt <- as.factor(dat$trt)              # Treatment as factor
dat$celltype <- as.factor(dat$celltype)  

#Part I: Variable Importance
# Here we select the most important variables for predicting survival outcome.
# We use variable importance to rank variables in the order of permutation importance 
# from high to low and also select the top variables by 3 methods (minimal depth, variable hunting,
# variable hunting-imp)
set.seed(123)  # For reproducibility
rsf_model <- rfsrc(Surv(time, status) ~ ., data = dat, 
                   ntree = 500,  # Number of trees
                   importance = TRUE,  # Compute variable importance
                   nsplit = 10)
# Print model summary
print(rsf_model)

#5. Assess Variable Importance
#We extract and visualize variable importance.
# Extract variable importance
vi <- rsf_model$importance
vi_df <- data.frame(Variable = names(vi), Importance = vi)

# Plot variable importance
ggplot(vi_df, aes(x = reorder(Variable, Importance), y = Importance)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  coord_flip() +
  theme_minimal() +
  labs(title = "Variable Importance in Random Survival Forest",
       x = "Variable", y = "Importance")
#Vimp with confidence intervals
Compute Confidence Intervals Using Multiple RSF Runs
# Define number of repetitions
n_repeats <- 100
vimp_list <- list()

# Run multiple RSF models and store variable importance scores
for (i in 1:n_repeats) {
  temp_model <- rfsrc(Surv(time, status) ~ ., data = dat)
  vimp_list[[i]] <- as.data.frame(vimp(temp_model)$importance)[, 1]
}

# Convert list to a matrix
vimp_matrix <- do.call(cbind, vimp_list)

# Compute mean and confidence intervals
vimp_mean <- rowMeans(vimp_matrix)
vimp_lower <- apply(vimp_matrix, 1, quantile, probs = 0.025)  # 2.5% lower bound
vimp_upper <- apply(vimp_matrix, 1, quantile, probs = 0.975)  # 97.5% upper bound

# Store results in a data frame
vimp_bootstrap_df <- data.frame(
  Variable = rownames(data.frame(vimp_result$importance)),
  Importance = vimp_mean,
  Lower_CI = vimp_lower,
  Upper_CI = vimp_upper
)

# Plot with error bars
ggplot(vimp_bootstrap_df, aes(x = reorder(Variable, Importance), y = Importance)) +
  geom_point(size = 3, color = "blue") +
  geom_errorbar(aes(ymin = Lower_CI, ymax = Upper_CI), width = 0.2, color = "red") +
  coord_flip() +
  theme_minimal() +
  labs(title = "Bootstrapped Variable Importance with Confidence Intervals",
       x = "Feature", y = "Importance Score")

#Part II: Variable Interpretation
#Here we interpret the effect of each variable on survival probability marginally
# using partial dependent plots
important_vars <- c("karno", "age", "diagtime")

# Create PDP plots for each variable
par(mfrow = c(1, length(important_vars)))  # Arrange plots in a row
for (var in important_vars) {
  plot.variable(rsf_model, xvar = var, partial = TRUE, 
                main = paste("Partial Dependence of", var),
                ylab = "Predicted Survival Probability")
}
#PDP with CI
plot.variable(rsf_model, xvar = "karno", partial = TRUE, show.plots = TRUE, 
              smooth.lines = TRUE, alpha = 0.2,  
              main = "PDP for Karnofsky Score with Confidence Intervals",
              ylab = "Predicted Survival Probability")
# Interpretation:
# •	The shaded region represents the confidence interval (CI).
# •	If CIs overlap, the relationship is less certain.

# PDP to show interaction
# 4. 3D Partial Dependence Plot for Two Variables
# To see interaction effects between two features, we plot a 3D PDP.
# 3D PDP for Karnofsky score and age
plot.variable(rsf_model, xvar = c("karno", "age"), partial = TRUE, 
              surface = TRUE, main = "3D PDP: Karnofsky Score & Age")
#Part III: Prediction
# Here we predict the survival probability for each new subject given baseline characteritics 
# or covariate information. We also predict the treatment effect on patient if the 
# patrient is given one of treatments and also best treatment for subjects and treatment
# switching times if alternative treatment is available.

#Part IV: Adhoc-SHAP analysis

# 1. Install and Load Required Libraries
# We need the shapviz package for SHAP-based interpretation.
library(shapviz)
#2. Compute SHAP Values for the RSF Model
# Compute SHAP values from the RSF model 
shap_values <- shapviz(rsf_model, method = "kernelshap") 
# Print SHAP values summary 
print(shap_values)
library(survex)
surexp <- survex::explain(rsf_model)
exp <- model_parts(surexp)
plot(exp)
# Interpretation:
# •	SHAP values quantify how much each feature contributes to an individual's survival prediction.
# •	Positive SHAP values increase survival probability, while negative values decrease it.
# ________________________________________
# 3. SHAP Summary Plot (Global Feature Importance)
# We visualize global feature importance with a summary plot.
# SHAP summary plot
plot(shap_values, kind = "bar", main = "SHAP Feature Importance")
# Interpretation:
#   •	Features with higher SHAP values have a greater impact on survival predictions.
# •	If Karnofsky score ranks highest, it means functional status strongly influences survival.
# 
# 4. SHAP Beeswarm Plot (Feature Effects Across Patients)
# The beeswarm plot shows how each feature influences survival for different individuals.
plot(shap_values, kind = "beeswarm", main = "SHAP Beeswarm Plot")
Interpretation:
  •	Each dot represents an individual patient.
# •	Color gradient (e.g., blue → red) shows the feature's magnitude (low → high).
# •	Higher SHAP values (right side) indicate that a feature increases survival probability.
# ________________________________________
# 5. SHAP Dependence Plot (Feature Interactions)
# To analyze feature interactions, we use SHAP dependence plots.
plot(shap_values, x = "karno", main = "SHAP Dependence Plot for Karnofsky Score")
# Interpretation:
# •	If higher Karnofsky scores consistently have positive SHAP values, it means better functional status improves survival.
# •	Vertical dispersion suggests interactions with other variables (e.g., age, diagnosis time).
# ________________________________________
# 6. SHAP Interaction Effects
#To check if features interact (e.g., age + Karnofsky score), we use an interaction plot.
plot(shap_values, x = "age", color = "karno", main = "SHAP Interaction: Age & Karnofsky Score")
# Interpretation:
# •	If color gradient (e.g., low Karnofsky scores in blue, high in red) aligns with SHAP values, it suggests a strong interaction between age and Karnofsky score.
# •	Older patients with high Karnofsky scores may have different survival effects than younger ones.
# ________________________________________
# Final Thoughts
# SHAP values provide local and global feature importance insights.
# Beeswarm and dependence plots help understand individual feature effects.
# SHAP interactions reveal complex relationships between features.

#Adhoc: Counterfactual analysis

geom_line() +
  theme_minimal() +
  labs(title = "Counterfactual Analysis: Karnofsky Score & Treatment",
       x = "Karnofsky Score", y = "Predicted Survival Probability",
       color = "Treatment Group")
# Interpretation:
# •	If increasing Karnofsky score leads to higher survival predictions, it suggests that improving functional status is beneficial.
# •	If switching treatment# 1. Install and Load Required Libraries
#We will use iml (interpretable machine learning) for counterfactual analysis.
library(iml)
# 2. Define a Counterfactual Explanation Function
# We create a function to generate counterfactual survival predictions for an 
# individual patient.
# Select a patient for counterfactual analysis
patient <- dat[1, ]  
# Define the predictor object for iml package
predictor <- Predictor$new(final_model, data = dat, y = dat$status)
# Generate counterfactual explanations
library(DALEX)
# Compute counterfactual changes
cf_explainer <- DALEX::explain(final_model, data = dat, y = dat$status)
# Generate counterfactuals by modifying one or more features
counterfactuals <- DALEX::counterfactual(cf_explainer, observation = patient, 
                                         variables = c("karno", "age", "trt"), 
                                         n = 5)  # Generate 5 counterfactual cases
# Print counterfactual cases
print(counterfactuals)
# Interpretation:
# •	The function modifies key patient features (e.g., increasing Karnofsky score, changing treatment) to see if the predicted survival probability improves.
# •	The output shows different scenarios where changes in patient characteristics could alter survival predictions.
# ________________________________________
# 3. Visualize Counterfactual Outcomes
# We can plot how survival predictions change under different scenarios.
# Convert counterfactual results to a dataframe
counterfactuals_df <- as.data.frame(counterfactuals)
# Plot counterfactual effects
library(ggplot2)
ggplot(counterfactuals_df, aes(x = karno, y = predict, color = as.factor(trt))) +
  geom_point(size = 4) + changes survival probabilities significantly, the patient might benefit from an alternative therapy.
# ________________________________________
# 4. Compare Original vs. Counterfactual Predictions
# To clearly compare, we print original vs. counterfactual predictions.
# Show original and modified patient predictions
comparison <- rbind(patient[, c("karno", "age", "trt")], counterfactuals_df)
rownames(comparison) <- c("Original", paste("CF", 1:5, sep = "_"))
# print(comparison)
# Interpretation:
# •	The table shows the original patient’s values vs. modified feature values and their effect on survival predictions.
# •	If small changes increase survival probability, it suggests modifiable risk factors (e.g., lifestyle, treatment changes).
# ________________________________________
# Final Thoughts
# Counterfactuals help understand what changes improve survival predictions.
# Visualizing different scenarios helps in treatment decision-making.
# Comparison tables show how modifiable factors affect survival outcomes.
# Individualized Treatment Recommendations Using Counterfactual Analysis
# Now that we've explored counterfactuals, we can take it a step further by using these 
# insights to make personalized treatment recommendations for patients. This approach helps 
# identify modifiable factors that could improve survival probabilities.
# ________________________________________
# 1. Generate Counterfactuals for a Patient
#We will generate alternative patient profiles by changing key variables like treatment type, Karnofsky score, and age.
# Load necessary packages
library(DALEX)
library(randomForestSRC)
# Select a specific patient (e.g., first patient in dataset)
patient <- dat[1, ]  
# Explain the RSF model
cf_explainer <- DALEX::explain(rsf_model, data = dat, y = dat$status)
# Generate counterfactual scenarios by modifying key variables
counterfactuals <- DALEX::counterfactual(cf_explainer, observation = patient, 
                                         variables = c("karno", "age", "trt"), 
                                         n = 5)  # Generate 5 counterfactuals
# Convert to dataframe for comparison
counterfactuals_df <- as.data.frame(counterfactuals)
# 2. Compare Survival Predictions for Different Treatments
# To determine which treatment is best for a specific patient, we analyze how 
# survival probabilities change.
# Print original patient and counterfactual scenarios
comparison <- rbind(patient[, c("karno", "age", "trt")], counterfactuals_df)
rownames(comparison) <- c("Original", paste("CF", 1:5, sep = "_"))
print(comparison)
# Interpretation:
#   •	The original patient’s survival prediction is compared to modified cases where treatment (trt) or functional score (karno) was changed.
# •	If a different treatment (trt) consistently improves survival, it might be a better alternative for this patient.
# ________________________________________
# 3. Visualize How Treatment Affects Survival
# We plot how treatment changes impact survival probabilities.
library(ggplot2)
ggplot(counterfactuals_df, aes(x = karno, y = predict, color = as.factor(trt))) +
  geom_point(size = 4) +
  geom_line() +
  theme_minimal() +
  labs(title = "Effect of Karnofsky Score and Treatment on Survival",
       x = "Karnofsky Score", y = "Predicted Survival Probability",
       color = "Treatment Group")
# Interpretation:
#   •	If one treatment (trt) consistently leads to higher survival probability, 
# it may be the preferred option.
# •	If increasing Karnofsky score improves survival regardless of treatment, 
# interventions to improve functional status should be prioritized.
# ________________________________________
# 4. Make Personalized Treatment Recommendations
# Using the counterfactual results, we can create a decision rule for selecting the best treatment.
# Find the best treatment option based on highest survival probability
best_treatment <- counterfactuals_df[which.max(counterfactuals_df$predict), "trt"]
# Recommend treatment
cat("Recommended Treatment for this patient:", best_treatment, "\n")
# Interpretation:
#   •	This finds the treatment associated with the highest survival prediction and recommends it for the patient.
# •	If the original treatment is not optimal, a change in therapy may be beneficial.
# ________________________________________
# Final Thoughts
# Personalized medicine: Using counterfactuals, we can make patient-specific treatment recommendations.
# Visualization helps: Seeing how treatments affect survival probabilities provides actionable insights.
# Modifiable factors: If functional status or diagnostic time significantly affects survival, lifestyle interventions and early screenings may be key.
# Automating Individualized Treatment Recommendations for Multiple Patients
# Now, let's extend our counterfactual analysis to automate personalized treatment recommendations for an entire patient dataset. This will allow us to systematically identify the best treatment options for multiple patients based on survival predictions.
# ________________________________________
# 1. Define a Function for Automated Treatment Recommendations
# We create a function that:
# 1.	Generates counterfactuals for each patient.
# 2.	Compares survival probabilities across different treatments.
# 3.	Recommends the treatment that maximizes survival.
library(DALEX)
library(randomForestSRC)
library(dplyr)
# Define function for treatment recommendation
recommend_treatment <- function(model, patient_data, num_counterfactuals = 5) {
  # Explain the RSF model
  cf_explainer <- DALEX::explain(model, data = dat, y = dat$status)
  # Initialize results list
  recommendations <- data.frame(ID = integer(), Best_Treatment = integer(), stringsAsFactors = FALSE)
  # Loop through each patient
  for (i in 1:nrow(patient_data)) {
    patient <- patient_data[i, ]
    # Generate counterfactuals by modifying treatment and Karnofsky score
    counterfactuals <- DALEX::counterfactual(cf_explainer, observation = patient, 
                                             variables = c("karno", "age", "trt"), 
                                             n = num_counterfactuals)
    
    # Convert to dataframe
    counterfactuals_df <- as.data.frame(counterfactuals)
    # Select the treatment associated with the highest predicted survival
    best_treatment <- counterfactuals_df[which.max(counterfactuals_df$predict), "trt"]
    # Store the recommendation
    recommendations <- rbind(recommendations, data.frame(ID = i, Best_Treatment = best_treatment))
  }
  return(recommendations)
}

# Apply the function to the entire dataset
treatment_recommendations <- recommend_treatment(final_model, dat)
# Print recommendations
print(treatment_recommendations)
# 2. Interpretation of Results
# This function: Processes each patient individually
# Generates counterfactuals for different treatments
# Identifies the treatment with the highest survival probability
# Stores and returns treatment recommendations
# ________________________________________
# 3. Visualizing Treatment Recommendations
# We can visualize how recommended treatments vary across patients.
ggplot(treatment_recommendations, aes(x = ID, y = Best_Treatment, fill = as.factor(Best_Treatment))) +
  geom_bar(stat = "identity") +
  theme_minimal() +
  labs(title = "Recommended Treatment for Each Patient",
       x = "Patient ID", y = "Recommended Treatment",
       fill = "Treatment Group")
# Interpretation:
# •	If one treatment is consistently recommended, it may be the most effective for the population.
# •	If recommendations vary across patients, it highlights the need for individualized treatment plans.
#________________________________________
# 4. Applying Recommendations in Clinical Settings
# Now that we have an automated recommendation system, doctors could:
# 1.	Use this tool to support clinical decisions.
# 2.	Adjust treatment plans based on modifiable patient factors.
# 3.	Identify patients who may benefit most from specific interventions.
# 
# Final Thoughts
# Automating counterfactuals enables large-scale personalized treatment recommendations.
# Doctors can use these insights to make data-driven clinical decisions.
# Further refinement (adding additional patient factors) could enhance the model’s accuracy.
# Incorporating Confidence Intervals into Treatment Recommendations
# To ensure that our treatment recommendations are reliable, we will calculate confidence 
# intervals (CIs) for survival predictions. This helps quantify uncertainty in our recommendations.
________________________________________
# 1. Modify Function to Include Confidence Intervals
# We will: Generate multiple counterfactuals per patient
# Compute mean and standard deviation of survival predictions
# Calculate 95% confidence intervals for each treatment option
library(DALEX)
library(randomForestSRC)
library(dplyr)

# Function to recommend treatment with confidence intervals
recommend_treatment_with_CI <- function(model, patient_data, num_counterfactuals = 10) {
  # Explain the RSF model
  cf_explainer <- DALEX::explain(model, data = dat, y = dat$status)
  
  # Initialize results
  recommendations <- data.frame(ID = integer(), Best_Treatment = integer(), 
                                Mean_Survival = numeric(), 
                                Lower_CI = numeric(), Upper_CI = numeric(), 
                                stringsAsFactors = FALSE)
  
  # Loop through each patient
  for (i in 1:nrow(patient_data)) {
    patient <- patient_data[i, ]
    
    # Generate multiple counterfactuals for treatment and Karnofsky score
    counterfactuals <- DALEX::counterfactual(cf_explainer, observation = patient, 
                                             variables = c("karno", "age", "trt"), 
                                             n = num_counterfactuals)
    
    # Convert to dataframe
    counterfactuals_df <- as.data.frame(counterfactuals)
    
    # Compute mean and confidence interval for each treatment
    treatment_stats <- counterfactuals_df %>%
      group_by(trt) %>%
      summarise(Mean_Survival = mean(predict),
                SD = sd(predict),
                Lower_CI = Mean_Survival - 1.96 * (SD / sqrt(n())),
                Upper_CI = Mean_Survival + 1.96 * (SD / sqrt(n())))
    
    # Select best treatment based on highest mean survival probability
    best_treatment <- treatment_stats %>% filter(Mean_Survival == max(Mean_Survival))
    
    # Store results
    recommendations <- rbind(recommendations, data.frame(ID = i, 
                                                         Best_Treatment = best_treatment$trt, 
                                                         Mean_Survival = best_treatment$Mean_Survival, 
                                                         Lower_CI = best_treatment$Lower_CI, 
                                                         Upper_CI = best_treatment$Upper_CI))
  }
  
  return(recommendations)
}

# Apply the function to the dataset
treatment_recommendations_CI <- recommend_treatment_with_CI(final_model, dat)

# Print recommendations with confidence intervals
# print(treatment_recommendations_CI)
# 2. Interpretation of Confidence Intervals
# Mean Survival → The expected survival probability for each recommended treatment.
# Lower CI / Upper CI → The range within which the survival probability is expected to fall with 95% confidence.
# If CIs overlap for two treatments, the choice may be less certain, suggesting the need for additional factors (e.g., biomarkers, patient preferences).
# ________________________________________
# 3. Visualizing Confidence Intervals for Recommendations
# Now, let's plot the survival probabilities with confidence intervals.
library(ggplot2)

ggplot(treatment_recommendations_CI, aes(x = as.factor(Best_Treatment), y = Mean_Survival)) +
  geom_point(size = 4) +
  geom_errorbar(aes(ymin = Lower_CI, ymax = Upper_CI), width = 0.2) +
  theme_minimal() +
  labs(title = "Treatment Recommendations with Confidence Intervals",
       x = "Recommended Treatment", y = "Predicted Survival Probability")
# Interpretation:
#   •	Treatments with narrower CIs have more stable predictions.
# •	If a treatment has a wide CI, the model is less certain about its effect.
# •	Treatments with overlapping CIs may not have a statistically significant difference.
# ________________________________________
# Time-Dependent Survival Analysis for Personalized Treatment Recommendations
# Now, let’s extend our approach by incorporating time-dependent survival analysis 
# to see how different treatments impact survival over time. This will provide a 
# longitudinal view of how treatment effects evolve.
________________________________________
#1. Use Kaplan-Meier Curves for Each Treatment
# Load necessary libraries
library(survival)
library(survminer)
library(randomForestSRC)

# Fit a Kaplan-Meier survival model for each treatment group
km_fit <- survfit(Surv(time, status) ~ trt, data = dat)

# Plot survival curves
ggsurvplot(km_fit, data = dat,
           conf.int = TRUE, # Show confidence intervals
           risk.table = TRUE, # Show risk table
           pval = TRUE, # Display log-rank test p-value
           ggtheme = theme_minimal(),
           title = "Kaplan-Meier Survival Curves by Treatment Group")
# Interpretation:
#   •	Each curve represents survival probability over time for a treatment group.
# •	The p-value tests if survival differences are statistically significant.
# •	If curves separate over time, it suggests that treatment effects change dynamically.
#________________________________________
# 2. Use Random Survival Forests for Time-Dependent Predictions
# Instead of a static recommendation, we will predict how survival probabilities evolve over time.
# Fit a Random Survival Forest model
rsf_model <- rfsrc(Surv(time, status) ~ ., data = dat, ntree = 500)

# Predict survival probabilities for a new patient
new_patient <- dat[1, ] # Example patient
survival_pred <- predict(rsf_model, newdata = new_patient, type = "survival")

# Convert to a data frame for plotting
preds <- as.data.frame(survival_pred$survival)%>%gather(col, value)
survival_df <- data.frame(Time = rsf_model$time.interest, 
                          Survival_Prob =preds$value )

# Plot survival probability over time
ggplot(survival_df, aes(x = Time, y = Survival_Prob)) +
  geom_line(size = 1.2, color = "blue") +
  theme_minimal() +
  labs(title = "Predicted Survival Probability Over Time",
       x = "Time (Days)", y = "Survival Probability")
# Interpretation:
#   •	The curve shows how the predicted survival probability decreases over time for the patient.
# •	A steeper decline suggests higher risk.
# •	Different patients will have different survival trajectories, helping guide long-term treatment plans.
# ________________________________________
# 3. Personalized Treatment Recommendations Over Time
#We will compare survival predictions for different treatment options.
# Generate survival predictions for each treatment option
treatment_options <- unique(dat$trt)
survival_results <- list()

for (t in treatment_options) {
  new_patient$trt <- t
  pred <- predict(rsf_model, newdata = new_patient, type = "survival")
  preds <- as.data.frame(pred$survival)%>%gather(col, value)
  survival_results[[as.character(t)]] <- data.frame(Time = rsf_model$time.interest, 
                                                    Survival_Prob = preds$value,
                                                    Treatment = as.character(t))
}

# Combine results into one data frame
survival_all <- do.call(rbind, survival_results)

# Plot survival curves for different treatments
ggplot(survival_all, aes(x = Time, y = Survival_Prob, color = Treatment)) +
  geom_line(size = 1.2) +
  theme_minimal() +
  labs(title = "Predicted Survival Over Time by Treatment",
       x = "Time (Days)", y = "Survival Probability", color = "Treatment Group")
# Interpretation:
#   •	This plot compares survival trajectories for different treatments.
# •	The treatment with the highest survival probability at later time points may be the optimal choice.
# •	If survival probabilities cross over time, treatment effects may vary based on patient condition.
________________________________________
# 4. Making Time-Dependent Recommendations
# Now, we select the best treatment at different time points.
# Identify best treatment at different time points
best_treatment_over_time <- survival_all %>%
  group_by(Time) %>%
  filter(Survival_Prob == max(Survival_Prob)) %>%
  select(Time, Treatment, Survival_Prob)

# Print best treatments over time
print(best_treatment_over_time)
# Interpretation:
#   •	This shows which treatment is best at different time points.
# •	If different treatments are best at different times, a switching strategy might be needed.
________________________________________
# Final Thoughts
# Time-dependent survival analysis provides deeper insights into treatment effectiveness.
# Survival curves help visualize long-term treatment impacts.
# Personalized recommendations can change over time, guiding dynamic treatment strategies.
# Optimizing Treatment Switching Strategies Based on Time-Dependent Survival Analysis
# Now that we've analyzed how different treatments impact survival over time, we can identify optimal points to switch treatments for better long-term outcomes.
# ________________________________________
# 1. Define a Treatment Switching Strategy
# A treatment switch may be recommended if:
# Survival probability for the current treatment declines significantly.
# Another treatment overtakes as the best option at a later time point.
# The gap between survival probabilities is clinically meaningful.
# We will identify when to switch treatments based on survival probability curves.
# 2. Identify the Optimal Treatment at Different Time Points
# We'll modify our previous code to find the best treatment at each time step.
# # Identify best treatment at different time points
best_treatment_over_time <- survival_all %>%
  group_by(Time) %>%
  filter(Survival_Prob == max(Survival_Prob)) %>%
  select(Time, Treatment, Survival_Prob)

# Print best treatment at different time points
print(best_treatment_over_time)
# Interpretation:
#   •	The best treatment at earlier time points may differ from later time points.
# •	If a different treatment consistently becomes better after a certain time, a switching strategy may improve survival.
# ________________________________________
# 3. Detect When to Switch Treatments
# We will identify time points where the best treatment changes.
# Detect treatment switch points
best_treatment_over_time <- best_treatment_over_time %>%
  mutate(Switch = ifelse(lag(Treatment, default = first(Treatment)) != Treatment, "Switch", "Stay"))
# Display only switch points
switch_points <- best_treatment_over_time %>% filter(Switch == "Switch")
print(switch_points)
# Interpretation:
#   •	The "Switch" column flags points where the best treatment changes.
# •	This suggests when a patient should switch treatments to maximize survival.
# ________________________________________
# 4. Visualizing Treatment Switching Over Time
# We will highlight the optimal switching points in a plot.
ggplot(survival_all, aes(x = Time, y = Survival_Prob, color = Treatment)) +
  geom_line(size = 1.2) +
  geom_vline(data = switch_points, aes(xintercept = Time), linetype = "dashed", color = "black") +
  theme_minimal() +
  labs(title = "Optimal Treatment Switching Strategy",
       x = "Time (Days)", y = "Survival Probability", color = "Treatment") +
  geom_text(data = switch_points, aes(x = Time, y = 0.5, label = paste("Switch to", Treatment)), 
            angle = 90, vjust = -0.5, hjust = 1)
# Interpretation:
#   •	Dashed lines mark recommended treatment switch points.
# •	Text annotations indicate which treatment to switch to at each point.
# •	This guides timing decisions for optimizing long-term patient survival.
# ________________________________________
# 5. Implementing a Time-Based Treatment Plan
# Now, we automate a personalized treatment schedule for patients.
# Create a treatment schedule for a given patient
create_treatment_plan <- function(patient_id) {
  patient_plan <- switch_points %>%
    select(Time, Treatment) %>%
    mutate(Patient_ID = patient_id)
  
  return(patient_plan)
}

# Generate a treatment schedule for patient 1
treatment_plan_patient1 <- create_treatment_plan(1)
print(treatment_plan_patient1)
# Interpretation:
#   •	This generates a custom treatment timeline for an individual patient.
# •	Physicians can use this plan to adjust treatments over time based on survival predictions.
# ________________________________________
# Final Thoughts
# Treatment switching can be optimized using time-dependent survival analysis.
# Patients may benefit from starting with one treatment and switching later.
# Visualization makes it easier to see when switching is needed.
# A personalized treatment schedule can guide clinical decisions.


####################################
###################################
#1. Load Required Packages
library(randomForestSRC)
library(survival)
library(ggplot2)

#2. Load Example Dataset
# We'll use the built-in dat dataset from the survival package, which 
# contains survival data for lung cancer patients.
dat <- veteran  # Load the dataset
head(dat)  # View first few rows
# •  time: Survival time in days
# •  status: Survival status (1 = censored, 2 = dead)
# •  trt: Treatment group
# •  age: Age in years
# •  celltype: Type of cancer cell
# •  karno: Karnofsky performance score (higher = better health)
# •  diagtime: Time since diagnosis
# •  priortx: Prior therapy (0 = No, 10 = Yes)

#3. Convert Variables & Create Survival Object
#Convert categorical variables to factors and define the survival object:
dat$status <- as.numeric(dat$status)  # Convert status (1 = alive, 0 = dead)
dat$trt <- as.factor(dat$trt)              # Treatment as factor
dat$celltype <- as.factor(dat$celltype)    # Cell type as factor

#4. Fit a Random Survival Forest Model
set.seed(123)  # For reproducibility
rsf_model <- rfsrc(Surv(time, status) ~ ., data = dat, 
                    ntree = 500,  # Number of trees
                    importance = TRUE,  # Compute variable importance
                    nsplit = 10)  # Improve splits for continuous variables

# Print model summary
print(rsf_model)

#5. Assess Variable Importance
#We extract and visualize variable importance.
# Extract variable importance
vi <- rsf_model$importance
vi_df <- data.frame(Variable = names(vi), Importance = vi)

# Plot variable importance
ggplot(vi_df, aes(x = reorder(Variable, Importance), y = Importance)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  coord_flip() +
  theme_minimal() +
  labs(title = "Variable Importance in Random Survival Forest",
       x = "Variable", y = "Importance")
#Obtaining Confidence Intervals for Feature Importance in Random Survival Forests (RSF)
# To obtain confidence intervals (CIs) for feature importance, 
# we can use bootstrap resampling or permutation-based methods. 
# The randomForestSRC package provides built-in options for this.

#1. Compute Confidence Intervals Using Bootstrapping
# Compute variable importance with confidence intervals
vimp_result <- vimp(rsf_model, importance = "permute", bootstrap = TRUE)

# Print variable importance with CIs
print(vimp_result)
#2. Extract and Visualize Confidence Intervals
#We extract lower and upper confidence bounds and plot them.
# Convert variable importance results to a data frame
vimp_df <- data.frame(
  Variable = rownames(vimp_result$importance),
  Importance = vimp_result$importance[, 1],  # Mean importance
  Lower_CI = vimp_result$importance[, 2],   # Lower bound
  Upper_CI = vimp_result$importance[, 3]    # Upper bound
)

# Plot with error bars
library(ggplot2)

ggplot(vimp_df, aes(x = reorder(Variable, Importance), y = Importance)) +
  geom_point(size = 3, color = "blue") +
  geom_errorbar(aes(ymin = Lower_CI, ymax = Upper_CI), width = 0.2, color = "red") +
  coord_flip() +
  theme_minimal() +
  labs(title = "Variable Importance with Confidence Intervals",
       x = "Feature", y = "Importance Score")
# Interpretation:
# •	Wider confidence intervals indicate higher uncertainty in feature importance.
# •	Non-overlapping CIs suggest stronger differences in importance.

#3. Alternative: Compute Confidence Intervals Using Multiple RSF Runs
# Define number of repetitions
n_repeats <- 100
vimp_list <- list()

# Run multiple RSF models and store variable importance scores
for (i in 1:n_repeats) {
  temp_model <- rfsrc(Surv(time, status) ~ ., data = dat)
  vimp_list[[i]] <- as.data.frame(vimp(temp_model)$importance)[, 1]
}

# Convert list to a matrix
vimp_matrix <- do.call(cbind, vimp_list)

# Compute mean and confidence intervals
vimp_mean <- rowMeans(vimp_matrix)
vimp_lower <- apply(vimp_matrix, 1, quantile, probs = 0.025)  # 2.5% lower bound
vimp_upper <- apply(vimp_matrix, 1, quantile, probs = 0.975)  # 97.5% upper bound

# Store results in a data frame
vimp_bootstrap_df <- data.frame(
  Variable = rownames(data.frame(vimp_result$importance)),
  Importance = vimp_mean,
  Lower_CI = vimp_lower,
  Upper_CI = vimp_upper
)

# Plot with error bars
ggplot(vimp_bootstrap_df, aes(x = reorder(Variable, Importance), y = Importance)) +
  geom_point(size = 3, color = "blue") +
  geom_errorbar(aes(ymin = Lower_CI, ymax = Upper_CI), width = 0.2, color = "red") +
  coord_flip() +
  theme_minimal() +
  labs(title = "Bootstrapped Variable Importance with Confidence Intervals",
       x = "Feature", y = "Importance Score")
#This approach is more computationally expensive, but it provides robust CIs by training multiple RSFs.
# ________________________________________
# Understanding Feature Effects on Survival Predictions Using Partial Dependence Plots (PDPs)
# Partial dependence plots (PDPs) help visualize how individual features influence 
# survival predictions in a random survival forest (RSF) model.
# ________________________________________
# 1. Compute Partial Dependence for a Feature
# The plot.variable() function in randomForestSRC computes partial dependence.
# Compute partial dependence for "karno" (Karnofsky score)
plot.variable(rsf_model, xvar = "karno", partial = TRUE, 
              main = "Partial Dependence of Karnofsky Score on Survival",
              ylab = "Predicted Survival Probability")

# Interpretation:
# •	If survival probability increases with higher Karnofsky scores, it means better functional status improves survival.
# •	A flat line suggests that the feature has little effect on survival.
________________________________________
# 2. PDP for Multiple Features
# To compare multiple features, we plot PDPs side-by-side.
# Define important variables to analyze
important_vars <- c("karno", "age", "diagtime")

# Create PDP plots for each variable
par(mfrow = c(1, length(important_vars)))  # Arrange plots in a row
for (var in important_vars) {
  plot.variable(rsf_model, xvar = var, partial = TRUE, 
                main = paste("Partial Dependence of", var),
                ylab = "Predicted Survival Probability")
}
#  Interpretation:
# •	Karnofsky score: Higher scores → higher survival probability.
# •	Age: Increasing age may reduce survival probability.
# •	Diagnostic time (diagtime): If longer diagnostic time correlates with better survival, it may indicate earlier-stage diagnoses.
# ________________________________________
# 3. PDP with Confidence Intervals
# To estimate uncertainty, we use bootstrap-based PDPs.
# Compute partial dependence with confidence intervals
plot.variable(rsf_model, xvar = "karno", partial = TRUE, show.plots = TRUE, 
              smooth.lines = TRUE, alpha = 0.2,  
              main = "PDP for Karnofsky Score with Confidence Intervals",
              ylab = "Predicted Survival Probability")
# Interpretation:
# •	The shaded region represents the confidence interval (CI).
# •	If CIs overlap, the relationship is less certain.

# 4. 3D Partial Dependence Plot for Two Variables
# To see interaction effects between two features, we plot a 3D PDP.
# 3D PDP for Karnofsky score and age
plot.variable(rsf_model, xvar = c("karno", "age"), partial = TRUE, 
              surface = TRUE, main = "3D PDP: Karnofsky Score & Age")
#  Interpretation:
# •	If the surface bends, it suggests a strong interaction between age and Karnofsky score.
# •	Example: Younger patients with high Karnofsky scores may have higher survival probability than older patients.

# Final Thoughts
# PDPs show how features impact survival predictions in RSF models.
# Confidence intervals help assess the reliability of PDP results.
# 3D PDPs reveal interactions between two features.
# Exploring SHAP Values for Feature Importance in Random Survival Forests
# SHAP (SHapley Additive exPlanations) values help us understand how each feature 
# influences individual survival predictions. Unlike PDPs, SHAP values provide local 
# explanations at the individual level.
________________________________________
# 1. Install and Load Required Libraries
# We need the shapviz package for SHAP-based interpretation.
library(shapviz)
#2. Compute SHAP Values for the RSF Model
# Compute SHAP values from the RSF model 
shap_values <- shapviz(rsf_model, method = "kernelshap") 
# Print SHAP values summary 
print(shap_values)
# Interpretation:
# •	SHAP values quantify how much each feature contributes to an individual's survival prediction.
# •	Positive SHAP values increase survival probability, while negative values decrease it.
# ________________________________________
# 3. SHAP Summary Plot (Global Feature Importance)
# We visualize global feature importance with a summary plot.
# SHAP summary plot
plot(shap_values, kind = "bar", main = "SHAP Feature Importance")
# Interpretation:
#   •	Features with higher SHAP values have a greater impact on survival predictions.
# •	If Karnofsky score ranks highest, it means functional status strongly influences survival.
# 
# 4. SHAP Beeswarm Plot (Feature Effects Across Patients)
# The beeswarm plot shows how each feature influences survival for different individuals.
plot(shap_values, kind = "beeswarm", main = "SHAP Beeswarm Plot")
Interpretation:
  •	Each dot represents an individual patient.
# •	Color gradient (e.g., blue → red) shows the feature's magnitude (low → high).
# •	Higher SHAP values (right side) indicate that a feature increases survival probability.
# ________________________________________
# 5. SHAP Dependence Plot (Feature Interactions)
# To analyze feature interactions, we use SHAP dependence plots.
plot(shap_values, x = "karno", main = "SHAP Dependence Plot for Karnofsky Score")
# Interpretation:
# •	If higher Karnofsky scores consistently have positive SHAP values, it means better functional status improves survival.
# •	Vertical dispersion suggests interactions with other variables (e.g., age, diagnosis time).
# ________________________________________
# 6. SHAP Interaction Effects
#To check if features interact (e.g., age + Karnofsky score), we use an interaction plot.
plot(shap_values, x = "age", color = "karno", main = "SHAP Interaction: Age & Karnofsky Score")
# Interpretation:
# •	If color gradient (e.g., low Karnofsky scores in blue, high in red) aligns with SHAP values, it suggests a strong interaction between age and Karnofsky score.
# •	Older patients with high Karnofsky scores may have different survival effects than younger ones.
# ________________________________________
# Final Thoughts
# SHAP values provide local and global feature importance insights.
# Beeswarm and dependence plots help understand individual feature effects.
# SHAP interactions reveal complex relationships between features.

# Counterfactual Explanations for Survival Predictions in Random Survival Forests
# Counterfactual analysis answers "What if?" questions by showing how changes in a 
# patient’s features (e.g., age, treatment, Karnofsky score) would affect survival predictions.
# ________________________________________

  geom_line() +
  theme_minimal() +
  labs(title = "Counterfactual Analysis: Karnofsky Score & Treatment",
       x = "Karnofsky Score", y = "Predicted Survival Probability",
       color = "Treatment Group")
# Interpretation:
# •	If increasing Karnofsky score leads to higher survival predictions, it suggests that improving functional status is beneficial.
# •	If switching treatment# 1. Install and Load Required Libraries
#We will use iml (interpretable machine learning) for counterfactual analysis.
library(iml)
# 2. Define a Counterfactual Explanation Function
# We create a function to generate counterfactual survival predictions for an 
# individual patient.
# Select a patient for counterfactual analysis
patient <- dat[1, ]  
# Define the predictor object for iml package
predictor <- Predictor$new(final_model, data = dat, y = dat$status)
# Generate counterfactual explanations
library(DALEX)
# Compute counterfactual changes
cf_explainer <- DALEX::explain(final_model, data = dat, y = dat$status)
# Generate counterfactuals by modifying one or more features
counterfactuals <- DALEX::counterfactual(cf_explainer, observation = patient, 
                                         variables = c("karno", "age", "trt"), 
                                         n = 5)  # Generate 5 counterfactual cases
# Print counterfactual cases
print(counterfactuals)
# Interpretation:
# •	The function modifies key patient features (e.g., increasing Karnofsky score, changing treatment) to see if the predicted survival probability improves.
# •	The output shows different scenarios where changes in patient characteristics could alter survival predictions.
# ________________________________________
# 3. Visualize Counterfactual Outcomes
# We can plot how survival predictions change under different scenarios.
# Convert counterfactual results to a dataframe
counterfactuals_df <- as.data.frame(counterfactuals)
# Plot counterfactual effects
library(ggplot2)
ggplot(counterfactuals_df, aes(x = karno, y = predict, color = as.factor(trt))) +
  geom_point(size = 4) + changes survival probabilities significantly, the patient might benefit from an alternative therapy.
# ________________________________________
# 4. Compare Original vs. Counterfactual Predictions
# To clearly compare, we print original vs. counterfactual predictions.
# Show original and modified patient predictions
comparison <- rbind(patient[, c("karno", "age", "trt")], counterfactuals_df)
rownames(comparison) <- c("Original", paste("CF", 1:5, sep = "_"))
# print(comparison)
# Interpretation:
# •	The table shows the original patient’s values vs. modified feature values and their effect on survival predictions.
# •	If small changes increase survival probability, it suggests modifiable risk factors (e.g., lifestyle, treatment changes).
# ________________________________________
# Final Thoughts
# Counterfactuals help understand what changes improve survival predictions.
# Visualizing different scenarios helps in treatment decision-making.
# Comparison tables show how modifiable factors affect survival outcomes.
# Individualized Treatment Recommendations Using Counterfactual Analysis
# Now that we've explored counterfactuals, we can take it a step further by using these 
# insights to make personalized treatment recommendations for patients. This approach helps 
# identify modifiable factors that could improve survival probabilities.
# ________________________________________
# 1. Generate Counterfactuals for a Patient
#We will generate alternative patient profiles by changing key variables like treatment type, Karnofsky score, and age.
# Load necessary packages
library(DALEX)
library(randomForestSRC)
# Select a specific patient (e.g., first patient in dataset)
patient <- dat[1, ]  
# Explain the RSF model
cf_explainer <- DALEX::explain(rsf_model, data = dat, y = dat$status)
# Generate counterfactual scenarios by modifying key variables
counterfactuals <- DALEX::counterfactual(cf_explainer, observation = patient, 
                                         variables = c("karno", "age", "trt"), 
                                         n = 5)  # Generate 5 counterfactuals
# Convert to dataframe for comparison
counterfactuals_df <- as.data.frame(counterfactuals)
# 2. Compare Survival Predictions for Different Treatments
# To determine which treatment is best for a specific patient, we analyze how 
# survival probabilities change.
# Print original patient and counterfactual scenarios
comparison <- rbind(patient[, c("karno", "age", "trt")], counterfactuals_df)
rownames(comparison) <- c("Original", paste("CF", 1:5, sep = "_"))
print(comparison)
# Interpretation:
#   •	The original patient’s survival prediction is compared to modified cases where treatment (trt) or functional score (karno) was changed.
# •	If a different treatment (trt) consistently improves survival, it might be a better alternative for this patient.
# ________________________________________
# 3. Visualize How Treatment Affects Survival
# We plot how treatment changes impact survival probabilities.
library(ggplot2)
ggplot(counterfactuals_df, aes(x = karno, y = predict, color = as.factor(trt))) +
  geom_point(size = 4) +
  geom_line() +
  theme_minimal() +
  labs(title = "Effect of Karnofsky Score and Treatment on Survival",
       x = "Karnofsky Score", y = "Predicted Survival Probability",
       color = "Treatment Group")
# Interpretation:
#   •	If one treatment (trt) consistently leads to higher survival probability, 
# it may be the preferred option.
# •	If increasing Karnofsky score improves survival regardless of treatment, 
# interventions to improve functional status should be prioritized.
# ________________________________________
# 4. Make Personalized Treatment Recommendations
# Using the counterfactual results, we can create a decision rule for selecting the best treatment.
# Find the best treatment option based on highest survival probability
best_treatment <- counterfactuals_df[which.max(counterfactuals_df$predict), "trt"]
# Recommend treatment
cat("Recommended Treatment for this patient:", best_treatment, "\n")
# Interpretation:
#   •	This finds the treatment associated with the highest survival prediction and recommends it for the patient.
# •	If the original treatment is not optimal, a change in therapy may be beneficial.
# ________________________________________
# Final Thoughts
# Personalized medicine: Using counterfactuals, we can make patient-specific treatment recommendations.
# Visualization helps: Seeing how treatments affect survival probabilities provides actionable insights.
# Modifiable factors: If functional status or diagnostic time significantly affects survival, lifestyle interventions and early screenings may be key.
# Automating Individualized Treatment Recommendations for Multiple Patients
# Now, let's extend our counterfactual analysis to automate personalized treatment recommendations for an entire patient dataset. This will allow us to systematically identify the best treatment options for multiple patients based on survival predictions.
# ________________________________________
# 1. Define a Function for Automated Treatment Recommendations
# We create a function that:
# 1.	Generates counterfactuals for each patient.
# 2.	Compares survival probabilities across different treatments.
# 3.	Recommends the treatment that maximizes survival.
library(DALEX)
library(randomForestSRC)
library(dplyr)
# Define function for treatment recommendation
recommend_treatment <- function(model, patient_data, num_counterfactuals = 5) {
  # Explain the RSF model
  cf_explainer <- DALEX::explain(model, data = dat, y = dat$status)
  # Initialize results list
  recommendations <- data.frame(ID = integer(), Best_Treatment = integer(), stringsAsFactors = FALSE)
  # Loop through each patient
  for (i in 1:nrow(patient_data)) {
    patient <- patient_data[i, ]
    # Generate counterfactuals by modifying treatment and Karnofsky score
    counterfactuals <- DALEX::counterfactual(cf_explainer, observation = patient, 
                                             variables = c("karno", "age", "trt"), 
                                             n = num_counterfactuals)
    
    # Convert to dataframe
    counterfactuals_df <- as.data.frame(counterfactuals)
    # Select the treatment associated with the highest predicted survival
    best_treatment <- counterfactuals_df[which.max(counterfactuals_df$predict), "trt"]
    # Store the recommendation
    recommendations <- rbind(recommendations, data.frame(ID = i, Best_Treatment = best_treatment))
  }
  return(recommendations)
}

# Apply the function to the entire dataset
treatment_recommendations <- recommend_treatment(final_model, dat)
# Print recommendations
print(treatment_recommendations)
# 2. Interpretation of Results
# This function: Processes each patient individually
# Generates counterfactuals for different treatments
# Identifies the treatment with the highest survival probability
# Stores and returns treatment recommendations
# ________________________________________
# 3. Visualizing Treatment Recommendations
# We can visualize how recommended treatments vary across patients.
ggplot(treatment_recommendations, aes(x = ID, y = Best_Treatment, fill = as.factor(Best_Treatment))) +
  geom_bar(stat = "identity") +
  theme_minimal() +
  labs(title = "Recommended Treatment for Each Patient",
       x = "Patient ID", y = "Recommended Treatment",
       fill = "Treatment Group")
# Interpretation:
# •	If one treatment is consistently recommended, it may be the most effective for the population.
# •	If recommendations vary across patients, it highlights the need for individualized treatment plans.
#________________________________________
# 4. Applying Recommendations in Clinical Settings
# Now that we have an automated recommendation system, doctors could:
# 1.	Use this tool to support clinical decisions.
# 2.	Adjust treatment plans based on modifiable patient factors.
# 3.	Identify patients who may benefit most from specific interventions.
# 
# Final Thoughts
# Automating counterfactuals enables large-scale personalized treatment recommendations.
# Doctors can use these insights to make data-driven clinical decisions.
# Further refinement (adding additional patient factors) could enhance the model’s accuracy.
# Incorporating Confidence Intervals into Treatment Recommendations
# To ensure that our treatment recommendations are reliable, we will calculate confidence 
# intervals (CIs) for survival predictions. This helps quantify uncertainty in our recommendations.
________________________________________
# 1. Modify Function to Include Confidence Intervals
# We will: Generate multiple counterfactuals per patient
# Compute mean and standard deviation of survival predictions
# Calculate 95% confidence intervals for each treatment option
library(DALEX)
library(randomForestSRC)
library(dplyr)

# Function to recommend treatment with confidence intervals
recommend_treatment_with_CI <- function(model, patient_data, num_counterfactuals = 10) {
  # Explain the RSF model
  cf_explainer <- DALEX::explain(model, data = dat, y = dat$status)
  
  # Initialize results
  recommendations <- data.frame(ID = integer(), Best_Treatment = integer(), 
                                Mean_Survival = numeric(), 
                                Lower_CI = numeric(), Upper_CI = numeric(), 
                                stringsAsFactors = FALSE)
  
  # Loop through each patient
  for (i in 1:nrow(patient_data)) {
    patient <- patient_data[i, ]
    
    # Generate multiple counterfactuals for treatment and Karnofsky score
    counterfactuals <- DALEX::counterfactual(cf_explainer, observation = patient, 
                                             variables = c("karno", "age", "trt"), 
                                             n = num_counterfactuals)
    
    # Convert to dataframe
    counterfactuals_df <- as.data.frame(counterfactuals)
    
    # Compute mean and confidence interval for each treatment
    treatment_stats <- counterfactuals_df %>%
      group_by(trt) %>%
      summarise(Mean_Survival = mean(predict),
                SD = sd(predict),
                Lower_CI = Mean_Survival - 1.96 * (SD / sqrt(n())),
                Upper_CI = Mean_Survival + 1.96 * (SD / sqrt(n())))
    
    # Select best treatment based on highest mean survival probability
    best_treatment <- treatment_stats %>% filter(Mean_Survival == max(Mean_Survival))
    
    # Store results
    recommendations <- rbind(recommendations, data.frame(ID = i, 
                                                         Best_Treatment = best_treatment$trt, 
                                                         Mean_Survival = best_treatment$Mean_Survival, 
                                                         Lower_CI = best_treatment$Lower_CI, 
                                                         Upper_CI = best_treatment$Upper_CI))
  }
  
  return(recommendations)
}

# Apply the function to the dataset
treatment_recommendations_CI <- recommend_treatment_with_CI(final_model, dat)

# Print recommendations with confidence intervals
# print(treatment_recommendations_CI)
# 2. Interpretation of Confidence Intervals
# Mean Survival → The expected survival probability for each recommended treatment.
# Lower CI / Upper CI → The range within which the survival probability is expected to fall with 95% confidence.
# If CIs overlap for two treatments, the choice may be less certain, suggesting the need for additional factors (e.g., biomarkers, patient preferences).
# ________________________________________
# 3. Visualizing Confidence Intervals for Recommendations
# Now, let's plot the survival probabilities with confidence intervals.
library(ggplot2)

ggplot(treatment_recommendations_CI, aes(x = as.factor(Best_Treatment), y = Mean_Survival)) +
  geom_point(size = 4) +
  geom_errorbar(aes(ymin = Lower_CI, ymax = Upper_CI), width = 0.2) +
  theme_minimal() +
  labs(title = "Treatment Recommendations with Confidence Intervals",
       x = "Recommended Treatment", y = "Predicted Survival Probability")
# Interpretation:
#   •	Treatments with narrower CIs have more stable predictions.
# •	If a treatment has a wide CI, the model is less certain about its effect.
# •	Treatments with overlapping CIs may not have a statistically significant difference.
# ________________________________________
# Time-Dependent Survival Analysis for Personalized Treatment Recommendations
# Now, let’s extend our approach by incorporating time-dependent survival analysis 
# to see how different treatments impact survival over time. This will provide a 
# longitudinal view of how treatment effects evolve.
________________________________________
#1. Use Kaplan-Meier Curves for Each Treatment
# Load necessary libraries
library(survival)
library(survminer)
library(randomForestSRC)

# Fit a Kaplan-Meier survival model for each treatment group
km_fit <- survfit(Surv(time, status) ~ trt, data = dat)

# Plot survival curves
ggsurvplot(km_fit, data = dat,
           conf.int = TRUE, # Show confidence intervals
           risk.table = TRUE, # Show risk table
           pval = TRUE, # Display log-rank test p-value
           ggtheme = theme_minimal(),
           title = "Kaplan-Meier Survival Curves by Treatment Group")
# Interpretation:
#   •	Each curve represents survival probability over time for a treatment group.
# •	The p-value tests if survival differences are statistically significant.
# •	If curves separate over time, it suggests that treatment effects change dynamically.
#________________________________________
# 2. Use Random Survival Forests for Time-Dependent Predictions
# Instead of a static recommendation, we will predict how survival probabilities evolve over time.
# Fit a Random Survival Forest model
rsf_model <- rfsrc(Surv(time, status) ~ ., data = dat, ntree = 500)

# Predict survival probabilities for a new patient
new_patient <- dat[1, ] # Example patient
survival_pred <- predict(rsf_model, newdata = new_patient, type = "survival")

# Convert to a data frame for plotting
preds <- as.data.frame(survival_pred$survival)%>%gather(col, value)
survival_df <- data.frame(Time = rsf_model$time.interest, 
                          Survival_Prob =preds$value )

# Plot survival probability over time
ggplot(survival_df, aes(x = Time, y = Survival_Prob)) +
  geom_line(size = 1.2, color = "blue") +
  theme_minimal() +
  labs(title = "Predicted Survival Probability Over Time",
       x = "Time (Days)", y = "Survival Probability")
# Interpretation:
#   •	The curve shows how the predicted survival probability decreases over time for the patient.
# •	A steeper decline suggests higher risk.
# •	Different patients will have different survival trajectories, helping guide long-term treatment plans.
# ________________________________________
# 3. Personalized Treatment Recommendations Over Time
#We will compare survival predictions for different treatment options.
# Generate survival predictions for each treatment option
treatment_options <- unique(dat$trt)
survival_results <- list()

for (t in treatment_options) {
  new_patient$trt <- t
  pred <- predict(rsf_model, newdata = new_patient, type = "survival")
  preds <- as.data.frame(pred$survival)%>%gather(col, value)
  survival_results[[as.character(t)]] <- data.frame(Time = rsf_model$time.interest, 
                                                    Survival_Prob = preds$value,
                                                    Treatment = as.character(t))
}

# Combine results into one data frame
survival_all <- do.call(rbind, survival_results)

# Plot survival curves for different treatments
ggplot(survival_all, aes(x = Time, y = Survival_Prob, color = Treatment)) +
  geom_line(size = 1.2) +
  theme_minimal() +
  labs(title = "Predicted Survival Over Time by Treatment",
       x = "Time (Days)", y = "Survival Probability", color = "Treatment Group")
# Interpretation:
#   •	This plot compares survival trajectories for different treatments.
# •	The treatment with the highest survival probability at later time points may be the optimal choice.
# •	If survival probabilities cross over time, treatment effects may vary based on patient condition.
________________________________________
# 4. Making Time-Dependent Recommendations
# Now, we select the best treatment at different time points.
# Identify best treatment at different time points
best_treatment_over_time <- survival_all %>%
  group_by(Time) %>%
  filter(Survival_Prob == max(Survival_Prob)) %>%
  select(Time, Treatment, Survival_Prob)

# Print best treatments over time
print(best_treatment_over_time)
# Interpretation:
#   •	This shows which treatment is best at different time points.
# •	If different treatments are best at different times, a switching strategy might be needed.
________________________________________
# Final Thoughts
# Time-dependent survival analysis provides deeper insights into treatment effectiveness.
# Survival curves help visualize long-term treatment impacts.
# Personalized recommendations can change over time, guiding dynamic treatment strategies.
# Optimizing Treatment Switching Strategies Based on Time-Dependent Survival Analysis
# Now that we've analyzed how different treatments impact survival over time, we can identify optimal points to switch treatments for better long-term outcomes.
# ________________________________________
# 1. Define a Treatment Switching Strategy
# A treatment switch may be recommended if:
# Survival probability for the current treatment declines significantly.
# Another treatment overtakes as the best option at a later time point.
# The gap between survival probabilities is clinically meaningful.
# We will identify when to switch treatments based on survival probability curves.
# 2. Identify the Optimal Treatment at Different Time Points
# We'll modify our previous code to find the best treatment at each time step.
# # Identify best treatment at different time points
best_treatment_over_time <- survival_all %>%
  group_by(Time) %>%
  filter(Survival_Prob == max(Survival_Prob)) %>%
  select(Time, Treatment, Survival_Prob)

# Print best treatment at different time points
print(best_treatment_over_time)
# Interpretation:
#   •	The best treatment at earlier time points may differ from later time points.
# •	If a different treatment consistently becomes better after a certain time, a switching strategy may improve survival.
# ________________________________________
# 3. Detect When to Switch Treatments
# We will identify time points where the best treatment changes.
# Detect treatment switch points
best_treatment_over_time <- best_treatment_over_time %>%
  mutate(Switch = ifelse(lag(Treatment, default = first(Treatment)) != Treatment, "Switch", "Stay"))
# Display only switch points
switch_points <- best_treatment_over_time %>% filter(Switch == "Switch")
print(switch_points)
# Interpretation:
#   •	The "Switch" column flags points where the best treatment changes.
# •	This suggests when a patient should switch treatments to maximize survival.
# ________________________________________
# 4. Visualizing Treatment Switching Over Time
# We will highlight the optimal switching points in a plot.
ggplot(survival_all, aes(x = Time, y = Survival_Prob, color = Treatment)) +
  geom_line(size = 1.2) +
  geom_vline(data = switch_points, aes(xintercept = Time), linetype = "dashed", color = "black") +
  theme_minimal() +
  labs(title = "Optimal Treatment Switching Strategy",
       x = "Time (Days)", y = "Survival Probability", color = "Treatment") +
  geom_text(data = switch_points, aes(x = Time, y = 0.5, label = paste("Switch to", Treatment)), 
            angle = 90, vjust = -0.5, hjust = 1)
# Interpretation:
#   •	Dashed lines mark recommended treatment switch points.
# •	Text annotations indicate which treatment to switch to at each point.
# •	This guides timing decisions for optimizing long-term patient survival.
# ________________________________________
# 5. Implementing a Time-Based Treatment Plan
# Now, we automate a personalized treatment schedule for patients.
# Create a treatment schedule for a given patient
create_treatment_plan <- function(patient_id) {
  patient_plan <- switch_points %>%
    select(Time, Treatment) %>%
    mutate(Patient_ID = patient_id)
  
  return(patient_plan)
}

# Generate a treatment schedule for patient 1
treatment_plan_patient1 <- create_treatment_plan(1)
print(treatment_plan_patient1)
# Interpretation:
#   •	This generates a custom treatment timeline for an individual patient.
# •	Physicians can use this plan to adjust treatments over time based on survival predictions.
# ________________________________________
# Final Thoughts
# Treatment switching can be optimized using time-dependent survival analysis.
# Patients may benefit from starting with one treatment and switching later.
# Visualization makes it easier to see when switching is needed.
# A personalized treatment schedule can guide clinical decisions.

# 
# 6. Perform Variable Selection
# To select the most important features, we use the Minimal Depth method.
# Compute minimal depth for variable selection
vimp_select <- var.select(rsf_model)
# Print selected variables
print(vimp_select$topvars)
#This method identifies top variables based on their depth in the trees.
# 7. Fit a Model with Selected Variables
# We now refit the model using only the top-selected variables.
selected_vars <- vimp_select$topvars  # Selected variables
formula_selected <- as.formula(paste("Surv(time, status) ~", paste(selected_vars, collapse = " + ")))
# Fit new model with selected variables
rsf_selected <- rfsrc(formula_selected, data = dat, 
                      ntree = 500, importance = TRUE)
# Print model performance
print(rsf_selected)
#8. Visualize Survival Curves
#Plot survival curves for different patient groups.
plot.survival.rfsrc(rsf_selected)
#9. Evaluate Model Performance
#Check Concordance Index (C-index), a measure of predictive accuracy.
print(rsf_selected$err.rate[length(rsf_selected$err.rate)])  # Final error rate
# Final Thoughts
# •	Variable importance helps identify key predictors of survival.
# •	Variable selection improves model efficiency and interpretability.
# •	The random survival forest is a powerful non-parametric method that handles complex interactions and missing data.
# Hyperparameter Tuning for Random Survival Forest using randomForestSRC
# To improve model performance, we can tune key hyperparameters:
#   1.	ntree (Number of Trees): More trees improve stability but increase computation time.
# 2.	mtry (Number of Variables Tried at Each Split): Affects bias-variance tradeoff.
# 3.	nodesize (Minimum Node Size): Controls tree depth; smaller values lead to deeper trees.
# 4.	nsplit (Number of Split Points for Continuous Variables): More splits improve precision.
# 1. Define Hyperparameter Grid
# We'll test different combinations of ntree, mtry, and nodesize.
library(caret)  # For tuning grid
set.seed(123)
# Define parameter grid
param_grid <- expand.grid(
  ntree = c(300, 500, 1000),  # Number of trees
  mtry = c(2, 4, 6),          # Number of features to split at each node
  nodesize = c(3, 5, 10)      # Minimum size of terminal nodes
)
# Store results
results <- data.frame(ntree = integer(), mtry = integer(), nodesize = integer(), c_index = numeric())

# Run tuning loop
for (i in 1:nrow(param_grid)) {
  cat("Running model", i, "of", nrow(param_grid), "\n")
  model <- rfsrc(Surv(time, status) ~ ., data = dat, 
                 ntree = param_grid$ntree[i], 
                 mtry = param_grid$mtry[i], 
                 nodesize = param_grid$nodesize[i],
                 importance = TRUE)
  # Extract C-index (last error rate)
  c_index <- 1 - model$err.rate[length(model$err.rate)]

  # Store results
  results <- rbind(results, c(param_grid$ntree[i], param_grid$mtry[i], param_grid$nodesize[i], c_index))
}

# Rename columns
colnames(results) <- c("ntree", "mtry", "nodesize", "c_index")

# Print best parameters
best_params <- results[which.max(results$c_index), ]
print(best_params)
# 2. Fit Final Model with Optimized Hyperparameters
# Using the best values from tuning:
best_model <- rfsrc(Surv(time, status) ~ ., data = dat,
                     ntree = best_params$ntree,
                     mtry = best_params$mtry,
                     nodesize = best_params$nodesize,
                     importance = TRUE)

# Print optimized model performance
print(best_model)
#3. Visualize Variable Importance for Optimized Model
vi_opt <- best_model$importance
vi_df_opt <- data.frame(Variable = names(vi_opt), Importance = vi_opt)

ggplot(vi_df_opt, aes(x = reorder(Variable, Importance), y = Importance)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  coord_flip() +
  theme_minimal() +
  labs(title = "Variable Importance (Optimized Model)",
       x = "Variable", y = "Importance")
#4. Final Model Evaluation
#Check Performance (Concordance Index)
print(1 - best_model$err.rate[length(best_model$err.rate)])
#Plot Survival Curves
plot.survival.rfsrc(best_model)
# Conclusion
# •	We tuned ntree, mtry, and nodesize to maximize C-index.
# •	The final model improves prediction accuracy over the default settings.
# •	Feature selection further improves interpretability.
# 
# Cross-Validation for Random Survival Forest using randomForestSRC
# To further validate the model, we'll use k-fold cross-validation to assess performance across multiple splits of the dataset. This helps reduce overfitting and provides a more reliable estimate of the model's performance.
# 1. Define k-Fold Cross-Validation Function
# We’ll create a function to split the data, train the model, and evaluate performance across folds.
library(randomForestSRC)
library(caret)  # For k-fold cross-validation
set.seed(123)   # For reproducibility
# Define the number of folds
k_folds <- 5
# Create folds
folds <- createFolds(dat$status, k = k_folds, list = TRUE)
# Store performance metrics
cv_results <- data.frame(Fold = integer(), C_Index = numeric())
# Perform k-fold cross-validation
for (i in 1:k_folds) {
  cat("Processing fold", i, "of", k_folds, "\n")
  # Split data into training and testing sets
  train_indices <- unlist(folds[-i])  # Use k-1 folds for training
  test_indices <- unlist(folds[i])    # Use 1 fold for testing
  train_data <- dat[train_indices, ]
  test_data <- dat[test_indices, ]
  # Fit the Random Survival Forest model with tuned hyperparameters
  model <- rfsrc(Surv(time, status) ~ ., data = train_data,
                 ntree = best_params$ntree,
                 mtry = best_params$mtry,
                 nodesize = best_params$nodesize,
                 importance = TRUE)
  # Make predictions on test set
  preds <- predict(model, newdata = test_data)
  # Compute Concordance Index (C-Index) for performance evaluation
  c_index <- 1 - preds$err.rate[length(preds$err.rate)]
  # Store results
  cv_results <- rbind(cv_results, data.frame(Fold = i, C_Index = c_index))
}
# Print cross-validation results
print(cv_results)
# Compute mean C-Index across all folds
mean_c_index <- mean(cv_results$C_Index)
cat("Mean C-Index across", k_folds, "folds:", mean_c_index, "\n")
# 2. Interpretation of Cross-Validation Results
# •	The C-Index measures how well the model ranks survival times (values close to 1 indicate 
#                                                                 better predictive accuracy).
# •	By averaging across k-folds, we get a more stable estimate of model performance.
# •	If variability is high, more folds or more data may improve stability.
# 3. Final Model Training on Full Data
# After confirming that cross-validation results are stable, we train the final model on the 
# entire dataset.
final_model <- rfsrc(Surv(time, status) ~ ., data = dat,
                     ntree = best_params$ntree,
                     mtry = best_params$mtry,
                     nodesize = best_params$nodesize,
                     importance = TRUE)

# Print final model performance
print(final_model)
# 4. Final Model Evaluation
# Variable Importance Visualization
vi_final <- final_model$importance
vi_df_final <- data.frame(Variable = names(vi_final), Importance = vi_final)
ggplot(vi_df_final, aes(x = reorder(Variable, Importance), y = Importance)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  coord_flip() +
  theme_minimal() +
  labs(title = "Variable Importance (Final Model)",
       x = "Variable", y = "Importance")
#Survival Curve Visualization
plot.survival.rfsrc(final_model)
#Final C-Index Performance
print(1 - final_model$err.rate[length(final_model$err.rate)])
# Conclusion
# Hyperparameter tuning improved model accuracy.
# Cross-validation ensured robustness and generalization.
# Final model trained on full data for deployment.
# Partial Dependence Plots & Individual Survival Predictions in Random Survival Forest
# We'll now explore partial dependence plots (PDPs) to understand how key variables 
# influence survival predictions and generate individual survival predictions for new patients.
#1. Partial Dependence Plots (PDPs)
# Partial dependence plots show the marginal effect of a variable on survival predictions while 
# averaging over other variables.
# Plot PDP for a Key Variable (e.g., Age)
library(ggplot2)
# Compute Partial Dependence for Age
pdp_age <- plot.variable(final_model, xvar = "age", partial = TRUE)
# Convert to Data Frame for Plotting
pdp_df <- data.frame(Age = pdp_age$plotthis$age$x, Survival = pdp_age$plotthis$age$y)
# Plot Partial Dependence of Age
ggplot(pdp_df, aes(x = Age, y = Survival)) +
  geom_line(color = "blue") +
  theme_minimal() +
  labs(title = "Partial Dependence of Age on Survival",
       x = "Age", y = "Predicted Survival")
# Interpretation: If survival probability decreases as age increases, older patients have worse survival outcomes.
# PDP for Karnofsky Performance Score
pdp_karno <- plot.variable(final_model, xvar = "karno", partial = TRUE)
pdp_df_karno <- data.frame(Karnofsky = pdp_karno$karno$values, Survival = pdp_karno$karno$yvar)
ggplot(pdp_df_karno, aes(x = Karnofsky, y = Survival)) +
  geom_line(color = "red") +
  theme_minimal() +
  labs(title = "Partial Dependence of Karnofsky Score on Survival",
       x = "Karnofsky Score", y = "Predicted Survival")
# Interpretation: If survival increases with higher Karnofsky scores, better health is linked to better outcomes.
# 2. Individual Survival Predictions
# We’ll predict survival probability for new patients.
# Example: Predict Survival for a New Patient
new_patient <- data.frame(
  trt = factor(1, levels = levels(dat$trt)),  # Treatment group
  age = 65,          # Patient age
  celltype = factor("adeno", levels = levels(dat$celltype)),  # Cancer type
  karno = 70,        # Karnofsky score
  diagtime = 3,      # Time since diagnosis
  prior = 10       # Prior therapy
)
# Predict survival for new patient
prediction <- predict(final_model, newdata = new_patient, na.action="na.impute")
# Extract survival probabilities
print(prediction$survival)
#Plot Individual Survival Curve
# Extract time points and survival probabilities
preds <- as.data.frame(prediction$survival)%>%gather(col, value)
surv_df <- data.frame(Time = final_model$time.interest, 
                      Survival_Prob = preds$value)
# Plot survival probability over time
ggplot(surv_df, aes(x = Time, y = Survival_Prob)) +
  geom_line(color = "darkgreen") +
  theme_minimal() +
  labs(title = "Predicted Survival Curve for New Patient",
       x = "Time (Days)", y = "Survival Probability")
# Interpretation: The curve shows the predicted survival probability over time for the new patient.
# Final Thoughts
# PDPs help interpret variable effects on survival.
# Individual survival predictions allow personalized risk assessment.
# Survival curves visualize patient-specific prognosis.
# SHAP (SHapley Additive Explanations) for Interpreting Random Survival Forest Predictions
# SHAP values provide a more detailed feature importance analysis 
#by showing how each variable contributes to individual survival predictions.
# 1. Install & Load Required Packages
library(iml)
library(randomForestSRC)
library(ggplot2)
#2. Prepare SHAP Analysis
#We use the trained random survival forest (final_model) to compute SHAP values.
# Prepare dataset (remove survival outcome for explanation)
X <- dat[, names(dat) != "time"]
X <- X[, names(X) != "status"]  # Remove survival variables
# Define Predictor Object
predictor <- Predictor$new(final_model, data = X, y = dat$status)
# Compute SHAP values
shapley <- Shapley$new(predictor, x.interest = X[1, ])  # Explain first observation
#3. Visualize SHAP Contributions for an Individual Patient
# Plot SHAP values for the first patient
plot(shapley) + ggtitle("SHAP Values for First Patient in Dataset")
# Interpretation:
#   •	Positive SHAP values increase the predicted survival risk (worse prognosis).
# •	Negative SHAP values decrease the predicted survival risk (better prognosis).
# •	We can see which variables impact this patient’s prediction the most.

# 4. Global Feature Importance using SHAP
# We can compute SHAP values for the entire dataset to see the most influential variables.
# Compute SHAP values for all data points
shapley_all <- FeatureImp$new(predictor, loss = "mae")

# Plot global SHAP importance
plot(shapley_all) + ggtitle("Global Feature Importance using SHAP")
# Compute SHAP values for all data points
shapley_all <- FeatureImp$new(predictor, loss = "mae")

# Plot global SHAP importance
plot(shapley_all) + ggtitle("Global Feature Importance using SHAP")
# Interpretation:
#   •	The most important variables (higher SHAP values) have the biggest impact on survival predictions.
# •	Helps confirm findings from variable importance plots but with deeper insights into individual contributions.
# 
# Final Thoughts
# SHAP values provide an intuitive way to explain how and why predictions are made.
# Global SHAP importance confirms key features driving survival risk.
# SHAP-based individual explanations enable personalized risk assessments.
# Time-Dependent Survival Prediction for Individual Patients
# We will now predict individual survival probabilities over time using the trained random survival forest (RSF) modeland visualize the time-dependent survival function.
# ________________________________________
# 1. Predict Survival Probabilities Over Time for an Individual
# We choose a patient and plot their predicted survival curve.
# Define a new patient
new_patient <- data.frame(
  trt = factor(1, levels = levels(dat$trt)),  # Treatment group
  age = 65,          # Patient age
  celltype = factor("adeno", levels = levels(dat$celltype)),  # Cancer type
  karno = 70,        # Karnofsky score
  diagtime = 3,      # Time since diagnosis
  prior = 10       # Prior therapy
)
# Predict survival probabilities for the new patient
prediction <- predict(final_model, newdata = new_patient, na.action="na.impute")
# Extract survival probabilities and time points
surv_df <- data.frame(Time = final_model$time.interest, 
                      Survival_Prob = prediction$survival)

# Print predicted survival probabilities at key time points
print(head(surv_df))
#2. Plot the Individual’s Survival Curve
library(ggplot2)
ggplot(surv_df, aes(x = Time, y = Survival_Prob)) +
  geom_line(color = "darkgreen", size = 1.2) +
  theme_minimal() +
  labs(title = "Predicted Survival Curve for New Patient",
       x = "Time (Days)", y = "Survival Probability") +
  ylim(0, 1)
# Interpretation:
#   •	The curve shows how the patient’s survival probability changes over time.
# •	A steeper decline indicates a higher risk of death early on, while a flatter curve suggests a longer survival period.
# 3. Compare Multiple Patients’ Survival Predictions
# We can compare different patients with different risk factors.
# Define multiple patients
new_patients <- data.frame(
  trt = factor(c(1, 2), levels = levels(dat$trt)),
  age = c(50, 75),
  celltype = factor(c("adeno", "squamous"), levels = levels(dat$celltype)),
  karno = c(80, 50),
  diagtime = c(5, 1),
  prior = c(0, 10)
)

# Predict survival for both patients
predictions <- predict(final_model, newdata = new_patients)
# Convert to Data Frame
surv_df1 <- data.frame(Time = final_model$time.interest, Survival_Prob = predictions$survival[1,], Patient = "Patient 1 (Age 50, Karnofsky 80)")
surv_df2 <- data.frame(Time = final_model$time.interest, Survival_Prob = predictions$survival[2,], Patient = "Patient 2 (Age 75, Karnofsky 50)")
# Combine data
surv_df_combined <- rbind(surv_df1, surv_df2)
# Plot Survival Curves for Both Patients
ggplot(surv_df_combined, aes(x = Time, y = Survival_Prob, color = Patient)) +
  geom_line(size = 1.2) +
  theme_minimal() +
  labs(title = "Comparison of Survival Predictions for Different Patients",
       x = "Time (Days)", y = "Survival Probability") +
  ylim(0, 1)
# Interpretation:
#   •	A younger patient (age 50, Karnofsky 80) may have a higher survival probability over time.
# •	An older patient (age 75, Karnofsky 50) with poorer health might have a steeper decline in survival probability.
# 
# Final Thoughts
# Individual survival curves allow personalized risk assessment.
# Comparing multiple patients helps visualize how different risk factors affect survival.
# The RSF model provides time-dependent probabilities, improving decision-making for treatment strategies.
# Risk Stratification Using Random Survival Forest (RSF)
# To improve clinical decision-making, we can stratify patients into high-risk and low-risk groups based on their predicted survival probabilities.
# ________________________________________
# 1. Define Risk Groups Using Predicted Survival
#We classify patients into low-risk vs. high-risk groups based on median survival probability at a fixed time (e.g., 180 days).
# Predict survival probabilities for the entire dataset
predictions <- predict(final_model, newdata = dat)
# Choose a time point for risk stratification (e.g., 180 days)
time_point <- 180
# Find the closest time index
closest_index <- which.min(abs(final_model$time.interest - time_point))
# Extract survival probabilities at the chosen time point
survival_probs <- predictions$survival[, closest_index]
# Define risk groups (High risk: Survival Prob < Median, Low risk: Survival Prob ≥ Median)
median_survival <- median(survival_probs)
dat$risk_group <- ifelse(survival_probs < median_survival, "High Risk", "Low Risk")
# Convert to factor for plotting
dat$risk_group <- factor(dat$risk_group, levels = c("Low Risk", "High Risk"))
# Print the first few classifications
head(dat[, c("time", "status", "risk_group")])
# 2. Kaplan-Meier Survival Curves for Risk Groups
# We now visualize the survival differences between low-risk and high-risk patients.
library(survival)
library(survminer)

# Fit Kaplan-Meier survival curves for risk groups
km_fit <- survfit(Surv(time, status) ~ risk_group, data = dat)

# Plot Kaplan-Meier Curves
ggsurvplot(km_fit, data = dat, 
           risk.table = TRUE, pval = TRUE, 
           conf.int = TRUE, 
           ggtheme = theme_minimal(),
           title = "Kaplan-Meier Survival Curves for Risk Groups",
           xlab = "Time (Days)", ylab = "Survival Probability",
           legend.title = "Risk Group",
           palette = c("blue", "red"))
# Interpretation:
#   •	The blue curve (low-risk group) has higher survival probabilities over time.
# •	The red curve (high-risk group) declines faster, indicating worse survival outcomes.
# •	The p-value assesses statistical significance between the two curves.
# ________________________________________
# 3. Compute Hazard Ratios Between Risk Groups
# To quantify the survival difference, we fit a Cox proportional hazards model.
# cox_model <- coxph(Surv(time, status) ~ risk_group, data = dat)
summary(cox_model)
# Key Outputs:
#   •	Hazard Ratio (HR): Measures risk of death in the high-risk group relative to the low-risk group.
# •	p-value: Tests if the risk groups are significantly different.
# A HR > 1 means the high-risk group has a higher risk of death.
# Final Thoughts
# Risk stratification helps identify patients with poor prognosis.
# Kaplan-Meier curves clearly show survival differences.
# Cox regression quantifies risk differences between groups.
# Personalized Treatment Effect Predictions Using Random Survival Forest (RSF)
# To personalize treatment decisions, we will analyze how different treatments affect survival for individual patients.
# ________________________________________
# 1. Estimate Individual Treatment Effects (ITE)
# The individual treatment effect (ITE) estimates how much a treatment improves or worsens survival for a given patient.
# Step 1: Predict Survival for Each Patient Under Different Treatments
# We compute survival curves with and without treatment to measure treatment impact.
# Define two datasets: one assuming all patients get Treatment 1, another for Treatment 2
dat_t1 <- dat
dat_t2 <- dat
dat_t1$trt <- factor(1, levels = levels(dat$trt))  # Assume all patients get Treatment 1
dat_t2$trt <- factor(2, levels = levels(dat$trt))  # Assume all patients get Treatment 2
# Predict survival probabilities for both treatment scenarios
pred_t1 <- predict(final_model, newdata = dat_t1)
pred_t2 <- predict(final_model, newdata = dat_t2)
# Choose a time point to measure treatment effect (e.g., 180 days)
time_point <- 180
closest_index <- which.min(abs(final_model$time.interest - time_point))

# Compute Individual Treatment Effect (ITE) for each patient
ite <- pred_t2$survival[, closest_index] - pred_t1$survival[, closest_index]
# Add ITE to the dataset
dat$ITE <- ite
# Print the first few patients with ITE values
head(dat[, c("time", "status", "trt", "ITE")])
# Interpretation:
#   •	Positive ITE → Treatment 2 improves survival more than Treatment 1.
# •	Negative ITE → Treatment 1 is better than Treatment 2.
# ________________________________________
# 2. Visualizing Treatment Effect
# We plot the distribution of ITE scores across patients.
library(ggplot2)
ggplot(dat, aes(x = ITE, fill = trt)) +
  geom_histogram(alpha = 0.6, bins = 30) +
  theme_minimal() +
  labs(title = "Distribution of Individual Treatment Effects",
       x = "Individual Treatment Effect (Survival Difference at 180 Days)",
       y = "Number of Patients") +
  scale_fill_manual(values = c("blue", "red"), name = "Treatment")
# Interpretation:
#   •	If most ITE values are above zero, Treatment 2 is generally better.
# •	If most ITE values are below zero, Treatment 1 is more beneficial.
# ________________________________________
# 3. Kaplan-Meier Curves for Each Treatment Group
# To further compare treatments, we plot Kaplan-Meier survival curves.
km_fit_trt <- survfit(Surv(time, status) ~ trt, data = dat)
ggsurvplot(km_fit_trt, data = dat, 
           risk.table = TRUE, pval = TRUE, 
           conf.int = TRUE,
           ggtheme = theme_minimal(),
           title = "Kaplan-Meier Survival Curves by Treatment Group",
           xlab = "Time (Days)", ylab = "Survival Probability",
           legend.title = "Treatment",
           palette = c("blue", "red"))
# Interpretation:
#   •	If the two survival curves separate, one treatment is more effective.
# •	A p-value < 0.05 suggests a significant survival difference.
# ________________________________________
# 4. Identify Patients Who Benefit Most from Treatment
#We can find the patients who benefit most from Treatment 2 by selecting those with highest ITE scores.
# Top 5 patients who benefit most from Treatment 2
best_treatment_2 <- dat[order(-dat$ITE), ][1:5, ]
# Top 5 patients who benefit most from Treatment 1
best_treatment_1 <- dat[order(dat$ITE), ][1:5, ]
print("Patients who benefit most from Treatment 2:")
print(best_treatment_2[, c("age", "celltype", "karno", "ITE")])

print("Patients who benefit most from Treatment 1:")
print(best_treatment_1[, c("age", "celltype", "karno", "ITE")])
# Interpretation:
#   •	Younger patients with high Karnofsky scores might benefit more from one treatment.
# •	Older patients or those with aggressive cancer types may respond differently.
# ________________________________________
# Final Thoughts
# Individual treatment effects (ITE) predict personalized survival benefits.
# Kaplan-Meier curves confirm overall treatment impact.
# We can identify patients who benefit the most from a specific treatment.
# Machine Learning-Based Subgroup Analysis for Personalized Treatment Selection
# We will use random survival forests (RSF) and decision trees to identify patient subgroups that benefit the most from a specific treatment.
# ________________________________________
# 1. Train a Decision Tree to Identify Treatment-Responsive Subgroups
# We use a conditional inference tree (ctree) to find subgroups based on patient characteristics.

library(partykit)
# Define outcome variable (survival time and event status)
dat$SurvObj <- with(dat, Surv(time, status))
# Train a conditional inference tree to identify patient subgroups
subgroup_model <- ctree(SurvObj ~ trt + age + celltype + karno + diagtime + prior, data = dat)

# Plot the decision tree
plot(subgroup_model, main = "Decision Tree for Identifying Treatment-Responsive Subgroups")
# Interpretation:
#   •	Each split represents a decision rule (e.g., "Age < 60?").
# •	The tree divides patients into subgroups, showing which factors affect treatment response.
# •	The leaf nodes show average survival outcomes per subgroup.
________________________________________
# 2. Kaplan-Meier Curves for Subgroups
# We now plot Kaplan-Meier curves for the identified subgroups to compare survival rates.
# Extract subgroup labels from the tree
dat$subgroup <- predict(subgroup_model, type = "response")
# Fit Kaplan-Meier survival curves for subgroups
km_fit_subgroups <- survfit(Surv(time, status) ~ subgroup, data = dat)
# Plot survival curves
ggsurvplot(km_fit_subgroups, data = dat,
           risk.table = TRUE, pval = TRUE, 
           conf.int = TRUE,
           ggtheme = theme_minimal(),
           title = "Survival Curves for Patient Subgroups",
           xlab = "Time (Days)", ylab = "Survival Probability",
           legend.title = "Subgroup")
# Interpretation:
#   •	Different subgroups have distinct survival probabilities.
# •	A p-value < 0.05 suggests significant survival differences among subgroups.
# ________________________________________
# 3. Identify Best Treatment for Each Subgroup
# We now check which treatment works best within each subgroup.
# Fit a Cox model to compare treatments within subgroups
cox_model_subgroup <- coxph(Surv(time, status) ~ subgroup * trt, data = dat)
# Print summary
summary(cox_model_subgroup)
# Interpretation:
#   •	If the interaction term (subgroup * trt) is significant, it means treatment effectiveness depends on the subgroup.
# •	We can identify which subgroup benefits the most from a specific treatment.
4. Machine Learning-Based Feature Importance for Subgroup Discovery
Instead of a decision tree, we can use the random survival forest (RSF) model to rank the most important factors that define treatment response.
# Compute variable importance from the RSF model
var_importance <- vimp(final_model)
# Plot variable importance
plot(var_importance, main = "Feature Importance for Predicting Treatment Response")
Interpretation:
  •	Features with higher importance scores are strong predictors of treatment response.
•	Example: If Karnofsky score is the most important, then patients with better functional status may benefit more from treatment.

Final Thoughts
Decision trees identify patient subgroups that respond differently to treatment.
Kaplan-Meier curves confirm survival differences across subgroups.
Machine learning models rank the most important predictors of treatment response.

