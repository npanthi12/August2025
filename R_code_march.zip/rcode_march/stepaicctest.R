if(TRUE){
t1time <- Sys.time()
t1time<- as.POSIXct(t1time)
library(openxlsx)
library(dplyr)
library(SurvMetrics)
library(haven)

indat <- read_sas("~/dat.sas7bdat")%>%
  filter(PDAC1LFL!="Y", COHORT11!="Y", PDACWTFL!="Y")


slpdat1 <- openxlsx::read.xlsx("~/slopelognlr_pdac.xlsx")

slpdat2 <- openxlsx::read.xlsx("~/slopetllpchg_pdac.xlsx")

d0 <- indat%>%filter(CHDXCLAS =="PANCREATIC")%>%left_join(slpdat1)%>%left_join(slpdat2)


dat0 <- d0%>%
  mutate(PFSAVAL=PFSISDEAVAL, PFSCNSR=PFSISDECNSR)%>%
  mutate(time=PFSAVAL, evnt=1-PFSCNSR)%>%
  mutate(
    BLNLR=as.numeric(round(BLNLR,2)))%>%
  filter(C1D1DS%in%c(120, 160, 200, 220, 300))
#filter(!is.na(RAS_Percentage_Change))

dat <- dat0


covs <- c("BLNLR",  "BLSOD", "C1D1DS", "C1D1DGP", "C1D1DGP1", "MMLNPTM", "BLLMETS", "BLBNMETS", "BLBMETS","BLECOGN","SEX", "PT5FUCFL", "PT5CMFL", "GISUABFL", "PTGEMCFL", "PTGCMFL", "TLAPANFL","PMELESFL", "AGE", "AGEGR3", "WEIGHT",  "PANCRESFL", "AGEDIAG", "METASTN",
          "SMKSTAT2", "RASGRPCAT1", "RASGRPCAT", "BLALB")


covs_cont1 <- c("BLNLR", "BLSOD",  "C1D1DS", "AGE",  "WEIGHT", "AGEDIAG", "METASTN", "BLALB")


# covs <- c("C1D1DS_quart", "C1D1DGP", "C1D1DGP1",  "LNPTM_quart","LNPTMCT4","LNPTCAT6","BLLMETS","BLBNMETS","BLECOGN", "SEX", "AGE_quart", "AGEGR1", "BLSOD_quart", "SMKSTAT2", "BLBMETS", "TLLUNGFL", "CHSTGGRP", "CPI90FLA",
#  "ICDY_quart", "BLALB_quart", "BLNLR_quart", "RAS_Detected_Pre", "RASGRPCAT2", "RASGRPCAT3",  "BLWTKG_quart")

exp_variable <- c("")
exp_variable_derived <- c("")
resp <- c("PFSISDEAVAL", "PFSISDECNSR")
resp_char <- "Progression-Free Survival"
pop <- 'CHDXCLAS =="PANCREATIC"'
pop_char <- "all treated PDAC subjects in 6236 study data"
corv <- 0.8
mincrit <- 0
minbuc <-0
minspl <- 0
ntre <- 500
sed <- 1234


library(haven)
library(survminer)
library(dplyr)
library(Hmisc)
library(AICcmodavg)
library(car)
library(broom)
library(cobalt)
library(ipw)
library(survey)
library(WeightIt)
library(glmtoolbox)
library(MatchIt)
library(MuMIn)
library(purrr)
library("survival")
library("survminer")
library(emmeans)
library(randomForestSRC)
library(ranger)
library(openxlsx)
library(randomForest)
library(dplyr)
library(ggraph)
library(igraph)
library(caret)
library(rpart.plot)
library(rpart)
library(party)
library(ggsurvfit)
library(visdat)
library(plotly)
library(GGally)
library(permimp)
library(DT)
library(ggsurvfit)
library(ggcorrplot)
library(tidyverse)
library(rcompanion)
library(knitr)
library(polycor)
library(StepReg)
library(pec)
#Import dataset
fin <- dat
findat20 <- fin%>%
  dplyr::filter_(pop)%>%
  dplyr::select(everything())

findat21 <- findat20%>%dplyr::select(all_of(covs), all_of(resp))
#Step1: Describe fin1 to get missing covariates
#Step2: Make a note of missing covaritaes
#Step3: Change missing covariates into factor
#Step1
covs11 <- c(covs[!covs%in%c("")], resp)
covs11
describe(findat21%>%dplyr::select(all_of(covs11)))
da <- findat21%>%dplyr::select(all_of(covs11))
data <- replace(da, da == "", NA)
da1 <- sapply(data, function(x) sum(is.na(x)))
names(da1[da1>0])
#cont <- c("BLALB", "ICDY", "BLSOD",  "AGE", "LNPTM", "C1D1DS", "BLNLR") 

#Step2
covs_miss <- names(da1[da1>0])

#Step3


findat22 <- data%>%dplyr::select(all_of(covs11))%>%
  drop_na()%>%
  dplyr::mutate_if(is.character, as.factor)%>%
  dplyr::mutate(evnt=1-PFSISDECNSR, time=PFSISDEAVAL)


if (TRUE){
  covs_miss <- colnames(data)[apply(is.na(data), 2, any)]
  covs_miss
  findat2 <- findat22
  findat2 <- as.data.frame(findat2)
  B <- 50000
  dim(findat2)
  
  covs <- colnames(findat2)[!colnames(findat2)%in%c(resp[1], resp[2], "time", "evnt")]
  form <- f.build("Surv(time,evnt)", covs)
  form
  
  findat2a <- findat2%>%
    dplyr::mutate(evnt=1-PFSISDECNSR, time=PFSISDEAVAL)
  
  fit <- coxph(form, data = findat2a, ties="breslow", x=TRUE)
  fit
  
}
}

source("~/stepAICC_1.R")
runAICC(fit, direction=c("both"))
library(MASS)
stepAIC(fit, direction="both")

object <- fit
direction <- "both"
scale=0
trace=1
keep=NULL
steps=1000
k=2
direction = c("both", "backward", 
              "forward")
runAICC <- function (object, scope, scale = 0, direction = c("both", "backward", 
                                                             "forward"), trace = 1, 
                     keep = NULL, steps = 1000, k = 2, 
                     ...) 
{

  Terms <- terms(object)
  object$call$formula <- object$formula <- Terms
  
  md <- missing(direction)
  direction <- match.arg(direction)
  backward <- direction == "both" | direction == "backward"
  forward <- direction == "both" | direction == "forward"
  
  
  if (missing(scope)) {
    fdrop <- numeric()
    fadd <- attr(Terms, "factors")
    if (md) 
      forward <- FALSE
  }
  else {
    if (is.list(scope)) {
      fdrop <- if (!is.null(fdrop <- scope$lower)) 
        attr(terms(update.formula(object, fdrop)), "factors")
      else numeric()
      fadd <- if (!is.null(fadd <- scope$upper)) 
        attr(terms(update.formula(object, fadd)), "factors")
    }
    else {
      fadd <- if (!is.null(fadd <- scope)) 
        attr(terms(update.formula(object, scope)), "factors")
      fdrop <- numeric()
    }
  }
  models <- vector("list", steps)
  if (!is.null(keep)) 
    keep.list <- vector("list", steps)
  n <- nobs(object, use.fallback = TRUE)
  fit <- object
  bAIC <- extractAIC(fit, scale, k = k, ...)
  edf <- bAIC[1L]
  bAIC <- bAIC[2L]+2*edf*(edf + 1) / (fit$n - edf - 1)
  if (is.na(bAIC)) 
    stop("AICc is not defined for this model, so 'step' cannot proceed")
  if (bAIC == -Inf) 
    stop("AICc is -infinity for this model, so 'step' cannot proceed")
  nm <- 1
  
  cut.string <- function(string) {
    if (length(string) > 1L) 
      string[-1L] <- paste0("\n", string[-1L])
    string
  }
  
  if (trace) {
    cat("Start:  AICc=", format(round(bAIC, 2)), "\n", cut.string(deparse(formula(fit))), 
        "\n\n", sep = "")
    flush.console()
  }
  mydeviance <- function(x, ...) deviance(x) %||% extractAIC(x, 
                                                             k = 0)[2L]
  models[[nm]] <- list(deviance = mydeviance(fit), df.resid = n - 
                         edf, change = "", AICc = bAIC)
  if (!is.null(keep)) 
    keep.list[[nm]] <- keep(fit, bAIC)
  usingCp <- FALSE
  while (steps > 0) {
    steps <- steps - 1
    AICc <- bAIC
    ffac <- attr(Terms, "factors")
    scope <- factor.scope(ffac, list(add = fadd, drop = fdrop))
    aod <- NULL
    change <- NULL
    if (backward && length(scope$drop)) {
      aod <- rdrop(fit, scope$drop, scale = scale, trace = trace, 
                   k = k, ...)
      rn <- row.names(aod)
      row.names(aod) <- c(rn[1L], paste("-", rn[-1L]))
      if (any(aod$Df == 0, na.rm = TRUE)) {
        zdf <- aod$Df == 0 & !is.na(aod$Df)
        change <- rev(rownames(aod)[zdf])[1L]
      }
    }
    if (is.null(change)) {
      if (forward && length(scope$add)) {
        aodf <- add1(fit, scope$add, scale = scale, trace = trace, 
                     k = k, ...)
        rn <- row.names(aodf)
        row.names(aodf) <- c(rn[1L], paste("+", rn[-1L]))
        aod <- if (is.null(aod)) 
          aodf
        else rbind(aod, aodf[-1, , drop = FALSE])
      }
      attr(aod, "heading") <- NULL
      nzdf <- if (!is.null(aod$Df)) 
        aod$Df != 0 | is.na(aod$Df)
      aod <- aod[nzdf, ]
      if (is.null(aod) || ncol(aod) == 0) 
        break
      nc <- match(c("Cp", "AICc"), names(aod))
      nc <- nc[!is.na(nc)][1L]
      o <- order(aod[, nc])
      if (trace) 
        print(aod[o, ])
      if (o[1L] == 1) 
        break
      change <- rownames(aod)[o[1L]]
    }
    usingCp <- match("Cp", names(aod), 0L) > 0L
    fit <- update(fit, paste("~ .", change), evaluate = FALSE)
    fit <- eval.parent(fit)
    nnew <- nobs(fit, use.fallback = TRUE)
    if (all(is.finite(c(n, nnew))) && nnew != n) 
      stop("number of rows in use has changed: remove missing values?")
    Terms <- terms(fit)
    bAIC <- extractAIC(fit, scale, k = k, ...)
    edf <- bAIC[1L]
    bAIC <-bAIC[2L]+2*edf*(edf + 1) / (fit$n - edf - 1)
    if (trace) {
      cat("\nStep:  AICc=", format(round(bAIC, 2)), "\n", 
          cut.string(deparse(formula(fit))), "\n\n", sep = "")
      flush.console()
    }
    if (bAIC >= AICc + 1e-07) 
      break
    nm <- nm + 1
    models[[nm]] <- list(deviance = mydeviance(fit), df.resid = n - 
                           edf, change = change, AICc = bAIC)
    if (!is.null(keep)) 
      keep.list[[nm]] <- keep(fit, bAIC)
  }
  re.arrange <- function(keep) {
    namr <- names(k1 <- keep[[1L]])
    namc <- names(keep)
    nc <- length(keep)
    nr <- length(k1)
    array(unlist(keep, recursive = FALSE), c(nr, nc), list(namr, 
                                                           namc))
  }
  if (!is.null(keep)) 
    fit$keep <- re.arrange(keep.list[seq(nm)])
  
  
  
  step.results <- function(models, fit, object, usingCp = FALSE) {
    change <- sapply(models, `[[`, "change")
    rd <- sapply(models, `[[`, "deviance")
    dd <- c(NA, abs(diff(rd)))
    rdf <- sapply(models, `[[`, "df.resid")
    ddf <- c(NA, diff(rdf))
    AICc <- sapply(models, `[[`, "AICc")
    heading <- c("Stepwise Model Path \nAnalysis of Deviance Table", 
                 "\nInitial Model:", deparse(formula(object)), "\nFinal Model:", 
                 deparse(formula(fit)), "\n")
    aod <- data.frame(Step = I(change), Df = ddf, Deviance = dd, 
                      `Resid. Df` = rdf, `Resid. Dev` = rd, AICc = AICc, 
                      check.names = FALSE)
    if (usingCp) {
      cn <- colnames(aod)
      cn[cn == "AICc"] <- "Cp"
      colnames(aod) <- cn
    }
    attr(aod, "heading") <- heading
    fit$anova <- aod
    fit
  }
  step.results(models = models[seq(nm)], fit, object, usingCp)
}
runAICC(fit, direction="both")
stepAIC(fit, direction="both")
stp(fit, direction="both")
stp <- function (object, scope, scale = 0, direction = c("both", "backward", 
                                                         "forward"), trace = 1, keep = NULL, steps = 1000, use.start = FALSE, 
                 k = 2, ...) 
{
  mydeviance <- function(x, ...) {
    dev <- deviance(x)
    if (!is.null(dev)) 
      dev
    else extractAIC(x, k = 0)[2L]
  }
  cut.string <- function(string) {
    if (length(string) > 1L) 
      string[-1L] <- paste("\n", string[-1L], sep = "")
    string
  }
  re.arrange <- function(keep) {
    namr <- names(k1 <- keep[[1L]])
    namc <- names(keep)
    nc <- length(keep)
    nr <- length(k1)
    array(unlist(keep, recursive = FALSE), c(nr, nc), list(namr, 
                                                           namc))
  }
  step.results <- function(models, fit, object, usingCp = FALSE) {
    change <- sapply(models, "[[", "change")
    rd <- sapply(models, "[[", "deviance")
    dd <- c(NA, abs(diff(rd)))
    rdf <- sapply(models, "[[", "df.resid")
    ddf <- c(NA, abs(diff(rdf)))
    AIC <- sapply(models, "[[", "AIC")
    heading <- c("Stepwise Model Path \nAnalysis of Deviance Table", 
                 "\nInitial Model:", deparse(formula(object)), "\nFinal Model:", 
                 deparse(formula(fit)), "\n")
    aod <- if (usingCp) 
      data.frame(Step = change, Df = ddf, Deviance = dd, 
                 `Resid. Df` = rdf, `Resid. Dev` = rd, Cp = AIC, 
                 check.names = FALSE)
    else data.frame(Step = change, Df = ddf, Deviance = dd, 
                    `Resid. Df` = rdf, `Resid. Dev` = rd, AIC = AIC, 
                    check.names = FALSE)
    attr(aod, "heading") <- heading
    class(aod) <- c("Anova", "data.frame")
    fit$anova <- aod
    fit
  }
  Terms <- terms(object)
  object$formula <- Terms
  if (inherits(object, "lme")) 
    object$call$fixed <- Terms
  else if (inherits(object, "gls")) 
    object$call$model <- Terms
  else object$call$formula <- Terms
  if (use.start) 
    warning("'use.start' cannot be used with R's version of 'glm'")
  md <- missing(direction)
  direction <- match.arg(direction)
  backward <- direction == "both" | direction == "backward"
  forward <- direction == "both" | direction == "forward"
  if (missing(scope)) {
    fdrop <- numeric()
    fadd <- attr(Terms, "factors")
    if (md) 
      forward <- FALSE
  }
  else {
    if (is.list(scope)) {
      fdrop <- if (!is.null(fdrop <- scope$lower)) 
        attr(terms(update.formula(object, fdrop)), "factors")
      else numeric()
      fadd <- if (!is.null(fadd <- scope$upper)) 
        attr(terms(update.formula(object, fadd)), "factors")
    }
    else {
      fadd <- if (!is.null(fadd <- scope)) 
        attr(terms(update.formula(object, scope)), "factors")
      fdrop <- numeric()
    }
  }
  models <- vector("list", steps)
  if (!is.null(keep)) 
    keep.list <- vector("list", steps)
  n <- nobs(object, use.fallback = TRUE)
  fit <- object
  bAIC <- extractAIC(fit, scale, k = k, ...)
  edf <- bAIC[1L]
  bAIC <- bAIC[2L]
  if (is.na(bAIC)) 
    stop("AIC is not defined for this model, so 'stepAIC' cannot proceed")
  if (bAIC == -Inf) 
    stop("AIC is -infinity for this model, so 'stepAIC' cannot proceed")
  nm <- 1
  Terms <- terms(fit)
  if (trace) {
    cat("Start:  AIC=", format(round(bAIC, 2)), "\n", cut.string(deparse(formula(fit))), 
        "\n\n", sep = "")
    utils::flush.console()
  }
  models[[nm]] <- list(deviance = mydeviance(fit), df.resid = n - 
                         edf, change = "", AIC = bAIC)
  if (!is.null(keep)) 
    keep.list[[nm]] <- keep(fit, bAIC)
  usingCp <- FALSE
  while (steps > 0) {
    steps <- steps - 1
    AIC <- bAIC
    ffac <- attr(Terms, "factors")
    if (!is.null(sp <- attr(Terms, "specials")) && !is.null(st <- sp$strata)) 
      ffac <- ffac[-st, ]
    scope <- factor.scope(ffac, list(add = fadd, drop = fdrop))
    aod <- NULL
    change <- NULL
    if (backward && length(scope$drop)) {
      aod <- dropterm(fit, scope$drop, scale = scale, trace = max(0, 
                                                                  trace - 1), k = k, ...)
      rn <- row.names(aod)
      row.names(aod) <- c(rn[1L], paste("-", rn[-1L], sep = " "))
      if (any(aod$Df == 0, na.rm = TRUE)) {
        zdf <- aod$Df == 0 & !is.na(aod$Df)
        nc <- match(c("Cp", "AIC"), names(aod))
        nc <- nc[!is.na(nc)][1L]
        ch <- abs(aod[zdf, nc] - aod[1, nc]) > 0.01
        if (any(is.finite(ch) & ch)) {
          warning("0 df terms are changing AIC")
          zdf <- zdf[!ch]
        }
        if (length(zdf) > 0L) 
          change <- rev(rownames(aod)[zdf])[1L]
      }
    }
    if (is.null(change)) {
      if (forward && length(scope$add)) {
        aodf <- addterm(fit, scope$add, scale = scale, 
                        trace = max(0, trace - 1), k = k, ...)
        rn <- row.names(aodf)
        row.names(aodf) <- c(rn[1L], paste("+", rn[-1L], 
                                           sep = " "))
        aod <- if (is.null(aod)) 
          aodf
        else rbind(aod, aodf[-1, , drop = FALSE])
      }
      attr(aod, "heading") <- NULL
      if (is.null(aod) || ncol(aod) == 0) 
        break
      nzdf <- if (!is.null(aod$Df)) 
        aod$Df != 0 | is.na(aod$Df)
      aod <- aod[nzdf, ]
      if (is.null(aod) || ncol(aod) == 0) 
        break
      nc <- match(c("Cp", "AIC"), names(aod))
      nc <- nc[!is.na(nc)][1L]
      o <- order(aod[, nc])
      if (trace) {
        print(aod[o, ])
        utils::flush.console()
      }
      if (o[1L] == 1) 
        break
      change <- rownames(aod)[o[1L]]
    }
    usingCp <- match("Cp", names(aod), 0) > 0
    fit <- update(fit, paste("~ .", change), evaluate = FALSE)
    fit <- eval.parent(fit)
    nnew <- nobs(fit, use.fallback = TRUE)
    if (all(is.finite(c(n, nnew))) && nnew != n) 
      stop("number of rows in use has changed: remove missing values?")
    Terms <- terms(fit)
    bAIC <- extractAIC(fit, scale, k = k, ...)
    edf <- bAIC[1L]
    bAIC <- bAIC[2L]
    if (trace) {
      cat("\nStep:  AIC=", format(round(bAIC, 2)), "\n", 
          cut.string(deparse(formula(fit))), "\n\n", sep = "")
      utils::flush.console()
    }
    if (bAIC >= AIC + 1e-07) 
      break
    nm <- nm + 1
    models[[nm]] <- list(deviance = mydeviance(fit), df.resid = n - 
                           edf, change = change, AIC = bAIC)
    if (!is.null(keep)) 
      keep.list[[nm]] <- keep(fit, bAIC)
  }
  if (!is.null(keep)) 
    fit$keep <- re.arrange(keep.list[seq(nm)])
  step.results(models = models[seq(nm)], fit, object, usingCp)
}
