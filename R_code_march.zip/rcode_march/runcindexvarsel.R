

addterm <-
  function(object, dat, scope, scale = 0, test = c("none", "Chisq"),
           k = 0, sorted = FALSE, trace = FALSE, ...)
  {
    if(missing(scope) || is.null(scope)) stop("no terms in scope")
    if(!is.character(scope))
      scope <- add.scope(object, update.formula(object, scope))
    if(!length(scope))
      stop("no terms in scope for adding to object")
    #     newform <- update.formula(object,
    #                               paste(". ~ . +", paste(scope, collapse="+")))
    #     data <- model.frame(update(object, newform)) # remove NAs
    #     object <- update(object, data = data)
    ns <- length(scope)
    ans <- matrix(nrow = ns + 1L, ncol = 2L,
                  dimnames = list(c("<none>", scope), c("df", "Cindex")))
    ###change
    redf <- extractAIC(object, scale, k = k)[1L]
    rAIC <- 1-SurvMetrics::Cindex(object, dat)[[1]]
    #rAIC <- 1-summary(object)$concordance[[1]]
    ans[1, ] <- c(redf, rAIC)
    ###change
    #ans[1L,  ] <- extractAIC(object, scale, k = k, ...)
    n0 <- nobs(object, use.fallback = TRUE)
    env <- environment(formula(object))
    for(i in seq_len(ns)) {
      tt <- scope[i]
      if(trace) {
        message(gettextf("trying + %s", tt), domain = NA)
        utils::flush.console()
      }
      nfit <- update(object, as.formula(paste("~ . +", tt)),
                     evaluate = FALSE)
      nfit <- try(eval(nfit, envir = env), silent = TRUE)
      ans[i + 1L, ] <- if (!inherits(nfit, "try-error")) {
        nnew <- nobs(nfit, use.fallback = TRUE)
        if (all(is.finite(c(n0, nnew))) && nnew != n0)
          stop("number of rows in use has changed: remove missing values?")
        ##Change
        redf <- extractAIC(nfit, scale, k = k)[1L]
        rAICc <- 1-SurvMetrics::Cindex(nfit, dat)[[1]]
        #rAICc <- 1-summary(nfit)$concordance[[1]]
        c(redf, rAICc)
        ##Change
        #extractAIC(nfit, scale, k = k, ...)
      } else NA_real_
    }
    dfs <- ans[, 1L] - ans[1L, 1L]
    dfs[1L] <- NA
    aod <- data.frame(Df = dfs, Cindex = ans[, 2L])
    o <- if(sorted) order(aod$Cindex) else seq_along(aod$Cindex)
    test <- match.arg(test)
    if(test == "Chisq") {
      dev <- ans[, 2L] - k*ans[, 1L]
      dev <- dev[1L] - dev; dev[1L] <- NA
      nas <- !is.na(dev)
      P <- dev
      P[nas] <- safe_pchisq(dev[nas], dfs[nas], lower.tail=FALSE)
      aod[, c("LRT", "Pr(Chi)")] <- list(dev, P)
    }
    aod <- aod[o, ]
    head <- c("Single term additions", "\nModel:", deparse(formula(object)))
    if(scale > 0)
      head <- c(head, paste("\nscale: ", format(scale), "\n"))
    class(aod) <- c("anova", "data.frame")
    attr(aod, "heading") <- head
    aod
  }



# object <- fit
# scale = 0
# test = c("none")
# k=2
# sorted=FALSE
# trace=FALSE
# scope=NULL
dropterm <-function(object, dat, scope, scale = 0, test = c("none", "Chisq"),
                    k = 2, sorted = FALSE, trace = FALSE, ...)
{
  tl <- attr(terms(object), "term.labels")
  if(missing(scope)) scope <- drop.scope(object)else {
    if(!is.character(scope))
      scope <- attr(terms(update.formula(object, scope)), "term.labels")
    if(!all(match(scope, tl, 0L)))
      stop("scope is not a subset of term labels")
  }
  ns <- length(scope)
  ans <- matrix(nrow = ns + 1L, ncol = 2L,
                dimnames =  list(c("<none>", scope), c("df", "Cindex")))
  ##change
  redf <- extractAIC(object, scale, k = k)[1L]
  rAICc <- 1-SurvMetrics::Cindex(object, dat)[[1]]
  #rAICc <- 1-summary(fit)$concordance[[1]]
  ans[1, ] <- c(redf, rAICc)
  ##change
  #ans[1,  ] <- extractAIC(object, scale, k = k, ...)
  n0 <- nobs(object, use.fallback = TRUE)
  env <- environment(formula(object))
  for(i in seq_len(ns)) {
    tt <- scope[i]
    if(trace) {
      message(gettextf("trying - %s", tt), domain = NA)
      utils::flush.console()
    }
    nfit <- update(object, as.formula(paste("~ . -", tt)),
                   evaluate = FALSE)
    nfit <- eval(nfit, envir=env) # was  eval.parent(nfit)
    ###change
    re <- extractAIC(nfit, scale, k = k)[1]
    ans[i + 1L, ] <- c(extractAIC(nfit, scale, k = k)[1],
                       1-SurvMetrics::Cindex(nfit, dat)[[1]])
    # ans[i + 1L, ] <- c(extractAIC(nfit, scale, k = k)[1], 
    #                    1-summary(nfit)$concordance[[1]])
    ###change
    #ans[i+1, ] <- extractAIC(nfit, scale, k = k, ...)
    nnew <- nobs(nfit, use.fallback = TRUE)
    if(all(is.finite(c(n0, nnew))) && nnew != n0)
      stop("number of rows in use has changed: remove missing values?")
  }
  dfs <- ans[1L , 1L] - ans[, 1L]
  dfs[1L] <- NA
  aod <- data.frame(Df = dfs, Cindex = ans[,2])
  o <- if(sorted) order(aod$Cindex) else seq_along(aod$Cindex)
  test <- match.arg(test)
  if(test == "Chisq") {
    dev <- ans[, 2L] - k*ans[, 1L]
    dev <- dev - dev[1L] ; dev[1L] <- NA
    nas <- !is.na(dev)
    P <- dev
    P[nas] <- safe_pchisq(dev[nas], dfs[nas], lower.tail = FALSE)
    aod[, c("LRT", "Pr(Chi)")] <- list(dev, P)
  }
  aod <- aod[o, ]
  head <- c("Single term deletions", "\nModel:", deparse(formula(object)))
  if(scale > 0)
    head <- c(head, paste("\nscale: ", format(scale), "\n"))
  class(aod) <- c("anova", "data.frame")
  attr(aod, "heading") <- head
  aod
  
}











# 
# extractAIC(fit)
# extractAIC(fit, k=0)
# extractAIC(fit, k=1)
# extractAIC(fit, k=2)
# extractAIC(fit, k=0)[2L]#2 log likelihood
# AIC(fit)
# extractAIC(fit, k=0)
# minustwologlik <- extractAIC(fit, k=0)[2]
# p <- extractAIC(fit)[1]
# F <- fit$nevent
# aiccsas <- minustwologlik+2*p*F/(F-p-1)
# aiccsas
# 
# aicsas <- minustwologlik+2*p
# aicsas
# extractAIC(fit, scale=0, k=0)[2]+(2*p*F)/(F-p-1)
# extractAIC(fit, k=0)[2]+(2*extractAIC(fit)[1]*fit$nevent)/(fit$nevent-extractAIC(fit)[1]-1)
# sbcsas <- minustwologlik+p*log(F)
# sbcsas
#AICC=AIC+(2*k*k+2*k)/(&nn-k-1)

runcindex <- function (object, dat, scope, scale = 0, direction = c("both", "backward", 
                                                                    "forward"), trace = 1, keep = NULL, 
                       steps = 1000, k = 0, use.start=FALSE, 
                       ...) 
{
  
  mydeviance <- function(x, ...) {
    dev <- deviance(x)
    if (!is.null(dev)) 
      dev
    else extractAIC(x, k = 0)[2L]
  }
  
  cut.string <- function(string) {
    if (length(string) > 1L) 
      string[-1L] <- paste("\n", string[-1L], sep = "")
    string
  }
  
  re.arrange <- function(keep) {
    namr <- names(k1 <- keep[[1L]])
    namc <- names(keep)
    nc <- length(keep)
    nr <- length(k1)
    array(unlist(keep, recursive = FALSE), c(nr, nc), list(namr, 
                                                           namc))
  }
  
  step.results <- function(models, fit, object, usingCp = FALSE) {
    change <- sapply(models, `[[`, "change")
    rd <- sapply(models, `[[`, "deviance")
    dd <- c(NA, abs(diff(rd)))
    rdf <- sapply(models, `[[`, "df.resid")
    ddf <- c(NA, diff(rdf))
    Cindex <- sapply(models, `[[`, "Cindex")
    
    
    heading <- c("Stepwise Model Path \nAnalysis of Deviance Table", 
                 "\nInitial Model:", deparse(formula(object)), "\nFinal Model:", 
                 deparse(formula(fit)), "\n")
    
    aod <- if (usingCp) 
      data.frame(Step = change, Df = ddf, Deviance = dd, 
                 `Resid. Df` = rdf, `Resid. Dev` = rd, Cp = Cindex, 
                 check.names = FALSE)
    
    else data.frame(Step = change, Df = ddf, Deviance = dd, 
                    `Resid. Df` = rdf, `Resid. Dev` = rd, Cindex = Cindex, 
                    check.names = FALSE)
    
    attr(aod, "heading") <- heading
    class(aod) <- c("Anova", "data.frame")
    fit$anova <- aod
    fit
  }
  
  
  Terms <- terms(object)
  object$formula <- Terms
  if (inherits(object, "lme")) 
    object$call$fixed <- Terms
  else if (inherits(object, "gls")) 
    object$call$model <- Terms
  else object$call$formula <- Terms
  if (use.start) warning("'use.start' cannot be used with R's version of 'glm'")
  md <- missing(direction)
  direction <- "both"
  backward <- direction == "both" | direction == "backward"
  forward <- direction == "both" | direction == "forward"
  
  
  if (missing(scope)) {
    fdrop <- numeric()
    fadd <- attr(Terms, "factors")
    if (md) 
      forward <- FALSE
  }
  else {
    if (is.list(scope)) {
      fdrop <- if (!is.null(fdrop <- scope$lower)) 
        attr(terms(update.formula(object, fdrop)), "factors")
      else numeric()
      fadd <- if (!is.null(fadd <- scope$upper)) 
        attr(terms(update.formula(object, fadd)), "factors")
    }
    else {
      fadd <- if (!is.null(fadd <- scope)) 
        attr(terms(update.formula(object, scope)), "factors")
      fdrop <- numeric()
    }
  }
  models <- vector("list", steps)
  if (!is.null(keep)) 
    keep.list <- vector("list", steps)
  n <- nobs(object, use.fallback = TRUE)
  fit <- object
  
  bAIC <- extractAIC(fit, scale, k = k)
  edf <- bAIC[1L]
  #bAIC <- bAIC[2L]
  #change
  bAIC <- 1-SurvMetrics::Cindex(fit, dat)[[1]] ##change
  #bAIC <- 1-summary(fit)$concordance[[1]]
  # extractAIC(fit, k=0)[2]+(2*p*F)/(F-p-1)
  # extractAIC(fit, k=0)[2]+(2*extractAIC(fit)[1]*fit$nevent)/(fit$nevent-extractAIC(fit)[1]-1)
  #change
  if (is.na(bAIC)) 
    stop("Cindex is not defined for this model, so 'stepcindex' cannot proceed")
  if (bAIC == -Inf) 
    stop("Cindex is -infinity for this model, so 'stepcindex' cannot proceed")
  
  nm <- 1
  Terms <- terms(fit)
  
  if (trace) {
    cat("Start:  Cindex=", format(round(1-bAIC, 5)), "\n", cut.string(deparse(formula(fit))), 
        "\n\n", sep = "")
    utils::flush.console()
  }
  
  models[[nm]] <- list(deviance = mydeviance(fit), df.resid = n - 
                         edf, change = "", Cindex = bAIC)
  
  if (!is.null(keep)) 
    keep.list[[nm]] <- keep(fit, bAIC)
  usingCp <- FALSE
  
  while (steps > 0) {
    steps <- steps - 1
    Cindex <- bAIC
    ffac <- attr(Terms, "factors")
    
    if (!is.null(sp <- attr(Terms, "specials")) && !is.null(st <- sp$strata)) 
      ffac <- ffac[-st, ]
    scope <- factor.scope(ffac, list(add = fadd, drop = fdrop))
    aod <- NULL
    change <- NULL
    
    if (backward && length(scope$drop)) {
      aod <- dropterm(fit, dat, scope$drop, scale = scale, trace = max(0, 
                                                                       trace - 1), k = k)##change
      rn <- row.names(aod)
      row.names(aod) <- c(rn[1L], paste("-", rn[-1L], sep = " "))
      
      if (any(aod$Df == 0, na.rm = TRUE)) {
        zdf <- aod$Df == 0 & !is.na(aod$Df)
        nc <- match(c("Cp", "Cindex"), names(aod))
        nc <- nc[!is.na(nc)][1L]
        ch <- abs(aod[zdf, nc] - aod[1, nc]) > 0.01
        if (any(is.finite(ch) & ch)) {
          warning("0 df terms are changing Cindex")
          zdf <- zdf[!ch]
        }
        if (length(zdf) > 0L) 
          change <- rev(rownames(aod)[zdf])[1L]
      }
      
    }
    
    if (is.null(change)) {
      if (forward && length(scope$add)) {
        aodf <- addterm(fit, dat, scope$add, scale = scale, 
                        trace = max(0, trace - 1), k = k, ...)#change
        rn <- row.names(aodf)
        row.names(aodf) <- c(rn[1L], paste("+", rn[-1L], 
                                           sep = " "))
        aod <- if (is.null(aod)) 
          aodf
        else rbind(aod, aodf[-1, , drop = FALSE])
      }
      attr(aod, "heading") <- NULL
      if (is.null(aod) || ncol(aod) == 0) 
        break
      nzdf <- if (!is.null(aod$Df)) 
        aod$Df != 0 | is.na(aod$Df)
      aod <- aod[nzdf, ]
      if (is.null(aod) || ncol(aod) == 0) 
        break
      nc <- match(c("Cp", "Cindex"), names(aod))
      nc <- nc[!is.na(nc)][1L]
      o <- order(aod[, nc])
      if (trace) {
        print(aod[o, ])
        utils::flush.console()
      }
      if (o[1L] == 1) 
        break
      change <- rownames(aod)[o[1L]]
    }
    usingCp <- match("Cp", names(aod), 0) > 0
    fit <- update(fit, paste("~ .", change), evaluate = FALSE)
    fit <- eval.parent(fit)
    nnew <- nobs(fit, use.fallback = TRUE)
    if (all(is.finite(c(n, nnew))) && nnew != n) 
      stop("number of rows in use has changed: remove missing values?")
    
    Terms <- terms(fit)
    bAIC <- extractAIC(fit, scale, k = k, ...)
    edf <- bAIC[1L]
    #bAIC <- bAIC[2L]
    #change
    
    bAIC <-1-SurvMetrics::Cindex(fit, dat)[[1]]#change
    #bAIC <- 1-summary(fit)$concordance[[1]]
    # extractAIC(fit, k=0)[2]+(2*p*F)/(F-p-1)
    # extractAIC(fit, k=0)[2]+(2*extractAIC(fit)[1]*fit$nevent)/(fit$nevent-extractAIC(fit)[1]-1)
    #change
    if (trace) {
      cat("\nStep:  Cindex=", format(round(1-bAIC, 5)), "\n", 
          cut.string(deparse(formula(fit))), "\n\n", sep = "")
      
      utils::flush.console()
    }
    if (bAIC >= Cindex + 1e-07) 
      break
    nm <- nm + 1
    models[[nm]] <- list(deviance = mydeviance(fit), df.resid = n - 
                           edf, change = change, Cindex = bAIC)
    
    if (!is.null(keep)) 
      keep.list[[nm]] <- keep(fit, bAIC)
  }
  if (!is.null(keep)) 
    fit$keep <- re.arrange(keep.list[seq(nm)])
  step.results(models = models[seq(nm)], fit, object, usingCp)
}

step_cindex <- function(object, dat, ..., trace = 0,
                     k = 2) {
  if(isTRUE(object$call$trace)) {
    warning("Trace detected. Turning it off.", immediate. = TRUE)
    call <- substitute(update(OBJ, trace = FALSE),
                       list(OBJ = substitute(object)))
    object <- eval.parent(call)
  }
  out <- runcindex(object, dat, ..., trace = trace, k = k)
  attr(out, "penalty") <- k
  out
}

#' @rdname step_cindex
#' @export
drop_termcindex <- function(object, ..., test = default_test(object), k, 
                      sorted = TRUE, decreasing = TRUE, delta  = TRUE) {
  if(!isS4(object) && isTRUE(object$call$trace)) {
    warning("Trace detected. Turning it off.", immediate. = TRUE)
    call <- substitute(update(OBJ, trace = FALSE),
                       list(OBJ = substitute(object)))
    object <- eval.parent(call)
  }
  k <- if(missing(k)) {
    p <- attr(object, "penalty")
    ifelse(is.null(p), 2, p)
  } else {
    if(is.character(k)) {
      switch(tolower(k),
             bic = max(2, log(nobs(object))),
             gic = (2 + log(nobs(object)))/2,
             aic =, 2)
    } else k
  }
  out <- dropterm(object, ..., test = test, k = k)
  if(sorted) out <- out[order(out$Cindex, decreasing = decreasing), ]
  if(delta) {
    out$Cindex <- out$Cindex - out$Cindex[rownames(out) == "<none>"]
    names(out) <- sub("Cindex", "delta_Cindex", names(out))
  }
  if(k != 2) {
    isBIC <- isTRUE(all.equal(k, log(nobs(object))))
    isGIC <- isTRUE(all.equal(k, (2 + log(nobs(object)))/2))
    names(out) <- sub("Cindex", ifelse(isBIC, "BIC",
                                    ifelse(isGIC, "GIC",
                                           paste0("IC(", round(k, 2), ")"))),
                      names(out))
  }
  structure(out, pName = "Cindex",
            class = c("drop_termcindex", class(out)))
}


plot.drop_termcindex <- function(x, ..., horiz = TRUE,
                           las = ifelse(horiz, 1, 2),
                           col = c("#DF536B", "#2297E6"),
                           border = c("#DF536B", "#2297E6"),
                           show.model = TRUE) {
  pName <- attr(x, "pName")
  stopifnot(isTRUE(any(grepl(pName, names(x)))))
  old_par <- par(no.readonly = TRUE)
  on.exit(par(old_par))
  # names(x)[grep(pName, names(x))[1]] <- pName ## remove any decoration such as "delta"
  Cindex <- x[[which(grepl(pName, names(x)))[1]]]
  names(Cindex) <- rownames(x)
  Cindex <- sort(Cindex - Cindex["<none>"])
  if(is.character(col) && length(col) == 2) {
    col <- ifelse(Cindex < 0, col[1], col[2])
  }
  if(is.character(border) && length(border) == 2) {
    border <- ifelse(Cindex < 0, border[1], border[2])
  }
  pmar <- pmax(par("mar"), (if(horiz) c(4,6,1,1) else c(6,4,1,1)) + 0.1)
  pmar[3:4] <- 1.1
  par(mar = pmar, cex.axis = 0.8)
  if(show.model) {
    h <- attr(x, "heading")
    h <- format(gsub("\n", "", h[!grepl("^Single ", h)]), justify = "left")
    layout(cbind(2:1), heights = c(1, 6), widths = 1, respect = FALSE)
    on.exit(layout(matrix(1)), add = TRUE)
  }
  if(horiz) {
    barplot(Cindex, xlab = bquote(Delta*' '*.(pName)), horiz = TRUE,
            las = las, col = col, border = border, ...)
  } else {
    barplot(Cindex, ylab = bquote(Delta*' '*.(pName)), horiz = FALSE,
            las = las, col = col, border = border, ...)
  }
  if(show.model) {
    par(mar = c(0, 0, 0, 0))
    plot.new()
    legend("bottomleft", legend = h, bty = "n", cex = 0.8)
  }
  invisible(x)
}

#' Guess the default test
#'
#' Find an appropriate test to use in \code{\link[MASS]{dropterm}} if not specified
#'
#' @param object a fitted model object accommodated by \code{\link[MASS]{dropterm}}
#'
#' @return A character string, one of \code{"F", "Chisq", or "none"}
#' @export
#'
#' @examples
#' fm <- glm.nb(Days ~ .^3, quine)
#' default_test(fm)
default_test <- function(object) {
  UseMethod("default_test")
}

#' @rdname default_test
#' @export
default_test.default <- function(object) {
  "none"
}

#' @rdname default_test
#' @export
default_test.negbin <- function(object) {
  "Chisq"
}

#' @rdname default_test
#' @export
default_test.lmerMod <- function(object) {
  "Chisq"
}

#' @rdname default_test
#' @export
default_test.glmerMod <- function(object) {
  "Chisq"
}

#' @rdname default_test
#' @export
default_test.multinom <- function(object) {
  ## same as 'negbin'
  "Chisq"
}

#' @rdname default_test
#' @export
default_test.polr <- function(object) {
  ## same as 'negbin'
  "Chisq"
}

#' @rdname default_test
#' @export
default_test.glm <- function(object) {
  switch(object$family$family,
         binomial =, poisson = "Chisq",
         gaussian =, Gamma =, quasi =, quasibinomial =,
         quasipoisson =, inverse.gaussian = "F",
         "none")
}

#' @rdname default_test
#' @export
default_test.lm <- function(object) {
  "F"
}


############################################################################
############################################################################
###                                                                      ###
###             A CRUDE BACKWARD ELIMINATION TOOL FOR MODELS             ###
###                (GOOD ENOUGH FOR GOVERNMENT PURPOSES)                 ###
###                                                                      ###
############################################################################
############################################################################


.eliminate <- function(object, ..., trace) {
  d <- MASS::dropterm(object, sorted = TRUE, ...)
  if(trace)
    print(d)
  if(rownames(d)[1] %in% c("<none>", "1")) { ## hit the limit, do nothing
    return(invisible(object))
  }
  var <- parse(text = rownames(d)[1])[[1]]
  if(trace)
    cat("\nEliminating: ", rownames(d)[1], "\n-----------\n")
  upd <- substitute(update(OBJ, . ~ . - VAR), list(OBJ = substitute(object),
                                                   VAR = var))
  return(invisible(eval.parent(upd)))
}

#' Naive backeward elimination
#'
#' A simple facility to refine models by backward elimination.
#' Covers cases where \code{\link{drop_term}} works but \code{\link{step_AIC}}
#' does not
#'
#' @param object A fitted model object
#' @param ... additional arguments passed to \code{\link{drop_term}} such as \code{k}
#' @param trace logical: do you want a trace of the process printed?
#' @param k penalty (default 2, as for AIC)
#'
#' @return A refined fitted model object
#' @export
#'
#' @examples
#' fm <- lm(medv ~ . + (rm + tax + lstat)^2 +
#'            I((rm - 6)^2) + I((tax - 400)^2) + I((lstat - 12)^2), Boston)
#' sfm <- step_down(fm, trace = TRUE, k = "bic")
step_down <- function(object, ..., trace = FALSE, k) {
  if(!isS4(object) && isTRUE(object$call$trace)) {
    warning("Trace detected. Turning it off.", immediate. = TRUE)
    call <- substitute(update(OBJ, trace = FALSE),
                       list(OBJ = substitute(object)))
    object <- eval.parent(call)
  }
  k <- if(missing(k)) {
    p <- attr(object, "penalty")
    ifelse(is.null(p), 2, p)
  } else {
    if(is.character(k)) {
      switch(tolower(k),
             bic = max(2, log(nobs(object))),
             gic = (2 + log(nobs(object)))/2,
             aic =, 2)
    } else k
  }
  # oldOpt <- options(warn = -1)
  # on.exit(options(oldOpt))
  
  obj <- object
  suppressWarnings({
    repeat {
      tmp <- .eliminate(obj, ..., trace = trace, k = k)
      if(identical(tmp, obj)) break
      obj <- tmp
    }
  })
  attr(obj, "penalty") <- k
  obj
}


#' Intermediate Information Criterion
#'
#' An AIC-variant criterion that weights complexity with a penalty
#' mid-way between 2 (as for AIC) and log(n) (as for BIC).  I.e.
#' "not too soft" and "not too hard", just "Glodilocks".
#'
#' @param object a fitted model object for which the criterion is desired
#'
#' @return The GIC criterion value
#' @export
#'
#' @examples
#' gm <- glm.nb(Days ~ Sex/(Age + Eth*Lrn), quine)
#' c(AIC = AIC(gm), GIC = GIC(gm), BIC = BIC(gm))
GIC <- function(object) {
  stats::AIC(object, k = (2 + log(stats::nobs(object)))/2)
}