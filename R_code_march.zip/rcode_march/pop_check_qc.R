

library(haven)
indat <- read_sas("~/adefpr_integrated.sas7bdat")
#Slide 19
# 2L+ PFS
#1200
indat2Lplus1200 <- indat%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200))

findat<- indat2Lplus1200%>%
  mutate(PFSAVAL=PFSISDEAVAL, PFSCNSR=PFSISDECNSR)%>%
  mutate(time=PFSAVAL, evnt=1-PFSCNSR)%>%
  mutate(AGEC=ifelse(AGE<=65, "<=65", ">65"))

#"COMPOUND","METASTNC", "BLNLR", "CHSTGGRP", "AGE", "BLLMETS", "BLSOD"
covs <-c( "COMPOUND", "AGEC",  "BLLMETS", "BLNLR", 
          "BLSOD", "CHSTGGRP",  "MMLNPTM")
form <- f.build("Surv(time,evnt)", covs)
#mPFS (95% CI)
fit <- survfit(Surv(time,evnt) ~ COMPOUND, data = findat, conf.type="plain")
print(ggsurvplot(fit, risk.table = TRUE, pval=paste("Log-rank p=", round(surv_pvalue(fit)[1,2], 2)),
                 title="KM-plot of covariates based on all-covariate analysis"))

# ggsurvfit(survfit2(Surv(time,evnt) ~ strata(node), data = findat2r), surv.median.line="hv")
# fit <- summary(survfit(Surv(time,evnt) ~ strata(node), data = findat2r))
kable(as.data.frame(summary(fit)$table))
#HR (unadjusted)
cpmod <- coxph(Surv(time,evnt) ~ COMPOUND, data = findat, ties="breslow")
Publish::publish(cpmod)
#HR (adjusted)
cpmod <- coxph(form, data = findat%>%filter(CHSTGGRP!=""), ties="breslow")
Publish::publish(cpmod)
# IPTW
###########################################################
# A. IPTW analysis
###########################################################
dat <- findat%>%filter(CHSTGGRP!="", !is.na(BLNLR))
# 1. Specify a treatment assignment model
glm_mod <- glm(COMPOUND ~ ICI90_LUNG + LNPTCAT5 + LBLALB, data=dat, family="binomial")
# 2. Get iptw weights
iptw_form <- f.build("COMPOUND", c("AGEC", "BLLMETS", "BLNLR", "BLSOD", "CHSTGGRP", "MMLNPTM"))

iptw_weights = weightit(iptw_form, data = dat, 
                        estimand = "ATE", 
                        method = "glm",
                        stabilize = TRUE,
                        focal=NULL)
dat$weights = iptw_weights$weights
# 3. Get adjusted plot
fit<- survfit(Surv(time,evnt) ~ COMPOUND, data = dat, 
              weights=weights, robust=T, conf.type="plain")
p <- ggsurvplot(fit, risk.table=TRUE,  risk.table.title= "Adjusted KM-plot by IPTW method", 
                data=dat)
p
# Median (95% CI)
median_ci_ <- as.data.frame(summary(fit)$table)%>%dplyr::mutate(trt=row.names(data.frame(summary(fit)$table)))%>%
  dplyr::select(trt, everything())
median_ci_

# Log-rank p-value
library(RISCA)
dat <- dat%>%mutate(grp=ifelse(COMPOUND=="Zoldon", 1, 0))
ipw.log.rank(dat$time, dat$evnt, dat$grp, dat$weights)

# Wald-test p-value
cox <- coxph(Surv(time,evnt) ~ COMPOUND, data=dat, ties = "breslow",  robust=TRUE, 
             weights=weights, x=TRUE)
cox
Publish::publish(cox)
# Balance diagnostics
bal_plt <- love.plot(bal.tab(iptw_weights, m.threshold = 0.1), stat="mean.diffs", grid=TRUE, stars="raw",abs=F)
bal_plt 
bal_sum <- bal.tab(iptw_weights, un=TRUE, threshold =c(m=0.1))
bal_sum
##########
#ATT
########
dat$COMPOUND <- factor(dat$COMPOUND, levels=c("Zoldon", "Daraxon"))
iptw_form
iptw_weights = weightit(iptw_form, data = dat, 
                        estimand = "ATT", 
                        method = "glm",
                        #stabilize = TRUE,
                        focal=NULL)
dat$weights = iptw_weights$weights

# 3. Get adjusted plot
fit<- survfit(Surv(time,evnt) ~ COMPOUND, data = dat, 
              weights=weights, robust=T, conf.type="plain")
p <- ggsurvplot(fit, risk.table=TRUE,  risk.table.title= "Adjusted KM-plot by IPTW method", 
                data=dat)
p
# Median (95% CI)
median_ci_ <- as.data.frame(summary(fit)$table)%>%dplyr::mutate(trt=row.names(data.frame(summary(fit)$table)))%>%
  dplyr::select(trt, everything())
median_ci_

# Log-rank p-value
library(RISCA)
dat <- dat%>%mutate(grp=ifelse(COMPOUND=="Zoldon", 1, 0))
ipw.log.rank(dat$time, dat$evnt, dat$grp, dat$weights)

# Wald-test p-value
cox <- coxph(Surv(time,evnt) ~ COMPOUND, data=dat, ties = "breslow",  robust=TRUE, 
             weights=weights, x=TRUE)
cox
Publish::publish(cox)
# Balance diagnostics
bal_plt <- love.plot(bal.tab(iptw_weights, m.threshold = 0.1), stat="mean.diffs", grid=TRUE, stars="raw",abs=F)
bal_plt 
bal_sum <- bal.tab(iptw_weights, un=TRUE, threshold =c(m=0.1))
bal_sum
#900
indat2Lplus1200 <- indat%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200, 900))

findat<- indat2Lplus1200%>%
  mutate(PFSAVAL=PFSISDEAVAL, PFSCNSR=PFSISDECNSR)%>%
  mutate(time=PFSAVAL, evnt=1-PFSCNSR)%>%
  mutate(AGEC=ifelse(AGE<=65, "<=65", ">65"))

covs <-c( "COMPOUND", "AGEC",  "BLLMETS", "BLNLR", 
          "BLSOD", "CHSTGGRP",  "MMLNPTM")
form <- f.build("Surv(time,evnt)", covs)
#mPFS (95% CI)
fit <- survfit(Surv(time,evnt) ~ COMPOUND, data = findat, conf.type="plain")
print(ggsurvplot(fit, risk.table = TRUE, pval=paste("Log-rank p=", round(surv_pvalue(fit)[1,2], 2)),
                 title="KM-plot of covariates based on all-covariate analysis"))

# ggsurvfit(survfit2(Surv(time,evnt) ~ strata(node), data = findat2r), surv.median.line="hv")
# fit <- summary(survfit(Surv(time,evnt) ~ strata(node), data = findat2r))
kable(as.data.frame(summary(fit)$table))
#HR (unadjusted)
cpmod <- coxph(Surv(time,evnt) ~ COMPOUND, data = findat, ties="breslow")
Publish::publish(cpmod)
#HR (adjusted)
cpmod <- coxph(form, data = findat%>%filter(CHSTGGRP!="", !is.na(BLNLR)), ties="breslow")
Publish::publish(cpmod)

# IPTW
###########################################################
# A. IPTW analysis
###########################################################
dat <- findat%>%filter(CHSTGGRP!="", !is.na(BLNLR))
# 1. Specify a treatment assignment model
#glm_mod <- glm(COMPOUND ~ ICI90_LUNG + LNPTCAT5 + LBLALB, data=dat, family="binomial")
# 2. Get iptw weights
iptw_form <- f.build("COMPOUND", c("AGEC", "BLLMETS", "BLNLR", "BLSOD", "CHSTGGRP", "MMLNPTM"))

iptw_weights = weightit(iptw_form, data = dat, 
                        estimand = "ATE", 
                        method = "glm",
                        stabilize = TRUE,
                        focal=NULL)
dat$weights = iptw_weights$weights
# 3. Get adjusted plot
fit<- survfit(Surv(time,evnt) ~ COMPOUND, data = dat, 
              weights=weights, robust=T, conf.type="plain")
p <- ggsurvplot(fit, risk.table=TRUE,  risk.table.title= "Adjusted KM-plot by IPTW method", 
                data=dat)
p
# Median (95% CI)
median_ci_ <- as.data.frame(summary(fit)$table)%>%dplyr::mutate(trt=row.names(data.frame(summary(fit)$table)))%>%
  dplyr::select(trt, everything())
median_ci_

# Log-rank p-value
library(RISCA)
dat <- dat%>%mutate(grp=ifelse(COMPOUND=="Zoldon", 1, 0))
ipw.log.rank(dat$time, dat$evnt, dat$grp, dat$weights)

# Wald-test p-value
cox <- coxph(Surv(time,evnt) ~ COMPOUND, data=dat, ties = "breslow",  robust=TRUE, 
             weights=weights, x=TRUE)
cox
Publish::publish(cox)
# Balance diagnostics
bal_plt <- love.plot(bal.tab(iptw_weights, m.threshold = 0.1), stat="mean.diffs", grid=TRUE, stars="raw",abs=F)
bal_plt 
bal_sum <- bal.tab(iptw_weights, un=TRUE, threshold =c(m=0.1))
bal_sum
##########
#ATT
########
dat$COMPOUND <- factor(dat$COMPOUND, levels=c("Zoldon", "Daraxon"))
iptw_form
iptw_weights = weightit(iptw_form, data = dat, 
                        estimand = "ATT", 
                        method = "glm",
                        #stabilize = TRUE,
                        focal=NULL)
dat$weights = iptw_weights$weights

# 3. Get adjusted plot
fit<- survfit(Surv(time,evnt) ~ COMPOUND, data = dat, 
              weights=weights, robust=T, conf.type="plain")
p <- ggsurvplot(fit, risk.table=TRUE,  risk.table.title= "Adjusted KM-plot by IPTW method", 
                data=dat)
p
# Median (95% CI)
median_ci_ <- as.data.frame(summary(fit)$table)%>%dplyr::mutate(trt=row.names(data.frame(summary(fit)$table)))%>%
  dplyr::select(trt, everything())
median_ci_

# Log-rank p-value
library(RISCA)
dat <- dat%>%mutate(grp=ifelse(COMPOUND=="Zoldon", 1, 0))
ipw.log.rank(dat$time, dat$evnt, dat$grp, dat$weights)

# Wald-test p-value
cox <- coxph(Surv(time,evnt) ~ COMPOUND, data=dat, ties = "breslow",  robust=TRUE, 
             weights=weights, x=TRUE)
cox
Publish::publish(cox)
# Balance diagnostics
bal_plt <- love.plot(bal.tab(iptw_weights, m.threshold = 0.1), stat="mean.diffs", grid=TRUE, stars="raw",abs=F)
bal_plt 
bal_sum <- bal.tab(iptw_weights, un=TRUE, threshold =c(m=0.1))
bal_sum
#Slide 19
# 3L+ PFS
#1200
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="Daraxon" & MMPDA3FL== "Y")|(COMPOUND=="Zoldon" & MMLNPTM== ">1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200))
dim(indat2Lplus1200)


findat<- indat2Lplus1200%>%
  mutate(PFSAVAL=PFSISDEAVAL, PFSCNSR=PFSISDECNSR)%>%
  mutate(time=PFSAVAL, evnt=1-PFSCNSR)%>%
  mutate(AGEC=ifelse(AGE<=65, "<=65", ">65"))

covs <-c( "COMPOUND", "AGEC",  "BLLMETS", "BLNLR", 
          "BLSOD", "CHSTGGRP")
form <- f.build("Surv(time,evnt)", covs)
#mPFS (95% CI)
fit <- survfit(Surv(time,evnt) ~ COMPOUND, data = findat, conf.type="plain")
print(ggsurvplot(fit, risk.table = TRUE, pval=paste("Log-rank p=", round(surv_pvalue(fit)[1,2], 2)),
                 title="KM-plot of covariates based on all-covariate analysis"))

# ggsurvfit(survfit2(Surv(time,evnt) ~ strata(node), data = findat2r), surv.median.line="hv")
# fit <- summary(survfit(Surv(time,evnt) ~ strata(node), data = findat2r))
kable(as.data.frame(summary(fit)$table))
#HR (unadjusted)
cpmod <- coxph(Surv(time,evnt) ~ COMPOUND, data = findat, ties="breslow")
Publish::publish(cpmod)
#HR (adjusted)
cpmod <- coxph(form, data = findat%>%filter(CHSTGGRP!="", !is.na(BLNLR)), ties="breslow")
Publish::publish(cpmod)
###########################################################
# A. IPTW analysis
###########################################################
dat <- findat%>%filter(CHSTGGRP!="", !is.na(BLNLR))
# 1. Specify a treatment assignment model
#glm_mod <- glm(COMPOUND ~ ICI90_LUNG + LNPTCAT5 + LBLALB, data=dat, family="binomial")
# 2. Get iptw weights
iptw_form <- f.build("COMPOUND", c("AGEC", "BLLMETS", "BLNLR", "BLSOD", "CHSTGGRP", "MMLNPTM"))

iptw_weights = weightit(iptw_form, data = dat, 
                        estimand = "ATE", 
                        method = "glm",
                        stabilize = TRUE,
                        focal=NULL)
dat$weights = iptw_weights$weights
# 3. Get adjusted plot
fit<- survfit(Surv(time,evnt) ~ COMPOUND, data = dat, 
              weights=weights, robust=T, conf.type="plain")
p <- ggsurvplot(fit, risk.table=TRUE,  risk.table.title= "Adjusted KM-plot by IPTW method", 
                data=dat)
p
# Median (95% CI)
median_ci_ <- as.data.frame(summary(fit)$table)%>%dplyr::mutate(trt=row.names(data.frame(summary(fit)$table)))%>%
  dplyr::select(trt, everything())
median_ci_

# Log-rank p-value
library(RISCA)
dat <- dat%>%mutate(grp=ifelse(COMPOUND=="Zoldon", 1, 0))
ipw.log.rank(dat$time, dat$evnt, dat$grp, dat$weights)

# Wald-test p-value
cox <- coxph(Surv(time,evnt) ~ COMPOUND, data=dat, ties = "breslow",  robust=TRUE, 
             weights=weights, x=TRUE)
cox
Publish::publish(cox)
# Balance diagnostics
bal_plt <- love.plot(bal.tab(iptw_weights, m.threshold = 0.1), stat="mean.diffs", grid=TRUE, stars="raw",abs=F)
bal_plt 
bal_sum <- bal.tab(iptw_weights, un=TRUE, threshold =c(m=0.1))
bal_sum
##########
#ATT
########
dat$COMPOUND <- factor(dat$COMPOUND, levels=c("Zoldon", "Daraxon"))
iptw_form
iptw_weights = weightit(iptw_form, data = dat, 
                        estimand = "ATT", 
                        method = "glm",
                        #stabilize = TRUE,
                        focal=NULL)
dat$weights = iptw_weights$weights

# 3. Get adjusted plot
fit<- survfit(Surv(time,evnt) ~ COMPOUND, data = dat, 
              weights=weights, robust=T, conf.type="plain")
p <- ggsurvplot(fit, risk.table=TRUE,  risk.table.title= "Adjusted KM-plot by IPTW method", 
                data=dat)
p
# Median (95% CI)
median_ci_ <- as.data.frame(summary(fit)$table)%>%dplyr::mutate(trt=row.names(data.frame(summary(fit)$table)))%>%
  dplyr::select(trt, everything())
median_ci_

# Log-rank p-value
library(RISCA)
dat <- dat%>%mutate(grp=ifelse(COMPOUND=="Zoldon", 1, 0))
ipw.log.rank(dat$time, dat$evnt, dat$grp, dat$weights)

# Wald-test p-value
cox <- coxph(Surv(time,evnt) ~ COMPOUND, data=dat, ties = "breslow",  robust=TRUE, 
             weights=weights, x=TRUE)
cox
Publish::publish(cox)
# Balance diagnostics
bal_plt <- love.plot(bal.tab(iptw_weights, m.threshold = 0.1), stat="mean.diffs", grid=TRUE, stars="raw",abs=F)
bal_plt 
bal_sum <- bal.tab(iptw_weights, un=TRUE, threshold =c(m=0.1))
bal_sum
#900
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="Daraxon" & MMPDA3FL== "Y")|(COMPOUND=="Zoldon" & MMLNPTM== ">1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200, 900))
dim(indat2Lplus1200)

findat<- indat2Lplus1200%>%
  mutate(PFSAVAL=PFSISDEAVAL, PFSCNSR=PFSISDECNSR)%>%
  mutate(time=PFSAVAL, evnt=1-PFSCNSR)%>%
  mutate(AGEC=ifelse(AGE<=65, "<=65", ">65"))

covs <-c( "COMPOUND", "AGEC",  "BLLMETS", "BLNLR", 
          "BLSOD", "CHSTGGRP")
form <- f.build("Surv(time,evnt)", covs)
#mPFS (95% CI)
fit <- survfit(Surv(time,evnt) ~ COMPOUND, data = findat, conf.type="plain")
print(ggsurvplot(fit, risk.table = TRUE, pval=paste("Log-rank p=", round(surv_pvalue(fit)[1,2], 2)),
                 title="KM-plot of covariates based on all-covariate analysis"))

# ggsurvfit(survfit2(Surv(time,evnt) ~ strata(node), data = findat2r), surv.median.line="hv")
# fit <- summary(survfit(Surv(time,evnt) ~ strata(node), data = findat2r))
kable(as.data.frame(summary(fit)$table))
#HR (unadjusted)
cpmod <- coxph(Surv(time,evnt) ~ COMPOUND, data = findat, ties="breslow")
Publish::publish(cpmod)
#HR (adjusted)
cpmod <- coxph(form, data = findat%>%filter(CHSTGGRP!="", !is.na(BLNLR)), ties="breslow")
Publish::publish(cpmod)
###########################################################
# A. IPTW analysis
###########################################################
dat <- findat%>%filter(CHSTGGRP!="", !is.na(BLNLR))
# 1. Specify a treatment assignment model
#glm_mod <- glm(COMPOUND ~ ICI90_LUNG + LNPTCAT5 + LBLALB, data=dat, family="binomial")
# 2. Get iptw weights
iptw_form <- f.build("COMPOUND", c("AGEC", "BLLMETS", "BLNLR", "BLSOD", "CHSTGGRP", "MMLNPTM"))

iptw_weights = weightit(iptw_form, data = dat, 
                        estimand = "ATE", 
                        method = "glm",
                        stabilize = TRUE,
                        focal=NULL)
dat$weights = iptw_weights$weights
# 3. Get adjusted plot
fit<- survfit(Surv(time,evnt) ~ COMPOUND, data = dat, 
              weights=weights, robust=T, conf.type="plain")
p <- ggsurvplot(fit, risk.table=TRUE,  risk.table.title= "Adjusted KM-plot by IPTW method", 
                data=dat)
p
# Median (95% CI)
median_ci_ <- as.data.frame(summary(fit)$table)%>%dplyr::mutate(trt=row.names(data.frame(summary(fit)$table)))%>%
  dplyr::select(trt, everything())
median_ci_

# Log-rank p-value
library(RISCA)
dat <- dat%>%mutate(grp=ifelse(COMPOUND=="Zoldon", 1, 0))
ipw.log.rank(dat$time, dat$evnt, dat$grp, dat$weights)

# Wald-test p-value
cox <- coxph(Surv(time,evnt) ~ COMPOUND, data=dat, ties = "breslow",  robust=TRUE, 
             weights=weights, x=TRUE)
cox
Publish::publish(cox)
# Balance diagnostics
bal_plt <- love.plot(bal.tab(iptw_weights, m.threshold = 0.1), stat="mean.diffs", grid=TRUE, stars="raw",abs=F)
bal_plt 
bal_sum <- bal.tab(iptw_weights, un=TRUE, threshold =c(m=0.1))
bal_sum
##########
#ATT
########
dat$COMPOUND <- factor(dat$COMPOUND, levels=c("Zoldon", "Daraxon"))
iptw_form
iptw_weights = weightit(iptw_form, data = dat, 
                        estimand = "ATT", 
                        method = "glm",
                        #stabilize = TRUE,
                        focal=NULL)
dat$weights = iptw_weights$weights

# 3. Get adjusted plot
fit<- survfit(Surv(time,evnt) ~ COMPOUND, data = dat, 
              weights=weights, robust=T, conf.type="plain")
p <- ggsurvplot(fit, risk.table=TRUE,  risk.table.title= "Adjusted KM-plot by IPTW method", 
                data=dat)
p
# Median (95% CI)
median_ci_ <- as.data.frame(summary(fit)$table)%>%dplyr::mutate(trt=row.names(data.frame(summary(fit)$table)))%>%
  dplyr::select(trt, everything())
median_ci_

# Log-rank p-value
library(RISCA)
dat <- dat%>%mutate(grp=ifelse(COMPOUND=="Zoldon", 1, 0))
ipw.log.rank(dat$time, dat$evnt, dat$grp, dat$weights)

# Wald-test p-value
cox <- coxph(Surv(time,evnt) ~ COMPOUND, data=dat, ties = "breslow",  robust=TRUE, 
             weights=weights, x=TRUE)
cox
Publish::publish(cox)
# Balance diagnostics
bal_plt <- love.plot(bal.tab(iptw_weights, m.threshold = 0.1), stat="mean.diffs", grid=TRUE, stars="raw",abs=F)
bal_plt 
bal_sum <- bal.tab(iptw_weights, un=TRUE, threshold =c(m=0.1))
bal_sum
#Slide 20
# 2L PFS
#1200
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="Daraxon" & MMP3PPFL== "Y")|(COMPOUND=="Zoldon" & MMLNPTM== "<=1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200))
dim(indat2Lplus1200)


findat<- indat2Lplus1200%>%
  mutate(PFSAVAL=PFSISDEAVAL, PFSCNSR=PFSISDECNSR)%>%
  mutate(time=PFSAVAL, evnt=1-PFSCNSR)%>%
  mutate(AGEC=ifelse(AGE<=65, "<=65", ">65"))

covs <-c( "COMPOUND", "AGEC",  "BLLMETS", "BLNLR", 
          "BLSOD", "CHSTGGRP")
form <- f.build("Surv(time,evnt)", covs)
#mPFS (95% CI)
fit <- survfit(Surv(time,evnt) ~ COMPOUND, data = findat, conf.type="plain")
print(ggsurvplot(fit, risk.table = TRUE, pval=paste("Log-rank p=", round(surv_pvalue(fit)[1,2], 2)),
                 title="KM-plot of covariates based on all-covariate analysis"))

# ggsurvfit(survfit2(Surv(time,evnt) ~ strata(node), data = findat2r), surv.median.line="hv")
# fit <- summary(survfit(Surv(time,evnt) ~ strata(node), data = findat2r))
kable(as.data.frame(summary(fit)$table))
#HR (unadjusted)
cpmod <- coxph(Surv(time,evnt) ~ COMPOUND, data = findat, ties="breslow")
Publish::publish(cpmod)
#HR (adjusted)

cpmod <- coxph(form, data = findat%>%filter(CHSTGGRP!="", !is.na(BLNLR)), ties="breslow")
Publish::publish(cpmod)
###########################################################
# A. IPTW analysis
###########################################################
dat <- findat%>%filter(CHSTGGRP!="", !is.na(BLNLR))
# 1. Specify a treatment assignment model
#glm_mod <- glm(COMPOUND ~ ICI90_LUNG + LNPTCAT5 + LBLALB, data=dat, family="binomial")
# 2. Get iptw weights
iptw_form <- f.build("COMPOUND", c("AGEC", "BLLMETS", "BLNLR", "BLSOD", "CHSTGGRP", "MMLNPTM"))

iptw_weights = weightit(iptw_form, data = dat, 
                        estimand = "ATE", 
                        method = "glm",
                        stabilize = TRUE,
                        focal=NULL)
dat$weights = iptw_weights$weights
# 3. Get adjusted plot
fit<- survfit(Surv(time,evnt) ~ COMPOUND, data = dat, 
              weights=weights, robust=T, conf.type="plain")
p <- ggsurvplot(fit, risk.table=TRUE,  risk.table.title= "Adjusted KM-plot by IPTW method", 
                data=dat)
p
# Median (95% CI)
median_ci_ <- as.data.frame(summary(fit)$table)%>%dplyr::mutate(trt=row.names(data.frame(summary(fit)$table)))%>%
  dplyr::select(trt, everything())
median_ci_

# Log-rank p-value
library(RISCA)
dat <- dat%>%mutate(grp=ifelse(COMPOUND=="Zoldon", 1, 0))
ipw.log.rank(dat$time, dat$evnt, dat$grp, dat$weights)

# Wald-test p-value
cox <- coxph(Surv(time,evnt) ~ COMPOUND, data=dat, ties = "breslow",  robust=TRUE, 
             weights=weights, x=TRUE)
cox
Publish::publish(cox)
# Balance diagnostics
bal_plt <- love.plot(bal.tab(iptw_weights, m.threshold = 0.1), stat="mean.diffs", grid=TRUE, stars="raw",abs=F)
bal_plt 
bal_sum <- bal.tab(iptw_weights, un=TRUE, threshold =c(m=0.1))
bal_sum
#900
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="Daraxon" & MMP3PPFL== "Y")|(COMPOUND=="Zoldon" & MMLNPTM== "<=1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200, 900))
dim(indat2Lplus1200)

findat<- indat2Lplus1200%>%
  mutate(PFSAVAL=PFSISDEAVAL, PFSCNSR=PFSISDECNSR)%>%
  mutate(time=PFSAVAL, evnt=1-PFSCNSR)%>%
  mutate(AGEC=ifelse(AGE<=65, "<=65", ">65"))

covs <-c( "COMPOUND", "AGEC",  "BLLMETS", "BLNLR", 
          "BLSOD", "CHSTGGRP")
form <- f.build("Surv(time,evnt)", covs)
#mPFS (95% CI)
fit <- survfit(Surv(time,evnt) ~ COMPOUND, data = findat, conf.type="plain")
print(ggsurvplot(fit, risk.table = TRUE, pval=paste("Log-rank p=", round(surv_pvalue(fit)[1,2], 2)),
                 title="KM-plot of covariates based on all-covariate analysis"))

# ggsurvfit(survfit2(Surv(time,evnt) ~ strata(node), data = findat2r), surv.median.line="hv")
# fit <- summary(survfit(Surv(time,evnt) ~ strata(node), data = findat2r))
kable(as.data.frame(summary(fit)$table))
#HR (unadjusted)
cpmod <- coxph(Surv(time,evnt) ~ COMPOUND, data = findat, ties="breslow")
Publish::publish(cpmod)
#HR (adjusted)
cpmod <- coxph(form, data = findat%>%filter(CHSTGGRP!="", !is.na(BLNLR)), ties="breslow")
Publish::publish(cpmod)
###########################################################
# A. IPTW analysis
###########################################################
dat <- findat%>%filter(CHSTGGRP!="", !is.na(BLNLR))
# 1. Specify a treatment assignment model
#glm_mod <- glm(COMPOUND ~ ICI90_LUNG + LNPTCAT5 + LBLALB, data=dat, family="binomial")
# 2. Get iptw weights
iptw_form <- f.build("COMPOUND", c("AGEC", "BLLMETS", "BLNLR", "BLSOD", "CHSTGGRP", "MMLNPTM"))

iptw_weights = weightit(iptw_form, data = dat, 
                        estimand = "ATE", 
                        method = "glm",
                        stabilize = TRUE,
                        focal=NULL)
dat$weights = iptw_weights$weights
# 3. Get adjusted plot
fit<- survfit(Surv(time,evnt) ~ COMPOUND, data = dat, 
              weights=weights, robust=T, conf.type="plain")
p <- ggsurvplot(fit, risk.table=TRUE,  risk.table.title= "Adjusted KM-plot by IPTW method", 
                data=dat)
p
# Median (95% CI)
median_ci_ <- as.data.frame(summary(fit)$table)%>%dplyr::mutate(trt=row.names(data.frame(summary(fit)$table)))%>%
  dplyr::select(trt, everything())
median_ci_

# Log-rank p-value
library(RISCA)
dat <- dat%>%mutate(grp=ifelse(COMPOUND=="Zoldon", 1, 0))
ipw.log.rank(dat$time, dat$evnt, dat$grp, dat$weights)

# Wald-test p-value
cox <- coxph(Surv(time,evnt) ~ COMPOUND, data=dat, ties = "breslow",  robust=TRUE, 
             weights=weights, x=TRUE)
cox
Publish::publish(cox)
# Balance diagnostics
bal_plt <- love.plot(bal.tab(iptw_weights, m.threshold = 0.1), stat="mean.diffs", grid=TRUE, stars="raw",abs=F)
bal_plt 
bal_sum <- bal.tab(iptw_weights, un=TRUE, threshold =c(m=0.1))
bal_sum
##ORR
#Slide 22
#2L+ ORR
#1200
source("~/rd.R")
indat2Lplus1200 <- indat%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200), SAF14WFL=="Y")%>%
  mutate(orrn=ifelse(ORR=="Yes", 1, 0),
         AGEC=ifelse(AGE<=65, "<=65", ">65"))
dim(indat2Lplus1200)
dat <- indat2Lplus1200%>%
  filter(CHSTGGRP!="")
dat$COMPOUND
rdres <- rd_res(dat=dat, respn="orrn", pred="COMPOUND", 
                covs=c("AGEC", "TLAPANFL", "CHSTGGRP", "BLECOGN"), 
                predlevtrt="Daraxon", predlevref= "Zoldon")
res1 <- data.frame(pop="2Lplus1200", `Daraxon (ORR(95%CI))`=rdres[[1]], `Zoldon (ORR(95%CI))`=rdres[[2]],
                   `Daraxon - Zoldon(Diff(95%CI))`=rdres[[3]])
#' resp <- "ORR"
#' respc <- "ORR"
#' pred <- "COMPOUND"
#' covs1 <-  c("AGE", "PMELESFL", "CHSTGGRP")
#' covs <- c("AGE", "PMELESFL", "CHSTGGRP")
#' 
#' options(scipen=99999)
#' form <- f.build("orrn", c(pred, covs))
#' form
#' dat$COMPOUND <- factor(dat$COMPOUND, levels=c("RMC-9805", "RMC-6236"))
#' dat$PMELESFL <- factor(dat$PMELESFL, levels=c("Y", "N"))
#' dat$CHSTGGRP <- factor(dat$CHSTGGRP, levels=c("IV", "<=III"))
#' fit1 <- glm(form, data = dat, family=binomial)
#' fit1
#' Publish::publish(fit1)
#' fit11 <- glm(f.build("orrn", c(pred)), data = dat, family=binomial)
#' fit11
#' Publish::publish(fit11)
#' require(MASS)
#' exp(cbind(coef(fit1), confint.default(fit1)))  
#' #Predicted values
#' 
#' pred_y_6236 <- stats::predict.glm(fit1, newdata=data.frame(dat%>%mutate(COMPOUND="RMC-6236")), type="response")
#' est6236<- mean(pred_y_6236, na.rm=T)
#' est6236
#' pred_y_9805 <- predict(fit1, newdata=data.frame(dat%>%mutate(COMPOUND="RMC-9805")), type="response")
#' est9805<- mean(pred_y_9805, na.rm=T)
#' est9805
#' estdiff <- est6236 - est9805
#' estdiff
#' #95% CI using bootstrapping
#' #' Run the boot function. Set a seed to obtain reproducibility
#' bootfunc <- function(data,index){
#'   boot_dat <- data[index,]
#'   fit1 <- glm(form, data = boot_dat, family="binomial")
#'   pred_y_6236 <- stats::predict.glm(fit1, newdata=data.frame(boot_dat%>%mutate(COMPOUND="RMC-6236")), type="response")
#'   pred_y_9805 <- predict(fit1, newdata=data.frame(boot_dat%>%mutate(COMPOUND="RMC-9805")), type="response")
#'   est_6236 <-  mean(pred_y_6236, na.rm=T)
#'   est_9805 <-  mean(pred_y_9805, na.rm=T)
#'   diff <- est_6236 - est_9805
#'   res <- c(est_6236, est_9805, diff)
#'   return(res)
#' }
#' set.seed(1234)
#' library(boot)
#' boot_res <- boot::boot(dat,bootfunc,R=2000)
#' boot_RD_6236 <- boot.ci(boot_res,index=1)
#' boot_RD_9805 <- boot.ci(boot_res,index=2)
#' boot_RD_diff <- boot.ci(boot_res,index=3)
#' ci_6236 <- paste(round(as.matrix(boot_RD_6236$bca[4]), 4), ",", 
#'                 round(as.matrix(boot_RD_6236$bca[5]), 4))
#' ci_9805 <- paste(round(as.matrix(boot_RD_9805$bca[4]), 4), ",", 
#'                 round(as.matrix(boot_RD_9805$bca[5]), 4))
#' ci_diff <- paste(round(as.matrix(boot_RD_diff$bca[4]), 4), ",", 
#'                 round(as.matrix(boot_RD_diff$bca[5]), 4))
#' res_6236 <- paste(round(est6236, 4), "(", ci_6236, ")")
#' res_9805 <- paste(round(est9805, 4), "(", ci_9805, ")")
#' res_diff <- paste(round(estdiff, 4), "(", ci_diff, ")")
#' res_6236
#' res_9805
#' res_diff
#' 
#' #Automated
#' dat$COMPOUND <- factor(dat$COMPOUND, levels=c("RMC-9805", "RMC-6236"))
#' dat$PMELESFL <- factor(dat$PMELESFL, levels=c("Y", "N"))
#' dat$CHSTGGRP <- factor(dat$CHSTGGRP, levels=c("IV", "<=III"))


#900
indat2Lplus1200 <- indat%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200, 900), SAF14WFL=="Y")%>%
  mutate(orrn=ifelse(ORR=="Yes", 1, 0),
         AGEC=ifelse(AGE<=65, "<=65", ">65"))
dim(indat2Lplus1200)
dat2 <- indat2Lplus1200%>%
  filter(CHSTGGRP!="")
rdres <- rd_res(dat=dat2, respn="orrn", pred="COMPOUND", 
                covs=c("AGEC", "TLAPANFL", "CHSTGGRP", "BLECOGN"), 
                predlevtrt="Daraxon", predlevref= "Zoldon")
res2 <- data.frame(pop="2Lplus900", `Daraxon (ORR(95%CI))`=rdres[[1]], `Zoldon (ORR(95%CI))`=rdres[[2]],
                   `Daraxon - Zoldon(Diff(95%CI))`=rdres[[3]])
#Slide 23
#3L Plus
#1200
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="Daraxon" & MMPDA3FL== "Y")|(COMPOUND=="Zoldon" & MMLNPTM== ">1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200), SAF14WFL=="Y")%>%
  mutate(orrn=ifelse(ORR=="Yes", 1, 0),
         AGEC=ifelse(AGE<=65, "<=65", ">65"))
dim(indat2Lplus1200)
dat3 <- indat2Lplus1200%>%
  filter(CHSTGGRP!="")
rdres <- rd_res(dat=dat3, respn="orrn", pred="COMPOUND", 
                covs=c("AGEC", "TLAPANFL", "CHSTGGRP", "BLECOGN"), 
                predlevtrt="Daraxon", predlevref= "Zoldon")
res3 <- data.frame(pop="3Lplus1200", `Daraxon (ORR(95%CI))`=rdres[[1]], `Zoldon (ORR(95%CI))`=rdres[[2]],
                   `Daraxon - Zoldon(Diff(95%CI))`=rdres[[3]])
#900
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="Daraxon" & MMPDA3FL== "Y")|(COMPOUND=="Zoldon" & MMLNPTM== ">1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200, 900), SAF14WFL=="Y")%>%
  mutate(orrn=ifelse(ORR=="Yes", 1, 0),
         AGEC=ifelse(AGE<=65, "<=65", ">65"))
dim(indat2Lplus1200)
dat4 <- indat2Lplus1200%>%
  filter(CHSTGGRP!="")
rdres <- rd_res(dat=dat4, respn="orrn", pred="COMPOUND", 
                covs=c("AGEC", "TLAPANFL", "CHSTGGRP", "BLECOGN"), 
                predlevtrt="Daraxon", predlevref= "Zoldon")
res4 <- data.frame(pop="3Lplus900", `Daraxon (ORR(95%CI))`=rdres[[1]], `Zoldon (ORR(95%CI))`=rdres[[2]],
                   `Daraxon - Zoldon(Diff(95%CI))`=rdres[[3]])
#Slide 24-2L
#2L
#1200
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="Daraxon" & MMP3PPFL== "Y")|(COMPOUND=="Zoldon" & MMLNPTM== "<=1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200), SAF14WFL=="Y")%>%
  mutate(orrn=ifelse(ORR=="Yes", 1, 0),
         AGEC=ifelse(AGE<=65, "<=65", ">65"))

dim(indat2Lplus1200)
dim(indat2Lplus1200)
dat5 <- indat2Lplus1200%>%
  filter(CHSTGGRP!="")
rdres <- rd_res(dat=dat5, respn="orrn", pred="COMPOUND",
                covs=c("AGEC", "TLAPANFL", "CHSTGGRP", "BLECOGN"),  
                predlevtrt="Daraxon", predlevref= "Zoldon")
res5 <- data.frame(pop="2L900", `Daraxon (ORR(95%CI))`=rdres[[1]], `Zoldon (ORR(95%CI))`=rdres[[2]],
                   `Daraxon - Zoldon(Diff(95%CI))`=rdres[[3]])
#900
indat2Lplus1200 <- indat%>%
  filter((COMPOUND=="Daraxon" & MMP3PPFL== "Y")|(COMPOUND=="Zoldon" & MMLNPTM== "<=1"))%>%
  filter(C1D1DS%in%c(160, 200, 220, 300, 1200, 900), SAF14WFL=="Y")%>%
  mutate(orrn=ifelse(ORR=="Yes", 1, 0),
         AGEC=ifelse(AGE<=65, "<=65", ">65"))
dim(indat2Lplus1200)
dat6 <- indat2Lplus1200%>%
  filter(CHSTGGRP!="")
rdres <- rd_res(dat=dat6, respn="orrn", pred="COMPOUND", 
                covs=c("AGEC", "TLAPANFL", "CHSTGGRP", "BLECOGN"), 
                predlevtrt="Daraxon", predlevref= "Zoldon")
res6 <- data.frame(pop="2Lplus900", `Daraxon (ORR(95%CI))`=rdres[[1]], `Zoldon (ORR(95%CI))`=rdres[[2]],
                   `Daraxon - Zoldon(Diff(95%CI))`=rdres[[3]])
final <- rbind(res1, res2, res3, res4, res5, res6)
final
write.xlsx(final, "ORR_diff_9805ref.xlsx")
