###########
library(mlr3)
library(mlr3proba)
## combine in list
tasks <- list(whas, rats)
library(paradox)
library(survivalmodels)
set_seed(1234)
library(mlr3)
library(mlr3proba)

## get the `whas` task from mlr3proba
whas <- tsk("whas")

## create our own task from the rats dataset
rats_data <- survival::rats
## convert characters to factors
rats_data$sex <- factor(rats_data$sex, levels = c("f", "m"))
rats <- TaskSurv$new("rats", rats_data, time = "time", event = "status")


## combine in list
tasks <- list(whas, rats)
library(paradox)
search_space = ps(
  dropout = p_dbl(lower = 0, upper = 1),
  weight_decay = p_dbl(lower = 0, upper = 0.5),
  learning_rate = p_dbl(lower = 0, upper = 1),
  
  nodes = p_int(lower = 1, upper = 32),
  k = p_int(lower = 1, upper = 4),
  
  .extra_trafo = function(x, param_set) {
    x$num_nodes = rep(x$nodes, x$k)
    x$nodes = x$k = NULL
    x
  }
)

ps$trafo
# search_space$trafo = function(x, param_set) {
#   x$num_nodes = rep(x$nodes, x$k)
#   x$nodes = x$k = NULL
#   return(x)
# }

library(mlr3tuning)

create_autotuner <- function(learner) {
  AutoTuner$new(
    learner = learner,
    search_space = search_space,
    resampling = rsmp("holdout"),
    measure = msr("surv.cindex"),
    terminator = trm("evals", n_evals = 2),
    tuner = tnr("random_search"))
}

## learners are stored in mlr3extralearners
library(mlr3extralearners)

## load learners
learners <- lrns(paste0("surv.", c("coxtime", "deephit", "deepsurv", 
                                   "loghaz", "pchazard")),
                 frac = 0.3, early_stopping = TRUE, epochs = 10,
                 optimizer = "adam"
)
flt_importance = flt("importance", learner = learners )
flt_importance$calculate(tsk_pen)
as.data.table(flt_importance)
# apply our function
learners <- lapply(learners, create_autotuner) 


library(mlr3pipelines)


create_pipeops <- function(learner) {
  po("encode") %>>% po("scale") %>>% po("learner", learner)
}

# apply our function
learners <- lapply(learners, create_pipeops)
## select holdout as the resampling strategy
library(mlr3)
resampling <- rsmp("cv", folds = 3)

## add KM and CPH
learners <- c(learners, lrns(c("surv.kaplan", "surv.coxph")))
design <- benchmark_grid(tasks, learners, resampling)
bm <- benchmark(design)

## Concordance index and Integrated Graf Score
msrs <- msrs(c("surv.cindex", "surv.graf"))
res <- bm$aggregate(msrs)[, c(3, 4, 7, 8)]
library(dplyr)
res%>%as.data.frame%>%arrange(desc(surv.cindex))
library(mlr3benchmark)

## create mlr3benchmark object
bma <- as.BenchmarkAggr(bm, 
                        measures = msrs(c("surv.cindex", "surv.graf")))

## run global Friedman test
bma$friedman_test()

## load ggplot2 for autoplots
library(ggplot2)
install.packages("PMCMRplus")
## critical difference diagrams for IGS
autoplot(bma, meas = "graf", type = "cd", ratio = 1/3, p.value = 0.2)

#
