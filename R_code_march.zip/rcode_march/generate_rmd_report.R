
#This is the R-script to generate R-markdown report from master template
###############################################################
###############################################################
#I. Import data and data processing
###############################################################
###############################################################
library(haven)
library(data.table)
library(dtplyr)
indat <- read_sas("~/adefpr_6236_02032025.sas7bdat")
slpdat1 <- openxlsx::read.xlsx("~/slopelognlr_pdac.xlsx")
slpdat2 <- openxlsx::read.xlsx("~/slopetllpchg_pdac.xlsx")

fin1 <- setDT(indat)
indat<- lazy_dt(indat)

dat <-fin1[PDAC1LFL!="Y" & COHORT11!="Y" & PDACWTFL!="Y",
          ][CHDXCLAS =="PANCREATIC" & SAFFL == "Y",][
            setDT(slpdat1), on="USUBJID"
            ][setDT(slpdat2), on="USUBJID"][, .BLNLR:=as.numeric(round(BLNLR,2)),
            ][BLCTDNAFL!="",][C1D1DS%in%c(120, 160, 200, 220, 300),]

dat$BLCTDNAFL <- factor(dat$BLCTDNAFL)
dat <- as.data.frame(dat)
#######################################################
#######################################################
##II. Parameters
#######################################################
#######################################################

#Covariates considered
covs_cons<- c("BLNLR",  "BLSOD", "C1D1DS", "C1D1DGP", "C1D1DGP1", "MMLNPTM", "BLLMETS", "BLBNMETS", "BLBMETS","BLECOGN","SEX", "PT5FUCFL", "PT5CMFL", "GISUABFL", "PTGEMCFL", "PTGCMFL", "TLAPANFL","PMELESFL", "AGE", "AGEGR3", "WEIGHT",  "PANCRESFL", "AGEDIAG", "METASTN",
              "SMKSTAT2", "RASGRPCAT1", "RASGRPCAT", "BLALB", "BLCTDNAFL")

#Continuous covariates considered
covs_cons_cont <- c("BLNLR", "BLSOD",  "C1D1DS", "AGE",  "WEIGHT", "AGEDIAG", "METASTN", "BLALB")

#Multi-category covariates
covs_multi <- c("RASGRPCAT", "RASGRPCAT1")

# Response variable for evaluation
resp <- c("PFSISDEAVAL", "PFSISDECNSR")
# Name of response variable
resp_char <- "Progression-Free Survival"
# Any additional population filter applied
pop <- 'CHDXCLAS =="PANCREATIC" & SAFFL == "Y"'
# Name of population (all lower case)
pop_char <- "all treated PDAC subjects in 6236 study data"
# Initial seed for random forest
sed <- 1234

#####################################################################
#####################################################################
#III. Create Rmarkdown report
#####################################################################
#####################################################################
# Specify directory
library(rmarkdown)
# Location of master RMD file
report_dir <- "~/baseline_temp.Rmd"
output_format <- html_document(toc = TRUE, toc_depth = 6, theme = "journal")
# Name of output file
#output_file <- "baseline_120_300_w_ctDNA_ss20_lasso_pdac"
output_file <- "temp3"
# Location of output file
output_dir <- "~/baseline/"
#Path to forest code
frstpath <- "~/runfrst"

# Title of output report
report_title <- paste("Identifying variables to predict ", resp_char,  
                      "Using Random Forest (120-300mg and baseline variables with ctDNA in PDAC))")

if(TRUE){#Default parameters
################################################
#################################################
####Note: Use this to change default parameter settings
#################################################
#################################################
#Specify parameters
#I. Random forest using All variables
#A. Tree
# Minimum criterion (1-p-value)
mincrit_all <- 0
# Minimum Bucket size
minbuc_all <-20
# Minimum Split size
minspl_all <- 10
#B. Forest
# Minimum Criterion (1-p-value)
mincrit_allf <- 0
# Threshold value
threshold_allf <- 0.2
# Number of trees
ntre_allf <- 100

#II. Random forest using uncorrelated variables
# Correlation cut-off
corv <- 0.8
#A. Tree
# Minimum criterion (1-p-value)
mincrit_un <- 0
# Minimum Bucket size
minbuc_un <-20
# Mimimum Split size
minspl_un <- 10

#B. Forest
# Minimum criterion (1-p-value)
mincrit_unf <- 0
# Threshold
threshold_unf <- 0.2
# Number of trees
ntre_unf <- 100

#III. Random forest using user-defined
#A. Tree
# Minimum criterion (1-p-value)
mincrit_us <- 0
# Minimum bucket size
minbuc_us <-20
# Minimum split size
minspl_us <- 10

#B. Forest
# Minimum criterion (1-p-value)
mincrit_usf <- 0
# Threshold value
threshold_usf <- 0.2
# Number of trees
ntre_usf <- 100

#IV. Single-tree analysis
# Minimum criterion (1-p-value)
mincrit_sg <- 0
# Minimum bucket size
minbuc_sg <-20
# Minimum split size
minspl_sg <- 10

#V: Other parameters
# Exposure variable
exp_variable <- c("")
# Derived Exposure variable
exp_variable_derived <- c("")

#VI. Desired Outputs: Set to TRUE or FALSE
#1. Missing values visualization
show_missing_val <- TRUE
#2. Descriptive summary of data
show_descriptive_summary <- TRUE
#3. Collinear variables/Collinearity
show_collinearity <- TRUE
#4. Variable selection by AICc
show_aicc_var_select <- FALSE
#5. Variable selection by LASSO
show_lasso_var_select <- TRUE
#6. Conditional random forest using all variables
show_randomforest_all <- TRUE
#7. Conditional random forest removing collinear variables
show_randomforest_uncorr <- TRUE
#8. Conditional random forest using user-specified variables
show_randomforest_userspecified <- TRUE
# User specified threshold (% of maximum variable importance)
user_thres <- 10
#9. Optimal cut-off using C-index (Continuous variables)
show_optimalcutoff_cindex <- TRUE
#10. Variable importance ranking using C-index
show_varimp_cindex <- TRUE
#11. Optimal cut-off using IBS (Continuous variables)
show_optimalcutoff_ibs <- TRUE
#12. Variable importance ranking using IBS
show_varimp_ibs <- TRUE
#13. Optimal cut-off using tree with single covariate (multi-category covariate)
show_single_cov_tree <- TRUE
#14. Final list of predictive covariates (most-predictive to least)
show_final_pred_list <- TRUE
#15. Descriptive summary of analysis data
show_descriptive_summary_adata <- TRUE

}#Default parameters

######################################################################
######################################################################
#Create report
######################################################################
######################################################################

rmarkdown::render(input = report_dir, output_format = output_format,
                  output_file = output_file, 
                  output_dir = output_dir, intermediates_dir = output_dir,
                  params = list(dat = dat, covs_cons = covs_cons, covs_cons_cont = covs_cons_cont, covs_multi = covs_multi,
                                exp_variable=exp_variable, exp_variable_derived = exp_variable_derived, resp=resp, resp_char=resp_char,
                                pop=pop, pop_char=pop_char, corv=corv, sed=sed, mincrit_all=mincrit_all, minbuc_all = minbuc_all,
                                minspl_all = minspl_all, mincrit_allf = mincrit_allf, threshold_allf = threshold_allf, ntre_allf = ntre_allf,
                                mincrit_un = mincrit_un, minbuc_un = minbuc_un, minspl_un = minspl_un, mincrit_unf = mincrit_unf,
                                threshold_unf = threshold_unf, ntre_unf = ntre_unf, mincrit_us = mincrit_us, minbuc_us = minbuc_us,
                                minspl_us = minspl_us, mincrit_usf = mincrit_usf, threshold_usf = threshold_usf, ntre_usf = ntre_usf,
                                mincrit_sg = mincrit_sg, minbuc_sg = minbuc_sg, minspl_sg = minspl_sg,
                                show_missing_val = show_missing_val, show_descriptive_summary = show_descriptive_summary,
                                show_collinearity = show_collinearity, show_aicc_var_select = show_aicc_var_select,
                                show_lasso_var_select = show_lasso_var_select, show_randomforest_all = show_randomforest_all,
                                show_randomforest_uncorr = show_randomforest_uncorr, show_randomforest_userspecified = show_randomforest_userspecified,
                                user_thres = user_thres, show_optimalcutoff_cindex = show_optimalcutoff_cindex, show_varimp_cindex = show_varimp_cindex,
                                show_optimalcutoff_ibs = show_optimalcutoff_ibs, show_varimp_ibs = show_varimp_ibs, show_single_cov_tree = show_single_cov_tree,
                                show_final_pred_list = show_final_pred_list, show_descriptive_summary_adata = show_descriptive_summary_adata, frstpath=frstpath,
                                set_title = report_title, filename=output_file))

##End



