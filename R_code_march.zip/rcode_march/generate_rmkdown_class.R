# Name of output file
output_file <- "orrh_baseline_120_300_wo_ctdna_14w_nsclc"
# Location of output file
output_dir <- "Z:/Private/npanthi/February analysis/analysis_refresh_02272025/classification/"
# Name of response variable
resp_char <- "Overall response rate confirmed or pending (ORRH)"
# Title of output report
report_title <- paste("Identifying variables that are most predictive for ", resp_char,  
                      "Using conditional Random Forest using baseline 
covariates in all treated NSCLC (120-300) without 
                      EGFR and with >=14wks of f/u and without ctDNA")

#This is the R-script to generate R-markdown report from master template
###############################################################
###############################################################
#I. Import data and data processing
###############################################################
###############################################################
library(haven)
library(data.table)
library(dtplyr)
indat <- read_sas("Z:/Private/npanthi/February analysis/analysis_refresh_02142025/adefpr_6236_02032025.sas7bdat")
slpdat1 <- openxlsx::read.xlsx("Z:/Private/npanthi/January analysis/slopepchgnlr.xlsx")
slpdat2 <- openxlsx::read.xlsx("Z:/Private/npanthi/January analysis/slopetllpchg.xlsx")

fin1 <- setDT(indat)
indat<- lazy_dt(indat)

dat <-fin1[CHDXCLAS =="LUNG" & SAFFL == "Y" & NXEGFR=="",][
  setDT(slpdat1)[, SLOPELOGNLR:=SLOPEPCHGNLR][,.(USUBJID, SLOPEPCHGNLR)], on="USUBJID"
][setDT(slpdat2), on="USUBJID"][, BLNLR:=as.numeric(round(BLNLR,2)),
][C1D1DS%in%c(120, 160, 200, 220, 300),
][FOLLOWUP_W>=14,][,`:=`(LNPTMCAT=factor(LNPTMCAT, levels=c("0/1", "2", ">=3"), ordered=T),
                         LNPTCAT = factor(LNPTCAT, levels=c("0/1", "2", ">=3"), ordered=T))
]


dat <- as.data.frame(dat)


#######################################################
#######################################################
##II. Parameters
#######################################################
#######################################################

#Covariates considered
covs_cons<- c( "C1D1DS", "C1D1DGP", "C1D1DGP1",  "LNPTM","LNPTMCAT","LNPTCAT","BLLMETS","BLBNMETS",
               "BLECOGN", "SEX", "AGE","AGEGR1", "SMKSTAT2", "BLBMETS", "TLLUNGFL", "CPI90FLA", 
               "ICDY", "BLALB",  "RASGRPCAT2", "RASGRPCAT3",  "WEIGHT", "BLSOD","BLNLR")

#Continuous covariates considered
covs_cons_cont <- c( "C1D1DS", "AGE", 
                     "ICDY", "BLALB", "WEIGHT", "BLSOD","BLNLR")

# Response variable for evaluation
resp <- "ORRH"
# Response variable level corresponding to response = "Y"
respyvar = "Yes"
# Name of population (all lower case)
pop_char <- "all treated lung subjects with >=14 wks of f/u in 6236 study data"
# Initial seed for random forest
sed <- 1234

#####################################################################
#####################################################################
#III. Create Rmarkdown report
#####################################################################
#####################################################################
# Specify directory
library(rmarkdown)
# Location of master RMD file
report_dir <- "Z:/Private/npanthi/February analysis/analysis_refresh_02142025/baseline/baseline_temp_class.Rmd"
output_format <- html_document(toc = TRUE, toc_depth = 6, theme = "journal")

#Path to forest code
frstpath <- "Z:/Private/npanthi/February analysis/analysis_9805/runfrst"

if(TRUE){#Default parameters
  ################################################
  #################################################
  ####Note: Use this to change default parameter settings
  #################################################
  #################################################
  #Specify parameters
  #I. Random forest using All variables
  #A. Tree
  # Minimum criterion (1-p-value)
  mincrit_all <- 0
  # Minimum Bucket size
  minbuc_all <-20
  # Minimum Split size
  minspl_all <- 10
  #B. Forest
  # Minimum Criterion (1-p-value)
  mincrit_allf <- 0
  # Threshold value
  threshold_allf <- 0.2
  # Number of trees
  ntre_allf <- 500
  
  #II. Random forest using uncorrelated variables
  # Correlation cut-off
  corv <- 0.8
  #A. Tree
  # Minimum criterion (1-p-value)
  mincrit_un <- 0
  # Minimum Bucket size
  minbuc_un <-20
  # Mimimum Split size
  minspl_un <- 10
  
  #B. Forest
  # Minimum criterion (1-p-value)
  mincrit_unf <- 0
  # Threshold
  threshold_unf <- 0.2
  # Number of trees
  ntre_unf <- 500
  
  #III. Random forest using user-defined
  #A. Tree
  # Minimum criterion (1-p-value)
  mincrit_us <- 0
  # Minimum bucket size
  minbuc_us <-20
  # Minimum split size
  minspl_us <- 10
  
  #B. Forest
  # Minimum criterion (1-p-value)
  mincrit_usf <- 0
  # Threshold value
  threshold_usf <- 0.2
  # Number of trees
  ntre_usf <- 500
  
  #IV. Single-tree analysis
  # Minimum criterion (1-p-value)
  mincrit_sg <- 0
  # Minimum bucket size
  minbuc_sg <-20
  # Minimum split size
  minspl_sg <- 10
  
  #VI. Desired Outputs: Set to TRUE or FALSE
  #1. Missing values visualization
  show_missing_val <- TRUE
  #2. Descriptive summary of data
  show_descriptive_summary <- TRUE
  #3. Collinear variables/Collinearity
  show_collinearity <- TRUE
  #4. Variable selection by AICc
  show_aicc_var_select <- TRUE
  #5. Conditional random forest using all variables
  show_randomforest_all <- TRUE
  #6. Conditional random forest removing collinear variables
  show_randomforest_uncorr <- TRUE
  #7. Conditional random forest using user-specified variables
  show_randomforest_userspecified <- TRUE
  # User specified threshold (% of maximum variable importance)
  user_thres <- 10
  #8. Optimal cut-off using ROC (Continuous variables)
  show_optimalcutoff_roc <- TRUE
  #9. Optimal cut-off using tree with single covariate 
  show_single_cov_tree <- TRUE
  #10. Final list of predictive covariates (most-predictive to least)
  show_final_pred_list <- TRUE
  #11. Descriptive summary of analysis data
  show_descriptive_summary_adata <- TRUE
  
}#Default parameters

######################################################################
######################################################################
#Create report
######################################################################
######################################################################

rmarkdown::render(input = report_dir, output_format = output_format,
                  output_file = output_file, output_dir = output_dir, intermediates_dir = output_dir,
                  params = list(dat = dat, covs_cons = covs_cons, covs_cons_cont = covs_cons_cont, 
                                resp=resp, respyvar = respyvar, resp_char=resp_char, pop_char=pop_char, corv=corv, sed=sed, mincrit_all=mincrit_all, minbuc_all = minbuc_all,
                                minspl_all = minspl_all, mincrit_allf = mincrit_allf, threshold_allf = threshold_allf, ntre_allf = ntre_allf,
                                mincrit_un = mincrit_un, minbuc_un = minbuc_un, minspl_un = minspl_un, mincrit_unf = mincrit_unf,
                                threshold_unf = threshold_unf, ntre_unf = ntre_unf, mincrit_us = mincrit_us, minbuc_us = minbuc_us,
                                minspl_us = minspl_us, mincrit_usf = mincrit_usf, threshold_usf = threshold_usf, ntre_usf = ntre_usf,
                                mincrit_sg = mincrit_sg, minbuc_sg = minbuc_sg, minspl_sg = minspl_sg,
                                show_missing_val = show_missing_val, show_descriptive_summary = show_descriptive_summary,
                                show_collinearity = show_collinearity, show_aicc_var_select = show_aicc_var_select,
                                show_randomforest_all = show_randomforest_all,
                                show_randomforest_uncorr = show_randomforest_uncorr, show_randomforest_userspecified = show_randomforest_userspecified,
                                user_thres = user_thres, show_optimalcutoff_roc = show_optimalcutoff_roc, 
                                show_single_cov_tree = show_single_cov_tree,
                                show_final_pred_list = show_final_pred_list, show_descriptive_summary_adata = show_descriptive_summary_adata, frstpath=frstpath,
                                set_title = report_title))

##End



