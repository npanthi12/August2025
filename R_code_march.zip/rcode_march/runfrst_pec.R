runfrst_pec <- function(dat, ntre,  sed, thres){
  set.seed(sed)
  fitcforest <- pecCforest(Surv(time, status)~., data = dat,  
                           controls = cforest_unbiased(ntree = ntre))
  return(fitcforest)
}


