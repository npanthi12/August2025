pder<-function(ahat,vc,x){
  phat<-plogis(x%*%ahat)
  pbar<-mean(phat)
  pderiv<-t(phat*(1-phat))%*%x/nrow(x)
  sepbar<-sqrt(pderiv%*%vc%*%t(pderiv))
  return(list(pbar=pbar,sepbar=sepbar,pderiv=pderiv))
}

ci_func <- function(mod){
  lmargins <- log((mod$pbar)/(1-mod$pbar))
  selmargin <- mod$sepbar/((mod$pbar*(1-mod$pbar)))
  lomargin <- lmargins-1.96*selmargin
  upmargin <- lmargins+1.96*selmargin
  lowerm<- exp(lomargin)/(1+exp(lomargin))
  uperm <- exp(upmargin)/(1+exp(upmargin))
  return(list(lowerm, uperm))
}

deltares <- function(fit){
  df<-fit$model
  vc<-vcov(fit)
  
  mat<-model.matrix(fit$formula,data=df)
  mat[,2] <-1
  pdermod<-pder(coef(fit),vc,mat)
  trt <- paste(round(pdermod$pbar, 4), "(", round(ci_func(pdermod)[[1]][[1]], 4), ",", round(ci_func(pdermod)[[2]][[1]], 4), ")")
  
  mat<-model.matrix(fit$formula,data=df)
  mat[,2] <-0
  pderref<-pder(coef(fit),vc,mat)
  ref <- paste(round(pderref$pbar, 4), "(", round(ci_func(pderref)[[1]][[1]], 4), ",", round(ci_func(pderref)[[2]][[1]], 4), ")")
  
  diff<-pdermod$pbar-pderref$pbar
  sediff<-sqrt((pdermod$pderiv-pderref$pderiv)%*%vc%*%t(pdermod$pderiv-pderref$pderiv))
  lowerdiff=diff-1.96*sediff
  upperdiff=diff+1.96*sediff
  trt_ref <- paste(round(diff, 4), "(", round(lowerdiff, 4), ",", round(upperdiff, 4), ")")
  return(list(trt, ref, trt_ref))
}