
# Load libraries
library(haven)
library(survminer)
library(dplyr)
library(Hmisc)
library(haven)
library(AICcmodavg)
library(car)
library(broom)
library(cobalt)
library(ipw)
library(survey)
library(WeightIt)
library(glmtoolbox)
library(MatchIt)
library(MuMIn)
library(purrr)
library("survival")
library("survminer")
library(emmeans)
#Set directory, paths
inDir = "Z:/Private/npanthi/R program/ER_analysis"


############Survival analysis
library(dplyr)
fin <-  read_sas("Z:/Private/npanthi/R program/Analysis_data.sas7bdat", NULL)%>%
  arrange(USUBJID)

findata <- fin%>%
  mutate(orru=ifelse(respondu=="Yes", 1, 
                     ifelse(respondu=="No", 0, NA)),
         orr=ifelse(respond=="Yes", 1, 
                    ifelse(respond=="No", 0, NA)),
         orruh=ifelse(responsep=="Yes", 1, 
                      ifelse(responsep=="No", 0, NA)),
         lcmax = ifelse(!is.na(CMAX), log(CMAX), CMAX),
         lcavg = ifelse(!is.na(CAVG), log(CAVG), CAVG),
         lcmin = ifelse(!is.na(CMIN), log(CMIN), CMIN),
         GISURGFL=ifelse(GISURGFL=="Y", "Y", "N"))

findata_pdac_14wk <- findata%>%
  filter(ATUTYPE=="PANCREATIC CANCER" & SAFKRAFL=="Y" & SAFFL=="Y" & SAFD14FL=="Y")
findat1 <- findata_pdac_14wk%>%
  select(USUBJID, PFSAVAL, PFSCNSR, CAVG, CMAX, CMIN, AUC,
         ECOGBL, NPLTPA,AGE, LIVMETBL, KRASG12, RACEA,
         WEIGHTBL, TUMSZBL, SMKSTATA, BSABL, GISURGFL)
findat2 <- findat1%>%
  mutate(time=PFSAVAL,
         evnt = 1-PFSCNSR,
         lcavg =log(CAVG),
         lcmax=log(CMAX),
         lcmin=log(CMIN),
         lauc =log(AUC))%>%
  select(time, evnt, lcavg, lcmax, lcmin, lauc,
         ECOGBL, NPLTPA,AGE, LIVMETBL, KRASG12, RACEA,
         WEIGHTBL, TUMSZBL, SMKSTATA, BSABL, GISURGFL)

findat2$KRASG12 <- factor(findat2$KRASG12)
findat2$SMKSTATA <- factor(findat2$SMKSTATA)
findat2$ECOGBL <- factor(findat2$ECOGBL)
findat2$NPLTPA <- factor(findat2$NPLTPA)
findat2$LIVMETBL <- factor(findat2$LIVMETBL)
findat2$RACEA <- factor(findat2$RACEA)
findat2$GISURGFL <- factor(findat2$GISURGFL)

findat2 <- as.data.frame(findat2)
B <- 500

# Building a RSF
library(randomForestSRC)
library("survival")
RF_obj <- rfsrc(Surv(time,evnt)~., findat2, ntree = B,  membership = TRUE, importance=TRUE, nsplit=10)

# RF_obj <- rfsrc(Surv(time,evnt)~lcavg+lcmax+lcmin+lauc+
#                   ECOGBL+NPLTPA+AGE+LIVMETBL+KRASG12+RACEA+
#                   +TUMSZBL+SMKSTATA+BSABL+GISURGFL, findat2, ntree = B,  membership = TRUE, importance=TRUE)

# Printing the RF object  
print(RF_obj)
vi <- RF_obj$importance
vi_df <- data.frame(Variable=names(vi), Importance=vi)
ggplot(vi_df, aes(x=reorder(Variable, Importance), y= Importance)) +
  geom_bar(stat="identity", fill="steelblue")+
  coord_flip()+
  theme_minimal()+
  labs(title="Variable Importnce in Random Survival Forest",
       x="Variable", y="Importance")
vimp_select <- var.select(RF_obj)
print(vimp_select$topvars)

selected_vars <- vimp_select$topvars
formula_selected <- as.formula(paste("Surv(time, evnt)~", paste(selected_vars, collapse="+")))
rsf_selected <- rfsrc(formula_selected, data=findat2, ntree=500, importance = TRUE)
print(rsf_selected)
plot.survival.rfsrc(rsf_selected)
print(rsf_selected$err.rate[length(rsf_selected$err.rate)])
#Parameter tuning
library(caret)
set.seed(1234)
param_grid <- expand.grid(ntree=c(300, 500, 1000), mtry=c(2, 4, 6), nodesize=c(3, 5, 10))
results <- data.frame(ntree=integer(), mtry=integer(), nodesize=integer(), c_index=numeric())
for(i in 1:nrow(param_grid)){
  cat("Running model", i, "of", nrow(param_grid), "\n")
  model <- rfsrc(Surv(time, status)~., data=veteran,
                 ntree=param_grid$ntree[i],
                 mtry=param_grid$nodesize[i],
                 nodesize=param_grid$nodesize[i],
                 importance=TRUE
                 )
  c_index <- 1-model$err.rate[length(model$err.rate)]
  results <- rbind(results, c(param_grid$ntree[i], param_grid$mtry[i], 
                              param_grid$nodesize[i], c_index))
  
}
colnames(results) <- c("ntree", "mtry", "nodesize", "c_index")
best_params <- results[which.max(results$c_index),]
print(best_params)

best_model <- rfsrc(Surv(time, status)~., data=veteran, 
                    ntree=best_params$ntree, mtry=best_params$mtry,
                    nodesize = best_params$nodesize, importance=TRUE)
vi_opt <- best_model$importance
vi_df_opt <- data.frame(Variable=names(vi_opt), Importance=vi_opt)
ggplot(vi_df_opt, aes(x=reorder(Variable, Importance), y= Importance)) +
  geom_bar(stat="identity", fill="steelblue")+
  coord_flip()+
  theme_minimal()+
  labs(title="Variable Importnce in Random Survival Forest",
       x="Variable", y="Importance")
print(1-best_model$err.rate[length(best_model$err.rate)])
plot.survival.rfsrc(best_model)
#Cross-validation
library(randomForestSRC)
library(caret)
set.seed(123)
k_folds <- 5
folds <- createFolds(veteran$status, k=k_folds, list=TRUE)
cv_results <- data.frame(Fold=integer(), C_Index=numeric())
for(i in 1:k_folds){
  cat("Processing fold", i , "of", k_folds, "\n")
  train_indices <- unlist(folds[i])
  test_indices <- unlist(folds[i])
  train_data <- veteran[train_indices, ]
  test_data <- veteran[test_indices,]
  model <- rfsrc(Surv(time, status)~. ,data=train_data,
                 ntree=best_params$ntree,
                 mtry=best_params$mtry,
                 nodesize=best_params$nodesize,
                 importance=TRUE)
  preds <- predict(model, newdata=test_data)
  c_index <- 1-preds$err.rate[length(preds$err.rate)]
  cv_results <- rbind(cv_results, data.frame(Fold=i, C_index=c_index))
}


mean_c_index <- mean(cv_results$C_index, na.rm=T)
cat("Mean C-Index across", k_folds, "folds:", mean_c_index, "\n")

veteran$trt <- factor(veteran$trt, levels=c("1", "2"))
veteran$celltype <- factor(veteran$celltype, levels=c("1",
                                                      "2", "3", "4"))

final_model <- rfsrc(Surv(time, status)~., data=veteran,
                     ntree=best_params$ntree,
                     mtry=best_params$mtry,
                     nodesize=best_params$nodesize,
                     importance=TRUE)
print(final_model)
vi_final <- final_model$importance
vi_df_final <- data.frame(Variable=names(vi_final), Importance=vi_final)
ggplot(vi_df_final, aes(x=reorder(Variable, Importance), y= Importance)) +
  geom_bar(stat="identity", fill="steelblue")+
  coord_flip()+
  theme_minimal()+
  labs(title="Variable Importnce (Final Model)",
       x="Variable", y="Importance")
plot.survival.rfsrc(final_model)
print(1-final_model$err.rate[length(final_model$err.rate)])

library(ggplot2)
pdp_age <- plot.variable(final_model, xvar="age", partial=TRUE)
pdp_df <- data.frame(Age=pdp_age$plotthis$age[1], Survival=pdp_age$plotthis$age[2])
ggplot(pdp_df, aes(x=x, y=yhat))+geom_line(color="blue")+theme_minimal()+
  labs(title="Partial Dependence of Age on Survival", x="Age", y="Predicted Survival")

pdp_karno <- plot.variable(final_model, xvar="karno", partial=TRUE)
pdp_df <- data.frame(Age=pdp_age$plotthis$age[1], Survival=pdp_age$plotthis$age[2])
ggplot(pdp_df, aes(x=x, y=yhat))+geom_line(color="blue")+theme_minimal()+
  labs(title="Partial Dependence of Age on Survival", x="Age", y="Predicted Survival")

new_patient <- data.frame(trt=factor("1", levels=c("1", "2")),
                          celltype=factor("2", levels=c("1",
                                                        "2", "3", "4")),
                          karno=70,
                          diagtime=3,
                          age=65,
                          prior=10)
prediction <- predict(final_model, newdata=new_patient)
print(prediction$survival)
preds <- as.data.frame(prediction$survival)%>%tidyr::gather(col, value)
surv_df <- data.frame(Time=final_model$time.interest, Survival_Prob=preds$value)
ggplot(surv_df, aes(x=Time, y = Survival_Prob))+geom_line(color="darkgreen")+
  theme_minimal()+
  labs(title="Predicted Survival Curve for New Patient", x="Time (Days)", 
       y="Survival Probability")

library(iml)
library(randomForestSRC)
library(ggplot2)
X <- veteran[, names(veteran)!="time"]
X <- X[, names(X)!="status"]

# Create a Predictor object for the iml package
predictor <- Predictor$new(final_model, data=X, y=veteran$status)

iml::Shapley$new(predictor, x.interest = X[1,])
shapley <- Shapley$new(predictor, x.interest=X[1,])
plot(shapley)+ggtitle("SHAP Values for first patient in Dataset")

shapley_all <- FeatureImp$new(predictor, loss="mae")
plot(shapley_all)+ggtitle("Global Feature Importance using SHAP")
##
pred_fun <- function(m, x) {
  predict(m, newdata=x)$predicted
}

pred_fun(final_model, veteran[1,])

xvars <- setdiff(colnames(veteran), c("time", "status"))

shap_values <- kernelshap(
  final_model, 
  X = veteran,
  feature_names = xvars,
  bg_X = veteran[sample(nrow(veteran), size = 100), ] ,
  pred_fun = pred_fun
)
sv <- shapviz(shap_values)
sv_importance(sv)
sv_dependence(sv, "age")
##Global
pred_fun(final_model, veteran)
xvars <- setdiff(colnames(veteran), c("time", "status"))

shap_values <- kernelshap(
  final_model, 
  X = veteran,
  feature_names = xvars,
  bg_X = veteran[sample(nrow(veteran), size = 100), ] ,
  pred_fun = pred_fun
)
sv <- shapviz(shap_values)
sv_importance(sv)
sv_dependence(sv, "age")
##
new_patient <- data.frame(trt=factor(1, levels=levels(veteran$trt)),
                          age=65,
                          celltype=factor(2),
                          karno=70,
                          diagtime=3,
                          prior=10)
prediction<- predict(final_model, newdata=new_patient)
preds <- as.data.frame(prediction$survival)%>%gather(col, value)
surv_df <- data.frame(Time=final_model$time.interest, Survival_Prob=preds$value)
print(head(surv_df))
ggplot(surv_df, aes(x=Time, y = Survival_Prob))+geom_line(color="darkgreen")+
  theme_minimal()+
  labs(title="Predicted Survival Curve for New Patient", x="Time (Days)", 
       y="Survival Probability")

new_patients <- data.frame(trt=factor(c(1, 2)),
                           age=c(50, 75),
                           celltype=factor(c("2", "1")),
                           karno=c(80, 50),
                           diagtime= c(5, 1),
                           prior=c(0, 10))
predictions <- predict(final_model, newdata=new_patients)
as.data.frame(predictions$survival)%>%gather(col, value)


surv_df1 <- data.frame(Time=final_model$time.interest, Survival_Prob=predictions$survival[1,], Patient="Patient 1 (Age 50, Karnofsky 80)")
surv_df2 <- data.frame(Time=final_model$time.interest, Survival_Prob=predictions$survival[2,], Patient="Patient 2 (Age 75, Karnofsky 50)")

surv_df_combined <- rbind(surv_df1, surv_df2)
ggplot(surv_df_combined, aes(x=Time, y = Survival_Prob, color=Patient))+geom_line(size=1.2)+
  theme_minimal()+
  labs(title="Comparison of survival predictions for different patients", x="Time (Days)", 
       y="Survival Probability")

predictions <- predict(final_model, newdata=veteran)
time_point <- 180
closest_index <- which.min(abs(final_model$time.interest - time_point))
survival_probs <- predictions$survival[,closest_index]
median_survival <- median(survival_probs)
veteran$risk_group <- ifelse(survival_probs<median_survival, "High Risk", "Low Risk")

veteran$risk_group <- factor(veteran$risk_group, levels=c("Low Risk", "High Risk"))
head(veteran[, c("time", "status", "risk_group")])
library(survival)
library(survminer)
km_fit <- survfit(Surv(time, status)~factor(risk_group), data=veteran)
ggsurvplot(km_fit)
ggsurvplot(km_fit, data=veteran, risk.table=TRUE, pval=TRUE, conf.int=T,
           ggtheme=theme_minimal(),
           title="Kaplan-Meier Survival Curves for Risk Groups",
           xlab="Time (Days)", ylab="Survival Probability",
           legend.title="Risk Group",
           palette=c("blue", "red"))
cox_model <- coxph(Surv(time, status) ~ risk_group, data=veteran)
cox_model
veteran_t1 <- veteran
veteran_t2 <- veteran
veteran_t1$trt <- factor(1, levels=levels(veteran$trt))
veteran_t2$trt <- factor(2, levels=levels(veteran$trt))

pred_t1 <- predict(final_model, newdata=veteran_t1)
pred_t2 <- predict(final_model, newdata=veteran_t2)
time_point <- 180
closest_index <- which.min(abs(final_model$time.interest-time_point))

ite <- pred_t2$survival[, closest_index]-pred_t1$survival[, closest_index]
veteran$ite <-ite
head(veteran[, c("time", "status", "trt", "ite")])
library(ggplot2)
veteran$trt <- factor(veteran$trt)
ggplot(veteran, aes(x=ite, fill=trt))+
  geom_histogram(alpha=0.6, bins=30)+
  theme_minimal()+
  labs(title="Distribution of Individual Treatment Effects",
       x = "Individual Treatment Effect (Survival Difference at 180 days)",
       y="Number of Patients")+geom_vline(xintercept = 0) +
  scale_fill_manual(values=c("blue", "red"), name="Treatment")

km_fit_trt <- survfit(Surv(time, status) ~trt, data=veteran)
ggsurvplot(km_fit_trt, data=veteran, risk.table=TRUE, pval=TRUE, conf.int=TRUE,
           ggtheme=theme_minimal(), title="Kaplan-Meier Survival Curves by Treatment Group",
           xlab="Time (Days)", ylab="Survival Probability",
           legend.title="Treatment",
           palette=c("blue", "red"))

best_treatment_2 <- veteran[order(-veteran$ite), ][1:5, ]
best_treatment_1 <- veteran[order(veteran$ite), ][1:5, ]
print("Patients who benefit most from Treatment 2:")
print(best_treatment_2[, c("age", "celltype", "karno", "ite")])
print("Patients who benefit most from Treatment 1:")
print(best_treatment_1[, c("age", "celltype", "karno", "ite")])

library(partykit)
veteran$SurvObj <- with(veteran, Surv(time, status))
subgroup_model <- ctree(SurvObj~trt+age+celltype+karno+diagtime+prior, data=veteran)
plot(subgroup_model, main="Decision Tree for Identifying Treatment-Responsive Subgroups")
veteran$subgroup <- predict(subgroup_model, type="response")
km_fit_subgroups <- survfit(Surv(time, status)~subgroup, data=veteran)
ggsurvplot(km_fit_subgroups, data=veteran, risk.table=T, pval=T,
           conf.int=T, theme=theme_minimal(),
           title="Survival Curves for Patient Subgroups",
           xlab="Time (Days)", ylab="Survival Probability",
           legend.title="Subgroup")

cox_model_subgroup <- coxph(Surv(time, status)~subgroup*trt, data=veteran)
summary(cox_model_subgroup)

var_importance <- vimp(final_model)
plot(var_importance, main="Feature Importance for Predicting Treatment Response")

vimp_result <- vimp(final_model, importance="permute", bootstrap=TRUE)
print(vimp_result)
plot(vimp_result)
vimp_df <- data.frame(Variable=rownames(vimp_result$importance),
                      Importance=vimp_result$importance[1, ],
                      LowerCI = vimp_result$importance[2,],
                      UpperCI = vimp_result$importance[3,])
ggsurvplot()
n_repeats <- 100
vimp_list <- list()
  for(i in 1:n_repeats){
    print(paste(i))
    temp_model <- rfsrc(Surv(time, status)~., data=veteran[, 1:8],
                              ntree=best_params$ntree,
                              mtry=best_params$mtry,
                              nodesize=best_params$nodesize,
                              importance=TRUE)
    vimp_list[[i]] <- as.data.frame(vimp(temp_model)$importance)[,1]
  }

vimp_matrix<-do.call(cbind, vimp_list)

vimp_mean <- rowMeans(vimp_matrix)
vimp_lower <- apply(vimp_matrix, 1, quantile, probs=0.025)
vimp_upper <- apply(vimp_matrix, 1, quantile, probs=0.975)
vimpprec <- vimp_upper-vimp_lower
vimp_bootstrap_df <- data.frame(Variable=rownames(as.data.frame(vimp_result$importance)),
                                Importance=vimp_mean,
                                Lower_CI = vimp_lower,
                                Upper_CI= vimp_upper,
                                vimpprec=vimpprec)
ggplot(vimp_bootstrap_df, aes(x=reorder(Variable, Importance), y=Importance))+
  geom_point(size=3, color="blue")+
  geom_errorbar(aes(ymin=Lower_CI, ymax=Upper_CI), width=0.2, color="red")+
  coord_flip()+
theme_minimal()+
  labs(title="Bootstrapped Variable Importance with Confidence Intervals",
       x="Feature", y="Importance Score")
library(ggplot2)
gg
## obtain Brier score using KM censoring distribution estimators
bs.km <- get.brier.survival(RF_obj, cens.mode = "km")$brier.score

## plot the brier score
par(mar = c(1, 1, 1, 1))
plot(bs.km, type = "s", col = 2, ylab="Brier Score")
View(jk.obj)

jk.obj <- subsample(RF_obj)
pdf("Z:/Private/npanthi/R program/VIMPsur.pdf", width = 15, height = 20)
par(oma = c(0.5, 8, 0.5, 0.5))
par(cex.axis = 1.0, cex.lab = 1.0, cex.main = 1.0, mar = c(6,1,1,1), mgp = c(2, 1, 0))
plot(jk.obj, xlab = "Variable Importance (x 100)", cex = 0.5)
dev.off()

vs.pbc <- var.select(object = RF_obj)
topvars <- vs.pbc$topvars
topvars

var.select(object = RF_obj, conservative = "low")
var.select(object = RF_obj, conservative = "medium")
var.select(object =RF_obj, conservative = "high")
##
vh.breast <- var.select(Surv(time,evnt)~., findat2,
                        method = "vh", nrep = 10, nstep = 5)

vh.breast 

# plot top 10 variables
plot.variable(vh.breast$rfsrc.refit.obj,
              xvar.names = vh.breast$topvars[1:10])
plot.variable(vh.breast$rfsrc.refit.obj,
              xvar.names = vh.breast$topvars[1:10], partial = TRUE)



if (library("survival", logical.return = TRUE))
{
  cox.weights <- function(rfsrc.f, rfsrc.data) {
    event.names <- all.vars(rfsrc.f)[1:2]
    p <- ncol(rfsrc.data) - 2
    event.pt <- match(event.names, names(rfsrc.data))
    xvar.pt <- setdiff(1:ncol(rfsrc.data), event.pt)
    sapply(1:p, function(j) {
      cox.out <- coxph(rfsrc.f, rfsrc.data[, c(event.pt, xvar.pt[j])])
      pvalue <- summary(cox.out)$coef[5]
      if (is.na(pvalue)) 1.0 else 1/(pvalue + 1e-100)
    })
  }       
  rfsrc.f <- as.formula(Surv(time,evnt)~.)
  cox.wts <- cox.weights(rfsrc.f, findat2)
  vh.breast.cox <- var.select(rfsrc.f, findat2, method = "vh", nstep = 5,
                              nrep = 10, xvar.wt = cox.wts)
}


plot(get.tree(RF_obj, 40))
plot.survival(rfsrc(Surv(time,evnt)~., findat2), cens.model = "rfsrc")
