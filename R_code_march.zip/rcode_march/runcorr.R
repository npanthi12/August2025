# Calculate a pairwise association between all variables in a data-frame. In particular nominal vs nominal with Chi-square, numeric vs numeric with Pearson correlation, and nominal vs numeric with ANOVA.
# Adopted from https://stackoverflow.com/a/52557631/590437
mixed_assoc <<- function(df, cor_method = "spearman", adjust_cramersv_bias = TRUE) {
  df_comb = expand.grid(names(df), names(df), stringsAsFactors = F) %>% set_names("X1", "X2")
  is_nominal = function(x) {
    is.factor(x) & !is.ordered(x)
  }
  is_numeric <- function(x) {
    is.integer(x) || is_double(x)
  }
  is_ordinal <- function(x) {
    is.ordered(x)
  }
  f = function(xName, yName) {
    x = dplyr::pull(df, xName)
    y = dplyr::pull(df, yName)
    result = if (is_nominal(x) && is_nominal(y)) {
      cv = cramerV(as.character(x), as.character(y), bias.correct = adjust_cramersv_bias)
      data.frame(xName, yName, assoc = cv, type = "cramersV")
    }
    else if (is_numeric(x) && is_numeric(y)) {
      correlation = cor(x, y, method = cor_method, use = "complete.obs")
      data.frame(xName, yName, assoc = correlation, type = "correlation")
    }
    else if (is_numeric(x) && is_nominal(y)) {
      r_squared = summary(lm(x ~ y))$r.squared
      data.frame(xName, yName, assoc = sqrt(r_squared), type = "anova")
    }
    else if (is_nominal(x) && is_numeric(y)) {
      r_squared = summary(lm(y ~ x))$r.squared
      data.frame(xName, yName, assoc = sqrt(r_squared), type = "anova")
    }
    else if (is_nominal(x) && is_ordinal(y)) {
      correl = hetcor(x, y)$correlations[1, 2]
      data.frame(xName, yName, assoc = correl, type = "polychoric")
    }
    else if (is_ordinal(x) && is_nominal(y)) {
      correl = hetcor(x, y)$correlations[1, 2]
      data.frame(xName, yName, assoc = correl, type = "polychoric")
    }
    else if (is_ordinal(x) && is_ordinal(y)) {
      correl = hetcor(x, y)$correlations[1, 2]
      data.frame(xName, yName, assoc = correl, type = "polychoric")
    }
    else if (is_ordinal(x) && is_numeric(y)) {
      correl = hetcor(x, y)$correlations[1, 2]
      data.frame(xName, yName, assoc = correl, type = "polyserial")
    }
    else if (is_numeric(x) && is_ordinal(y)) {
      correl = hetcor(x, y)$correlations[1, 2]
      data.frame(xName, yName, assoc = correl, type = "polyserial")
    }
    else {
      warning(paste("unmatched column type combination: ", class(x), class(y)))
    }
    result %>% dplyr::mutate(complete_obs_pairs = sum(!is.na(x) & !is.na(y)), complete_obs_ratio = complete_obs_pairs/length(x)) %>% dplyr::rename(x = xName, y = yName)
  }
  map2_df(df_comb$X1, df_comb$X2, f)
}


panel.cor <- function(x, y, digits = 2, prefix = "", cex.cor, ...) {
  usr <- par("usr")
  on.exit(par(usr))
  par(usr = c(0, 1, 0, 1))
  Cor <- abs(cor(x, y)) # Remove abs function if desired
  txt <- paste0(prefix, format(c(Cor, 0.123456789), digits = digits)[1])
  if(missing(cex.cor)) {
    cex.cor <- 0.4 / strwidth(txt)
  }
  text(0.5, 0.5, txt,
       cex = 1 + cex.cor * Cor) # Resize the text by level of correlation
}
