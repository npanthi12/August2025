library(survival)
library(xgboost)
library(mlr3proba)
library(mlr3)
library(mlr3learners)
library(data.table)

dat <- survival::lung
dat <- na.omit(dat)

dat$event <- as.integer(dat$status==2)

features <- c("age", "sex", "ph.ecog", "ph.karno", "pat.karno", "meal.cal", "wt.loss")
X <- as.matrix(dat[, features])
y <- dat[, c("time", "event")]

dtrain <- xgb.DMatrix(data=X, label=y$time)
setinfo(dtrain, "label_lower_bound", y$time)
setinfo(dtrain, "label_upper_bound", y$time + 1)
setinfo(dtrain, "event", y$event)

##########################
library(survXgboost)
library(survival)
library(xgboost)
dat <- survival::lung
dat <- na.omit(dat)
# doesn't handle missing values at the moment
dat$status <- dat$status - 1 # format status variable correctly such that 1 is event/death and 0 is censored/alive
label <- ifelse(dat$status == 1, dat$time, -dat$time)

val_ind <- sample.int(nrow(dat), 0.1 * nrow(dat))
x_train <- as.matrix(dat[-val_ind, !names(dat) %in% c("time", "status")])
x_label <- label[-val_ind]
x_val <- xgb.DMatrix(as.matrix(dat[val_ind, !names(dat) %in% c("time", "status")]),
                     label = label[val_ind])

# train surv_xgboost
surv_xgboost_model <- xgb.train.surv(
  params = list(
    objective = "survival:cox",
    eval_metric = "cox-nloglik",
    eta = 0.05 # larger eta leads to algorithm not converging, resulting in NaN predictions
  ), data = x_train, label = x_label,
  watchlist = list(val2 = x_val),
  nrounds = 1000, early_stopping_rounds = 30
)

# predict survival curves
times <- seq(10, 1000, 50)
survival_curves <- predict(object = surv_xgboost_model, newdata = x_train, type = "surv", times = times)
matplot(times, t(survival_curves[1:5, ]), type = "l")
feature_names <- colnames(x_train)
importance_matrix <- xgb.importance(feature_names = feature_names, model = surv_xgboost_model)
print(importance_matrix)
xgb.plot.importance(importance_matrix)
#Features that contribute above-average gain to model
top_features <- importance_matrix$Feature[importance_matrix$Gain >= median(importance_matrix$Gain)]
top_features
#Low impact features
low_impact_features <- importance_matrix$Feature[importance_matrix$Gain < quantile(importance_matrix$Gain, 0.25)]
low_impact_features
